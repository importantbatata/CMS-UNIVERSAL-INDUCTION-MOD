# ECU Lab v1.11.0 and CMS calibration foundation

**Reviewed:** 2026-11-05  
**CMS mod baseline:** 0.8.87  
**Source archive:** `third_party/ecu-lab-1.11.0.zip`  
**SHA-256:** `77BE9F5E108CEFEA1226EA53CA8749DF586C7D4E9D330786055026C79BDB57DE`

## What ECU Lab actually provides

The provided archive identifies itself as ECU Lab `1.11.0`, MIT licensed. Its license requires retaining the copyright and permission notice when redistributing substantial portions. No ECU Lab implementation code has been copied into the CMS plugin.

ECU Lab is a standalone JavaScript/React/Electron engine-management simulator. It has a simulation core and an editable calibration state, but it is not a CMS plugin or a C# library. Its editable base tables use RPM columns `[800, 1500, 2500, 3500, 4500, 5500, 6500, 7500]`, MAP rows `[200, 150, 100, 70, 40, 20]` kPa absolute (descending), VE percent, spark timing degrees, and AFR. Its persistence adapter stores career statistics in a browser/Electron storage backend; it does not define a CMS vehicle/calibration interchange format. ECU Lab's defaults and engine presets belong to its own simulator and are not CMS factory maps.

That means a safe direct integration is not currently available. The archive is being used as a reviewed reference for table concepts and units only. Its axes are not treated as verified CMS axes, and no ECU Lab sample tune is silently applied to a game engine.

## Verified CMS integration points

The existing plugin already has an active `CarLoader` lookup using `PrepareCarPhysics.Get()` and a dyno fallback. It resolves the current installed engine root name through `CurrentEngineIdentifier()` and has per-car identity scoping for induction preferences. Those were implemented for the induction system, not an ECU interface.

The local game-code audit has verified `CarLoader.GetEngine()` and `GetEngineType()` as lookup methods and `BuildCarIdentityKey(loader)` as the mod's stable vehicle-key builder. It has not found a verified player ECU screen, engine-specific ECU table source, calibration writer, or safe game save-data extension for these maps. The existing torque and power Harmony hooks are experimental and depend on a CMS/Unity native ECall that cannot run in an ordinary desktop test process.

## What was implemented in this pass

`src/EcuCalibrationSchema.cs` adds a mod-owned schema version 1 record. It contains vehicle identity, installed-engine identity, hardware fingerprint, RPM and absolute-MAP axes, VE, lambda target, ignition timing, and optional boost curve. Validation rejects unsupported schema versions, missing identities, malformed axes, mismatched table sizes, NaN/infinity, and values outside the declared conservative data bounds. A record can be selected only when the vehicle, installed engine, and hardware fingerprint match exactly (case-insensitive identity comparison).

`src/EcuMapEvaluator.cs` adds a deterministic RPM/absolute-MAP bilinear sampler for VE, lambda, ignition, and optional boost targets. It clamps requests outside the table axes to the edge and rejects non-finite inputs. Eight standalone assertions cover interpolation, clamping, invalid inputs, and naturally aspirated records without a boost map.

This remains a data/evaluator foundation only. It has no factory tune defaults, save writer, ECU UI, automatic live hardware fingerprint builder, or performance application path. It cannot yet change CMS behavior. Exact hardware-signature derivation, calibration persistence, and a verified ECU/game integration point remain prerequisites before records can be authored or applied.

## Current feature status

| Capability | Status | Evidence / limit |
|---|---|---|
| ECU Lab v1.11.0 source and license review | **Complete** | Local archive metadata, README, license, table source, and storage adapter inspected. |
| Active vehicle lookup | **Implemented for induction** | Existing plugin path, not wired to an ECU UI. |
| Installed engine ID lookup | **Implemented for induction context** | Current engine root ID extraction; not complete factory specification discovery. |
| Calibration schema and numerical/identity validation | **Implemented in this pass** | Standalone C# model and 9 assertion harness checks. |
| Calibration map evaluation | **Implemented as an isolated model** | RPM/absolute-MAP bilinear sampler; 8 assertions. Not connected to CMS performance. |
| Automatic ECU interface selection | **Not implemented** | No verified CMS ECU UI hook. |
| Fuel/ignition/boost map editing | **Not implemented** | No verified CMS map application pipeline. |
| Calibration save/load | **Not implemented** | No mod-owned serializer/store wired; existing PlayerPrefs hold induction settings only. |
| ECU Lab tune import/export | **Not implemented** | ECU Lab publishes no CMS interchange format in reviewed source. |
| Power response to player ECU maps | **Not implemented** | Existing induction performance path is not a general ECU map evaluator. |

## Next implementation sequence

1. Identify a real CMS scene or UI that can host tuning controls, then verify its class, method signatures, and lifecycle in local assemblies/call sites.
2. Build a hardware fingerprint from actual installed parts using verified data; keep unknown parts explicit and refuse application when a signature cannot be formed.
3. Add a safe, versioned mod-owned serializer with atomic writes and migration tests. Keep it separate from CMS saves until a supported extension point is verified.
4. Bind the record selector to the current `CarLoader`, current installed engine ID, and actual hardware signature. Switching context must invalidate the previous selection.
5. Implement map editing and performance effects only after the game-side calculation boundary is verified. Unsupported engines should show diagnostics, not inherit another engine's tune.
6. Consider an explicit ECU Lab import/export converter only after defining units, axis ordering, and validation. Converting ECU Lab's descending MAP axis to an ascending internal axis must be deliberate and tested.

## Verification performed

| Check | Result |
|---|---|
| ECU Lab archive version/license/content | **Inspected** — package says 1.11.0 and MIT. |
| ECU Lab code copied into mod | **No** — avoids unnecessary license coupling. |
| Schema assertions | **Passed: 9** — valid record, exact matching, vehicle/engine/hardware mismatch, duplicate RPM, NaN fuel, out-of-range boost, wrong dimensions. |
| CMS plugin compilation | **Passed cleanly** — generated `build/CMS18TurboPrototype.dll` for development version 0.8.88. |
| Offline project validator | **Passed** — source, installed-game signatures, assets, and profile checks; expected warnings say 0.8.88 is not installed and the latest runtime log is from 0.8.87. |
| Live ECU interface / vehicle save-load | **Not run** — no ECU UI or map application exists yet; CMS not launched. |

## Backup and scope

Before these edits, the current source, build script, README, and docs were copied to `backups/pre_ecu_calibration_20261105-150709/`. No game assembly, installed plugin, player save, or third-party ECU Lab source was modified. The project folder is not a Git working tree, so the verified file backup is the rollback point for this pass.

