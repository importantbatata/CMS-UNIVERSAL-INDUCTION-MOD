param(
    [string]$PluginPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'build\CMS18TurboPrototype.dll')
)

$ErrorActionPreference = 'Stop'
$assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $PluginPath).Path)
$modelType = $assembly.GetType('CMS18TurboPrototype.ChargeAirModel', $true)
$flags = [Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$calculate = $modelType.GetMethod('Calculate', $flags)
$stateType = $assembly.GetType('CMS18TurboPrototype.ChargeAirState', $true)

function Assert-Pass([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw "FAIL: $Message" }
    Write-Output "PASS: $Message"
}
function Get-Value($State, [string]$Name) {
    return [single]$stateType.GetField($Name, $flags).GetValue($State)
}

$ambient = [single]298.15
$baseline = $calculate.Invoke($null, [object[]]@([single]0, [single]0.70, [single]0.60, [single]0.55, $ambient, [single]14.6959))
$boosted = $calculate.Invoke($null, [object[]]@([single]10, [single]0.70, [single]0.60, [single]0.55, $ambient, [single]14.6959))
$noCooler = $calculate.Invoke($null, [object[]]@([single]10, [single]0.70, [single]0.0, [single]0.55, $ambient, [single]14.6959))
$noDrop = $calculate.Invoke($null, [object[]]@([single]10, [single]0.70, [single]0.60, [single]0.0, $ambient, [single]14.6959))

Assert-Pass ((Get-Value $baseline 'AirDensityRatio') -eq 1.0 -and (Get-Value $baseline 'ManifoldBoostPsi') -eq 0.0) 'zero boost returns ambient manifold pressure and density'
Assert-Pass ((Get-Value $boosted 'ManifoldBoostPsi') -lt 10.0 -and (Get-Value $boosted 'ManifoldBoostPsi') -gt 9.0) 'intercooler pressure drop lowers manifold gauge boost below compressor outlet target'
Assert-Pass ((Get-Value $boosted 'ManifoldTemperatureKelvin') -lt (Get-Value $noCooler 'ManifoldTemperatureKelvin')) 'positive intercooler effectiveness reduces charge temperature'
Assert-Pass ((Get-Value $noDrop 'AirDensityRatio') -gt (Get-Value $boosted 'AirDensityRatio')) 'pressure drop reduces estimated manifold air density'
Assert-Pass ((Get-Value $boosted 'CompressorOutletTemperatureKelvin') -gt $ambient -and (Get-Value $boosted 'ManifoldTemperatureKelvin') -gt $ambient) 'compression heating remains represented after cooling'

$invalid = $calculate.Invoke($null, [object[]]@([single]::PositiveInfinity, [single]::NaN, [single]::NaN, [single]::NegativeInfinity, [single]::NaN, [single]::NaN))
$finiteFields = @('CompressorOutletTemperatureKelvin','ManifoldTemperatureKelvin','ManifoldAbsolutePressurePsi','ManifoldBoostPsi','AirDensityRatio')
foreach ($field in $finiteFields) {
    $value = Get-Value $invalid $field
    Assert-Pass (-not [single]::IsNaN($value) -and -not [single]::IsInfinity($value)) "invalid inputs produce finite $field"
}
Assert-Pass ((Get-Value $invalid 'AirDensityRatio') -ge 1.0 -and (Get-Value $invalid 'AirDensityRatio') -le 4.0) 'density estimate stays inside the configured stability bounds'
Write-Output 'Charge-air model checks passed against compiled plugin; values remain estimates, not in-game measurements.'
