param(
    [string]$PluginPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'build\CMS18TurboPrototype.dll')
)

$ErrorActionPreference = 'Stop'
$assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $PluginPath).Path)
$modelType = $assembly.GetType('CMS18TurboPrototype.TurboPerformanceModel', $true)
$flags = [Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$sizes = @($modelType.GetMethod('GetSupportedInducerSizes', $flags).Invoke($null, @()))
$getTier = $modelType.GetMethod('GetTier', $flags)
$calculateSpool = $modelType.GetMethod('CalculateSpool', $flags)
$limitAirflow = $modelType.GetMethod('LimitAirDensityRatio', $flags)
$normalizeBoost = $modelType.GetMethod('NormalizeBoostPsi', $flags)

function Assert-Pass([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw "FAIL: $Message" }
    Write-Output "PASS: $Message"
}

Assert-Pass (($sizes -join ',') -eq '35,45,55,62,67,76,88') 'the built model exposes each specified compressor-inducer tier'
$previousFlow = 0.0
foreach ($size in $sizes) {
    $tier = $getTier.Invoke($null, [object[]]@([int]$size))
    $tierType = $tier.GetType()
    $diameter = [int]$tierType.GetField('InducerMm', $flags).GetValue($tier)
    $minimumHp = [int]$tierType.GetField('ApproxMinHorsepower', $flags).GetValue($tier)
    $maximumHp = [int]$tierType.GetField('ApproxMaxHorsepower', $flags).GetValue($tier)
    $flow = [single]$tierType.GetField('EstimatedMaxFlowLbPerMinute', $flags).GetValue($tier)
    $efficiency = [single]$tierType.GetField('AssumedPeakEfficiency', $flags).GetValue($tier)
    Assert-Pass ($diameter -eq $size -and $minimumHp -gt 0 -and $maximumHp -gt $minimumHp -and $flow -gt $previousFlow -and $efficiency -gt 0.0 -and $efficiency -lt 1.0) "$size mm tier has an ordered illustrative HP range, increasing estimated flow, and bounded efficiency"
    $previousFlow = $flow
}
$small = $getTier.Invoke($null, [object[]]@([int]35))
$large = $getTier.Invoke($null, [object[]]@([int]88))
$smallSpool = [single]$calculateSpool.Invoke($null, [object[]]@($small, [single]0.5, [single]1.0))
$largeSpool = [single]$calculateSpool.Invoke($null, [object[]]@($large, [single]0.5, [single]1.0))
$smallLimit = [single]$limitAirflow.Invoke($null, [object[]]@($small, [single]100, [single]3.0))
$largeLimit = [single]$limitAirflow.Invoke($null, [object[]]@($large, [single]100, [single]3.0))
Assert-Pass ($smallSpool -gt $largeSpool -and $smallSpool -le 1.0 -and $largeSpool -ge 0.0) 'the small tier responds sooner at mid-range RPM than the largest tier'
Assert-Pass ($smallLimit -lt $largeLimit -and $smallLimit -le 3.0 -and $largeLimit -le 3.0) 'the modeled flow ceiling increases with size and never exceeds requested pressure ratio'
$nan = [single]::NaN
$positiveInfinity = [single]::PositiveInfinity
$negativeInfinity = [single]::NegativeInfinity
$nanSpool = [single]$calculateSpool.Invoke($null, [object[]]@($small, $nan, [single]1.0))
$infiniteLoadSpool = [single]$calculateSpool.Invoke($null, [object[]]@($small, [single]0.5, $positiveInfinity))
$nanBaseRatio = [single]$limitAirflow.Invoke($null, [object[]]@($small, $nan, [single]2.0))
$infiniteRequestedRatio = [single]$limitAirflow.Invoke($null, [object[]]@($large, [single]100, $positiveInfinity))
$nanBoost = [single]$normalizeBoost.Invoke($null, [object[]]@($nan, [single]32, [single]8))
$infiniteBoost = [single]$normalizeBoost.Invoke($null, [object[]]@($positiveInfinity, [single]32, [single]8))
$negativeInfiniteBoost = [single]$normalizeBoost.Invoke($null, [object[]]@($negativeInfinity, [single]32, [single]8))
Assert-Pass ($nanSpool -eq 0.0 -and $infiniteLoadSpool -ge 0.0 -and $infiniteLoadSpool -le 1.0) 'non-finite RPM fraction and load inputs produce bounded spool values'
Assert-Pass ([single]::IsNaN($nanBaseRatio) -eq $false) 'NaN engine horsepower cannot propagate into the modeled airflow ratio'
Assert-Pass ($infiniteRequestedRatio -eq 1.0) 'invalid requested airflow is reduced to a finite safe ratio'
Assert-Pass ($nanBoost -eq 8.0 -and $infiniteBoost -eq 8.0 -and $negativeInfiniteBoost -eq 8.0) 'invalid boost targets normalize to the configured safe default'
Write-Output 'Turbo size model checks passed against the compiled plugin. Values are design estimates, not measured compressor maps.'
