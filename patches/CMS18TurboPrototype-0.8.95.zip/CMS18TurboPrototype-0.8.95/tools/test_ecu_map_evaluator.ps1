$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$work = Join-Path $env:TEMP ('cms18-ecu-map-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$harness = Join-Path $work 'Harness.cs'
$exe = Join-Path $work 'Harness.exe'
$schema = Join-Path $root 'src\EcuCalibrationSchema.cs'
$evaluator = Join-Path $root 'src\EcuMapEvaluator.cs'
$compat = Join-Path $root 'src\EngineCompatibilityCatalog.cs'
@'
using System;
using CMS18TurboPrototype;
internal static class Harness
{
    private static int checks;
    private static void Check(bool value, string name)
    {
        checks++;
        if (!value) throw new Exception("FAIL: " + name);
        Console.WriteLine("PASS: " + name);
    }
    private static EcuCalibrationRecord Record()
    {
        return new EcuCalibrationRecord {
            VehicleKey="car-a", EngineId="engine_r4", HardwareFingerprint="turbo-a",
            RpmAxis=new int[]{1000,2000}, MapAxisKpaAbsolute=new float[]{50,100},
            VolumetricEfficiencyPercent=new float[]{50,100,150,200},
            LambdaTarget=new float[]{0.8f,1.0f,1.2f,1.4f},
            IgnitionTimingDegrees=new float[]{10,20,30,40},
            BoostTargetPsi=new float[]{0,10}
        };
    }
    public static int Main()
    {
        EcuCalibrationSample sample; string reason;
        Check(EcuMapEvaluator.TrySample(Record(),1500,75,out sample,out reason), "valid grid sample accepted");
        Check(Math.Abs(sample.VolumetricEfficiencyPercent-125.0f)<0.001f, "bilinear VE interpolation");
        Check(Math.Abs(sample.LambdaTarget-1.1f)<0.001f && Math.Abs(sample.IgnitionTimingDegrees-25.0f)<0.001f, "lambda and timing interpolate consistently");
        Check(sample.BoostTargetPsi.HasValue && Math.Abs(sample.BoostTargetPsi.Value-5.0f)<0.001f, "optional boost curve interpolates by RPM");
        Check(EcuMapEvaluator.TrySample(Record(),0,10,out sample,out reason) && Math.Abs(sample.VolumetricEfficiencyPercent-50.0f)<0.001f, "out-of-axis requests clamp to nearest edge");
        Check(!EcuMapEvaluator.TrySample(Record(),Single.NaN,75,out sample,out reason), "non-finite RPM rejected");
        Check(!EcuMapEvaluator.TrySample(Record(),1500,0,out sample,out reason), "non-positive absolute MAP rejected");
        EcuCalibrationRecord noBoost=Record(); noBoost.BoostTargetPsi=null;
        Check(EcuMapEvaluator.TrySample(noBoost,1500,75,out sample,out reason) && !sample.BoostTargetPsi.HasValue, "naturally aspirated calibration has no boost value");
        Console.WriteLine("Assertions: " + checks);
        return 0;
    }
}
'@ | Set-Content -LiteralPath $harness -Encoding UTF8
& $compiler '/nologo' '/target:exe' "/out:$exe" $schema $evaluator $compat $harness
if ($LASTEXITCODE -ne 0) { throw "C# test compilation failed with exit code $LASTEXITCODE" }
& $exe
if ($LASTEXITCODE -ne 0) { throw "ECU map evaluator tests failed with exit code $LASTEXITCODE" }
