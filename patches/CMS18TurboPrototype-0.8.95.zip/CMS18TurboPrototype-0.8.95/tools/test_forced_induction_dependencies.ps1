$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$work = Join-Path $env:TEMP ('cms18-induction-dependencies-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$harness = Join-Path $work 'Harness.cs'
$exe = Join-Path $work 'Harness.exe'
$model = Join-Path $root 'src\ForcedInductionDependencyModel.cs'
@'
using System;
using System.Collections.Generic;
using CMS18TurboPrototype;
internal static class Harness
{
    private static int checks;
    private static void Check(bool value, string name)
    {
        checks++;
        if (!value) throw new Exception("FAIL: " + name);
        Console.WriteLine("PASS: " + name);
    }
    private static List<string> Components()
    {
        return new List<string> { "turbo_manifold", "turbocharger", "downpipe", "air_filter",
            "hot_side_pipe", "intercooler", "cold_side_pipe", "throttle_body", "oil_feed",
            "oil_return", "wastegate", "blow_off_valve", "boost_controller" };
    }
    private static List<ForcedInductionDependencyModel.Connection> Connections()
    {
        return new List<ForcedInductionDependencyModel.Connection> {
            new ForcedInductionDependencyModel.Connection("cylinder_head.exhaust", "turbo_manifold.inlet"),
            new ForcedInductionDependencyModel.Connection("turbo_manifold.outlet", "turbocharger.turbine_inlet"),
            new ForcedInductionDependencyModel.Connection("turbocharger.turbine_outlet", "downpipe.inlet"),
            new ForcedInductionDependencyModel.Connection("downpipe.outlet", "exhaust.inlet"),
            new ForcedInductionDependencyModel.Connection("air_filter.outlet", "turbocharger.compressor_inlet"),
            new ForcedInductionDependencyModel.Connection("turbocharger.compressor_outlet", "hot_side_pipe.inlet"),
            new ForcedInductionDependencyModel.Connection("hot_side_pipe.outlet", "intercooler.inlet"),
            new ForcedInductionDependencyModel.Connection("intercooler.outlet", "cold_side_pipe.inlet"),
            new ForcedInductionDependencyModel.Connection("cold_side_pipe.outlet", "throttle_body.inlet"),
            new ForcedInductionDependencyModel.Connection("oil_source.pressurized", "turbocharger.oil_feed"),
            new ForcedInductionDependencyModel.Connection("turbocharger.oil_drain", "crankcase.oil_return"),
            new ForcedInductionDependencyModel.Connection("wastegate.exhaust_inlet", "turbo_manifold.wastegate_port"),
            new ForcedInductionDependencyModel.Connection("wastegate.actuator", "boost_controller.output"),
            new ForcedInductionDependencyModel.Connection("blow_off_valve.charge_pipe_port", "cold_side_pipe.bov_port"),
            new ForcedInductionDependencyModel.Connection("blow_off_valve.pressure_reference", "intake_manifold.reference")
        };
    }
    public static int Main()
    {
        var empty = ForcedInductionDependencyModel.ValidateSingleTurbo(null, null);
        Check(!empty.IsComplete && empty.MissingComponents.Length == 13 && empty.MissingConnections.Length == 15,
            "empty build reports each required component and connection");

        var components = Components(); var connections = Connections();
        Check(ForcedInductionDependencyModel.ValidateSingleTurbo(components, connections).IsComplete,
            "complete single-turbo dependency graph is accepted");

        components.Remove("oil_return");
        var missingReturn = ForcedInductionDependencyModel.ValidateSingleTurbo(components, connections);
        Check(!missingReturn.IsComplete && Array.IndexOf(missingReturn.MissingComponents, "oil_return") >= 0,
            "missing oil-return component prevents activation");
        components.Add("oil_return");

        connections.RemoveAt(10);
        var disconnectedReturn = ForcedInductionDependencyModel.ValidateSingleTurbo(components, connections);
        Check(!disconnectedReturn.IsComplete && disconnectedReturn.MissingConnections.Length == 1
            && disconnectedReturn.MissingConnections[0].Contains("crankcase.oil_return"),
            "disconnected oil-return route prevents activation");

        connections.Add(new ForcedInductionDependencyModel.Connection("turbocharger.oil_drain", "crankcase.oil_return"));
        connections.Add(new ForcedInductionDependencyModel.Connection("turbocharger.oil_drain", "crankcase.oil_return"));
        Check(ForcedInductionDependencyModel.ValidateSingleTurbo(components, connections).IsComplete,
            "duplicate valid connections do not break validation");

        Console.WriteLine("Assertions: " + checks + "; standalone dependency model only, no CMS installation integration claimed.");
        return 0;
    }
}
'@ | Set-Content -LiteralPath $harness -Encoding UTF8
& $compiler '/nologo' '/target:exe' "/out:$exe" $model $harness
if ($LASTEXITCODE -ne 0) { throw "Dependency model test compilation failed: $LASTEXITCODE" }
& $exe
if ($LASTEXITCODE -ne 0) { throw "Dependency model tests failed: $LASTEXITCODE" }
