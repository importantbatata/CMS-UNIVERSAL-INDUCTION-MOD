param(
    [string]$AssemblyPath = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018\cms2018_Data\Managed\Assembly-CSharp-firstpass.dll',
    [string]$CecilPath = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018\BepInEx\core\Mono.Cecil.dll',
    [string]$OutputPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'build\engine-lifecycle-firstpass-IL.txt')
)

$ErrorActionPreference = 'Stop'
foreach ($path in @($AssemblyPath, $CecilPath)) {
    if (-not (Test-Path -LiteralPath $path)) { throw "Required assembly not found: $path" }
}

$localCecilPath = Join-Path $env:TEMP 'CMS18-engine-lifecycle-Mono.Cecil.dll'
Copy-Item -LiteralPath $CecilPath -Destination $localCecilPath -Force
Unblock-File -LiteralPath $localCecilPath
Add-Type -Path $localCecilPath

$module = [Mono.Cecil.ModuleDefinition]::ReadModule($AssemblyPath)
$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add("Assembly: $AssemblyPath")
$lines.Add("SHA-256: $((Get-FileHash -Algorithm SHA256 -LiteralPath $AssemblyPath).Hash)")
$lines.Add("MVID: $($module.Mvid)")
$lines.Add('')

function Get-TypeTree($type) {
    $type
    foreach ($nested in $type.NestedTypes) { Get-TypeTree $nested }
}

function Write-Method($method) {
    $signature = ($method.Parameters | ForEach-Object { $_.ParameterType.FullName }) -join ', '
    $lines.Add("  METHOD $($method.ReturnType.FullName) $($method.Name)($signature)")
    if (-not $method.HasBody) { return }
    foreach ($instruction in $method.Body.Instructions) {
        $operand = if ($null -eq $instruction.Operand) { '' } else { ' ' + $instruction.Operand.ToString() }
        $lines.Add(('    {0,-12}{1}{2}' -f $instruction.Offset.ToString('X4'), $instruction.OpCode.Name, $operand))
    }
}

$typeNames = @('MountObject', 'PartScript', 'InteractiveObject', 'GameScript', 'GameManager', 'CarLoader', 'NewGroupItem')
$methodNames = @{
    MountObject = @('SetFullUnmountPosition', 'SetFullMountPosition', 'CalcUnmountPos', 'PrepareToMount', 'SetPosition')
    PartScript = @('GetNextMountObject', 'HidePreview', 'ShowPreviewToMount', 'ActionUnMount', 'ActionMount', 'DoMount', 'FastUnmount', 'FastMount', 'GetIDWithTuned', 'IsUnmounted')
    InteractiveObject = @('CanMountGroup', 'GetPart', 'Update')
    GameScript = @('GetObjectsOnEngineStand', 'SetObjectsOnEngineStand', 'SetGroupOnEngineStand', 'SetEngineOnEngineStand', 'SelectToMount', 'SelectToUnMount', 'PrepareItemsToMount', 'PrepareItemToMount', 'PrepareAllItemsToMount', 'HideAllUnMounted', 'ShowAllUnMounted')
    GameManager = @('ActionInsertEngineToCar', 'MountGroup', 'ActionMountGroup', 'ActionUnMountGroup')
    CarLoader = @('GetEngine', 'GetEngineType', 'GetSaveName', 'GetRoot', 'CreateEngine', 'SetEngine', 'SwapEngine', 'RedoneEnginePartScriptBlocks', 'IsPartUnmounted')
    NewGroupItem = @()
}
$fieldPattern = 'mount|engine|part|unmount|preview|group|item|id|tuned|collider|hide|save|car|name|loader'
$types = @($module.Types | ForEach-Object { Get-TypeTree $_ })
foreach ($name in $typeNames) {
    $type = $types | Where-Object { $_.Name -eq $name } | Select-Object -First 1
    if ($null -eq $type) { continue }
    $lines.Add("TYPE $($type.FullName)")
    foreach ($field in $type.Fields) {
        if ($field.Name -match $fieldPattern) { $lines.Add("  FIELD $($field.FieldType.FullName) $($field.Name)") }
    }
    foreach ($method in $type.Methods) {
        if ($method.Name -in $methodNames[$name]) { Write-Method $method }
    }
    $lines.Add('')
}

$directory = Split-Path -Parent $OutputPath
if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
[System.IO.File]::WriteAllLines($OutputPath, $lines, [System.Text.UTF8Encoding]::new($false))
if ($module -is [System.IDisposable]) { $module.Dispose() }
Write-Output "Wrote $($lines.Count) lines to $OutputPath"
