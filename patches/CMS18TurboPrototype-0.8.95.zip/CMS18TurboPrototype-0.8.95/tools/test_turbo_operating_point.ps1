param(
    [string]$PluginPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'build\CMS18TurboPrototype.dll')
)

$ErrorActionPreference = 'Stop'
$assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $PluginPath).Path)
$flags = [Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$modelType = $assembly.GetType('CMS18TurboPrototype.TurboOperatingPointModel', $true)
$tierType = $assembly.GetType('CMS18TurboPrototype.TurboPerformanceModel', $true)
$calculate = $modelType.GetMethod('Calculate', $flags)
$getTier = $tierType.GetMethod('GetTier', $flags)
$stateType = $assembly.GetType('CMS18TurboPrototype.TurboOperatingPoint', $true)

function Assert-Pass([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw "FAIL: $Message" }
    Write-Output "PASS: $Message"
}
function Get-Field($State, [string]$Name) {
    return $stateType.GetField($Name, $flags).GetValue($State)
}
function Get-ChargeField($State, [string]$Name) {
    $charge = Get-Field $State 'ChargeAir'
    return $charge.GetType().GetField($Name, $flags).GetValue($charge)
}

$streetTier = $getTier.Invoke($null, [object[]]@([int]55))
$smallTier = $getTier.Invoke($null, [object[]]@([int]35))
$largeTier = $getTier.Invoke($null, [object[]]@([int]88))
$street = $calculate.Invoke($null, [object[]]@($streetTier, [single]20, [single]1, [single]150, [single]298.15, [single]14.6959))
$small = $calculate.Invoke($null, [object[]]@($smallTier, [single]20, [single]1, [single]150, [single]298.15, [single]14.6959))
$large = $calculate.Invoke($null, [object[]]@($largeTier, [single]20, [single]1, [single]150, [single]298.15, [single]14.6959))
$spooled = $calculate.Invoke($null, [object[]]@($streetTier, [single]20, [single]0.5, [single]150, [single]298.15, [single]14.6959))
$unspooled = $calculate.Invoke($null, [object[]]@($streetTier, [single]20, [single]0, [single]150, [single]298.15, [single]14.6959))
$invalid = $calculate.Invoke($null, [object[]]@($streetTier, [single]::PositiveInfinity, [single]::NaN, [single]::NaN, [single]::NaN, [single]::NaN))

Assert-Pass ((Get-Field $small 'CompressorBoostPsi') -le (Get-Field $street 'CompressorBoostPsi') -and (Get-Field $street 'CompressorBoostPsi') -le (Get-Field $large 'CompressorBoostPsi')) 'larger flow tier does not deliver less boost at equal RPM/load and baseline power'
Assert-Pass ((Get-Field $small 'FlowUtilization') -le 1.01 -and (Get-Field $street 'FlowUtilization') -le 1.01 -and (Get-Field $large 'FlowUtilization') -le 1.01) 'delivered charge remains within the selected tier flow estimate'
Assert-Pass ((Get-Field $unspooled 'CompressorBoostPsi') -eq 0 -and (Get-ChargeField $unspooled 'ManifoldBoostPsi') -eq 0) 'zero spool yields ambient manifold conditions'
Assert-Pass ((Get-Field $spooled 'CompressorBoostPsi') -gt (Get-Field $unspooled 'CompressorBoostPsi') -and (Get-Field $spooled 'CompressorBoostPsi') -le (Get-Field $street 'CompressorBoostPsi')) 'spool fraction scales delivered boost monotonically'
Assert-Pass ((Get-Field $street 'CompressorEfficiency') -gt 0.39 -and (Get-Field $street 'CompressorEfficiency') -le 0.70) 'estimated efficiency remains finite and below the tier peak'
Assert-Pass ((Get-ChargeField $street 'ManifoldBoostPsi') -le (Get-Field $street 'CompressorBoostPsi')) 'estimated intercooler pressure loss keeps manifold boost below compressor outlet boost'

foreach ($field in @('CompressorBoostPsi','CompressorEfficiency','FlowUtilization','Spool')) {
    $value = [single](Get-Field $invalid $field)
    Assert-Pass (-not [single]::IsNaN($value) -and -not [single]::IsInfinity($value)) "invalid input produces finite $field"
}
Assert-Pass ((Get-Field $invalid 'CompressorBoostPsi') -ge 0 -and (Get-Field $invalid 'CompressorBoostPsi') -le 32) 'invalid boost inputs remain within the model stability bound'
Write-Output 'Turbo operating point checks passed. Model values remain estimates, not measured compressor-map results.'
