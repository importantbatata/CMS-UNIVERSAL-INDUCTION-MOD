$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$work = Join-Path $env:TEMP ('cms18-engine-identity-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$harness = Join-Path $work 'Harness.cs'
$exe = Join-Path $work 'Harness.exe'
@'
using System;
using CMS18TurboPrototype;
internal static class Harness
{
    private static int checks;
    private static void Check(bool value, string name)
    {
        checks++;
        if (!value) throw new Exception("FAIL: " + name);
        Console.WriteLine("PASS: " + name);
    }
    public static int Main()
    {
        EngineIdentityProfile profile;
        Check(EngineIdentityCatalog.TryGet("engine_r4(Clone)", out profile), "normalizes a live cloned engine root ID");
        Check(profile.DisplayName == "I4 DOHC AQC" && profile.CylinderCount == 4
            && profile.SandboxConfiguration == "I4", "maps verified base I4 identity to sandbox layout");
        Check(EngineIdentityCatalog.TryGet("engine_r6_dohc_wzdluzny", out profile)
            && profile.DisplayName == "I6 DOHC" && profile.SandboxConfiguration == "I6",
            "automatically recognizes the in-game I6 DOHC engine");
        Check(EngineIdentityCatalog.TryGet("engine_v8_stary_2carb", out profile)
            && profile.IsCarburetedLabel && profile.CylinderCount == 8,
            "retains carbureted metadata without claiming kit compatibility");
        Check(EngineIdentityCatalog.TryGet("engine_w12", out profile)
            && profile.CylinderCount == 12 && profile.SandboxConfiguration == String.Empty,
            "recognizes W12 identity but does not map it to an unsupported sandbox model");
        Check(!EngineIdentityCatalog.TryGet("engine_not_in_local_car_configs", out profile),
            "rejects IDs absent from the verified local car config catalog");
        Check(EngineIdentityCatalog.TryGet("engine_r4_turbo", out profile)
            && profile.HasFactoryInductionLabel && profile.DisplayName == "I4 DOHC Turbocharged",
            "identifies a native turbo variant separately from the naturally aspirated base ID");
        Console.WriteLine("PASS: " + checks + " engine identity checks");
        return 0;
    }
}
'@ | Set-Content -LiteralPath $harness -Encoding UTF8
& $compiler /nologo /target:exe "/out:$exe" $root\src\EngineCompatibilityCatalog.cs $root\src\EngineIdentityCatalog.cs $harness
if ($LASTEXITCODE -ne 0) { throw 'Engine identity catalog harness compilation failed.' }
& $exe
if ($LASTEXITCODE -ne 0) { throw "Engine identity tests failed with exit code $LASTEXITCODE" }
