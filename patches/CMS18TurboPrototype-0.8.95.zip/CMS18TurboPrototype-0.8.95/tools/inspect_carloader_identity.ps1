param(
    [string]$AssemblyPath = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018\cms2018_Data\Managed\Assembly-CSharp-firstpass.dll',
    [string]$CecilPath = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018\BepInEx\core\Mono.Cecil.dll',
    [string]$OutputPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'docs\carloader-identity-IL.txt')
)

$ErrorActionPreference = 'Stop'
foreach ($path in @($AssemblyPath, $CecilPath)) {
    if (-not (Test-Path -LiteralPath $path)) { throw "Required assembly not found: $path" }
}

$localCecilPath = Join-Path $env:TEMP 'CMS18-carloader-identity-Mono.Cecil.dll'
Copy-Item -LiteralPath $CecilPath -Destination $localCecilPath -Force
Unblock-File -LiteralPath $localCecilPath
Add-Type -Path $localCecilPath

$module = [Mono.Cecil.ModuleDefinition]::ReadModule($AssemblyPath)
$types = @($module.Types | ForEach-Object { Get-TypeTree $_ })
$type = $types | Where-Object { $_.Name -eq 'CarLoader' } | Select-Object -First 1
if ($null -eq $type) { throw 'CarLoader type was not found.' }

$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add("Assembly: $AssemblyPath")
$lines.Add("SHA-256: $((Get-FileHash -Algorithm SHA256 -LiteralPath $AssemblyPath).Hash)")
$lines.Add("MVID: $($module.Mvid)")
$lines.Add("TYPE $($type.FullName)")
$lines.Add('FIELDS')
foreach ($field in $type.Fields) { $lines.Add("  $($field.FieldType.FullName) $($field.Name)") }
$lines.Add('METHODS')
foreach ($method in $type.Methods) {
    $signature = ($method.Parameters | ForEach-Object { $_.ParameterType.FullName }) -join ', '
    $lines.Add("  $($method.ReturnType.FullName) $($method.Name)($signature)")
}
$relatedTypes = @($types | Where-Object {
    $_.Name -eq 'NewCarData' -or
    ($_.DeclaringType -eq $type -and $_.Name -match 'LoadCarFromFile|LoadCar.*Iterator')
})
foreach ($relatedType in $relatedTypes) {
    $lines.Add("TYPE $($relatedType.FullName)")
    foreach ($field in $relatedType.Fields) {
        if ($field.Name -match 'carToLoad|factoryLicensePlate|licensePlate|place|file|name|customer') {
            $lines.Add("  FIELD $($field.FieldType.FullName) $($field.Name)")
        }
    }
}
$lines.Add('IDENTITY AND LOAD IL')
foreach ($method in @($type.Methods) + @($relatedTypes | ForEach-Object { $_.Methods })) {
    if (-not $method.HasBody) { continue }
    $relevant = $method.Name -match 'SaveName|Load|Save|Deserialize|Serialize|Prepare|Create|Start|Awake|SetRoot|GetRoot|LicensePlate|SetCustomerCar' -or
        @($method.Body.Instructions | Where-Object {
            $_.Operand -is [Mono.Cecil.FieldReference] -and
            $_.Operand.Name -match 'carToLoad|root|e_type|Save|carParts|carFrom|factoryLicensePlate|licensePlate|place|customerCar'
        }).Count -gt 0
    if (-not $relevant) { continue }
    $signature = ($method.Parameters | ForEach-Object { $_.ParameterType.FullName }) -join ', '
    $lines.Add("METHOD $($method.ReturnType.FullName) $($method.Name)($signature)")
    foreach ($instruction in $method.Body.Instructions) {
        $operand = if ($null -eq $instruction.Operand) { '' } else { ' ' + $instruction.Operand.ToString() }
        $lines.Add(('  {0,-12}{1}{2}' -f $instruction.Offset.ToString('X4'), $instruction.OpCode.Name, $operand))
    }
    $lines.Add('')
}

$directory = Split-Path -Parent $OutputPath
if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
[System.IO.File]::WriteAllLines($OutputPath, $lines, [System.Text.UTF8Encoding]::new($false))
if ($module -is [System.IDisposable]) { $module.Dispose() }
Write-Output "Wrote $($lines.Count) lines to $OutputPath"
