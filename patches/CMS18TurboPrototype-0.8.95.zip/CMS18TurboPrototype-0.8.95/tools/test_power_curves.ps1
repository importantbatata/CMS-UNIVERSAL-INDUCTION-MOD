param(
    [string]$GameRoot = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018',
    [string]$PluginPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'build\CMS18TurboPrototype.dll')
)

$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSEdition -eq 'Core') {
    $windowsPowerShell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $windowsPowerShell)) {
        throw 'This suite includes a CMS BinaryFormatter round-trip and requires Windows PowerShell/.NET Framework. Windows PowerShell was not found.'
    }
    $frameworkArguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath, '-GameRoot', $GameRoot, '-PluginPath', $PluginPath)
    & $windowsPowerShell @frameworkArguments
    exit $LASTEXITCODE
}
$managed = Join-Path $GameRoot 'cms2018_Data\Managed'
$core = Join-Path $GameRoot 'BepInEx\core'
$testAssemblyCache = Join-Path $env:TEMP 'CMS18TurboPrototype-testassemblies'
New-Item -ItemType Directory -Path $testAssemblyCache -Force | Out-Null
$assemblies = @(
    (Join-Path $managed 'UnityEngine.dll'),
    (Join-Path $managed 'UnityEngine.CoreModule.dll'),
    (Join-Path $managed 'UnityEngine.TextRenderingModule.dll'),
    (Join-Path $managed 'UnityEngine.IMGUIModule.dll'),
    (Join-Path $core 'BepInEx.dll'),
    (Join-Path $core 'Mono.Cecil.dll'),
    (Join-Path $core 'MonoMod.Utils.dll'),
    (Join-Path $core 'MonoMod.RuntimeDetour.dll'),
    (Join-Path $core 'HarmonyXInterop.dll'),
    (Join-Path $core '0Harmony.dll'),
    (Join-Path $managed 'Assembly-CSharp-firstpass.dll'),
    $PluginPath
)
foreach ($assemblyPath in $assemblies) {
    if (-not (Test-Path -LiteralPath $assemblyPath)) { throw "Required assembly not found: $assemblyPath" }
    $loadPath = $assemblyPath
    if ($assemblyPath.StartsWith($managed, [StringComparison]::OrdinalIgnoreCase) -or
        $assemblyPath.StartsWith($core, [StringComparison]::OrdinalIgnoreCase)) {
        $loadPath = Join-Path $testAssemblyCache (Split-Path -Leaf $assemblyPath)
        Copy-Item -LiteralPath $assemblyPath -Destination $loadPath -Force
        Unblock-File -LiteralPath $loadPath
    }
    [Reflection.Assembly]::LoadFrom($loadPath) | Out-Null
}

$pluginAssembly = [AppDomain]::CurrentDomain.GetAssemblies() |
    Where-Object { $_.Location -eq $PluginPath } | Select-Object -First 1
if ($null -eq $pluginAssembly) { throw 'Could not load the compiled prototype DLL.' }

$pluginType = $pluginAssembly.GetType('CMS18TurboPrototype.TurboPrototypePlugin', $true)
$modeType = $pluginAssembly.GetType('CMS18TurboPrototype.InductionMode', $true)
$gameAssembly = [AppDomain]::CurrentDomain.GetAssemblies() |
    Where-Object { $_.GetName().Name -eq 'Assembly-CSharp-firstpass' } | Select-Object -First 1
$settingsType = $gameAssembly.GetType('VehiclePhysics.Engine+Settings', $true)
$flags = [Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$spoolMethod = $pluginType.GetMethod('CalculateSpoolForSample', $flags)
if ($null -eq $spoolMethod -or -not $spoolMethod.IsStatic) { throw 'Compiled spool calculation method was not found.' }

$settings = [Activator]::CreateInstance($settingsType)
$settingsType.GetField('idleRpm', $flags).SetValue($settings, [single]800)
$settingsType.GetField('peakRpm', $flags).SetValue($settings, [single]5500)

function Invoke-Spool([int]$Mode, [single]$Rpm, [single]$Throttle) {
    $enumValue = [Enum]::ToObject($script:modeType, $Mode)
    return [single]$script:spoolMethod.Invoke($null, [object[]]@($enumValue, $script:settings, $Rpm, $Throttle))
}

$passed = 0
function Assert-Pass([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw "FAIL: $Message" }
    Write-Output "PASS: $Message"
    $script:passed++
}

$turboModelType = $pluginAssembly.GetType('CMS18TurboPrototype.TurboPerformanceModel', $true)
$tierType = $pluginAssembly.GetType('CMS18TurboPrototype.TurboPerformanceTier', $true)
$tierSizesMethod = $turboModelType.GetMethod('GetSupportedInducerSizes', $flags)
$getTierMethod = $turboModelType.GetMethod('GetTier', $flags)
$tierSpoolMethod = $turboModelType.GetMethod('CalculateSpool', $flags)
$flowLimitMethod = $turboModelType.GetMethod('LimitAirDensityRatio', $flags)
if ($null -eq $tierSizesMethod -or $null -eq $getTierMethod -or $null -eq $tierSpoolMethod -or $null -eq $flowLimitMethod) {
    throw 'The selectable turbo performance model is incomplete.'
}
$tierSizes = @($tierSizesMethod.Invoke($null, @()))
$tier35 = $getTierMethod.Invoke($null, [object[]]@([int]35))
$tier88 = $getTierMethod.Invoke($null, [object[]]@([int]88))
$spool35 = [single]$tierSpoolMethod.Invoke($null, [object[]]@($tier35, [single]0.5, [single]1.0))
$spool88 = [single]$tierSpoolMethod.Invoke($null, [object[]]@($tier88, [single]0.5, [single]1.0))
$flow35 = [single]$flowLimitMethod.Invoke($null, [object[]]@($tier35, [single]100, [single]3.0))
$flow88 = [single]$flowLimitMethod.Invoke($null, [object[]]@($tier88, [single]100, [single]3.0))
Assert-Pass (($tierSizes -join ',') -eq '35,45,55,62,67,76,88') 'turbo model exposes all seven specified compressor-inducer tiers'
Assert-Pass ($spool35 -gt $spool88 -and $spool35 -le 1.0 -and $spool88 -ge 0.0) 'small turbo tier reaches useful spool earlier than the 88 mm tier'
Assert-Pass ($flow35 -lt $flow88 -and $flow35 -le 3.0 -and $flow88 -le 3.0) 'smaller turbo tier receives a lower estimated airflow ceiling without exceeding requested pressure ratio'

$off = Invoke-Spool 0 5500 1
$turboIdle = Invoke-Spool 1 800 1
$turboMid = Invoke-Spool 1 3500 1
$turboPeak = Invoke-Spool 1 5500 1
$turboNoLoad = Invoke-Spool 1 5500 0
$superIdle = Invoke-Spool 2 800 1
$superPeak = Invoke-Spool 2 5500 1
$proIdle = Invoke-Spool 3 800 1
$proMid = Invoke-Spool 3 3500 1
$proPeak = Invoke-Spool 3 5500 1
$partClassifier = $pluginType.GetMethod('ClassifyNativePartId', $flags)
if ($null -eq $partClassifier -or -not $partClassifier.IsStatic) { throw 'Native induction part classifier was not found.' }

Assert-Pass ($off -eq 0.0) 'Off mode produces zero spool'
Assert-Pass ($turboIdle -eq 0.0 -and $turboMid -gt $turboIdle -and $turboPeak -gt $turboMid -and $turboPeak -le 1.0) 'Turbo spool rises with RPM through its lag range'
Assert-Pass ($turboNoLoad -eq 0.0) 'Turbo spool falls to zero without throttle load'
Assert-Pass ($superIdle -gt 0.0 -and $superPeak -eq 1.0) 'Supercharger has immediate low-RPM response and reaches full spool'
Assert-Pass ($proIdle -gt 0.0 -and $proMid -gt $proIdle -and $proPeak -gt $proMid -and $proPeak -le 1.0) 'ProCharger rotor speed follows engine RPM and its centrifugal boost rises quadratically'
$p1xBoostMethod = $pluginType.GetMethod('CalculateP1XBoostPsi', $flags)
$p1xImpellerMethod = $pluginType.GetMethod('CalculateP1XImpellerRpm', $flags)
$manifoldGaugeMethod = $pluginType.GetMethod('CalculateManifoldGaugePsi', $flags)
if ($null -eq $p1xBoostMethod -or -not $p1xBoostMethod.IsStatic -or $null -eq $p1xImpellerMethod -or -not $p1xImpellerMethod.IsStatic -or $null -eq $manifoldGaugeMethod -or -not $manifoldGaugeMethod.IsStatic) { throw 'P-1X speed, boost or manifold pressure model was not found.' }
$p1xBoostAtPeak = [single]$p1xBoostMethod.Invoke($null, [object[]]@($settings, [single]5500, [single]8))
$p1xBoostAtHalfPeak = [single]$p1xBoostMethod.Invoke($null, [object[]]@($settings, [single]2750, [single]8))
$p1xBoostAtSpeedLimit = [single]$p1xBoostMethod.Invoke($null, [object[]]@($settings, [single]6500, [single]32))
$p1xImpellerAtPeak = [single]$p1xImpellerMethod.Invoke($null, [object[]]@($settings, [single]5500, [single]8))
$p1xImpellerAtHalfPeak = [single]$p1xImpellerMethod.Invoke($null, [object[]]@($settings, [single]2750, [single]8))
$wotManifoldGauge = [single]$manifoldGaugeMethod.Invoke($null, [object[]]@([single]8, [single]1))
$closedThrottleGauge = [single]$manifoldGaugeMethod.Invoke($null, [object[]]@([single]8, [single]0))
Assert-Pass ([Math]::Abs($p1xBoostAtPeak - 8.0) -lt 0.01 -and [Math]::Abs(($p1xBoostAtHalfPeak / $p1xBoostAtPeak) - 0.25) -lt 0.01 -and $p1xBoostAtSpeedLimit -le 32.0) 'P-1X pressure follows centrifugal speed-squared behavior and published 32 psi / 65,000 rpm limits'
Assert-Pass ([Math]::Abs($p1xImpellerAtPeak - 32500.0) -lt 1.0 -and [Math]::Abs($p1xImpellerAtHalfPeak - 16250.0) -lt 1.0) 'P-1X impeller tach reads the 4.10:1 drive model against the 65,000 rpm rating'
Assert-Pass ([Math]::Abs($wotManifoldGauge - 8.0) -lt 0.01 -and $closedThrottleGauge -lt -9.5 -and [Math]::Abs(([Math]::Abs($closedThrottleGauge) * 2.03602) - 20.0) -lt 0.1) 'manifold gauge reports boost at wide-open throttle and realistic vacuum at closed throttle'
$boostLimitMethod = $pluginType.GetMethod('GetMaximumBoostPsi', $flags)
$p1xTorqueClampMethod = $pluginType.GetMethod('ClampP1XTorqueDelta', $flags)
if ($null -eq $boostLimitMethod -or -not $boostLimitMethod.IsStatic -or $null -eq $p1xTorqueClampMethod -or -not $p1xTorqueClampMethod.IsStatic) { throw 'P-1X boost-tier or rated-power limit helper was not found.' }
$streetP1XLimit = [single]$boostLimitMethod.Invoke($null, [object[]]@([Enum]::ToObject($modeType, 3), [bool]$false))
$highBoostP1XLimit = [single]$boostLimitMethod.Invoke($null, [object[]]@([Enum]::ToObject($modeType, 3), [bool]$true))
$clampedP1XDelta = [single]$p1xTorqueClampMethod.Invoke($null, [object[]]@([single]350, [single]1000, [single]5500))
$clampedP1XHp = (350.0 + $clampedP1XDelta) * 5500.0 / 7127.0
Assert-Pass ($streetP1XLimit -eq 20.0 -and $highBoostP1XLimit -eq 32.0) 'street and high-boost P-1X kits expose 20 and 32 psi ceilings'
Assert-Pass ([Math]::Abs($clampedP1XHp - 950.0) -lt 0.02) 'P-1X torque gain cannot exceed its 950 hp component rating'

$customProchargerId = 'cms18_procharger_p1x'
$customProchargerHighBoostId = 'cms18_procharger_p1x_highboost'
$customTurboKitId = 'cms18_turbo_kit'
$customSuperchargerKitId = 'cms18_supercharger_kit'
$universalMountId = 'cms18_universal_induction_mount'
$universalMountVariantId = $universalMountId + '(0)'
$localizationSource = Get-Content -LiteralPath (Join-Path (Split-Path -Parent $PSScriptRoot) 'src\CMS18TurboPrototype.cs') -Raw
Assert-Pass ($localizationSource.Contains('Patch(typeof(Localization), "Get"') -and $localizationSource.Contains('CMS18 ProCharger Mount Bracket') -and $localizationSource.Contains('ProCharger P-1X Centrifugal Supercharger')) 'Synthetic engine mount and P-1X item receive readable names in part-selection localization'
$customProchargerMode = [int]$partClassifier.Invoke($null, [object[]]@($customProchargerId))
$customHighBoostMode = [int]$partClassifier.Invoke($null, [object[]]@($customProchargerHighBoostId))
Assert-Pass ($customProchargerMode -eq 3) 'Custom ProCharger shop part is classified as Procharger'
Assert-Pass ($customHighBoostMode -eq 3) 'High-boost P-1X shop part uses the same ProCharger model and power path'
$tuneIdNormalizer = $pluginType.GetMethod('NormalizeProchargerTuneId', $flags)
if ($null -eq $tuneIdNormalizer -or -not $tuneIdNormalizer.IsStatic) { throw 'ProCharger tune ID normalizer was not found.' }
$customProchargerVariantId = $customProchargerId + '(0)'
$customVariantMode = [int]$partClassifier.Invoke($null, [object[]]@($customProchargerVariantId))
$invalidCustomVariantMode = [int]$partClassifier.Invoke($null, [object[]]@($customProchargerId + '(x)'))
$emptyPartIdMode = [int]$partClassifier.Invoke($null, [object[]]@(''))
$whitespacePartIdMode = [int]$partClassifier.Invoke($null, [object[]]@('   '))
$normalizedCustomTuneId = [string]$tuneIdNormalizer.Invoke($null, [object[]]@($customProchargerId))
$normalizedVariantTuneId = [string]$tuneIdNormalizer.Invoke($null, [object[]]@($customProchargerVariantId))
$normalizedStockTuneId = [string]$tuneIdNormalizer.Invoke($null, [object[]]@('turbo_2'))
Assert-Pass ($customVariantMode -eq 3) 'Numeric engine-slot suffix on custom ProCharger IDs is recognized'
Assert-Pass ($invalidCustomVariantMode -eq 0) 'Non-numeric custom ID suffix is rejected'
Assert-Pass ($emptyPartIdMode -eq 0 -and $whitespacePartIdMode -eq 0) 'Empty and whitespace part IDs are safely rejected by the Mono-compatible classifier'
Assert-Pass ($normalizedCustomTuneId -eq 'turbo_2' -and $normalizedVariantTuneId -eq 'turbo_2') 'Bare and suffixed ProCharger tuning IDs resolve through the stock turbo prefab ID'
Assert-Pass ($normalizedStockTuneId -eq 'turbo_2') 'Stock turbo tuning IDs pass through unchanged'
$customPartClassifier = $pluginType.GetMethod('ModeForInductionPartId', $flags)
$customTurboMode = [int]$customPartClassifier.Invoke($null, [object[]]@($customTurboKitId + '(0)'))
$customSuperchargerMode = [int]$customPartClassifier.Invoke($null, [object[]]@($customSuperchargerKitId + '(0)'))
$universalMountCheck = $pluginType.GetMethod('IsUniversalMountId', $flags)
$isUniversalMount = [bool]$universalMountCheck.Invoke($null, [object[]]@($universalMountVariantId))
 $isUniversalMountPrefixed = [bool]$universalMountCheck.Invoke($null, [object[]]@('!' + $universalMountId))
Assert-Pass ($customTurboMode -eq 1 -and $customSuperchargerMode -eq 2 -and $isUniversalMount -and $isUniversalMountPrefixed) 'Turbo, supercharger and ProCharger kits have valid universal engine-slot IDs'
$slotCompatibility = $pluginType.GetMethod('IsProchargerCompatibleSlot', $flags)
if ($null -eq $slotCompatibility -or -not $slotCompatibility.IsStatic) { throw 'ProCharger slot compatibility method was not found.' }
$prochargerFitsTurboExhaustSlot = [bool]$slotCompatibility.Invoke($null, [object[]]@($customProchargerVariantId, 'turbo_2(0)'))
$customFitsOtherSlot = [bool]$slotCompatibility.Invoke($null, [object[]]@($customProchargerId, 'supercharger_1'))
$customTurboFitsR4Slot = [bool]$slotCompatibility.Invoke($null, [object[]]@($customTurboKitId, 'w_r4_turbo_poczatkowy(0)'))
$customSuperFitsNativeSupercharger = [bool]$slotCompatibility.Invoke($null, [object[]]@($customSuperchargerKitId, 'v8_supercharger(0)'))
$customTurboFitsUniversalSlot = [bool]$slotCompatibility.Invoke($null, [object[]]@($customTurboKitId, $universalMountVariantId))
$customSuperFitsUniversalSlot = [bool]$slotCompatibility.Invoke($null, [object[]]@($customSuperchargerKitId, $universalMountVariantId))
$customP1XFitsUniversalSlot = [bool]$slotCompatibility.Invoke($null, [object[]]@($customProchargerId, $universalMountVariantId))
 $mountDoesNotReplaceItself = [bool]$slotCompatibility.Invoke($null, [object[]]@($universalMountVariantId, $universalMountVariantId))
 $mountDoesNotReplaceKits = [bool]$slotCompatibility.Invoke($null, [object[]]@($universalMountVariantId, $customProchargerVariantId))
Assert-Pass ($customTurboFitsR4Slot -and $customSuperFitsNativeSupercharger -and $customTurboFitsUniversalSlot -and $customSuperFitsUniversalSlot -and $customP1XFitsUniversalSlot -and -not $prochargerFitsTurboExhaustSlot -and -not $customFitsOtherSlot -and -not $mountDoesNotReplaceItself -and -not $mountDoesNotReplaceKits) 'all three kits fit the any-engine mount, native kits retain matching slots, and internal mounts cannot appear as replacement parts'
$mountSelectorFilter = $pluginType.GetMethod('ShouldHideUniversalMountFromSelector', $flags)
$hideMountId = [bool]$mountSelectorFilter.Invoke($null, [object[]]@($universalMountVariantId, $universalMountVariantId, $universalMountVariantId))
$hideMountInNormalId = [bool]$mountSelectorFilter.Invoke($null, [object[]]@($universalMountId, 'turbo_2', $universalMountVariantId))
$keepPurchasedP1X = [bool]$mountSelectorFilter.Invoke($null, [object[]]@($universalMountId, $customProchargerVariantId, 'turbo_2'))
$keepTunedMountKit = [bool]$mountSelectorFilter.Invoke($null, [object[]]@($universalMountId, $universalMountVariantId, $customProchargerVariantId))
Assert-Pass ($hideMountId -and $hideMountInNormalId -and -not $keepPurchasedP1X -and -not $keepTunedMountKit) 'mount selector removes mount duplicates while preserving the purchased P-1X kit in either saved-ID layout'
$pulleyScore = $pluginType.GetMethod('ScoreCrankPulleyCandidate', $flags)
$r4PulleyScore = [int]$pulleyScore.Invoke($null, [object[]]@('r4_kolo_pasowe_walu'))
$englishPulleyScore = [int]$pulleyScore.Invoke($null, [object[]]@('crankshaft_pulley'))
$unrelatedPulleyScore = [int]$pulleyScore.Invoke($null, [object[]]@('r4_kolektor_dolotowy3'))
Assert-Pass ($r4PulleyScore -eq 0 -and $englishPulleyScore -eq 0 -and $unrelatedPulleyScore -eq [int]::MaxValue) 'crank-pulley ranking recognizes the observed Polish R4 part ID without matching intake parts'
$compatibilityHookType = $pluginAssembly.GetType('CMS18TurboPrototype.TurboPrototypeHooks', $true)
$isTuningHook = $compatibilityHookType.GetMethod('InductionIsTuningPrefix', [Type[]]@([string], [string], [bool].MakeByRefType()))
 $selectorHook = $compatibilityHookType.GetMethod('InductionInventoryGetItemsPostfix')
if ($null -eq $isTuningHook -or $null -eq $selectorHook) { throw 'ProCharger compatibility or selector hook was not found.' }
$compatibleHookArgs = [object[]]@($customProchargerVariantId, $universalMountVariantId, $false)
$runNativeCompatibilityCheck = [bool]$isTuningHook.Invoke($null, $compatibleHookArgs)
Assert-Pass (-not $runNativeCompatibilityCheck -and [bool]$compatibleHookArgs[2]) 'P-1X compatibility hook exposes the item to CMS replacement lists for any-engine mounts'

$gameInventoryType = $gameAssembly.GetType('GameInventory', $true)
$partScriptType = $gameAssembly.GetType('PartScript', $true)
$gameScriptType = $gameAssembly.GetType('GameScript', $true)
$gameManagerType = $gameAssembly.GetType('GameManager', $true)
$carLoaderType = $gameAssembly.GetType('CarLoader', $true)
$groupType = $gameAssembly.GetType('NewGroupItem', $true)
$addShopRow = $gameInventoryType.GetMethod('AddToPartPropertyList', [Type[]]@(
    [string], [int], [int], [string], [int], [int], [int], [int[]], [single], [bool],
    [string], [string], [string]
))
$getMainShopRows = $gameInventoryType.GetMethod('GetItems', [Type[]]@([string]))
$getShopItemProperty = $gameInventoryType.GetMethod('GetItemProperty', [Type[]]@([string]))
$getPartPrefab = $gameInventoryType.GetMethod('GetGO', [Type[]]@([string]))
$getPartPreviewPrefab = $gameInventoryType.GetMethod('GetGO2', [Type[]]@([string]))
Assert-Pass ($null -ne $addShopRow -and $null -ne $getMainShopRows -and $null -ne $getShopItemProperty) 'GameInventory exposes dynamic part-row insertion, shop listing, and product lookup APIs'
Assert-Pass ($null -ne $getPartPrefab -and $null -ne $getPartPreviewPrefab) 'GameInventory exposes separate mount and shop-preview prefab lookup APIs'

$tunePartMethod = $partScriptType.GetMethod('TunePart', [Type[]]@([string], [bool]))
$setPartIdMethod = $partScriptType.GetMethod('SetID', [Type[]]@([string]))
$setTunedIdMethod = $partScriptType.GetMethod('SetTunedID', [Type[]]@([string]))
$getEffectivePartIdMethod = $partScriptType.GetMethod('GetIDWithTuned', [Type[]]@())
Assert-Pass ($null -ne $tunePartMethod -and $null -ne $setPartIdMethod -and $null -ne $setTunedIdMethod -and $null -ne $getEffectivePartIdMethod) 'PartScript exposes the base-prefab tuning and persistent custom-ID hooks'

$standGroupGetter = $gameScriptType.GetMethod('GetGroupOnEngineStand', [Type[]]@())
$standGroupSetter = $gameScriptType.GetMethod('SetGroupOnEngineStand', [Type[]]@($groupType))
$standEmptyCheck = $gameScriptType.GetMethod('EngineStandIsEmpty', [Type[]]@())
Assert-Pass ($null -ne $standGroupGetter -and $null -ne $standGroupSetter -and $null -ne $standEmptyCheck) 'GameScript exposes the engine-stand group read, restore, and occupied checks'

$insertEngine = $gameManagerType.GetMethod('ActionInsertEngineToCar', [Type[]]@($groupType))
$swapEngine = $carLoaderType.GetMethod('SwapEngine', [Type[]]@($groupType))
$getCarEngine = $carLoaderType.GetMethod('GetEngine', [Type[]]@())
Assert-Pass ($null -ne $insertEngine -and $null -ne $swapEngine -and $null -ne $getCarEngine) 'GameManager and CarLoader expose engine-transfer and engine-load callbacks'
$transferHooksType = $pluginAssembly.GetType('CMS18TurboPrototype.TurboPrototypeHooks', $true)
$sourceText = Get-Content -LiteralPath (Join-Path (Split-Path -Parent $PSScriptRoot) 'src\CMS18TurboPrototype.cs') -Raw
$standMountIsAddedDuringContextRefresh = $sourceText.Contains('EnsureUniversalMountOnStand(game);') -and
    $sourceText.Contains('must exist even before the')
$sameEngineMountIsTransferGated = $sourceText.Contains('string groupKitId = FindInductionKitId(group);') -and
    $sourceText.Contains('pendingHasUniversalMount = mode != InductionMode.Off') -and
    $sourceText.Contains('|| GroupContainsUniversalMount(group)') -and
    $sourceText.Contains('|| IsInductionPartId(groupKitId);') -and
    $sourceText.Contains('if (!pendingHasUniversalMount || pendingSwapObserved || pendingInstallLoader == null || group == null) return;')
$setEnginePostfixHook = $transferHooksType.GetMethod('SetEnginePostfix', [Type[]]@($carLoaderType))
$insertPostfixHook = $transferHooksType.GetMethod('InsertEnginePostfix', [Type[]]@($groupType, [System.Collections.IEnumerator].MakeByRefType()))
$swapPostfixHook = $transferHooksType.GetMethod('SwapEnginePostfix', [Type[]]@($carLoaderType, $groupType, [System.Collections.IEnumerator].MakeByRefType()))
$trackingEnumeratorType = $pluginType.GetNestedType('InstallTrackingEnumerator', $flags)
$trackingEnumeratorConstructor = if ($null -ne $trackingEnumeratorType) { $trackingEnumeratorType.GetConstructor($flags, $null, [Type[]]@([System.Collections.IEnumerator], $pluginType, $groupType, $carLoaderType, [bool]), $null) } else { $null }
Assert-Pass ($standMountIsAddedDuringContextRefresh -and $sameEngineMountIsTransferGated -and $null -ne $setEnginePostfixHook -and $null -ne $insertPostfixHook -and $null -ne $swapPostfixHook -and $null -ne $trackingEnumeratorConstructor) 'saved induction kits trigger universal-mount insertion on matching engine transfers and both transfer paths remain tracked'
Assert-Pass ($sourceText.Contains('PrepareUniversalMountForInstalledKit(engine, mount)') -and $sourceText.Contains('SetPartField(mount, "unmounted", false)') -and $sourceText.Contains('colliders[i].enabled = true')) 'saved kit restoration reactivates the CMS-unmounted virtual mount and its selection collider'
Assert-Pass ($sourceText.Contains('SaveGroupKitSelection(standGroup, mode)') -and $sourceText.Contains('KitIdForMode(pendingInstallMode)') -and $sourceText.Contains('private const int PartSelectionLayer = 16;')) 'F8-selected kits persist through engine transfer and the universal mount remains selectable'
$oneClickVirtualMount = $sourceText.Contains('VirtualMountAnchorName') -and $sourceText.Contains('SetPartField(part, "oneClickUnmount", true);') -and $sourceText.Contains('SetPartField(part, "MountObjects", new MountObject[0]);') -and -not $sourceText.Contains('AddVirtualMountBoltHeads(anchor)')
Assert-Pass $oneClickVirtualMount 'internal visual mount unmounts in one click and creates no synthetic unscrew bolts'
$postTransferPlacement = $sourceText.Contains('PositionUniversalMountNearDrivePulley(engine, mount.transform);') -and $sourceText.Contains('target = FindEngineContainer(candidate);')
Assert-Pass $postTransferPlacement 'virtual mount is re-anchored using the complete engine after transfer and avoids parenting to an engine-block subpart'
$mountedNameLocalization = $sourceText.Contains('partMouseOver') -and $sourceText.Contains('ModeForInductionPartId(selectedPart.GetTunedID())') -and $sourceText.Contains('ProCharger P-1X Centrifugal Supercharger')
Assert-Pass $mountedNameLocalization 'selected virtual mount localizes to its active kit name'
Assert-Pass ($sourceText.Contains('candidate.IsReady && HasPartPropertyList(candidate)') -and $sourceText.Contains('HasValidTurboTemplate(candidate)') -and -not $sourceText.Contains('candidate.IsReady && candidate.IsReadyFillPartPropertyList') -and $sourceText.Contains('InductionShopGetItemsPostfix') -and $sourceText.Contains('HasShopProperty(inventory') -and $sourceText.Contains('GetItemProperty returns an unregistered placeholder')) 'shop registration waits for a usable part catalog and stock template without relying on the false parts-ready flag'
$customTuneBypassesVanilla = $sourceText.Contains('public static bool InductionTunePartPrefix') -and
    $sourceText.Contains('if (IsInductionPartId(__0))') -and
    $sourceText.Contains('if (__instance != null) __instance.SetTunedID(__0);') -and
    $sourceText.Contains('return false;')
Assert-Pass $customTuneBypassesVanilla 'custom induction tune IDs bypass stock catalog lookup and are handled by the plugin postfix'
$menuButtonIsIdempotent = $sourceText.Contains('Button freshButton = originalButton;') -and
    $sourceText.Contains('freshButton.onClick = new Button.ButtonClickedEvent();') -and
    $sourceText.Contains('exitButton.transform.parent.GetComponentsInChildren<Transform>(true)') -and
    $sourceText.Contains('normalizedItems.Insert(normalizedExitIndex, modsButton);')
Assert-Pass $menuButtonIsIdempotent 'main menu reuses the existing cloned Exit button and registers only one Mods row item'
$installSequence = New-Object System.Collections.ArrayList
[void]$installSequence.Add('fade')
[void]$installSequence.Add('install')
$trackedInstall = $trackingEnumeratorConstructor.Invoke([object[]]@($installSequence.GetEnumerator(), $null, $null, $null, $false))
$firstInstallStep = [bool]$trackedInstall.MoveNext()
$firstInstallValue = [string]$trackedInstall.Current
$secondInstallStep = [bool]$trackedInstall.MoveNext()
$secondInstallValue = [string]$trackedInstall.Current
$installFinished = -not [bool]$trackedInstall.MoveNext()
$trackingSource = Get-Content -LiteralPath (Join-Path (Split-Path -Parent $PSScriptRoot) 'src\CMS18TurboPrototype.cs') -Raw
$trackingMatch = [regex]::Match($trackingSource, '(?s)class InstallTrackingEnumerator\s*:\s*IEnumerator\s*\{.*?(?=\r?\n\s*private void Awake)')
$actionFreeTracking = $trackingMatch.Success -and -not $trackingMatch.Value.Contains('System.Action') -and -not $trackingMatch.Value.Contains('Action<')
Assert-Pass ($firstInstallStep -and $firstInstallValue -eq 'fade' -and $secondInstallStep -and $secondInstallValue -eq 'install' -and $installFinished -and $actionFreeTracking) 'engine-install coroutine forwards every step without loading Mono-incompatible System.Action delegate fields'
$failedInstall = $trackingEnumeratorConstructor.Invoke([object[]]@($null, $null, $null, $null, $false))
$installExceptionObserved = $false
try { $null = $failedInstall.MoveNext() } catch { $installExceptionObserved = $true }
Assert-Pass $installExceptionObserved 'failed engine-install coroutine propagates its original exception when tracking has no game context'
$emptyInstallSequence = New-Object System.Collections.ArrayList
$safeCompletion = $trackingEnumeratorConstructor.Invoke([object[]]@($emptyInstallSequence.GetEnumerator(), $null, $null, $null, $false))
$safeCompletionFaultObserved = $false
try { $safeCompletionFinished = -not [bool]$safeCompletion.MoveNext() } catch { $safeCompletionFaultObserved = $true }
Assert-Pass ($safeCompletionFinished -and -not $safeCompletionFaultObserved) 'tracking finalization does not cancel a completed vanilla engine-install coroutine'

$inventoryItemType = $gameAssembly.GetType('NewInventoryItem', $true)
$newHashType = $gameAssembly.GetType('NewHash', $true)
$getNormalIdMethod = $inventoryItemType.GetMethod('GetNormalID', [Type[]]@())
$inventoryItemConstructor = $inventoryItemType.GetConstructor([Type[]]@())
$newHashConstructor = $newHashType.GetConstructor([Type[]]@())
$normalIdField = $inventoryItemType.GetField('ID', $flags)
$extraParametersField = $inventoryItemType.GetField('extraParameters', $flags)
$normalIdHashAdd = $newHashType.GetMethod('Add', [Type[]]@([object], [object]))
Assert-Pass ($null -ne $getNormalIdMethod -and $null -ne $inventoryItemConstructor -and $null -ne $newHashConstructor -and $null -ne $normalIdField -and $null -ne $extraParametersField -and $null -ne $normalIdHashAdd) 'NewInventoryItem exposes its saved NormalID route'
$savedPart = $inventoryItemConstructor.Invoke([object[]]@())
$savedPartExtras = $newHashConstructor.Invoke([object[]]@())
$normalIdField.SetValue($savedPart, 'turbo_2')
$extraParametersField.SetValue($savedPart, $savedPartExtras)
$defaultNormalId = [string]$getNormalIdMethod.Invoke($savedPart, [object[]]@())
Assert-Pass ($defaultNormalId -eq 'turbo_2') 'Engine-stand save item falls back to its stock prefab ID without a NormalID extra'
$normalIdHashAdd.Invoke($savedPartExtras, [object[]]@('NormalID', $customProchargerVariantId)) | Out-Null
$restoredNormalId = [string]$getNormalIdMethod.Invoke($savedPart, [object[]]@())
Assert-Pass ($restoredNormalId -eq $customProchargerVariantId) 'Engine-stand save item preserves the suffixed custom ProCharger ID over the stock turbo prefab ID'
$mountItemListField = $groupType.GetField('ItemList', $flags)
$mountGroup = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($groupType)
$mountItem = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($inventoryItemType)
$normalIdField.SetValue($mountItem, 'cms18_universal_induction_mount(0)')
$mountItemExtras = $newHashConstructor.Invoke([object[]]@())
$extraParametersField.SetValue($mountItem, $mountItemExtras)
$mountItemExtrasTable = $mountItemExtras.GetHashTable()
$mountItemExtrasTable['NormalID'] = $customProchargerVariantId
$mountItemList = [Activator]::CreateInstance($mountItemListField.FieldType)
$mountItemListField.FieldType.GetMethod('Add', [Type[]]@($inventoryItemType)).Invoke($mountItemList, [object[]]@($mountItem)) | Out-Null
$mountItemListField.SetValue($mountGroup, $mountItemList)
$groupContainsUniversalMountMethod = $pluginType.GetMethod('GroupContainsUniversalMount', $flags)
$groupContainsUniversalMount = [bool]$groupContainsUniversalMountMethod.Invoke($null, [object[]]@($mountGroup))
$findMountKitIdMethod = $pluginType.GetMethod('FindUniversalMountKitId', $flags)
$mountKitFromSavedNormalId = [string]$findMountKitIdMethod.Invoke($null, [object[]]@($mountGroup))
$normalIdField.SetValue($mountItem, $customProchargerVariantId)
$mountItemExtrasTable['NormalID'] = $universalMountVariantId
$mountKitFromReversedIds = [string]$findMountKitIdMethod.Invoke($null, [object[]]@($mountGroup))
$normalPartGroup = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($groupType)
$normalPartItem = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($inventoryItemType)
$normalIdField.SetValue($normalPartItem, 'i4_engine_block')
$normalPartList = [Activator]::CreateInstance($mountItemListField.FieldType)
$mountItemListField.FieldType.GetMethod('Add', [Type[]]@($inventoryItemType)).Invoke($normalPartList, [object[]]@($normalPartItem)) | Out-Null
$mountItemListField.SetValue($normalPartGroup, $normalPartList)
$normalGroupContainsUniversalMount = [bool]$groupContainsUniversalMountMethod.Invoke($null, [object[]]@($normalPartGroup))
Assert-Pass ($groupContainsUniversalMount -and -not $normalGroupContainsUniversalMount -and $mountKitFromSavedNormalId -eq $customProchargerVariantId -and $mountKitFromReversedIds -eq $customProchargerVariantId) 'engine transfer detects saved mount and kit IDs in either item-ID layout'
$partPropertyType = $gameInventoryType.GetNestedType('PartProperty', $flags)
$partPropertyConstructor = $partPropertyType.GetConstructor([Type[]]@([string]))
$turboTemplate = $partPropertyConstructor.Invoke([object[]]@('turbo_2'))
$partPropertyType.GetField('Price', $flags).SetValue($turboTemplate, [int]5000)
$partPropertyType.GetField('PartGroup', $flags).SetValue($turboTemplate, [int]4)
$partPropertyType.GetField('ExamineGroup', $flags).SetValue($turboTemplate, [int]2)
$partPropertyType.GetField('RepairGroup', $flags).SetValue($turboTemplate, [int]2)
$partPropertyType.GetField('SpecialGroup', $flags).SetValue($turboTemplate, [int]0)
$partPropertyType.GetField('TuningValue', $flags).SetValue($turboTemplate, [single]1.0)
$partPropertyType.GetField('IsBody', $flags).SetValue($turboTemplate, [bool]$false)
$partPropertyType.GetField('ShopGroup', $flags).SetValue($turboTemplate, 'Engine')
$partPropertyType.GetField('ShopName', $flags).SetValue($turboTemplate, 'MainShop')
$partPropertyType.GetField('LocalizedName', $flags).SetValue($turboTemplate, 'Turbocharger')
$partPropertyType.GetField('Brand', $flags).SetValue($turboTemplate, 'CMS')
$partPropertyType.GetField('DLC', $flags).SetValue($turboTemplate, [int[]]@())
$templateValidator = $pluginType.GetMethod('IsValidProchargerShopTemplate', $flags)
if ($null -eq $templateValidator -or -not $templateValidator.IsStatic) { throw 'ProCharger shop-template validator was not found.' }
Assert-Pass ([bool]$templateValidator.Invoke($null, [object[]]@($turboTemplate))) 'Native turbo_2 template with SpecialGroup 0 is accepted for the Engine shop'
$partPropertyType.GetField('ShopGroup', $flags).SetValue($turboTemplate, 'Body')
Assert-Pass (-not [bool]$templateValidator.Invoke($null, [object[]]@($turboTemplate))) 'Non-Engine shop template is rejected'
$partPropertyType.GetField('ShopGroup', $flags).SetValue($turboTemplate, 'Engine')
$shopPropertyFactory = $pluginType.GetMethod('CreateProchargerShopProperty', $flags)
if ($null -eq $shopPropertyFactory -or -not $shopPropertyFactory.IsStatic) { throw 'ProCharger shop property factory was not found.' }
$prochargerProperty = $shopPropertyFactory.Invoke($null, [object[]]@($turboTemplate))
$customPropertyId = [string]$partPropertyType.GetField('ID', $flags).GetValue($prochargerProperty)
$customPropertyPrice = [int]$partPropertyType.GetField('Price', $flags).GetValue($prochargerProperty)
$customPropertyShopGroup = [string]$partPropertyType.GetField('ShopGroup', $flags).GetValue($prochargerProperty)
$customPropertyShopName = [string]$partPropertyType.GetField('ShopName', $flags).GetValue($prochargerProperty)
$customPropertySpecialGroup = [int]$partPropertyType.GetField('SpecialGroup', $flags).GetValue($prochargerProperty)
$customPropertyDlc = [int[]]$partPropertyType.GetField('DLC', $flags).GetValue($prochargerProperty)
Assert-Pass ($customPropertyId -eq $customProchargerId) 'ProCharger product receives its distinct saved part ID'
Assert-Pass ($customPropertyPrice -ge 12500) 'ProCharger product receives a retail shop price'
Assert-Pass ($customPropertyShopGroup -eq 'Engine' -and $customPropertyShopName -eq 'MainShop') 'ProCharger product is registered in Main Shop / Engine'
Assert-Pass ($customPropertySpecialGroup -eq 0) 'ProCharger product preserves the native turbo_2 SpecialGroup 0 value'
Assert-Pass ($customPropertyDlc.Count -eq 1 -and $customPropertyDlc[0] -eq 0) 'ProCharger uses CMS base-game DLC sentinel so native shop cards remain visible'
$highBoostPropertyFactory = $pluginType.GetMethod('CreateProchargerHighBoostShopProperty', $flags)
if ($null -eq $highBoostPropertyFactory -or -not $highBoostPropertyFactory.IsStatic) { throw 'High-boost ProCharger shop property factory was not found.' }
$highBoostProperty = $highBoostPropertyFactory.Invoke($null, [object[]]@($turboTemplate))
$highBoostPropertyId = [string]$partPropertyType.GetField('ID', $flags).GetValue($highBoostProperty)
$highBoostPropertyPrice = [int]$partPropertyType.GetField('Price', $flags).GetValue($highBoostProperty)
$highBoostPropertyShop = [string]$partPropertyType.GetField('ShopName', $flags).GetValue($highBoostProperty)
$highBoostPropertyDlc = [int[]]$partPropertyType.GetField('DLC', $flags).GetValue($highBoostProperty)
Assert-Pass ($highBoostPropertyId -eq $customProchargerHighBoostId -and $highBoostPropertyPrice -gt $customPropertyPrice -and $highBoostPropertyPrice -eq 24900 -and $highBoostPropertyShop -eq 'TuningShop') 'higher-priced 32 psi P-1X is assigned to Tuning Shop'
Assert-Pass ($highBoostPropertyDlc.Count -eq 1 -and $highBoostPropertyDlc[0] -eq 0) 'high-boost ProCharger uses CMS base-game DLC sentinel so tuning-shop cards remain visible'
$shopInventory = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($gameInventoryType)
$templateRowArguments = [object[]]@(
    'turbo_2',
    [int]$partPropertyType.GetField('Price', $flags).GetValue($turboTemplate),
    [int]$partPropertyType.GetField('PartGroup', $flags).GetValue($turboTemplate),
    [string]$partPropertyType.GetField('ShopGroup', $flags).GetValue($turboTemplate),
    [int]$partPropertyType.GetField('ExamineGroup', $flags).GetValue($turboTemplate),
    [int]$partPropertyType.GetField('RepairGroup', $flags).GetValue($turboTemplate),
    [int]$partPropertyType.GetField('SpecialGroup', $flags).GetValue($turboTemplate),
    [int[]]$partPropertyType.GetField('DLC', $flags).GetValue($turboTemplate),
    [single]$partPropertyType.GetField('TuningValue', $flags).GetValue($turboTemplate),
    [bool]$partPropertyType.GetField('IsBody', $flags).GetValue($turboTemplate),
    [string]$partPropertyType.GetField('LocalizedName', $flags).GetValue($turboTemplate),
    [string]$partPropertyType.GetField('Brand', $flags).GetValue($turboTemplate),
    'MainShop'
)
$addShopRow.Invoke($shopInventory, $templateRowArguments) | Out-Null
$missingP1xPlaceholder = $getShopItemProperty.Invoke($shopInventory, [object[]]@($customPropertyId))
$missingP1xShopName = $partPropertyType.GetField('ShopName', $flags).GetValue($missingP1xPlaceholder)
$missingP1xId = $partPropertyType.GetField('ID', $flags).GetValue($missingP1xPlaceholder)
$missingP1xShopGroup = $partPropertyType.GetField('ShopGroup', $flags).GetValue($missingP1xPlaceholder)
$hasShopProperty = $pluginType.GetMethod('HasShopProperty', $flags)
$registerInductionProperty = $pluginType.GetMethod('RegisterInductionProperty', $flags)
Assert-Pass ($null -ne $missingP1xPlaceholder -and [string]$missingP1xId -eq $customPropertyId -and [string]$missingP1xShopName -eq $customPropertyId -and [string]$missingP1xShopGroup -eq $customPropertyId -and -not [bool]$hasShopProperty.Invoke($null, [object[]]@($shopInventory, $customPropertyId, 'MainShop'))) 'CMS placeholder shop fields copy the requested ID and fail real catalog validation'
$registerInductionProperty.Invoke($null, [object[]]@($shopInventory, $turboTemplate, $customPropertyId, 'ProCharger P-1X', 'ProCharger', 'MainShop', [int]12500)) | Out-Null
$registeredP1x = $getShopItemProperty.Invoke($shopInventory, [object[]]@($customPropertyId))
Assert-Pass ($null -ne $registeredP1x -and [string]$partPropertyType.GetField('ID', $flags).GetValue($registeredP1x) -eq $customPropertyId -and [string]$partPropertyType.GetField('ShopName', $flags).GetValue($registeredP1x) -eq 'MainShop' -and [string]$partPropertyType.GetField('ShopGroup', $flags).GetValue($registeredP1x) -eq 'Engine' -and [string]$partPropertyType.GetField('LocalizedName', $flags).GetValue($registeredP1x) -eq 'ProCharger P-1X') 'shop registration adds the P-1X despite GetItemProperty returning a placeholder for its missing ID'
$shopRowArguments = [object[]]@(
    $customPropertyId,
    $customPropertyPrice,
    [int]$partPropertyType.GetField('PartGroup', $flags).GetValue($prochargerProperty),
    [string]$partPropertyType.GetField('ShopGroup', $flags).GetValue($prochargerProperty),
    [int]$partPropertyType.GetField('ExamineGroup', $flags).GetValue($prochargerProperty),
    [int]$partPropertyType.GetField('RepairGroup', $flags).GetValue($prochargerProperty),
    $customPropertySpecialGroup,
    [int[]]$partPropertyType.GetField('DLC', $flags).GetValue($prochargerProperty),
    [single]$partPropertyType.GetField('TuningValue', $flags).GetValue($prochargerProperty),
    [bool]$partPropertyType.GetField('IsBody', $flags).GetValue($prochargerProperty),
    [string]$partPropertyType.GetField('LocalizedName', $flags).GetValue($prochargerProperty),
    [string]$partPropertyType.GetField('Brand', $flags).GetValue($prochargerProperty),
    $customPropertyShopName
)
$addShopRow.Invoke($shopInventory, $shopRowArguments) | Out-Null
$mainShopRows = $getMainShopRows.Invoke($shopInventory, [object[]]@('MainShop'))
$otherShopRows = $getMainShopRows.Invoke($shopInventory, [object[]]@('OtherShop'))
$mainShopCustomCount = 0
foreach ($row in $mainShopRows) {
    if ([string]$partPropertyType.GetField('ID', $flags).GetValue($row) -eq $customPropertyId) { $mainShopCustomCount++ }
}
$addShopRow.Invoke($shopInventory, $shopRowArguments) | Out-Null
$rowsAfterDuplicateRegistration = $getMainShopRows.Invoke($shopInventory, [object[]]@('MainShop'))
$duplicateCustomCount = 0
foreach ($row in $rowsAfterDuplicateRegistration) {
    if ([string]$partPropertyType.GetField('ID', $flags).GetValue($row) -eq $customPropertyId) { $duplicateCustomCount++ }
}
Assert-Pass ($mainShopCustomCount -eq 1 -and $otherShopRows.Count -eq 0) 'Actual GameInventory list APIs return the custom product only under Main Shop'
Assert-Pass ($duplicateCustomCount -eq 1) 'Repeated AddToPartPropertyList calls do not duplicate the custom shop item'
$lookedUpProperty = $getShopItemProperty.Invoke($shopInventory, [object[]]@($customPropertyId + '(0)'))
$lookedUpId = [string]$partPropertyType.GetField('ID', $flags).GetValue($lookedUpProperty)
$lookedUpPrice = [int]$partPropertyType.GetField('Price', $flags).GetValue($lookedUpProperty)
$lookedUpShop = [string]$partPropertyType.GetField('ShopName', $flags).GetValue($lookedUpProperty)
Assert-Pass ($lookedUpId -eq $customPropertyId -and $lookedUpPrice -eq $customPropertyPrice -and $lookedUpShop -eq 'MainShop') 'Actual GameInventory.GetItemProperty resolves suffixed custom IDs to the registered product data'
$highBoostShopRowArguments = [object[]]@(
    $highBoostPropertyId,
    $highBoostPropertyPrice,
    [int]$partPropertyType.GetField('PartGroup', $flags).GetValue($highBoostProperty),
    [string]$partPropertyType.GetField('ShopGroup', $flags).GetValue($highBoostProperty),
    [int]$partPropertyType.GetField('ExamineGroup', $flags).GetValue($highBoostProperty),
    [int]$partPropertyType.GetField('RepairGroup', $flags).GetValue($highBoostProperty),
    [int]$partPropertyType.GetField('SpecialGroup', $flags).GetValue($highBoostProperty),
    [int[]]$partPropertyType.GetField('DLC', $flags).GetValue($highBoostProperty),
    [single]$partPropertyType.GetField('TuningValue', $flags).GetValue($highBoostProperty),
    [bool]$partPropertyType.GetField('IsBody', $flags).GetValue($highBoostProperty),
    [string]$partPropertyType.GetField('LocalizedName', $flags).GetValue($highBoostProperty),
    [string]$partPropertyType.GetField('Brand', $flags).GetValue($highBoostProperty),
    $highBoostPropertyShop
)
$addShopRow.Invoke($shopInventory, $highBoostShopRowArguments) | Out-Null
$tuningShopRows = $getMainShopRows.Invoke($shopInventory, [object[]]@('TuningShop'))
$mainShopRowsWithHighBoost = $getMainShopRows.Invoke($shopInventory, [object[]]@('MainShop'))
$highBoostInTuningShop = @($tuningShopRows | Where-Object { [string]$partPropertyType.GetField('ID', $flags).GetValue($_) -eq $customProchargerHighBoostId }).Count -eq 1
$highBoostInMainShop = @($mainShopRowsWithHighBoost | Where-Object { [string]$partPropertyType.GetField('ID', $flags).GetValue($_) -eq $customProchargerHighBoostId }).Count -gt 0
Assert-Pass ($highBoostInTuningShop -and -not $highBoostInMainShop) 'GameInventory exposes the high-boost P-1X in Tuning Shop only'

foreach ($partId in @('turbo_2', 't_turbo_2', 't_turbo_1', 'i3_turbo', 't_i3_turbo', 'i4_turbo', 't_i4_turbo', 'rot_new_turbo', 't_rot_new_turbo', 'b61_turbo', 't_b61_turbo', 'b62_turbo', 't_b62_turbo', 'b62_porsche_turbo', 'w12_turbo', 't_w12_turbo', 'v12_huayra_turbo', 't_v12_huayra_turbo', 'w_r4_turbo_poczatkowy', 't_w_r4_turbo_poczatkowy')) {
    $detected = [int]$partClassifier.Invoke($null, [object[]]@($partId))
    Assert-Pass ($detected -eq 1) "Native CMS turbo ID '$partId' is recognized"
}
foreach ($partId in @('v8_supercharger', 'v8_supercharger_stary')) {
    $detected = [int]$partClassifier.Invoke($null, [object[]]@($partId))
    Assert-Pass ($detected -eq 2) "Buyable native supercharger part '$partId' is recognized"
}
foreach ($nonPartId in @('v8_quattroporte_kolektorturbo', 't_v8_quattroporte_kolektorturbo', 'v8_supercharger_kolektor_dolotowy', 'v8_supercharger_kolektor_dolotowy_stary', 'turbo_2_mounts', 'b61_turbo_mounts', 'v8_supercharger_mounts', 'turboSound', 'superchargerSound', 'Turbocharger_2')) {
    $nonPartMode = [int]$partClassifier.Invoke($null, [object[]]@($nonPartId))
    Assert-Pass ($nonPartMode -eq 0) "Non-compressor resource '$nonPartId' does not trigger boost detection"
}
$engineType = $gameAssembly.GetType('VehiclePhysics.Engine', $true)
$groupMetadataSerializable = $groupType.IsSerializable -and $inventoryItemType.IsSerializable -and $newHashType.IsSerializable
Assert-Pass $groupMetadataSerializable 'CMS engine-group and inventory metadata types are serializable'
$groupMetadataPlugin = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($pluginType)
$groupMetadata = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($groupType)
$groupType.GetField('GroupName', $flags).SetValue($groupMetadata, 'i4_engine')
$itemListField = $groupType.GetField('ItemList', $flags)
$groupItems = [Activator]::CreateInstance($itemListField.FieldType)
$itemListField.FieldType.GetMethod('Add', [Type[]]@($inventoryItemType)).Invoke($groupItems, [object[]]@($savedPart)) | Out-Null
$itemListField.SetValue($groupMetadata, $groupItems)
$annotateGroupMethod = $pluginType.GetMethod('AnnotateGroup', $flags)
$readGroupSettingsMethod = $pluginType.GetMethod('TryReadGroupSettings', $flags)
if ($null -eq $annotateGroupMethod -or $null -eq $readGroupSettingsMethod) { throw 'Engine-group metadata methods were not found.' }
$annotateGroupMethod.Invoke($groupMetadataPlugin, [object[]]@($groupMetadata, [Enum]::ToObject($modeType, 3), [single]11.5)) | Out-Null
$readGroupArguments = [object[]]@($groupMetadata, [Enum]::ToObject($modeType, 0), [single]0)
$readGroupResult = [bool]$readGroupSettingsMethod.Invoke($groupMetadataPlugin, $readGroupArguments)
Assert-Pass ($readGroupResult -and [int]$readGroupArguments[1] -eq 3 -and [Math]::Abs([single]$readGroupArguments[2] - 11.5) -lt 0.001) 'Engine-stand mode and boost metadata can be written to and read from the saved group item'
$groupInventoryDataType = $gameAssembly.GetType('NewGroupInventoryData', $true)
$groupInventoryData = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($groupInventoryDataType)
$inventoryListField = $groupInventoryDataType.GetField('inventoryList', $flags)
$serializedGroups = [Activator]::CreateInstance($inventoryListField.FieldType)
$inventoryListField.FieldType.GetMethod('Add', [Type[]]@($groupType)).Invoke($serializedGroups, [object[]]@($groupMetadata)) | Out-Null
$inventoryListField.SetValue($groupInventoryData, $serializedGroups)
[System.AppContext]::SetSwitch('System.Runtime.Serialization.EnableUnsafeBinaryFormatterSerialization', $true)
$memoryStream = [System.IO.MemoryStream]::new()
try {
    $formatter = New-Object -TypeName System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
    $formatter.Serialize($memoryStream, $groupInventoryData)
    $memoryStream.Position = 0
    $restoredGroupData = $formatter.Deserialize($memoryStream)
    $restoredGroups = $inventoryListField.GetValue($restoredGroupData)
    $restoredItem = $restoredGroups[0].ItemList[0]
    $restoredMode = [int]$restoredItem.extraParameters.GetFromKey('cms18_induction_mode')
    $restoredPsi = [single]$restoredItem.extraParameters.GetFromKey('cms18_boost_psi')
} finally {
    $memoryStream.Dispose()
}
Assert-Pass ($restoredMode -eq 3 -and [Math]::Abs($restoredPsi - 11.5) -lt 0.001) 'CMS BinaryFormatter groupInventory data preserves induction mode and boost metadata through a save-format round-trip'
$hooksType = $pluginAssembly.GetType('CMS18TurboPrototype.TurboPrototypeHooks', $true)
$powerHook = $hooksType.GetMethod('PowerPostfix', [Type[]]@($engineType, [single], [single].MakeByRefType()))
Assert-Pass ($null -ne $powerHook -and $powerHook.IsStatic) 'Harmony power postfix matches the game CalculatePowerInKw signature'
$engineSpecsType = $engineType.GetNestedType('EngineSpecs', $flags)
$engineSpecsMethod = $engineType.GetMethod('GetEngineSpecifications', $flags, $null, [Type[]]@($engineSpecsType.MakeByRefType()), $null)
$sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'src\CMS18TurboPrototype.cs'
$runtimeSource = Get-Content -LiteralPath $sourcePath -Raw
$factorySpecsPatchRegistered = $runtimeSource -match 'Patch\(typeof\(VehiclePhysics\.Engine\),\s*"GetEngineSpecifications"'
Assert-Pass ($null -ne $engineSpecsType -and $null -ne $engineSpecsMethod -and $engineSpecsMethod.IsPublic -and -not $factorySpecsPatchRegistered) 'shared factory engine-specification method is verified but intentionally not patched by the mod'
$engineSettingsType = $engineType.GetNestedType('Settings', $flags)
$engineSettings = [Activator]::CreateInstance($engineSettingsType)
foreach ($value in @(
    @('idleRpm', 800),
    @('peakRpm', 5500),
    @('maxRpm', 6500),
    @('idleRpmTorque', 180),
    @('peakRpmTorque', 260),
    @('idleRpmCurveBias', 0.5),
    @('peakRpmCurveBias', 0.5),
    @('frictionTorque', 20),
    @('rotationalFriction', 0.03),
    @('viscousFriction', 0.002)
)) {
    $engineSettingsType.GetField($value[0], $flags).SetValue($engineSettings, [single]$value[1])
}

$engine = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($engineType)
$engineType.GetField('settings', $flags).SetValue($engine, $engineSettings)
$maxTorqueMethod = $engineType.GetMethod('GetMaxPowerTorque', $flags)
$calculateTorqueMethod = $engineType.GetMethod('CalculateTorque', $flags)
$calculatePowerMethod = $engineType.GetMethod('CalculatePowerInKw', $flags)
$applyTorqueMethod = $pluginType.GetMethod('ApplyTorque', $flags)
 $applyPowerMethod = $pluginType.GetMethod('ApplyPower', $flags)
if ($null -eq $calculateTorqueMethod -or $null -eq $calculatePowerMethod -or $null -eq $applyTorqueMethod -or $null -eq $applyPowerMethod) { throw 'Compiled live/game torque or power methods were not found.' }

function New-PluginTestInstance([int]$Mode, [single]$BoostPsi, [single]$Spool, [bool]$DynoSampling, [bool]$HighBoost = $false) {
    $pluginInstance = [Runtime.Serialization.FormatterServices]::GetUninitializedObject($script:pluginType)
    $script:pluginType.GetField('activeMode', $script:flags).SetValue($pluginInstance, [Enum]::ToObject($script:modeType, $Mode))
    $script:pluginType.GetField('activeBoostPsi', $script:flags).SetValue($pluginInstance, $BoostPsi)
    $script:pluginType.GetField('activeHasHighBoostProcharger', $script:flags).SetValue($pluginInstance, $HighBoost)
    $script:pluginType.GetField('activeHasCustomInduction', $script:flags).SetValue($pluginInstance, $true)
    $script:pluginType.GetField('activeTurboInducerMm', $script:flags).SetValue($pluginInstance, [int]55)
    $script:pluginType.GetField('currentSpool', $script:flags).SetValue($pluginInstance, $Spool)
    $script:pluginType.GetField('dynoTorqueSampling', $script:flags).SetValue($pluginInstance, $DynoSampling)
    return $pluginInstance
}

$instanceField = $pluginType.GetField('Instance', $flags)
function Invoke-CompiledTorque([int]$Mode, [single]$BoostPsi, [single]$Rpm, [single]$Throttle, [single]$Spool, [bool]$DynoSampling = $false, [bool]$HighBoost = $false) {
    $pluginInstance = New-PluginTestInstance $Mode $BoostPsi $Spool $DynoSampling $HighBoost
    $base = [single]$script:calculateTorqueMethod.Invoke($script:engine, [object[]]@([single]$Rpm, [single]$Throttle))
    $arguments = [object[]]@($script:engine, $Rpm, $Throttle, $base)
    # PowerShell surfaces the updated ref argument from MethodInfo.Invoke as
    # pipeline output. Suppress it so the function returns only one torque value.
    $null = $script:applyTorqueMethod.Invoke($pluginInstance, $arguments)
    return [single]$arguments[3]
}

function Invoke-CompiledPower([int]$Mode, [single]$BoostPsi, [single]$Rpm, [bool]$HighBoost = $false) {
    $pluginInstance = New-PluginTestInstance $Mode $BoostPsi 0 $false $HighBoost
    $base = [single]$script:calculatePowerMethod.Invoke($script:engine, [object[]]@([single]$Rpm))
    $arguments = [object[]]@($script:engine, $Rpm, $base)
    $null = $script:applyPowerMethod.Invoke($pluginInstance, $arguments)
    return [single]$arguments[2]
}

$grossTorque = [single]$maxTorqueMethod.Invoke($engine, [object[]]@([single]3500))
$baseTorque = [single]$calculateTorqueMethod.Invoke($engine, [object[]]@([single]3500, [single]1))
$zeroThrottleBase = [single]$calculateTorqueMethod.Invoke($engine, [object[]]@([single]3500, [single]0))
$offTorque = Invoke-CompiledTorque 0 8 3500 1 1
$turbo4Psi = Invoke-CompiledTorque 1 4 3500 1 1
$turbo8Psi = Invoke-CompiledTorque 1 8 3500 1 1
$dynoTurboTorque = Invoke-CompiledTorque 1 8 3500 1 1 $true
$dynoSuperchargerTorque = Invoke-CompiledTorque 2 8 3500 1 1 $true
$dynoProchargerTorque = Invoke-CompiledTorque 3 8 3500 1 1 $true
$turboHalfSpool = Invoke-CompiledTorque 1 8 3500 1 0.5
$turboHalfThrottle = Invoke-CompiledTorque 1 8 3500 0.5 1
$halfThrottleBase = [single]$calculateTorqueMethod.Invoke($engine, [object[]]@([single]3500, [single]0.5))
$superchargerTorque = Invoke-CompiledTorque 2 8 3500 1 1
$prochargerTorque = Invoke-CompiledTorque 3 8 3500 1 1
$streetP1XTorque = Invoke-CompiledTorque 3 20 3500 1 1 $false $false
$highBoostP1XTorque = Invoke-CompiledTorque 3 24 3500 1 1 $false $true
$basePowerKw = [single]$calculatePowerMethod.Invoke($engine, [object[]]@([single]3500))
$offPowerKw = Invoke-CompiledPower 0 8 3500
$turboPowerKw = Invoke-CompiledPower 1 8 3500
$superchargerPowerKw = Invoke-CompiledPower 2 8 3500
$prochargerPowerKw = Invoke-CompiledPower 3 8 3500
$streetP1XPowerKw = Invoke-CompiledPower 3 20 3500 $false
$highBoostP1XPowerKw = Invoke-CompiledPower 3 24 3500 $true
$zeroBoostPowerKw = Invoke-CompiledPower 1 0 3500
$expectedTurboPowerGainKw = ($dynoTurboTorque - $baseTorque) * 3500 * 0.104719755 * 0.001
$observedTurboPowerGainKw = $turboPowerKw - $basePowerKw
$expectedSuperchargerPowerGainKw = ($dynoSuperchargerTorque - $baseTorque) * 3500 * 0.104719755 * 0.001
$observedSuperchargerPowerGainKw = $superchargerPowerKw - $basePowerKw
$expectedProchargerPowerGainKw = ($dynoProchargerTorque - $baseTorque) * 3500 * 0.104719755 * 0.001
$observedProchargerPowerGainKw = $prochargerPowerKw - $basePowerKw
$zeroBoostTorque = Invoke-CompiledTorque 1 0 3500 1 1
$zeroThrottleTorque = Invoke-CompiledTorque 1 8 3500 0 1

Assert-Pass ($grossTorque -gt $baseTorque -and $baseTorque -gt 0) 'Torque test baseline uses the game CalculateTorque method with friction'
Assert-Pass ($offTorque -eq $baseTorque) 'Off mode leaves the game engine torque unchanged'
Assert-Pass ($turbo8Psi -gt $baseTorque) 'Turbo mode adds torque at positive boost and load'
Assert-Pass ($turboHalfSpool -gt $baseTorque -and $turboHalfSpool -lt $turbo8Psi) 'Turbo torque gain scales with spool fraction'
Assert-Pass ($turboHalfThrottle -gt $halfThrottleBase -and ($turboHalfThrottle - $halfThrottleBase) -lt ($turbo8Psi - $baseTorque)) 'Induction torque gain scales with throttle load'
Assert-Pass ($superchargerTorque -gt $baseTorque) 'Supercharger mode adds torque at positive boost and load'
Assert-Pass ($prochargerTorque -gt $baseTorque) 'Procharger mode adds torque at positive boost and load'
Assert-Pass ($highBoostP1XTorque -gt $streetP1XTorque -and $highBoostP1XPowerKw -gt $streetP1XPowerKw) 'high-boost P-1X produces more torque and power than the 20 psi street kit'
Assert-Pass ($offPowerKw -eq $basePowerKw) 'Off mode leaves the game engine power unchanged'
Assert-Pass ($turboPowerKw -gt $basePowerKw) 'Turbo boost increases the game CalculatePowerInKw result'
Assert-Pass ($superchargerPowerKw -gt $basePowerKw) 'Supercharger boost increases the game CalculatePowerInKw result'
Assert-Pass ($prochargerPowerKw -gt $basePowerKw) 'Procharger boost increases the game CalculatePowerInKw result'
Assert-Pass ([Math]::Abs($expectedTurboPowerGainKw - $observedTurboPowerGainKw) -lt 0.002) 'Dyno power-curve gain matches the sampled torque-curve gain at the same RPM'
Assert-Pass ([Math]::Abs($expectedSuperchargerPowerGainKw - $observedSuperchargerPowerGainKw) -lt 0.002) 'Supercharger power-curve gain matches its sampled torque-curve gain at the same RPM'
Assert-Pass ([Math]::Abs($expectedProchargerPowerGainKw - $observedProchargerPowerGainKw) -lt 0.002) 'Procharger power-curve gain matches its sampled torque-curve gain at the same RPM'
Assert-Pass ($zeroBoostPowerKw -eq $basePowerKw) 'A zero boost target adds no power'
Assert-Pass ($turbo8Psi -gt $turbo4Psi) 'Higher turbo boost target increases calculated torque'
Assert-Pass ($zeroBoostTorque -eq $baseTorque) 'A zero boost target adds no torque'
Assert-Pass ($zeroThrottleTorque -eq $zeroThrottleBase) 'Zero throttle adds no induction torque'

$advanceSpoolMethod = $pluginType.GetMethod('AdvanceSpool', $flags)
$lastEngineField = $pluginType.GetField('lastEngine', $flags)
$lastRpmField = $pluginType.GetField('lastRpm', $flags)
$lastThrottleField = $pluginType.GetField('lastThrottle', $flags)
$currentSpoolField = $pluginType.GetField('currentSpool', $flags)
$spoolTargetField = $pluginType.GetField('spoolTarget', $flags)
$liveBoostField = $pluginType.GetField('liveBoostPsi', $flags)
if ($null -eq $advanceSpoolMethod -or $null -eq $lastEngineField -or $null -eq $lastRpmField -or $null -eq $lastThrottleField -or $null -eq $currentSpoolField -or $null -eq $spoolTargetField -or $null -eq $liveBoostField) { throw 'Compiled time-dependent spool fields or method were not found.' }
function Invoke-SpoolAdvance([int]$Mode, [single]$BoostPsi, [single]$InitialSpool, [single]$Rpm, [single]$Throttle, [single]$DeltaTime) {
    $pluginInstance = New-PluginTestInstance $Mode $BoostPsi $InitialSpool $false
    $script:lastEngineField.SetValue($pluginInstance, $script:engine)
    $script:lastRpmField.SetValue($pluginInstance, $Rpm)
    $script:lastThrottleField.SetValue($pluginInstance, $Throttle)
    $null = $script:advanceSpoolMethod.Invoke($pluginInstance, [object[]]@($DeltaTime))
    return [pscustomobject]@{
        Spool = [single]$script:currentSpoolField.GetValue($pluginInstance)
        Target = [single]$script:spoolTargetField.GetValue($pluginInstance)
        Boost = [single]$script:liveBoostField.GetValue($pluginInstance)
    }
}
$turboTransient = Invoke-SpoolAdvance 1 8 0 5000 1 0.1
$prochargerTransient = Invoke-SpoolAdvance 3 8 0 5000 1 0.1
$superchargerTransient = Invoke-SpoolAdvance 2 8 0 5000 1 0.1
$turboThrottleLift = Invoke-SpoolAdvance 1 8 0.5 5000 0 0.1
$offTransient = Invoke-SpoolAdvance 0 8 0.5 5000 1 0.1
Assert-Pass ($superchargerTransient.Spool -gt $prochargerTransient.Spool -and $prochargerTransient.Spool -gt $turboTransient.Spool) 'supercharger spool responds fastest, with ProCharger between it and turbo lag'
Assert-Pass ($turboTransient.Spool -gt 0 -and $turboTransient.Spool -lt $turboTransient.Target) 'turbo transient spool approaches its target over time instead of jumping instantly'
Assert-Pass ($turboThrottleLift.Spool -lt 0.5 -and $turboThrottleLift.Spool -gt 0 -and $turboThrottleLift.Target -eq 0) 'turbo spool decays progressively after throttle lift'
Assert-Pass ($offTransient.Spool -lt 0.5 -and $offTransient.Boost -eq 0) 'turning induction off unloads spool and clears the boost gauge'

Write-Output ("Spool samples: turbo mid={0:F3}, supercharger idle={1:F3}, procharger mid={2:F3}" -f $turboMid,$superIdle,$proMid)
Write-Output ("Torque samples: base={0:F1}, turbo8={1:F1}, supercharger8={2:F1}, procharger8={3:F1}" -f $baseTorque,$turbo8Psi,$superchargerTorque,$prochargerTorque)
Write-Output ("Power samples: base={0:F2} kW, turbo8={1:F2} kW, supercharger8={2:F2} kW, procharger8={3:F2} kW" -f $basePowerKw,$turboPowerKw,$superchargerPowerKw,$prochargerPowerKw)
Write-Output ("{0} compiled-code spool/torque/power checks passed." -f $passed)
