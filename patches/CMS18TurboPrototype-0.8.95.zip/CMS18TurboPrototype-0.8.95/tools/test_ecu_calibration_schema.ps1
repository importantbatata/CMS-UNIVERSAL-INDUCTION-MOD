$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$work = Join-Path $env:TEMP ('cms18-ecu-schema-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$harness = Join-Path $work 'Harness.cs'
$exe = Join-Path $work 'Harness.exe'
$source = Join-Path $root 'src\EcuCalibrationSchema.cs'
$compat = Join-Path $root 'src\EngineCompatibilityCatalog.cs'
@'
using System;
using CMS18TurboPrototype;
internal static class Harness
{
    private static int checks;
    private static void Check(bool value, string name)
    {
        checks++;
        if (!value) throw new Exception("FAIL: " + name);
        Console.WriteLine("PASS: " + name);
    }
    private static EcuCalibrationRecord Valid()
    {
        return new EcuCalibrationRecord {
            VehicleKey="emden_plate_test", EngineId="engine_r4", HardwareFingerprint="na-stock-v1",
            RpmAxis=new int[]{800,1500,2500}, MapAxisKpaAbsolute=new float[]{30,70,100},
            VolumetricEfficiencyPercent=new float[9], LambdaTarget=new float[]{1,1,1,1,1,1,1,1,1},
            IgnitionTimingDegrees=new float[9], BoostTargetPsi=null
        };
    }
    public static int Main()
    {
        string reason;
        EcuCalibrationRecord r=Valid();
        Check(r.Validate(out reason), "valid record accepted");
        Check(EcuCalibrationRecord.TrySelect(r,"emden_plate_test","ENGINE_R4","na-stock-v1",out reason), "exact identity selected case-insensitively");
        Check(!EcuCalibrationRecord.TrySelect(r,"other_car","engine_r4","na-stock-v1",out reason), "other vehicle rejected");
        Check(!EcuCalibrationRecord.TrySelect(r,"emden_plate_test","engine_v8","na-stock-v1",out reason), "different installed engine rejected");
        Check(!EcuCalibrationRecord.TrySelect(r,"emden_plate_test","engine_r4","turbo-kit-v1",out reason), "changed hardware rejected");
        r=Valid(); r.RpmAxis=new int[]{800,800,2500}; Check(!r.Validate(out reason), "duplicate RPM axis rejected");
        r=Valid(); r.LambdaTarget[0]=Single.NaN; Check(!r.Validate(out reason), "NaN fuel target rejected");
        r=Valid(); r.BoostTargetPsi=new float[]{0,5,41}; Check(!r.Validate(out reason), "out-of-range boost rejected");
        r=Valid(); r.IgnitionTimingDegrees=new float[8]; Check(!r.Validate(out reason), "wrong map dimensions rejected");
        Console.WriteLine("Assertions: " + checks);
        return 0;
    }
}
'@ | Set-Content -LiteralPath $harness -Encoding ASCII
& $compiler /nologo /target:exe "/out:$exe" $source $compat $harness
if ($LASTEXITCODE -ne 0) { throw 'ECU schema test harness did not compile.' }
& $exe
if ($LASTEXITCODE -ne 0) { throw 'ECU schema tests failed.' }
Remove-Item -LiteralPath $work -Recurse -Force
