# CMS 2018 Forced Induction Expansion — Existing Project Audit

**Audit basis:** existing `installable_part_fix` source, build scripts, model assets, targeted `Assembly-CSharp-firstpass.dll` IL audits, build validator, saved test artifacts, prior user live-test reports, and the expansion specification supplied on 2026-11-04.

**Current built patch:** 0.8.87 is compiled and installed. Its shop-card visibility fix is supported by the user's latest live screenshots showing the standard P-1X in Main Shop and the 32 PSI P-1X in Tuning Shop. Other features remain subject to their individual live-test status below; no broad expansion feature should be treated as complete based on those shop screenshots.

## Feasibility and verified game integration

This is an existing BepInEx/Harmony plugin. The canonical source is `src/CMS18TurboPrototype.cs`; `build.ps1` compiles that file against local CMS 2018 Unity/game assemblies and embeds the ProCharger OBJ. The installable package is built from `build/CMS18TurboPrototype.dll`. The plugin does not permanently edit `Assembly-CSharp.dll`.

The following game targets have been checked against the local game assemblies and are also asserted by `tools/validate_build.ps1`:

| Verified class/method | Existing mod use |
|---|---|
| `VehiclePhysics.Engine.CalculateTorque` | Active dyno sampling hook for torque. |
| `VehiclePhysics.Engine.CalculatePowerInKw` | Power hook derived from the sampled torque delta. |
| `CarEngineHelper.DrawPowerTorqueChart` | Dyno chart sampling context. |
| `DynoManager.PrepareDyno` | Dyno lifecycle context. |
| `GameManager.ActionInsertEngineToCar` | Crane insertion tracking. |
| `CarLoader.SwapEngine` | Engine replacement tracking. |
| `CarLoader.GetEngine`, `CarLoader.GetRoot` | Current engine/vehicle lookup and transfer recovery. |
| `GameScript.GetGroupOnEngineStand`, `SetGroupOnEngineStand` | Stand selection/settings. |
| `PieMenuController.ReadOptionsFromIni` | Forced-induction radial option. |
| `GameInventory.GetItems`, `GetGO`, `GetGO2`, `GetItemProperty`, `GetThumb` | Shop/part registration and preview plumbing. |
| `PartScript.TunePart`, `GetIDWithTuned`, `IsUnmounted` | Virtual-mount selection and CMS part lifecycle. |
| `Raycast.Update` selection behavior | Layer 16 is required, and the hit collider itself must carry `PartScript`. |

Unity framework assemblies provide rendering, input, scene, and physics primitives; the verified engine construction and dyno behavior lives in CMS gameplay assemblies. The plugin uses `PlayerPrefs` namespaced by selected profile for mod-specific per-car settings and kit identity, and stores stand mode/boost metadata on the engine group. The universal mount is runtime-created, not a native saved inventory item; the mod reconstructs it from its profile-scoped car kit record on load. That lifecycle is a key risk and explains why transfer must be verified before adding additional part state.

Relevant source evidence is in `docs/Assembly-CSharp-firstpass-audit.md`, `docs/firstpass-selection-IL.txt`, `docs/carloader-identity-IL.txt`, `docs/dyno-firstpass-IL.txt`, and `docs/dyno-assembly-IL.txt`. IL dumps are evidence for static method/field behavior, not proof of live behavior.

## Feature status against the supplied specification

| Spec area | Status in existing project | Limits / next work |
|---|---|---|
| Single turbo | **Partial prototype.** Buyable CMS Turbo Kit, native CMS turbo visual copy, boost/spool calculation, radial selection, generic virtual mount. Patch 0.8.81 adds the first explicit response profile for the verified base `engine_r4` I4 DOHC AQC; patch 0.8.82 adds an in-game 35/45/55/62/67/76/88 mm modeled inducer selector. The setting persists globally, per stand engine group, and per identified car, and affects estimated spool, efficiency, and airflow ceilings. | This remains a virtual kit and coarse model, not a complete physical conversion. There is no matched turbo manifold, downpipe, oil feed/return, intercooler, separate charge piping, wastegate, component SKU selection, or verified install/remove/save/reload cycle. All generic tier flow, efficiency, and spool values are estimates, not measured compressor maps or in-game measurements. |
| Twin/sequential/compound/twincharged turbo | **Missing.** | No separate hardware, bank assignment, staged control, or coordinated boost. Keep disabled until single turbo is verified. |
| Roots supercharger | **Partial prototype.** Buyable mode and copied native CMS Roots visual; simple mechanical-speed response. | No engine-specific lower intake, bypass, snout/pulley selection, or real installation dependencies. |
| Twin-screw supercharger | **Missing.** | No asset, kit, distinct response model, or mounting implementation. |
| Centrifugal / ProCharger | **Partial prototype.** Standard $12,500 Main Shop P-1X, $24,900 high-boost Tuning Shop P-1X (up to 32 psi), custom OBJ, brackets/belt/ducts, purchase entry, and prior user-confirmed dyno gains. | Transfer into a car is the active unresolved live bug; fitment is approximate. Interchangeable pulley, oil/cooling, installation dependency, and full save/load state are absent. |
| Engine-specific mounting / compatibility | **Partial.** Engine-local placement, pulley/intake/air-filter discovery, carburetor detection/gating, and per-car identity safeguards. Patch 0.8.81 starts a catalog with one verified base-engine identifier (`engine_r4`, localized as I4 DOHC AQC). | No verified geometry/clearance profile, displacement, fuel-system metadata, installable hardware compatibility, or other engine entries. Do not infer universal fitment from this first entry. |
| Boost and performance model | **Partial.** Boost target UI, patch 0.8.82 modeled turbo size/spool/flow tiers, centrifugal speed-squared approximation bounded by published P-1X limits, compressor heat/density and intercooler-efficiency assumptions, belt-drive losses, boost gauge, and active-car-scoped dyno torque/power sampling. | No verified turbo compressor maps; 0.8.82 diameter tiers are assumptions. No exhaust backpressure, selectable intercooler/heat soak, fuel or ignition limits, knock model, or separate live achieved-boost map. Earlier live tests reported unchanged curve shape. |
| Intercoolers, charge piping, valves, wastegates, controllers | **Partial visuals only for ProCharger tubing.** | The required selectable, separately purchasable and installable hardware and dependency checks do not exist. |
| Pulley system | **Partial visual/model.** Fixed P-1X drive alignment and belt/tensioner geometry are generated. | No interchangeable diameter inventory, crank pulley compatibility, belt slip/overspeed response, or wear. |
| Engine durability / failure | **Missing.** | No progressive CMS-condition-linked wear, component damage, failure states, or realism setting. |
| Supporting internals / fuel / cooling upgrades | **Missing.** | No supporting upgrade inventory or gameplay effect. |
| Shop / kits | **Partial.** Existing Main Shop/Tuning Shop registration for the four current prototype products. | No Forced Induction & Performance category, component catalog, engine compatibility explanation, included-part kits, or assisted install mode. |
| Installation dependency graph | **Missing.** The current universal virtual mount preserves selection and can restore a visual, but is not a network of physical installation nodes. | Define dependencies only after CMS's actual mount and save constraints for a first real kit are verified. |
| Save/load | **Partial.** Profile-scoped `PlayerPrefs` car identity/mode/boost/kit record and group metadata; reload code recreates the virtual mount. | No versioned schema for the requested multi-part build, component conditions, failures, pulley/controller settings, migration, or uninstall warning. Current transfer behavior is not yet verified under 0.8.80. |
| Audio | **Missing.** | No additional forced-induction audio profiles or volume control. |
| Mods menu / stand UI | **Implemented in prototype.** BepInEx Mods list and stand radial chooser. | Cursor behavior and recent 0.8.80 lifecycle need user live confirmation; not part of the core missing turbo hardware. |
| Automatic engine detection / ECU calibration | **Partial detection only; ECU tuning missing.** The plugin already finds the active `CarLoader`, uses the engine root's actual normalized `engine_…` identifier, and keeps the induction settings scoped to a car identity. Part changes are re-evaluated by the existing context refresh. | No verified CMS ECU map editor, ECU hardware registry, factory fuel/ignition maps, calibration writer, or tuning-screen hook has been identified. The compatibility catalog has one entry (`engine_r4`) for an illustrative boost response model, not a tune. See [ECU Lab and auto-detection audit](ECU-LAB-AUTO-DETECTION-FEASIBILITY.md). |
| Packaging / safety | **Implemented for current patches.** Existing build/install scripts, rollback backups, numbered patch archive, offline validator, profile isolation. | Keep game saves and original assemblies untouched; continue requiring a matching installed/build/package DLL and closed-game install. |

## Incremental development plan

1. **Live-check the current build on `cms18promo`.** Confirm the forced-induction chooser, stand selection, engine transfer, bay visibility/selection, untouched-car isolation, then compare dyno at low and high boost. Capture `BepInEx/LogOutput.log` if transfer or the curve is wrong. The operating-point model affects only the estimated turbo mode; the user's earlier ProCharger transfer issue remains a separate live-only gate.
2. **Verify the first single-turbo target.** Use the locally inspected CMS identifiers and actual engine parts to choose one non-carbureted naturally aspirated engine and one vehicle. Confirm a complete install/remove/save/reload loop while preserving the original engine ID. Don't claim support for other engines based on visual placement alone.
3. **Expand the engine compatibility catalog** from verified game IDs and measured runtime bounds/parts. Keep engine-specific placement and allowed kits in this data layer; unknown engines should report unsupported/unverified rather than inheriting guessed coordinates. Patch 0.8.81 added one engine profile; patch 0.8.82 adds generic modeled turbo size tiers, not new verified engine support. Automatic identity lookup is already used for induction settings, but it is not ECU calibration selection.
4. **Build one true single-turbo dependency chain** on that target: matched exhaust manifold, turbo, downpipe, oil lines, charge piping, intercooler, bypass/BOV and wastegate/controller as feasible within CMS's verified mount system. Make missing connections disable boost and explain why.
5. **Add a versioned mod save-data schema** after the first installable part chain survives CMS save/reload. Migrate existing `PlayerPrefs` and group metadata; do not rewrite original profile saves in place.
6. **Add physical-model layers incrementally:** turbo size and bounded compressor behavior, intercooler heat/pressure drop, then fuel/ignition constraints and durability. Validate each against dyno samples without mutating shared factory engine specs.
7. **Expand to Roots / twin-screw / centrifugal variants, then multi-turbo layouts and audio** only after single-kit compatibility and persistence pass.

## Patch 0.8.83 — numeric-boundary stability repair

The existing performance model accepted NaN and infinity at several numeric boundaries. Invalid values can propagate through RPM normalization, spool, requested airflow ratio, and boost settings; this can produce unusable estimates or corrupt persisted/session settings. Patch 0.8.83 adds finite checks and bounded fallbacks in the existing turbo model and sanitizes stored/selected boost, engine RPM inputs used by the new model, and P-1X speed calculations. It does not change the transfer/reconciliation code, shop registrations, part IDs, or radial-menu implementation.

**Status:** Compiled successfully. Fourteen standalone assertions against the built model passed. Offline build/assembly/resource validator passed; it reports the installed plugin is still 0.8.80 and no 0.8.83 startup log exists. `test_power_curves.ps1` cannot invoke `VehiclePhysics.Engine`'s native `ECall` from an offline process, so runtime torque and dyno behavior are **not tested**. No CMS launch, install, save edit, or gameplay test occurred.

This patch addresses one verified class of calculation defect; it is not a complete audit of every hypothetical runtime failure in the specification. The unresolved physical dependency chain, cross-car/transfer live behavior, real compressor maps, durability, full shop catalog, save-schema migration, and carbed-engine compatibility remain as listed above and in [Patch 0.8.83 report](../build/release_0.8.83/report.md).

## Proposed maintainable layout

The shipped project currently builds one source file and has extensive Harmony/runtime coupling. Avoid a broad refactor during transfer stabilization. After behavior is stable, extract code without changing public IDs or saved keys into:

```text
src/
  PluginEntry.cs                 # BepInEx startup and verified patch registration
  EngineCompatibility.cs         # verified engine IDs, layout and supported kits
  InductionPartDefinitions.cs    # stable part IDs, prices and prerequisites
  InstallationDependencies.cs    # validated physical connection graph
  BoostAndPerformanceModel.cs    # pure calculations independent of Unity UI
  InductionPersistence.cs        # versioned mod-specific schema and migration
  ShopAndInventoryIntegration.cs # CMS GameInventory hooks
  InductionVisuals.cs            # current engine-local model/mesh generation
  InductionUi.cs                 # existing radial chooser, Mods page, tuning UI
model/                            # existing OBJ/MTL and backups
docs/                            # assembly evidence, feasibility and patch reports
tools/                            # existing build, inspection, packaging, validation
```

The current single-file layout is retained until the transfer test passes; splitting it beforehand would add risk without advancing the unresolved gameplay behavior.

## Patch 0.8.81 — expansion kickoff

- Added `src/EngineCompatibilityCatalog.cs` with a single entry for the Emden Lotz base engine (`engine_r4`, localized in the installed car data as I4 DOHC AQC). The separate `engine_r4_turbo` variant is not treated as the naturally aspirated target.
- Connected the profile only to turbo spool calculations for the current active/stand engine and dyno samples. Unknown engines continue using the existing generic calculation. The original engine ID and shared factory engine specifications are not modified.
- The 55 mm compressor tier and .27/.82 spool-fraction thresholds are prototype assumptions based on the user-provided design brief. They are not a measured CMS turbo map, manufacturer map, or verified horsepower result.
- Build succeeded as 0.8.81. Offline validator passed all configured static, assembly-signature, resource, and model checks. It reports that 0.8.80 remains installed. No game launch, live test, save edit, or game-file replacement occurred.
- The remaining major dependency is still a physical single-turbo parts/dependency chain and verified install/remove/save/reload behavior. This kickoff does not fix the previously reported ProCharger transfer issue and does not claim a working complete turbo conversion.

## Patch 0.8.82 — turbo size model increment

- Reused the existing `cms18_turbo_kit`, stand panel, active-car settings, engine-group metadata, and per-car dyno hook. No ProCharger transfer, radial-menu, or stock factory-spec path was changed.
- Added seven compressor-inducer tiers (35–88 mm) with the specification's illustrative horsepower bands, assumed flow ceilings, assumed compressor efficiencies, and tier-specific spool curves. They are clearly presented as modeled estimates because no validated compressor maps are present in the project or local game assets.
- Added size selection to the existing turbo stand and tuning panels. Size is retained in profile-scoped `PlayerPrefs`, engine-group metadata for crane transfer, and per-car settings.
- The active turbo torque calculation now uses tier efficiency and a coarse airflow-density ceiling. Factory specs are not edited. It is not a calibrated engine model and does not require physical manifold/oil/downpipe/intercooler nodes yet.
- Build, static validator, and offline compiled-code model checks passed. Installed patch remains 0.8.80; no game launch, live test, save edit, or game-file replacement occurred.
- Remaining core gate: implement and verify a genuinely engine-specific turbo installation path and persist installed components across the complete crane/car/save cycle. Do not infer that the new selector makes every engine physically compatible.

## Patch 0.8.83 — numeric-boundary stability repair

Patch 0.8.83 added finite checks to the existing boost, spool, compressor-speed, and airflow estimate boundaries. Build, 14 compiled-model assertions, and the offline game-signature/resource validator passed. The native engine calculation could not run outside the game because CMS uses an ECall. Installed version remained 0.8.80; no game launch or install occurred. It did not change the transfer, shop, radial-menu, or visual mounting paths.

## Patch 0.8.84 — bounded charge-air estimate

The existing dyno torque estimate used compressor heating and an assumed intercooler effectiveness but treated compressor target pressure as manifold pressure. Patch 0.8.84 extracts that calculation into `src/ChargeAirModel.cs`, applies an estimated intercooler pressure loss, and passes the resulting estimated manifold air-density ratio into the existing torque delta calculation. It preserves existing part IDs, shop entries, saved-setting keys, mounts, and Harmony targets. The default pressure loss/effectiveness are generic estimates, not measurements, and no separate intercooler purchase/install item is added.

**Status:** build succeeded; 11 standalone assertions for zero boost, pressure loss, cooling, density, compression heat, invalid inputs, and bounded output passed; 14 existing turbo-size/input assertions passed; offline game-signature/resource validator passed. The full power-curve script reaches its native CMS engine invocation and fails outside CMS because its ECall method must run in a system module. Thus native torque/dyno behavior is **not verified**. Patch 0.8.84 is now installed with a rollback copy; CMS was not launched. No save edit occurred. The release and detailed test result are in [Patch 0.8.84 report](../build/release_0.8.84/report.md).

The remaining implementation is still extensive: actual transfer verification/fix, complete installable dependency chains, selectable intercooler/wastegate/BOV/controller parts, verified non-DLC engine catalog, carbureted turbo rules, multiple turbo/supercharger configurations, pulley hardware, engine durability/failure, complete save schema, and live dyno validation. None should be marked complete from this calculation-only increment.

## Verification state

Static method-signature, IL, mesh, package, offline build, and isolated model checks passed for the 0.8.85 deliverable. They do not prove live transfer, selection, save/reload, dyno response, engine compatibility, or untouched-car isolation. No CMS run is claimed by this audit.

## Patch 0.8.85 — flow-aware turbo operating point

Patch 0.8.85 extends the existing turbo tier and charge-air path. At each sampled RPM/load point, it estimates delivered compressor pressure using the target and existing spool estimate, then limits charge density by the selected tier's illustrative maximum flow. Estimated compressor efficiency varies with pressure ratio and distance from the assumed operating-flow region. The bounded resulting charge state feeds the torque delta; the active boost gauge uses the same estimated delivered compressor pressure.

This does **not** use real turbo maps, verified engine displacement, measured ambient/charge temperatures, or selectable intercooler data. Flow ceilings, efficiencies, and fixed intercooler behavior remain stated estimates. A tier that is smaller than the estimated baseline engine flow can return nearly zero modeled boost; this is intended as an undersized-compressor limitation, not an engine-strength estimate. There is still no true physical turbo manifold/oil/downpipe/intercooler/dependency chain. No CMS launch or live dyno is claimed.

**Verification:** C# build passed. Eleven isolated turbo operating-point assertions passed, alongside the existing 11 charge-air and 14 turbo-tier checks. The offline validator passed its game method signatures, model/resource, UI, shop, and packaging checks; it reported the previous 0.8.84 runtime still installed during validation. `test_power_curves.ps1` is not evidence of native dyno behavior because CMS's internal `VehiclePhysics.Engine` call cannot execute in the offline host. The patch archive is [release_0.8.85](../build/release_0.8.85/).

**Install state (2026-11-04):** After the offline validator run, the 0.8.85 DLL was installed to the existing BepInEx plugin location with the install script's replace-and-backup option. The installed DLL's SHA-256 matches the built DLL (`357FA3A3C3A50053E0BC347E8974E8FD82C8776D005EB1BC4ABAE579C4FFF907`); the prior plugin was preserved as `build/installed-backups/CMS18TurboPrototype-20261104-202223.dll`. CMS was not launched. No live test, save edit, or in-game validation was performed.

## Patch 0.8.86 — transfer-time visible-mesh locator

The 0.8.85 live log shows the exact crank pulley and intake parts in the engine hierarchy, but CMS reports `IsUnmounted() == true` while the engine is being transferred/reconciled. The visual placement helpers treated that flag as absence, so the ProCharger fell back to a coarse whole-engine bounds estimate. Patch 0.8.86 keeps CMS installation state untouched and permits a part marked unmounted as a **visual reference only** when it has active, enabled renderer geometry. Mounted matches still win over equally ranked transfer-time candidates. The same rule is used for crank pulley, intake, and air-filter visual targets.

This targets the root cause shown in the log; it does not guarantee fitment on every engine. It does not add physical install nodes, turbo hardware, or make the synthetic kit a native CMS assembly. Unknown engine geometry still needs live inspection and verified compatibility entries.

**Expansion status:** Existing partial systems include turbo-size/flow and charge-air estimates, per-car scoping safeguards, shop entries, Mods menu, and visual induction setup. The requested full expansion is **not complete**: twin-turbo, sequential/compound, Roots/twin-screw hardware, a physical single-turbo dependency chain, selectable wastegates/BOV/intercoolers/pulleys, durability/failure, a broader verified engine catalog, and versioned full-build save persistence remain missing or partial. The next expansion milestone is a verified physical single-turbo dependency chain on one supported original engine, after this transfer/placement repair is live-tested.

**Verification:** C# compilation passed. Offline model and signature/resource/package checks are recorded in the 0.8.86 report. CMS was not launched; transfer placement, shop behavior, dyno response, save/reload, and untouched-car isolation remain live-test items.

# ECU and calibration work — development patch 0.8.88

The supplied ECU Lab v1.11.0 archive was reviewed; it is a standalone MIT-licensed simulator and does not provide a CMS C# integration library or CMS tune interchange format. Patch 0.8.88 adds only a mod-owned versioned calibration record and strict identity/data validation. Automatic ECU UI selection, persistence, actual map application, and gameplay performance response are still not implemented. The installed game remains on 0.8.87; the 0.8.88 build is not installed or live-tested. See [ECU Lab feasibility](ECU-LAB-AUTO-DETECTION-FEASIBILITY.md) and [patch report](../build/release_0.8.88/report.md).

# ECU Lab simulation sandbox port — development patch 0.8.89

Per the clarification that ECU Lab is a simulation sandbox, patch 0.8.89 adds an isolated C# port of selected engine simulation equations: geometry, charge thermodynamics, trapped air mass, and parasitic friction/torque. The 23-assertion reference harness compares its outputs with ECU Lab v1.11.0 JavaScript modules. The port is not wired to CMS performance hooks, so it does not yet affect the in-game dyno. The full combustion-cycle/per-point solver remains unported. Build, isolated simulation assertions, existing induction/calibration assertions, and offline validator pass. The built patch was not installed and CMS was not launched. See [simulation port report](../build/release_0.8.89/report.md).


## Patch 0.8.94 follow-up — radial-menu non-interference

User feedback confirmed the gearbox tuning action remained unavailable after the earlier separate ECU Lab radial insertion. Patch 0.8.94 removes all ECU Lab option insertion/selection logic from the shared car-parts radial and opens the existing sandbox with F9 instead. The forced-induction action remains limited to the engine-stand menu. Build and offline checks passed; CMS was not launched, so actual coexistence with the gearbox-tuning mod remains to be confirmed live.

Expansion work remains incremental: 0.8.93's single-turbo component/connection validator is included, but still has no call site in CMS installation. The next substantial dependency is verifying and registering actual CMS-native part/install identifiers before attempting to use the model to gate boost. The full expansion is not complete.

## Patch 0.8.95 — read-only automatic engine identity for the simulation sandbox

An engine-identity catalog now covers 58 IDs present in the local vehicle config data and uses English localization labels when available. The existing active-engine-root lookup feeds the ECU Lab sandbox; I4/I6/V6/V8 identities choose the matching available sandbox layout, while recognized unsupported layouts are identified without being coerced into an unsupported model. Cloned IDs are normalized. Bore, stroke, compression, clearance, and fitment remain unknown/manual; the identity registry is not an installation compatibility list. This does not implement live ECU tuning or modify the game dyno. Engine catalog tests pass 7/7, and the full current offline regression checks plus validator pass. Patch 0.8.95 is not installed and CMS was not launched; user live confirmation is still required. See `build/release_0.8.95/report.md`.
