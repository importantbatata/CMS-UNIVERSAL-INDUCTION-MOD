# CMS 2018 forced induction and ECU mod — debugging audit

**Date:** 2026-11-05  
**Project version reviewed:** 0.8.87  
**Scope:** Existing `installable_part_fix` project, local game assemblies and logs, current packaged plugin, available calculation checks, and the user's expansion requirements.

## Executive status

This is an existing BepInEx/Harmony plugin, not a new project. It contains a working project/build/package structure, a Mods menu, forced-induction chooser, virtual induction kits, shop listings, visual installation models, per-car induction settings, and experimental sampled dyno torque/power hooks. Prior live reports confirm the two ProCharger shop cards and some engine-stand/car installation behavior in earlier patches. That evidence does not establish the full mechanical dependency system or the broad expansion requested here.

The current project is **not a complete ECU tuning mod**. Automatic engine identification exists only for the existing induction context; there are no player-editable fuel/ignition/boost calibration tables, ECU calibration UI, calibration registry, or safe map-writer. The physical single-turbo assembly chain, full multi-configuration systems, and durability model are also missing. The active dyno path is experimental and cannot be validated by the standalone native-engine reflection test because CMS calls `VehiclePhysics.Engine` through Unity/Mono ECalls. CMS was not launched in this audit.

## Preservation and project inventory

- Project root: `work/installable_part_fix` in the Codex workspace.
- Canonical runtime source: `src/CMS18TurboPrototype.cs`.
- Calculation modules: `src/TurboPerformanceModel.cs`, `src/TurboOperatingPointModel.cs`, `src/ChargeAirModel.cs`, and `src/EngineCompatibilityCatalog.cs`.
- Visual source/assets: `model/` (including P-1X OBJ/MTL) and embedded resource configuration in the project/build script.
- Build/package/deploy/validation: `build.ps1`, `tools/`, `build/release_0.8.87/`, and numbered patch directories.
- Runtime integration: BepInEx plugin with Harmony patches. The project compiles against local CMS/Unity managed assemblies and does not permanently patch the game's `Assembly-CSharp.dll`.
- No Git repository exists in this project directory. Before the audit, a file-level rollback checkpoint was created at `backups/pre_audit_20261105-113812/`, with 44 files and `SHA256-MANIFEST.csv`. This preserves the source, model, tools, and documentation used for review; it does not include or alter user save files.
- Runtime framework/loader versions are read from the local project and installed game artifacts; do not infer that a different Unity editor installation means this BepInEx plugin is built as a Unity project. No Unity asset bundle is built by the current script.

## Baseline build and checks

| Check | Result | Evidence / limits |
|---|---|---|
| Clean project build (`build.ps1`) | **PASS** | Produced `build/CMS18TurboPrototype.dll`. |
| Offline project validator | **PASS with warnings** | Run with profile integrity checks skipped. Source, package asset, assembly signature, and available log checks completed. It cannot prove live CMS behavior. |
| Turbo tier model | **PASS** | 14 assertions (`tools/test_turbo_size_model.ps1`). |
| Charge-air model | **PASS** | 11 assertions (`tools/test_charge_air_model.ps1`). |
| Turbo operating-point model | **PASS** | 11 assertions (`tools/test_turbo_operating_point.ps1`). |
| Integrated power-curve script | **NOT PASS / environment-limited** | After aligning its stale shared-spec-hook checks with current source, 87 preceding assertions passed. The script then attempted CMS's native `VehiclePhysics.Engine.CalculateTorque`; standalone PowerShell reports `ECall methods must be packaged into a system module`. This is not a live dyno result. |
| CMS launch and in-game regression | **NOT RUN** | No game launch, save edits, or live tests in this audit. |
| Shop registration | **UNVERIFIED in this run** | Current runtime log does not prove live shop registration; earlier user screenshots confirm cards in a prior tested version. |

The installed game plugin matched the archived 0.8.87 release DLL, and all five active C# source files matched that release's packaged source. A fresh local compile emitted a different DLL hash because the compiler assigns a new PE module MVID. Therefore identical-version fresh-build hash equality is not a sound validator rule.

## Verified integration evidence

The project validator checks real local CMS targets used by the code, including the torque and power methods and the existing shop, radial, vehicle, and inventory seams. Existing documentation records `PrepareCarPhysics.Get()`, `DynoManager.Get()`, `CarLoader.GetEngine()`, and `CarLoader.GetEngineType()` as inspected active-context lookups. The mod resolves a current engine root identifier for induction behavior. This is not equivalent to verified ECU calibration support or complete engine specification discovery.

The unsafe shared factory-engine specification hook was intentionally removed after live reports showed factory values and other vehicles being contaminated. The current validator was previously requiring a runtime log line for that removed hook. That expectation was removed; factory specifications must remain untouched unless a safe vehicle-specific measured-output hook is proven.

## Defect register

| ID | Severity | Finding and root cause | Repair / verification |
|---|---|---|---|
| AUD-001 | Medium | Validator rejected a valid installed 0.8.87 plugin because a fresh compiler output had a different hash/MVID even though the installed binary matched the packaged release and active source matched. | Updated `tools/validate_build.ps1` to compare the installed DLL to the archived release artifact and compare active source to release source. Offline validator passed. |
| AUD-002 | Low | Validator expected a log message from `GetEngineSpecifications` hook that current source intentionally does not register. | Removed the stale runtime-log expectation. Assembly/source checks and validator passed. |
| AUD-003 | High | Integrated power-curve harness calls CMS's native `CalculateTorque` from a standalone PowerShell process; Unity/Mono ECall is unavailable there. It also attempted to reintroduce the shared factory-spec hook inside its test. | Updated `tools/test_power_curves.ps1` to assert that the current plugin does not register a `GetEngineSpecifications` patch and removed the obsolete test-only patch block. 87 preceding assertions now pass; native torque remains unavailable offline and needs an in-game test. |
| AUD-004 | Critical | Historical live report identified cross-car ProCharger/factory-power contamination in older builds. | Existing project disables the shared engine-spec hook and scopes torque/power changes to a dyno sampling window and active kit context. Static build passes; **current in-game regression remains unverified**. Test untouched car first before dyno. |
| AUD-005 | High | Active engine detection covers induction context only; ECU calibration selection is absent. | Not implemented: no verified player ECU/tuning UI integration point or map application system. Do not display fabricated engine-specific calibrations. |
| AUD-006 | High | Induction kits are virtual/aggregate parts rather than a full physical component and dependency graph. | Not implemented: manifold/turbo/downpipe/oil/charge-pipe/intercooler/wastegate/BOV installation chain and completeness gating are absent. |
| AUD-007 | High | Native dyno response cannot be proved by offline model checks; user reported earlier readings where factory and measured values moved together. | Current code avoids the shared factory-spec path. Live dyno with baseline and modified vehicle is required; no claim of current verified gain. |
| AUD-008 | Medium | Existing status/docs overstate test scope if model assertions are read as in-game acceptance. | Added this audit separating standalone model, validator, and gameplay evidence. |

## Feature status

| Feature | Status | Current evidence / gap |
|---|---|---|
| BepInEx plugin, Harmony startup, build/package | **WORKING offline** | Builds; signature/resource validator completes. Runtime startup from prior logs exists. |
| Mods menu and radial/chooser UI | **PARTIALLY WORKING** | Prior live user confirmation; recent integration state still needs live retest after relevant changes. |
| Main and tuning shop ProCharger cards | **PARTIALLY WORKING** | Prior screenshots show standard $12,500 and High-Boost $24,900; current registration is not established by this audit's runtime log. |
| Visual P-1X and generated piping | **PARTIALLY WORKING** | Prior reports repeatedly describe fitment, orientation, and transfer bugs; current visuals require live inspection. Visual mesh does not prove mechanical connections. |
| Per-car induction mode/boost metadata | **PARTIALLY WORKING** | Existing persistence and isolation logic; full versioned vehicle configuration and multi-part inventory persistence are not present. |
| Engine identification | **PARTIALLY WORKING** | Active induction engine-root detection exists; one explicit compatibility catalog entry (`engine_r4`) is verified. Do not assume broad engine-ID coverage. |
| Turbo sizing/charge-air estimate | **PARTIALLY WORKING** | Pure bounded models and 36 assertions passed. Parameters are modeled estimates, not manufacturer compressor maps. |
| Dyno HP/torque integration | **PARTIALLY WORKING / NOT LIVE-VERIFIED** | Hooks are scoped to dyno sampling; native ECall can't run offline. No current live dyno evidence in this audit. |
| ECU Lab v1.11.0 source reuse | **UNVERIFIED** | Exact source archive fetch/clone failed TLS (`SEC_E_NO_CREDENTIALS`); no source or license was locally reviewed. Repository is described as standalone, not a CMS plugin. |
| ECU UI, calibration registry, fuel/ignition/boost maps | **NOT IMPLEMENTED / hook UNVERIFIED** | No proven player-facing CMS ECU editor or map writer located in prior local scan. |
| Single/twin/sequential/compound turbo hardware | **NOT IMPLEMENTED as full systems** | Current virtual mode prototypes do not implement full mechanical parts/dependencies. |
| Roots/twin-screw/centrifugal hardware | **PARTIAL** | Existing mode/visual prototype only; no complete bracket/manifold/belt/pulley/bypass dependency system. |
| Wastegates, blow-off valves, selectable intercoolers | **NOT IMPLEMENTED as purchase/install systems** | Fixed estimates do not make these physical systems. |
| Durability/knock/failure/repair | **NOT IMPLEMENTED** | No verified integration with CMS part condition for engine stress/failure. |
| Complete shop catalog and kits | **PARTIAL** | Two P-1X items; full categories, kit components, transaction coverage, compatibility filters absent. |
| Full save/load migration | **PARTIAL / NOT VERIFIED** | Existing per-car preferences and group metadata do not satisfy the requested full vehicle-specific calibration/part schema. |
| Live tests and regression | **NOT RUN this audit** | User has to run the game for acceptance. No saves touched. |

## ECU Lab source access

The requested ECU Lab tag was identified as v1.11.0, commit `b9f2327`, through the release page. HTTPS archive/clone requests failed during TLS setup with `SEC_E_NO_CREDENTIALS`. The exact tagged source and license were not available locally, so no code was copied, built, or claimed compatible. The repository README suggests a standalone simulator/browser-oriented project, not a CMS extension; any reuse needs source/license inspection first.

## Changes made in this audit

1. `tools/validate_build.ps1`: validates installed binary against the packaged release and checks active source equivalence instead of requiring fresh-build binary hash equality.
2. `tools/validate_build.ps1`: no longer expects a log line for the intentionally removed shared engine-spec hook.
3. `tools/test_power_curves.ps1`: tests absence of registration for the shared factory-spec patch and removes the obsolete test-only Harmony hook block.
4. Added this audit report. No gameplay source or game installation was changed. The build output was regenerated locally; the game plugin was not reinstalled.

## Prioritized next work

1. **Safety/regression:** on a disposable sandbox, check an untouched car's factory specs and absence of induction before any modified-car dyno. Confirm car identity isolation and current live plugin version.
2. **Dyno correctness:** capture one untouched baseline and one kit-equipped run; compare factory versus measured outputs, curve shape, boost target/achieved values. Do not re-enable the shared engine-spec hook.
3. **Harness cleanup:** remove stale spec-hook expectations and split pure calculation tests from CMS-native ECall integration. Use a verified mocked/base-torque seam for deterministic standalone tests; leave the actual Harmony integration to a live game run.
4. **ECU feasibility:** obtain the exact ECU Lab v1.11.0 archive and license locally; continue inspecting CMS scene/prefab/assembly call paths for a real player tuning interface. No guessed hook.
5. **Calibrations:** first implement a mod-owned, versioned, read-only engine/hardware diagnostic context keyed by vehicle plus installed-engine identity; only add editable maps once real map axes and performance application are verified.
6. **Physical system:** replace the aggregate prototype only incrementally, preserving part IDs and save metadata, starting with one verified engine and one single-turbo dependency chain.
7. **Durability and advanced configurations:** defer twin/sequential/compound systems and engine damage until single-turbo installation, boost, dyno, and persistence pass.

## Manual live validation checklist

CMS was not launched. When testing is available:

1. Confirm the running plugin version in the BepInEx log.
2. Load an untouched car first; verify no induction part appears and factory engine values are unchanged.
3. Open the shop and confirm each expected card and price. Do not infer purchase/installation success from a card alone.
4. Verify a modified car's installed kit is visible/selectable and isolated from another vehicle.
5. Record factory and measured dyno HP/torque at the same RPM and take a baseline screenshot/log.
6. Change boost on the equipped car and verify measured results/curve change while factory values remain fixed.
7. Save/reload only a sandbox vehicle, then repeat visibility and isolation checks.

Stop if an untouched car receives a kit or factory specifications change. Do not test on the user's only production save.
# ECU expansion update — development patch 0.8.88

ECU Lab v1.11.0 is now present under `third_party/` and reviewed. Its license is MIT; it is a JavaScript/React/Electron simulator with no CMS bridge or C# library found in the inspected source. Added `src/EcuCalibrationSchema.cs`, which validates an explicit, vehicle/engine/hardware-keyed map record without providing factory values or applying it to the game. The build and schema checks passed. Existing model checks passed. The full offline validator passed its static/source checks and reports expected not-installed/runtime-log warnings. The installed plugin remains 0.8.87. No game launch or save changes occurred. Detailed status is in [ECU-LAB-AUTO-DETECTION-FEASIBILITY.md](ECU-LAB-AUTO-DETECTION-FEASIBILITY.md).

# ECU Lab simulation sandbox port — development patch 0.8.89

The earlier source-access limitation is historical and superseded: the exact ECU Lab v1.11.0 source archive is available locally and its MIT license has been reviewed. The user clarified that ECU Lab is wanted as a simulation sandbox, not a tuning tool. Patch 0.8.89 ports a selected equation subset into `src/EcuLabSimulationCore.cs`, including geometry, charge thermodynamics, trapped-air mass, and friction torque. The isolated reference test passes 23 assertions; existing turbo, charge-air, operating-point, calibration-schema, and map-evaluator tests pass; the build and offline validator pass. The C# module remains isolated from CMS power hooks. It does not yet port `point.js` or the full cycle solver and does not alter dyno output. The build is not installed and CMS was not launched. See the [0.8.89 report](../build/release_0.8.89/report.md).

