# ECU Lab v1.11.0 simulation sandbox port

**Reviewed:** 2026-11-05  
**CMS mod baseline:** 0.8.87  
**Source archive:** `third_party/ecu-lab-1.11.0.zip`  
**SHA-256:** `77BE9F5E108CEFEA1226EA53CA8749DF586C7D4E9D330786055026C79BDB57DE`

## What ECU Lab actually provides

The local source archive identifies itself as ECU Lab `1.11.0`, MIT licensed. Its license requires retaining the copyright and permission notice when redistributing substantial portions. Version 0.8.89 ports selected equations from the JavaScript simulation core into a clean-room C# implementation; it does not vendor the JavaScript application code. The full notice is preserved with the source archive under `third_party/ecu-lab-1.11.0/LICENSE`.

ECU Lab is a standalone JavaScript/React/Electron **engine-simulation sandbox** with a simulation core and a separate editable calibration state. It is not a CMS plugin or C# library. This project is porting the simulation mathematics, not treating ECU Lab as a tuning editor. The application also has editable calibration tables, but those are not being imported or used as CMS tunes. Its storage adapter and presets belong to its own simulator; they are not CMS vehicle/save formats or verified CMS factory specifications.

That means a safe direct application-level integration is not currently available. The simulation source is being used as a mathematical reference and the subset below is reimplemented in C#. No ECU Lab sample tune is applied to a game engine.

## Verified CMS integration points

The existing plugin already has an active `CarLoader` lookup using `PrepareCarPhysics.Get()` and a dyno fallback. It resolves the current installed engine root name through `CurrentEngineIdentifier()` and has per-car identity scoping for induction preferences. Those were implemented for the induction system, not an ECU interface.

The local game-code audit has verified `CarLoader.GetEngine()` and `GetEngineType()` as lookup methods and `BuildCarIdentityKey(loader)` as the mod's stable vehicle-key builder. It has not found a verified player ECU screen, engine-specific ECU table source, calibration writer, or safe game save-data extension for these maps. The existing torque and power Harmony hooks are experimental and depend on a CMS/Unity native ECall that cannot run in an ordinary desktop test process.

## What was implemented in this pass

Patch 0.8.89 adds `src/EcuLabSimulationCore.cs`, an isolated C# simulation module. It includes architecture/geometry derivation, compressor charge heating and intercooler cooling, residual fraction and trapped-charge temperature mixing, fuel-evaporation cooling, exhaust temperature estimate, inlet-Mach/VE adjustment, trapped air mass by the ideal gas law, and ECU Lab rubbing/pumping friction plus friction torque. Source references are ECU Lab v1.11.0 `src/sim/engine.js`, `thermo.js`, `cycle.js`, and `friction.js`. Twenty-three assertions compare results to JavaScript reference outputs or validate rejected inputs. It is not called by CMS gameplay hooks and does not change dyno or car power yet.

Not ported: the full per-point engine solve (`point.js`), two-zone combustion cycle (`cycle.js` integration), fuel/ignition/knock, turbo transient simulation, live state, audio, nor ECU Lab's broader systems. Treat this as the first validated model slice, not a complete simulator.

`src/EcuCalibrationSchema.cs` adds a mod-owned schema version 1 record. It contains vehicle identity, installed-engine identity, hardware fingerprint, RPM and absolute-MAP axes, VE, lambda target, ignition timing, and optional boost curve. Validation rejects unsupported schema versions, missing identities, malformed axes, mismatched table sizes, NaN/infinity, and values outside the declared conservative data bounds. A record can be selected only when the vehicle, installed engine, and hardware fingerprint match exactly (case-insensitive identity comparison).

`src/EcuMapEvaluator.cs` adds a deterministic RPM/absolute-MAP bilinear sampler for VE, lambda, ignition, and optional boost targets. It clamps requests outside the table axes to the edge and rejects non-finite inputs. Eight standalone assertions cover interpolation, clamping, invalid inputs, and naturally aspirated records without a boost map.

This remains a data/evaluator foundation only. It has no factory tune defaults, save writer, ECU UI, automatic live hardware fingerprint builder, or performance application path. It cannot yet change CMS behavior. Exact hardware-signature derivation, calibration persistence, and a verified ECU/game integration point remain prerequisites before records can be authored or applied.

## Current feature status

| Capability | Status | Evidence / limit |
|---|---|---|
| ECU Lab v1.11.0 source and license review | **Complete** | Local archive metadata, README, license, table source, and storage adapter inspected. |
| Selected simulation equations ported to isolated C# | **Implemented in 0.8.89** | Geometry, charge thermodynamics, trapped-air mass, and friction model; 23 JavaScript-reference/invalid-input assertions. Not connected to CMS gameplay. |
| Active vehicle lookup | **Implemented for induction** | Existing plugin path, not wired to an ECU UI. |
| Installed engine ID lookup | **Implemented for induction context** | Current engine root ID extraction; not complete factory specification discovery. |
| Calibration schema and numerical/identity validation | **Implemented in this pass** | Standalone C# model and 9 assertion harness checks. |
| Calibration map evaluation | **Implemented as an isolated model** | RPM/absolute-MAP bilinear sampler; 8 assertions. Not connected to CMS performance. |
| Automatic ECU interface selection | **Not implemented** | No verified CMS ECU UI hook. |
| Fuel/ignition/boost map editing | **Not implemented** | No verified CMS map application pipeline. |
| Calibration save/load | **Not implemented** | No mod-owned serializer/store wired; existing PlayerPrefs hold induction settings only. |
| ECU Lab tune import/export | **Not implemented** | Not in the requested simulator-port scope; no CMS interchange format is established. |
| Power response to player ECU maps | **Not implemented** | Existing induction performance path is not a general ECU map evaluator. |

## Next implementation sequence

1. Identify a real CMS scene or UI that can host tuning controls, then verify its class, method signatures, and lifecycle in local assemblies/call sites.
2. Build a hardware fingerprint from actual installed parts using verified data; keep unknown parts explicit and refuse application when a signature cannot be formed.
3. Add a safe, versioned mod-owned serializer with atomic writes and migration tests. Keep it separate from CMS saves until a supported extension point is verified.
4. Bind the record selector to the current `CarLoader`, current installed engine ID, and actual hardware signature. Switching context must invalidate the previous selection.
5. Implement map editing and performance effects only after the game-side calculation boundary is verified. Unsupported engines should show diagnostics, not inherit another engine's tune.
6. Consider an explicit ECU Lab import/export converter only after defining units, axis ordering, and validation. Converting ECU Lab's descending MAP axis to an ascending internal axis must be deliberate and tested.

## Verification performed

| Check | Result |
|---|---|
| ECU Lab archive version/license/content | **Inspected** — package says 1.11.0 and MIT. |
| ECU Lab code copied into mod | **No** — avoids unnecessary license coupling. |
| Schema assertions | **Passed: 9** — valid record, exact matching, vehicle/engine/hardware mismatch, duplicate RPM, NaN fuel, out-of-range boost, wrong dimensions. |
| CMS plugin compilation | **Passed cleanly** — generated `build/CMS18TurboPrototype.dll` for development version 0.8.88. |
| Offline project validator | **Passed** — source, installed-game signatures, assets, and profile checks; expected warnings say 0.8.88 is not installed and the latest runtime log is from 0.8.87. |
| C# simulation subset | **Passed: 23** — reference values compared to ECU Lab v1.11.0 JavaScript modules; invalid absolute pressure and negative RPM rejected. |
| Live ECU interface / vehicle save-load | **Not run** — this port is not connected to a CMS ECU UI or map application; CMS not launched. |

## Backup and scope

The 0.8.89 changes were made on top of the existing 0.8.88 calibration foundation; the separate simulation core was wired into the existing build. The pre-port backup is `backups/pre_ecu_lab_sim_port_20261105-161351/`. No game assembly, installed plugin, player save, or third-party ECU Lab source was modified. The project folder is not a Git working tree, so the verified file backup is the rollback point for this pass.

