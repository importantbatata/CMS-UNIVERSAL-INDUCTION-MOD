# Existing project inventory — 2026-11-04

This records the existing project tree at the end of the audit: **1441 files**. The CSV lists relative path, extension, and byte size for each file. The two inventory files are omitted from the CSV to avoid self-reference; the pre-audit snapshot is outside the project tree and excluded.

| Extension | Count |
|---|---:|
| `.dat` | 932 |
| `.dll` | 115 |
| `.md` | 92 |
| `.obj` | 90 |
| `.ps1` | 86 |
| `.txt` | 55 |
| `.cs` | 31 |
| `.zip` | 14 |
| `.log` | 9 |
| `.mtl` | 8 |
| `.fm` | 5 |
| `.json` | 3 |
| `.vdf` | 1 |

Primary areas: `src/` (3 current C# files); `model/` (OBJ/MTL meshes and model backups); `tools/` (PowerShell build, assembly inspection, validation and calculation checks); `build/` (compiled plugin, historical patch archives, rollback records and 0.8.83 review package); `docs/` and root Markdown/text (audit, patch/live-test history); `profile3/` and `save_backup/` (preserved test/profile data, not edited).

Build evidence and runtime limits are summarized in [Patch 0.8.83 report](../build/release_0.8.83/report.md). This folder is not a Git checkout. A full pre-audit copy and SHA-256 manifest provide the recovery checkpoint.
