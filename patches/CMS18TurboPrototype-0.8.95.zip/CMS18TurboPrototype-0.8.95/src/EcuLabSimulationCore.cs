using System;

namespace CMS18TurboPrototype
{
    /// <summary>
    /// C# port of selected ECU Lab v1.11.0 standalone simulation equations.
    /// Source project: https://github.com/DNiev/ecu-lab (MIT; Caribou Tuning and Turtle.GTI).
    /// This is an isolated simulation sandbox module, not a CMS ECU/tuning integration.
    /// Port scope: engine-architecture derivation, charge thermodynamics, trapped air,
    /// and parasitic friction estimates. Not the full ECU Lab combustion-cycle solver.
    /// </summary>
    internal static class EcuLabSimulationCore
    {
        internal const float AmbientKelvin = 298.0f;
        internal const float BarometricKpa = 101.325f;
        internal const float PsiToKpa = 6.895f;
        internal const float GammaExponent = 0.286f;
        internal const float CompressorIsentropicEfficiency = 0.70f;
        internal const float IntercoolerEffectiveness = 0.70f;

        internal const float ResidualBase = 0.04f;
        internal const float ResidualCompressionReference = 10.5f;
        internal const float ResidualPerOverlapDegree = 0.004f;
        internal const float ResidualLoadExponent = 1.15f;
        internal const float ResidualMaximum = 0.35f;
        internal const float ResidualTemperatureKelvin = 1050.0f;
        internal const float ChargeSpecificHeat = 1005.0f;
        internal const float GasolineLatentHeat = 350000.0f;
        internal const float EthanolLatentHeat = 760000.0f;
        internal const float FuelEvaporationFraction = 0.60f;
        internal const float ExhaustBaseKelvin = 590.0f;
        internal const float ExhaustLoadSpanKelvin = 714.0f;
        internal const float ExhaustLoadScale = 0.48f;
        internal const float ExhaustPerRetardKelvin = 14.0f;
        internal const float ExhaustRichCoolingKelvin = 420.0f;

        internal const float CamBaseDuration = 210.0f;
        internal const float DefaultRedlineRpm = 7500.0f;
        internal const float AirGasConstant = 287.0f;
        internal const float RubbingBasePa = 45000.0f;
        internal const float RubbingPerRpmPa = 6.5f;
        internal const float SpringRpmBias = 0.6f;
        internal const float BearingFmepPerMainPa = 3000.0f;
        internal const float BalanceShaftFmepFraction = 0.06f;

        internal sealed class EngineInput
        {
            internal string Configuration { get; set; }
            internal float BoreMm { get; set; }
            internal float StrokeMm { get; set; }
            internal float Compression { get; set; }
            internal bool CastIronBlock { get; set; }
            internal bool CastIronHead { get; set; }
            internal float? CamDurationDegrees { get; set; }
            internal float? SpringRate { get; set; }
            internal float? RedlineRpm { get; set; }
        }

        internal sealed class EngineState
        {
            internal int CylinderCount;
            internal float DisplacementLitres;
            internal float BoreStrokeRatio;
            internal float Compression;
            internal float BoreMm;
            internal float StrokeMm;
            internal float BoreFlameFactor;
            internal float ChamberOffsetKelvin;
            internal float TorqueScale;
            internal float BearingWearMultiplier;
            internal string Character;
            internal float PerCylinderLitres;
            internal float CamDurationDegrees;
            internal float SpringRate;
            internal float OverlapDegrees;
            internal float ValveFloatRpm;
            internal float SpringFrictionPa;
            internal float BearingFrictionPa;
            internal float BalanceShaftFrictionFraction;
            internal float RedlineRpm;
        }

        internal static bool TryDeriveEngine(EngineInput input, out EngineState result, out string error)
        {
            result = null;
            error = String.Empty;
            if (input == null) { error = "Engine input is missing."; return false; }
            int cylinders = CylinderCount(input.Configuration);
            if (cylinders == 0) { error = "Engine configuration is not supported by this ECU Lab port."; return false; }
            if (!Finite(input.BoreMm) || !Finite(input.StrokeMm) || input.BoreMm <= 0 || input.StrokeMm <= 0
                || !Finite(input.Compression) || input.Compression <= 1.0f)
            { error = "Bore, stroke, and compression must be finite positive engine geometry."; return false; }

            float displacement = (float)(Math.PI / 4.0 * input.BoreMm / 10.0 * input.BoreMm / 10.0
                * input.StrokeMm / 10.0 * cylinders / 1000.0);
            float ratio = input.BoreMm / input.StrokeMm;
            float duration = input.CamDurationDegrees.HasValue && Finite(input.CamDurationDegrees.Value)
                ? input.CamDurationDegrees.Value : CamBaseDuration;
            float springRate = input.SpringRate.HasValue && Finite(input.SpringRate.Value)
                ? input.SpringRate.Value : 50.0f;
            float redline = input.RedlineRpm.HasValue && Finite(input.RedlineRpm.Value)
                ? input.RedlineRpm.Value : DefaultRedlineRpm;
            float overlap = CamOverlapDegrees(duration);
            float springPa = SpringFrictionPa(springRate);
            float bearingFriction = (MainBearingCount(input.Configuration) - 4.0f) * 3000.0f;
            bool balanceShafts = input.Configuration == "I4" && displacement >= 1.8f;

            result = new EngineState();
            result.CylinderCount = cylinders;
            result.DisplacementLitres = displacement;
            result.BoreStrokeRatio = ratio;
            result.Compression = input.Compression;
            result.BoreMm = input.BoreMm;
            result.StrokeMm = input.StrokeMm;
            result.BoreFlameFactor = input.BoreMm / 92.0f;
            result.ChamberOffsetKelvin = input.CastIronHead ? 22.0f : 0.0f;
            result.TorqueScale = displacement / 3.5f;
            result.BearingWearMultiplier = input.CastIronBlock ? 0.85f : 1.0f;
            result.Character = ratio > 1.08f ? "Oversquare — revs and breathes higher"
                : ratio < 0.95f ? "Undersquare — stronger low-end torque" : "Square — balanced";
            result.PerCylinderLitres = displacement / cylinders;
            result.CamDurationDegrees = duration;
            result.SpringRate = springRate;
            result.OverlapDegrees = overlap;
            result.ValveFloatRpm = ValveFloatRpmFor(springRate, duration);
            result.SpringFrictionPa = springPa;
            result.BearingFrictionPa = bearingFriction;
            result.BalanceShaftFrictionFraction = balanceShafts ? 0.06f : 0.0f;
            result.RedlineRpm = redline;
            return true;
        }

        internal static float ChargeTemperatureKelvin(float boostPsi, bool intercooler,
            float ambientKelvin, float barometricKpa, float? compressorEfficiency)
        {
            if (boostPsi <= 0.0f) return ambientKelvin;
            float pressureRatio = (barometricKpa + boostPsi * PsiToKpa) / barometricKpa;
            float compressed = compressorEfficiency.HasValue
                ? ambientKelvin * (1.0f + ((float)Math.Pow(pressureRatio, GammaExponent) - 1.0f)
                    / compressorEfficiency.Value)
                : ambientKelvin * (float)Math.Pow(pressureRatio,
                    GammaExponent / CompressorIsentropicEfficiency);
            return intercooler
                ? ambientKelvin + (compressed - ambientKelvin) * (1.0f - IntercoolerEffectiveness)
                : compressed;
        }

        internal static float ResidualFraction(float mapKpa, float exhaustManifoldKpa,
            float overlapDegrees, float compression)
        {
            float backflow = (float)Math.Pow(Math.Max(0.05f,
                exhaustManifoldKpa / Math.Max(1.0f, mapKpa)), ResidualLoadExponent);
            float overlapTerm = 1.0f + overlapDegrees * ResidualPerOverlapDegree;
            float clearanceTerm = (ResidualCompressionReference - 1.0f)
                / Math.Max(1.5f, compression - 1.0f);
            return Clamp(ResidualBase * backflow * overlapTerm * clearanceTerm, 0.0f, ResidualMaximum);
        }

        internal static float TrappedChargeKelvin(float intakeKelvin, float residualFraction)
        {
            return intakeKelvin * (1.0f - residualFraction)
                + ResidualTemperatureKelvin * residualFraction;
        }

        internal static float EvaporativeCoolingKelvin(float fuelMassGrams,
            float airMassGrams, float stoichiometricRatio, float? latentHeatJPerKg)
        {
            float latent = latentHeatJPerKg.HasValue ? latentHeatJPerKg.Value
                : (stoichiometricRatio < 12.0f ? EthanolLatentHeat : GasolineLatentHeat);
            float heatJ = fuelMassGrams / 1000.0f * latent * FuelEvaporationFraction;
            return heatJ / Math.Max(1.0e-6f, airMassGrams / 1000.0f * ChargeSpecificHeat);
        }

        internal static float ExhaustTemperatureKelvin(float chargeIndex, float lambda,
            float knockRetardDegrees)
        {
            float loadRise = ExhaustLoadSpanKelvin
                * (1.0f - (float)Math.Exp(-Math.Max(0.0f, chargeIndex) / ExhaustLoadScale));
            return ExhaustBaseKelvin + loadRise
                + ExhaustPerRetardKelvin * Math.Max(0.0f, knockRetardDegrees)
                - ExhaustRichCoolingKelvin * Math.Max(0.0f, 1.0f - lambda);
        }

        internal static float MeanPistonSpeedMetresPerSecond(float strokeMm, float rpm)
        {
            return 2.0f * (strokeMm / 1000.0f) * (rpm / 60.0f);
        }

        internal static float InletMachIndex(float strokeMm, float rpm, float sonicVelocityMs)
        {
            return 3.86f * MeanPistonSpeedMetresPerSecond(strokeMm, rpm) / sonicVelocityMs;
        }

        internal static float MachVolumetricEfficiencyMultiplier(float strokeMm,
            float rpm, float chargeKelvin)
        {
            const float gammaAir = 1.4f;
            const float gasConstantAir = 287.0f;
            float sonic = (float)Math.Sqrt(gammaAir * gasConstantAir * chargeKelvin);
            float over = Math.Max(0.0f, InletMachIndex(strokeMm, rpm, sonic) - 0.155f);
            return Math.Max(0.55f, 1.0f - 10.0f * over * over);
        }

        internal static float CamPeakShiftRpm(float camDurationDegrees)
        {
            return (camDurationDegrees - CamBaseDuration) * 32.0f;
        }

        internal static float CamOverlapDegrees(float camDurationDegrees)
        {
            return Math.Max(0.0f, (camDurationDegrees - CamBaseDuration) * 0.55f);
        }

        internal static float ValveFloatRpmFor(float springRate, float camDurationDegrees)
        {
            return 7950.0f + (springRate - 50.0f) * 58.0f
                - (camDurationDegrees - CamBaseDuration) * 14.0f;
        }

        internal static float SpringFrictionPa(float springRate)
        {
            return Math.Max(0.0f, (springRate - 50.0f) * 190.0f);
        }

        internal static float BoreStrokeCharacterMultiplier(float rpm, float boreStrokeRatio)
        {
            float normalizedRpm = (rpm - 4500.0f) / 3000.0f;
            return 1.0f + (boreStrokeRatio - 1.0f) * 0.3f * normalizedRpm;
        }

        /// <summary>ECU Lab cycle.js trappedAirGrams, returning grams per cylinder-cycle.</summary>
        internal static bool TryTrappedAirGrams(float veActualPercent, float mapAbsoluteKpa,
            float chargeKelvin, float sweptVolumeCubicMetres, out float grams)
        {
            grams = 0.0f;
            if (!Finite(veActualPercent) || !Finite(mapAbsoluteKpa) || !Finite(chargeKelvin)
                || !Finite(sweptVolumeCubicMetres) || veActualPercent < 0.0f
                || mapAbsoluteKpa <= 0.0f || chargeKelvin <= 0.0f || sweptVolumeCubicMetres <= 0.0f)
                return false;
            float density = (mapAbsoluteKpa * 1000.0f) / (AirGasConstant * chargeKelvin);
            grams = (veActualPercent / 100.0f) * sweptVolumeCubicMetres * density * 1000.0f;
            return Finite(grams);
        }

        /// <summary>ECU Lab friction.js rubbingFmepPa.</summary>
        internal static bool TryRubbingFmepPa(float rpm, float springFrictionPa,
            float bearingFmepPa, float balanceShaftFraction, out float resultPa)
        {
            resultPa = 0.0f;
            if (!Finite(rpm) || !Finite(springFrictionPa) || !Finite(bearingFmepPa)
                || !Finite(balanceShaftFraction) || rpm < 0.0f || springFrictionPa < 0.0f
                || bearingFmepPa < 0.0f || balanceShaftFraction < 0.0f)
                return false;
            float rpmShare = (1.0f - SpringRpmBias) + SpringRpmBias * (rpm / 7500.0f);
            resultPa = (RubbingBasePa + rpm * RubbingPerRpmPa + springFrictionPa * rpmShare
                + bearingFmepPa) * (1.0f + balanceShaftFraction);
            return Finite(resultPa);
        }

        /// <summary>ECU Lab friction.js pumpingFmepPa; positive means pumping loss.</summary>
        internal static bool TryPumpingFmepPa(float mapAbsoluteKpa, float exhaustAbsoluteKpa,
            out float resultPa)
        {
            resultPa = 0.0f;
            if (!Finite(mapAbsoluteKpa) || !Finite(exhaustAbsoluteKpa)
                || mapAbsoluteKpa <= 0.0f || exhaustAbsoluteKpa <= 0.0f) return false;
            resultPa = (exhaustAbsoluteKpa - mapAbsoluteKpa) * 1000.0f;
            return Finite(resultPa);
        }

        /// <summary>ECU Lab friction.js frictionTorqueNm for a four-stroke engine.</summary>
        internal static bool TryFrictionTorqueNm(float rpm, float displacementLitres,
            float mapAbsoluteKpa, float exhaustAbsoluteKpa, float springFrictionPa,
            float bearingFmepPa, float balanceShaftFraction, out float torqueNm)
        {
            torqueNm = 0.0f;
            if (!Finite(displacementLitres) || displacementLitres <= 0.0f) return false;
            float rubbing, pumping;
            if (!TryRubbingFmepPa(rpm, springFrictionPa, bearingFmepPa,
                balanceShaftFraction, out rubbing)
                || !TryPumpingFmepPa(mapAbsoluteKpa, exhaustAbsoluteKpa, out pumping)) return false;
            torqueNm = ((rubbing + pumping) * (displacementLitres / 1000.0f))
                / (4.0f * (float)Math.PI);
            return Finite(torqueNm);
        }

        private static int CylinderCount(string configuration)
        {
            if (configuration == "I4") return 4;
            if (configuration == "I6" || configuration == "V6") return 6;
            if (configuration == "V8") return 8;
            return 0;
        }

        private static int MainBearingCount(string configuration)
        {
            if (configuration == "I4" || configuration == "V8") return 5;
            if (configuration == "I6") return 7;
            return 4;
        }

        private static float Clamp(float value, float minimum, float maximum)
        {
            return Math.Max(minimum, Math.Min(maximum, value));
        }

        private static bool Finite(float value)
        {
            return !Single.IsNaN(value) && !Single.IsInfinity(value);
        }
    }
}
