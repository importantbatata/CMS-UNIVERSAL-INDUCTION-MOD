using System;

namespace CMS18TurboPrototype
{
    /// <summary>
    /// Mod-owned, versioned calibration payload. It contains no factory tune or
    /// CMS calibration values by default. Map cells are row-major: MAP row, RPM
    /// column. MAP is absolute kPa; fuel values are lambda; timing is degrees BTDC.
    /// </summary>
    internal sealed class EcuCalibrationRecord
    {
        internal const int CurrentSchemaVersion = 1;

        internal int SchemaVersion = CurrentSchemaVersion;
        internal string VehicleKey;
        internal string EngineId;
        internal string HardwareFingerprint;
        internal string CalibrationName;
        internal string SourceDescription;
        internal int[] RpmAxis;
        internal float[] MapAxisKpaAbsolute;
        internal float[] VolumetricEfficiencyPercent;
        internal float[] LambdaTarget;
        internal float[] IgnitionTimingDegrees;
        internal float[] BoostTargetPsi;

        internal EcuCalibrationRecord()
        {
            VehicleKey = String.Empty;
            EngineId = String.Empty;
            HardwareFingerprint = String.Empty;
            CalibrationName = String.Empty;
            SourceDescription = String.Empty;
            RpmAxis = null;
            MapAxisKpaAbsolute = null;
            VolumetricEfficiencyPercent = null;
            LambdaTarget = null;
            IgnitionTimingDegrees = null;
            BoostTargetPsi = null;
        }

        internal bool Validate(out string reason)
        {
            reason = String.Empty;
            if (SchemaVersion != CurrentSchemaVersion)
                return Fail("Unsupported calibration schema version.", out reason);
            if (IsBlank(VehicleKey) || IsBlank(EngineId) || IsBlank(HardwareFingerprint))
                return Fail("Vehicle, installed engine, and hardware identities are required.", out reason);
            if (RpmAxis == null || RpmAxis.Length < 2 || !IsStrictlyIncreasing(RpmAxis))
                return Fail("RPM axis must contain at least two increasing positive values.", out reason);
            if (!IsFiniteIncreasing(MapAxisKpaAbsolute) || MapAxisKpaAbsolute.Length < 2
                || MapAxisKpaAbsolute[0] <= 0.0f)
                return Fail("MAP axis must contain at least two increasing absolute-kPa values.", out reason);

            int cellCount = RpmAxis.Length * MapAxisKpaAbsolute.Length;
            if (!ValidMap(VolumetricEfficiencyPercent, cellCount, 0.0f, 200.0f))
                return Fail("Volumetric-efficiency table is missing, malformed, or outside 0–200 percent.", out reason);
            if (!ValidMap(LambdaTarget, cellCount, 0.60f, 1.60f))
                return Fail("Lambda table is missing, malformed, or outside 0.60–1.60.", out reason);
            if (!ValidMap(IgnitionTimingDegrees, cellCount, -15.0f, 60.0f))
                return Fail("Ignition table is missing, malformed, or outside -15–60 degrees.", out reason);
            if (BoostTargetPsi != null && !ValidMap(BoostTargetPsi, RpmAxis.Length, 0.0f, 40.0f))
                return Fail("Boost table is malformed or outside 0–40 PSI.", out reason);
            return true;
        }

        /// <summary>Exact identity matching only; hardware changes make a tune inactive.</summary>
        internal bool Matches(string vehicleKey, string engineId, string hardwareFingerprint)
        {
            return SameIdentity(VehicleKey, vehicleKey)
                && SameIdentity(EngineId, EngineCompatibilityCatalog.NormalizeEngineId(engineId))
                && SameIdentity(HardwareFingerprint, hardwareFingerprint);
        }

        internal static bool TrySelect(EcuCalibrationRecord record, string vehicleKey,
            string installedEngineId, string hardwareFingerprint, out string reason)
        {
            reason = String.Empty;
            if (record == null) return Fail("No saved calibration exists for this context.", out reason);
            if (!record.Validate(out reason)) return false;
            if (!record.Matches(vehicleKey, installedEngineId, hardwareFingerprint))
                return Fail("Saved calibration identity does not match this vehicle, installed engine, and hardware.", out reason);
            return true;
        }

        private static bool ValidMap(float[] values, int expectedLength, float minimum, float maximum)
        {
            if (values == null || values.Length != expectedLength) return false;
            for (int i = 0; i < values.Length; i++)
                if (!IsFinite(values[i]) || values[i] < minimum || values[i] > maximum) return false;
            return true;
        }

        private static bool IsStrictlyIncreasing(int[] values)
        {
            for (int i = 0; i < values.Length; i++)
                if (values[i] <= 0 || (i > 0 && values[i] <= values[i - 1])) return false;
            return true;
        }

        private static bool IsFiniteIncreasing(float[] values)
        {
            if (values == null) return false;
            for (int i = 0; i < values.Length; i++)
                if (!IsFinite(values[i]) || (i > 0 && values[i] <= values[i - 1])) return false;
            return true;
        }

        private static bool IsFinite(float value)
        {
            return !Single.IsNaN(value) && !Single.IsInfinity(value);
        }

        private static bool SameIdentity(string left, string right)
        {
            return !IsBlank(left) && !IsBlank(right)
                && String.Equals(left.Trim(), right.Trim(), StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsBlank(string value)
        {
            return value == null || value.Trim().Length == 0;
        }

        private static bool Fail(string message, out string reason)
        {
            reason = message;
            return false;
        }
    }
}
