using System;

namespace CMS18TurboPrototype
{
    /// <summary>
    /// Coarse turbo tiers for the virtual CMS kit. Diameter means compressor
    /// inducer diameter. Flow and horsepower classes are intentionally labelled
    /// as estimates: no compressor maps for these generic tiers ship with CMS.
    /// </summary>
    internal sealed class TurboPerformanceTier
    {
        internal readonly int InducerMm;
        internal readonly int ApproxMinHorsepower;
        internal readonly int ApproxMaxHorsepower;
        internal readonly float EstimatedMaxFlowLbPerMinute;
        internal readonly float AssumedPeakEfficiency;
        internal readonly float SpoolStartFraction;
        internal readonly float SpoolFullFraction;

        internal TurboPerformanceTier(int inducerMm, int approximateMinHorsepower,
            int approximateMaxHorsepower, float estimatedMaxFlowLbPerMinute,
            float assumedPeakEfficiency, float spoolStartFraction, float spoolFullFraction)
        {
            InducerMm = inducerMm;
            ApproxMinHorsepower = approximateMinHorsepower;
            ApproxMaxHorsepower = approximateMaxHorsepower;
            EstimatedMaxFlowLbPerMinute = estimatedMaxFlowLbPerMinute;
            AssumedPeakEfficiency = assumedPeakEfficiency;
            SpoolStartFraction = spoolStartFraction;
            SpoolFullFraction = spoolFullFraction;
        }
    }

    internal static class TurboPerformanceModel
    {
        internal const int DefaultInducerMm = 55;
        internal const float EstimatedHorsepowerPerLbPerMinute = 10.0f;

        // Horsepower / flow tiers follow the illustrative ranges in the user
        // specification. Efficiency and spool points are tuning assumptions,
        // not measured CMS or manufacturer compressor-map values.
        private static readonly TurboPerformanceTier[] Tiers =
        {
            new TurboPerformanceTier(35, 120, 220, 22.0f, 0.62f, 0.19f, 0.65f),
            new TurboPerformanceTier(45, 200, 350, 35.0f, 0.66f, 0.23f, 0.73f),
            new TurboPerformanceTier(55, 300, 550, 55.0f, 0.70f, 0.27f, 0.82f),
            new TurboPerformanceTier(62, 450, 750, 75.0f, 0.72f, 0.32f, 0.89f),
            new TurboPerformanceTier(67, 550, 950, 95.0f, 0.73f, 0.36f, 0.94f),
            new TurboPerformanceTier(76, 750, 1200, 120.0f, 0.74f, 0.41f, 0.98f),
            new TurboPerformanceTier(88, 1000, 1600, 160.0f, 0.75f, 0.47f, 1.0f)
        };

        internal static int[] GetSupportedInducerSizes()
        {
            int[] result = new int[Tiers.Length];
            for (int i = 0; i < Tiers.Length; i++) result[i] = Tiers[i].InducerMm;
            return result;
        }

        internal static TurboPerformanceTier GetTier(int inducerMm)
        {
            for (int i = 0; i < Tiers.Length; i++)
                if (Tiers[i].InducerMm == inducerMm) return Tiers[i];
            return Tiers[2];
        }

        internal static int NormalizeInducerSize(int inducerMm)
        {
            return GetTier(inducerMm).InducerMm;
        }

        internal static float CalculateSpool(TurboPerformanceTier tier, float rpmFraction, float load)
        {
            if (tier == null) tier = GetTier(DefaultInducerMm);
            if (!IsFinite(rpmFraction)) rpmFraction = 0.0f;
            if (!IsFinite(load)) load = 0.0f;
            float range = Clamp01((rpmFraction - tier.SpoolStartFraction)
                / Math.Max(0.01f, tier.SpoolFullFraction - tier.SpoolStartFraction));
            float response = range * range * (3.0f - 2.0f * range);
            return response * (float)Math.Pow(Clamp01(load), 0.72f);
        }

        /// <summary>
        /// Caps density-derived charge gain when estimated engine airflow would
        /// exceed the selected tier's estimated flow class. Horsepower-to-flow
        /// conversion is a game approximation, not a turbo map.
        /// </summary>
        internal static float LimitAirDensityRatio(TurboPerformanceTier tier,
            float naturallyAspiratedHorsepower, float requestedDensityRatio)
        {
            if (tier == null) tier = GetTier(DefaultInducerMm);
            if (!IsFinite(naturallyAspiratedHorsepower) || naturallyAspiratedHorsepower < 0.0f)
                naturallyAspiratedHorsepower = 0.0f;
            if (!IsFinite(requestedDensityRatio) || requestedDensityRatio < 1.0f)
                requestedDensityRatio = 1.0f;
            float baselineHp = Math.Max(1.0f, naturallyAspiratedHorsepower);
            float estimatedBaseFlow = baselineHp / EstimatedHorsepowerPerLbPerMinute;
            float maximumDensityRatio = tier.EstimatedMaxFlowLbPerMinute / estimatedBaseFlow;
            return Math.Min(Math.Max(1.0f, requestedDensityRatio), Math.Max(1.0f, maximumDensityRatio));
        }

        internal static float NormalizeBoostPsi(float value, float maximum, float fallback)
        {
            if (!IsFinite(maximum) || maximum < 0.0f) maximum = 0.0f;
            if (!IsFinite(fallback)) fallback = 0.0f;
            if (!IsFinite(value)) value = fallback;
            fallback = Math.Max(0.0f, Math.Min(maximum, fallback));
            if (!IsFinite(value)) value = fallback;
            return Math.Max(0.0f, Math.Min(maximum, value));
        }

        internal static bool IsFinite(float value)
        {
            return !Single.IsNaN(value) && !Single.IsInfinity(value);
        }

        private static float Clamp01(float value)
        {
            if (!IsFinite(value)) return 0.0f;
            return Math.Max(0.0f, Math.Min(1.0f, value));
        }
    }
}
