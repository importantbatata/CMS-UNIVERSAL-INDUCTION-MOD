using System;

namespace CMS18TurboPrototype
{
    internal struct EcuCalibrationSample
    {
        internal float VolumetricEfficiencyPercent;
        internal float LambdaTarget;
        internal float IgnitionTimingDegrees;
        internal float? BoostTargetPsi;
    }

    /// <summary>
    /// Deterministic calibration-table sampler. This is deliberately not wired
    /// to CMS performance hooks until a verified ECU/game integration exists.
    /// Map cells use MAP-row-major order with RPM varying fastest.
    /// </summary>
    internal static class EcuMapEvaluator
    {
        internal static bool TrySample(EcuCalibrationRecord record, float rpm,
            float manifoldAbsoluteKpa, out EcuCalibrationSample sample, out string reason)
        {
            sample = new EcuCalibrationSample();
            reason = String.Empty;
            if (record == null || !record.Validate(out reason))
            {
                if (String.IsNullOrEmpty(reason)) reason = "Calibration record is missing.";
                return false;
            }
            if (!IsFinite(rpm) || !IsFinite(manifoldAbsoluteKpa) || manifoldAbsoluteKpa <= 0.0f)
            {
                reason = "RPM and absolute manifold pressure must be finite, with pressure above zero.";
                return false;
            }

            float ve = Bilinear(record, record.VolumetricEfficiencyPercent, rpm, manifoldAbsoluteKpa);
            float lambda = Bilinear(record, record.LambdaTarget, rpm, manifoldAbsoluteKpa);
            float ignition = Bilinear(record, record.IgnitionTimingDegrees, rpm, manifoldAbsoluteKpa);
            float? boost = null;
            if (record.BoostTargetPsi != null)
                boost = Linear(record.RpmAxis, record.BoostTargetPsi, rpm);

            if (!IsFinite(ve) || !IsFinite(lambda) || !IsFinite(ignition)
                || (boost.HasValue && !IsFinite(boost.Value)))
            {
                reason = "Calibration sample produced a non-finite value.";
                return false;
            }

            sample.VolumetricEfficiencyPercent = ve;
            sample.LambdaTarget = lambda;
            sample.IgnitionTimingDegrees = ignition;
            sample.BoostTargetPsi = boost;
            return true;
        }

        private static float Bilinear(EcuCalibrationRecord record, float[] values,
            float rpm, float mapKpa)
        {
            int x0, x1, y0, y1;
            float tx, ty;
            Bracket(record.RpmAxis, rpm, out x0, out x1, out tx);
            Bracket(record.MapAxisKpaAbsolute, mapKpa, out y0, out y1, out ty);
            int width = record.RpmAxis.Length;
            float a = Lerp(values[y0 * width + x0], values[y0 * width + x1], tx);
            float b = Lerp(values[y1 * width + x0], values[y1 * width + x1], tx);
            return Lerp(a, b, ty);
        }

        private static float Linear(int[] axis, float[] values, float input)
        {
            int lo, hi;
            float t;
            Bracket(axis, input, out lo, out hi, out t);
            return Lerp(values[lo], values[hi], t);
        }

        private static void Bracket(int[] axis, float input, out int lo, out int hi, out float t)
        {
            if (input <= axis[0]) { lo = hi = 0; t = 0.0f; return; }
            int last = axis.Length - 1;
            if (input >= axis[last]) { lo = hi = last; t = 0.0f; return; }
            lo = 0;
            while (lo < last - 1 && input > axis[lo + 1]) lo++;
            hi = lo + 1;
            t = (input - axis[lo]) / (axis[hi] - axis[lo]);
        }

        private static void Bracket(float[] axis, float input, out int lo, out int hi, out float t)
        {
            if (input <= axis[0]) { lo = hi = 0; t = 0.0f; return; }
            int last = axis.Length - 1;
            if (input >= axis[last]) { lo = hi = last; t = 0.0f; return; }
            lo = 0;
            while (lo < last - 1 && input > axis[lo + 1]) lo++;
            hi = lo + 1;
            t = (input - axis[lo]) / (axis[hi] - axis[lo]);
        }

        private static float Lerp(float a, float b, float t)
        {
            return a + (b - a) * t;
        }

        private static bool IsFinite(float value)
        {
            return !Single.IsNaN(value) && !Single.IsInfinity(value);
        }
    }
}
