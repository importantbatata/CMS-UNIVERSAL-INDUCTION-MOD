using System;

namespace CMS18TurboPrototype
{
    /// <summary>
    /// Compatibility information for CMS engine prefabs. A profile only records
    /// facts verified from the local game data plus explicitly-labelled model
    /// assumptions; it does not imply that a complete parts kit exists yet.
    /// </summary>
    internal sealed class EngineCompatibilityProfile
    {
        internal readonly string EngineId;
        internal readonly string DisplayName;
        internal readonly int CylinderCount;
        internal readonly string Layout;
        internal readonly float TurboSpoolStartFraction;
        internal readonly float TurboFullSpoolFraction;
        internal readonly string TurboSizingNote;

        internal EngineCompatibilityProfile(string engineId, string displayName, int cylinderCount,
            string layout, float turboSpoolStartFraction, float turboFullSpoolFraction,
            string turboSizingNote)
        {
            EngineId = engineId;
            DisplayName = displayName;
            CylinderCount = cylinderCount;
            Layout = layout;
            TurboSpoolStartFraction = turboSpoolStartFraction;
            TurboFullSpoolFraction = turboFullSpoolFraction;
            TurboSizingNote = turboSizingNote;
        }
    }

    internal static class EngineCompatibilityCatalog
    {
        // The game car config maps EmdenLotz to engine_r4; English.txt labels
        // engine_r4 as "I4 DOHC AQC". The base ID is distinct from
        // engine_r4_turbo. Turbo spool fractions are prototype assumptions,
        // not a measured CMS or manufacturer compressor map.
        private static readonly EngineCompatibilityProfile[] Profiles =
        {
            new EngineCompatibilityProfile(
                "engine_r4",
                "I4 DOHC AQC (Emden Lotz base engine)",
                4,
                "inline",
                0.27f,
                0.82f,
                "55 mm compressor inducer street tier; illustrative 300–550 hp class from the supplied design brief")
        };

        internal static bool TryGet(string engineId, out EngineCompatibilityProfile profile)
        {
            profile = null;
            if (String.IsNullOrEmpty(engineId)) return false;
            string normalized = NormalizeEngineId(engineId);
            for (int i = 0; i < Profiles.Length; i++)
            {
                if (!String.Equals(normalized, Profiles[i].EngineId, StringComparison.OrdinalIgnoreCase)) continue;
                profile = Profiles[i];
                return true;
            }
            return false;
        }

        internal static string NormalizeEngineId(string value)
        {
            if (String.IsNullOrEmpty(value)) return String.Empty;
            string normalized = value.Trim();
            int clone = normalized.IndexOf("(Clone)", StringComparison.OrdinalIgnoreCase);
            if (clone >= 0) normalized = normalized.Substring(0, clone);
            return normalized.Trim().ToLowerInvariant();
        }
    }
}
