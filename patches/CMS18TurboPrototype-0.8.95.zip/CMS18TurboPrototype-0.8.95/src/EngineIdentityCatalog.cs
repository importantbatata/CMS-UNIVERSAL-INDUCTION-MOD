using System;

namespace CMS18TurboPrototype
{
    /// <summary>
    /// Read-only identities collected from the installed game's car config type= entries
    /// and English localization labels. This is identity metadata, not a fitment list.
    /// Bore, stroke, compression, clearances, and kit compatibility remain unknown.
    /// </summary>
    internal sealed class EngineIdentityProfile
    {
        internal readonly string EngineId;
        internal readonly string DisplayName;
        internal readonly string Layout;
        internal readonly int CylinderCount;
        internal readonly string SandboxConfiguration;
        internal readonly bool IsCarburetedLabel;
        internal readonly bool HasFactoryInductionLabel;

        internal EngineIdentityProfile(string engineId, string displayName)
        {
            EngineId = engineId;
            DisplayName = displayName;
            IsCarburetedLabel = displayName.IndexOf("carb", StringComparison.OrdinalIgnoreCase) >= 0;
            HasFactoryInductionLabel = displayName.IndexOf("turbo", StringComparison.OrdinalIgnoreCase) >= 0
                || displayName.IndexOf("supercharged", StringComparison.OrdinalIgnoreCase) >= 0;
            string parsedLayout;
            int parsedCylinderCount;
            string parsedSandboxConfiguration;
            ParseLocalizedLayout(displayName, out parsedLayout, out parsedCylinderCount, out parsedSandboxConfiguration);
            Layout = parsedLayout;
            CylinderCount = parsedCylinderCount;
            SandboxConfiguration = parsedSandboxConfiguration;
        }

        private static void ParseLocalizedLayout(string name, out string layout, out int cylinders,
            out string sandboxConfiguration)
        {
            layout = "Unverified";
            cylinders = 0;
            sandboxConfiguration = String.Empty;
            if (String.IsNullOrEmpty(name)) return;
            string value = name.Trim().ToUpperInvariant();
            if (value.StartsWith("ROTARY", StringComparison.Ordinal)) { layout = "rotary"; return; }
            if (value.StartsWith("B6", StringComparison.Ordinal)) { layout = "boxer"; cylinders = 6; return; }
            string[] labels = { "W12", "V12", "V10", "V8", "V6", "I6", "I4", "I3" };
            int[] counts = { 12, 12, 10, 8, 6, 6, 4, 3 };
            for (int i = 0; i < labels.Length; i++)
            {
                if (!value.StartsWith(labels[i], StringComparison.Ordinal)) continue;
                layout = labels[i].Substring(0, 1) == "I" ? "inline"
                    : labels[i].Substring(0, 1) == "V" ? "V" : "W";
                cylinders = counts[i];
                if (labels[i] == "I4" || labels[i] == "I6" || labels[i] == "V6" || labels[i] == "V8")
                    sandboxConfiguration = labels[i];
                return;
            }
        }
    }

    internal static class EngineIdentityCatalog
    {
        // IDs are limited to engine types actually referenced by installed car config files.
        // Display labels come from StreamingAssets/Localizations/English.txt.
        // Missing labels deliberately remain raw IDs and receive no inferred geometry.
        private static readonly EngineIdentityProfile[] Profiles =
        {
            new EngineIdentityProfile("engine_b61_porsche", "B6 Twin Turbo"),
            new EngineIdentityProfile("engine_b62_2_porsche", "B6 Turbo"),
            new EngineIdentityProfile("engine_b62_porsche", "B6"),
            new EngineIdentityProfile("engine_i3", "I3 DOHC"),
            new EngineIdentityProfile("engine_i3_turbo", "I3 DOHC Turbocharged"),
            new EngineIdentityProfile("engine_i4", "I4 DOHC BFM"),
            new EngineIdentityProfile("engine_i4_4x4", "I4 DOHC 4x4"),
            new EngineIdentityProfile("engine_i4_l134", "I4"),
            new EngineIdentityProfile("engine_i6_old", "I6 OHV"),
            new EngineIdentityProfile("engine_r4", "I4 DOHC AQC"),
            new EngineIdentityProfile("engine_r4_2", "I4 DOHC APZ"),
            new EngineIdentityProfile("engine_r4_old", "I4 DOHC ABU"),
            new EngineIdentityProfile("engine_r4_sohc", "I4 SOHC ABT"),
            new EngineIdentityProfile("engine_r4_sohc_4x4", "I4 SOHC 4x4"),
            new EngineIdentityProfile("engine_r4_sohc_wzdluzny", "I4 SOHC BMJ"),
            new EngineIdentityProfile("engine_r4_turbo", "I4 DOHC Turbocharged"),
            new EngineIdentityProfile("engine_r6_dohc_wzdluzny", "I6 DOHC"),
            new EngineIdentityProfile("engine_r6_m130", "engine_r6_m130"),
            new EngineIdentityProfile("engine_r6_sebring", "I6 SOHC"),
            new EngineIdentityProfile("engine_r6_sohc", "I6 M186"),
            new EngineIdentityProfile("engine_rot_new", "ROTARY 1"),
            new EngineIdentityProfile("engine_rot_old", "ROTARY 2"),
            new EngineIdentityProfile("engine_v10", "V10 DOHC"),
            new EngineIdentityProfile("engine_v10_2", "V10 OHV"),
            new EngineIdentityProfile("engine_v10_3", "engine_v10_3"),
            new EngineIdentityProfile("engine_v12_huayra", "V12 SOHC Twin Turbo"),
            new EngineIdentityProfile("engine_v12_zonda", "V12 DOHC"),
            new EngineIdentityProfile("engine_v6_30", "V6 DOHC AKZ"),
            new EngineIdentityProfile("engine_v6_30_rwd", "V6 DOHC CHG"),
            new EngineIdentityProfile("engine_v6_pentastar", "V6 DOHC AQE"),
            new EngineIdentityProfile("engine_v8", "V8 DOHC AXK"),
            new EngineIdentityProfile("engine_v8_289", "V8 OHV WINDSOR"),
            new EngineIdentityProfile("engine_v8_289_racing", "V8 OHV WINDSOR RACE"),
            new EngineIdentityProfile("engine_v8_345_4x4", "V8 HEMI B 4x4"),
            new EngineIdentityProfile("engine_v8_360", "engine_v8_360"),
            new EngineIdentityProfile("engine_v8_392hemi", "V8 HEMI"),
            new EngineIdentityProfile("engine_v8_429", "V8 OHV 385"),
            new EngineIdentityProfile("engine_v8_4x4", "V8 DOHC 4x4"),
            new EngineIdentityProfile("engine_v8_61hemi", "engine_v8_61hemi"),
            new EngineIdentityProfile("engine_v8_62hemi", "V8 OHV HEMI B"),
            new EngineIdentityProfile("engine_v8_bentley", "V8 OHV"),
            new EngineIdentityProfile("engine_v8_coyote", "V8 DOHC COYOTE"),
            new EngineIdentityProfile("engine_v8_f350", "V8 SOHC BOSS RWD"),
            new EngineIdentityProfile("engine_v8_f350_4x4", "V8 SOHC BOSS 4x4"),
            new EngineIdentityProfile("engine_v8_hemi", "V8 OHV HEMI"),
            new EngineIdentityProfile("engine_v8_hemiShaker", "engine_v8_hemiShaker"),
            new EngineIdentityProfile("engine_v8_m119", "engine_v8_m119"),
            new EngineIdentityProfile("engine_v8_m159", "engine_v8_m159"),
            new EngineIdentityProfile("engine_v8_magnum", "V8 OHV MAG"),
            new EngineIdentityProfile("engine_v8_quattroporte", "V8 Twin-Turbo DOHC"),
            new EngineIdentityProfile("engine_v8_scharged", "V8 DOHC Supercharged"),
            new EngineIdentityProfile("engine_v8_sec", "engine_v8_sec"),
            new EngineIdentityProfile("engine_v8_sixpack", "V8 OHV 6P"),
            new EngineIdentityProfile("engine_v8_stary", "V8 1carb OHV"),
            new EngineIdentityProfile("engine_v8_stary_2carb", "V8 2carb OHV"),
            new EngineIdentityProfile("engine_v8_stary_scharged", "V8 2carb OHV Supercharged"),
            new EngineIdentityProfile("engine_v8_stradale", "V8 DOHC BCN"),
            new EngineIdentityProfile("engine_w12", "W12 Twin-Turbo")
        };

        internal static bool TryGet(string engineId, out EngineIdentityProfile profile)
        {
            profile = null;
            if (String.IsNullOrEmpty(engineId)) return false;
            string normalized = EngineCompatibilityCatalog.NormalizeEngineId(engineId);
            for (int i = 0; i < Profiles.Length; i++)
            {
                if (!String.Equals(normalized, Profiles[i].EngineId, StringComparison.OrdinalIgnoreCase)) continue;
                profile = Profiles[i];
                return true;
            }
            return false;
        }
    }
}
