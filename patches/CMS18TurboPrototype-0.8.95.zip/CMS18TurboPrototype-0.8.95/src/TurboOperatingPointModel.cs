using System;

namespace CMS18TurboPrototype
{
    /// <summary>
    /// Bounded steady-state turbo estimate using the project's illustrative
    /// size-tier flow capacities. It is not a compressor map or live telemetry.
    /// </summary>
    internal struct TurboOperatingPoint
    {
        internal readonly float CompressorBoostPsi;
        internal readonly float CompressorEfficiency;
        internal readonly float FlowUtilization;
        internal readonly float Spool;
        internal readonly ChargeAirState ChargeAir;

        internal TurboOperatingPoint(float compressorBoostPsi, float compressorEfficiency,
            float flowUtilization, float spool, ChargeAirState chargeAir)
        {
            CompressorBoostPsi = compressorBoostPsi;
            CompressorEfficiency = compressorEfficiency;
            FlowUtilization = flowUtilization;
            Spool = spool;
            ChargeAir = chargeAir;
        }
    }

    internal static class TurboOperatingPointModel
    {
        private const float AssumedIntercoolerEffectiveness = 0.62f;
        private const float AssumedIntercoolerPressureDropPsi = 0.55f;
        private const float MinimumEfficiency = 0.40f;
        private const int SearchIterations = 18;

        internal static TurboOperatingPoint Calculate(TurboPerformanceTier tier,
            float targetBoostPsi, float spool, float baselineHorsepower,
            float ambientTemperatureKelvin, float ambientPressurePsi)
        {
            if (tier == null) tier = TurboPerformanceModel.GetTier(TurboPerformanceModel.DefaultInducerMm);
            if (!TurboPerformanceModel.IsFinite(targetBoostPsi) || targetBoostPsi < 0.0f) targetBoostPsi = 0.0f;
            targetBoostPsi = Math.Min(32.0f, targetBoostPsi);
            if (!TurboPerformanceModel.IsFinite(spool)) spool = 0.0f;
            spool = Clamp01(spool);
            if (!TurboPerformanceModel.IsFinite(baselineHorsepower) || baselineHorsepower < 0.0f)
                baselineHorsepower = 0.0f;

            float requestedBoost = targetBoostPsi * spool;
            float baseFlow = baselineHorsepower / TurboPerformanceModel.EstimatedHorsepowerPerLbPerMinute;
            float maximumFlow = Math.Max(0.01f, tier.EstimatedMaxFlowLbPerMinute);
            float maximumDensityRatio = baseFlow <= 0.01f
                ? 4.0f : Math.Max(1.0f, maximumFlow / baseFlow);
            float efficiency = tier.AssumedPeakEfficiency;
            float deliveredBoost = requestedBoost;
            ChargeAirState charge = default(ChargeAirState);

            // A few bounded passes let estimated efficiency respond to pressure
            // ratio and operating flow before the tier's flow ceiling is applied.
            for (int pass = 0; pass < 3; pass++)
            {
                deliveredBoost = FindFlowLimitedBoost(requestedBoost, efficiency,
                    maximumDensityRatio, ambientTemperatureKelvin, ambientPressurePsi, out charge);
                float requestedStateEfficiency = EstimateEfficiency(tier, requestedBoost,
                    baseFlow * charge.AirDensityRatio / maximumFlow);
                efficiency = Math.Min(tier.AssumedPeakEfficiency,
                    Math.Max(MinimumEfficiency, requestedStateEfficiency));
            }

            deliveredBoost = FindFlowLimitedBoost(requestedBoost, efficiency,
                maximumDensityRatio, ambientTemperatureKelvin, ambientPressurePsi, out charge);
            float flowUtilization = baseFlow * charge.AirDensityRatio / maximumFlow;
            if (!TurboPerformanceModel.IsFinite(flowUtilization)) flowUtilization = 0.0f;
            flowUtilization = Math.Max(0.0f, Math.Min(1.5f, flowUtilization));
            return new TurboOperatingPoint(deliveredBoost, efficiency, flowUtilization, spool, charge);
        }

        private static float FindFlowLimitedBoost(float requestedBoost,
            float efficiency, float maximumDensityRatio, float ambientTemperatureKelvin,
            float ambientPressurePsi, out ChargeAirState selectedCharge)
        {
            float low = 0.0f;
            float high = requestedBoost;
            selectedCharge = ChargeAirModel.Calculate(0.0f, efficiency,
                AssumedIntercoolerEffectiveness, AssumedIntercoolerPressureDropPsi,
                ambientTemperatureKelvin, ambientPressurePsi);
            if (high <= 0.0f) return 0.0f;

            for (int i = 0; i < SearchIterations; i++)
            {
                float mid = (low + high) * 0.5f;
                ChargeAirState candidate = ChargeAirModel.Calculate(mid, efficiency,
                    AssumedIntercoolerEffectiveness, AssumedIntercoolerPressureDropPsi,
                    ambientTemperatureKelvin, ambientPressurePsi);
                if (candidate.AirDensityRatio <= maximumDensityRatio)
                {
                    low = mid;
                    selectedCharge = candidate;
                }
                else
                {
                    high = mid;
                }
            }
            return low;
        }

        private static float EstimateEfficiency(TurboPerformanceTier tier,
            float compressorBoostPsi, float flowUtilization)
        {
            float absolutePressure = ChargeAirModel.StandardAmbientPressurePsi
                + Math.Max(0.0f, compressorBoostPsi);
            float pressureRatio = absolutePressure / ChargeAirModel.StandardAmbientPressurePsi;
            float flowPenalty = Math.Abs(flowUtilization - 0.68f) * 0.08f;
            float pressurePenalty = Math.Max(0.0f, pressureRatio - 2.0f) * 0.025f;
            float value = tier.AssumedPeakEfficiency - flowPenalty - pressurePenalty;
            return Math.Max(MinimumEfficiency, Math.Min(tier.AssumedPeakEfficiency, value));
        }

        private static float Clamp01(float value)
        {
            return Math.Max(0.0f, Math.Min(1.0f, value));
        }
    }
}
