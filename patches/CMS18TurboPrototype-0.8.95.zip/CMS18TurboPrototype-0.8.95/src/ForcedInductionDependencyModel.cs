using System;
using System.Collections.Generic;

namespace CMS18TurboPrototype
{
    /// <summary>
    /// Pure, mod-owned dependency validator for the first complete single-turbo
    /// conversion. Component/connection keys here are internal schema keys, not
    /// CMS part IDs. It is intentionally not wired to the current virtual kit.
    /// </summary>
    internal static class ForcedInductionDependencyModel
    {
        internal sealed class Connection
        {
            internal readonly string From;
            internal readonly string To;

            internal Connection(string from, string to)
            {
                From = Normalize(from);
                To = Normalize(to);
            }
        }

        internal sealed class Validation
        {
            internal readonly bool IsComplete;
            internal readonly string[] MissingComponents;
            internal readonly string[] MissingConnections;

            internal Validation(List<string> missingComponents, List<string> missingConnections)
            {
                MissingComponents = missingComponents.ToArray();
                MissingConnections = missingConnections.ToArray();
                IsComplete = MissingComponents.Length == 0 && MissingConnections.Length == 0;
            }
        }

        private static readonly string[] RequiredComponents =
        {
            "turbo_manifold", "turbocharger", "downpipe", "air_filter",
            "hot_side_pipe", "intercooler", "cold_side_pipe", "throttle_body",
            "oil_feed", "oil_return", "wastegate", "blow_off_valve",
            "boost_controller"
        };

        private static readonly Connection[] RequiredConnections =
        {
            new Connection("cylinder_head.exhaust", "turbo_manifold.inlet"),
            new Connection("turbo_manifold.outlet", "turbocharger.turbine_inlet"),
            new Connection("turbocharger.turbine_outlet", "downpipe.inlet"),
            new Connection("downpipe.outlet", "exhaust.inlet"),
            new Connection("air_filter.outlet", "turbocharger.compressor_inlet"),
            new Connection("turbocharger.compressor_outlet", "hot_side_pipe.inlet"),
            new Connection("hot_side_pipe.outlet", "intercooler.inlet"),
            new Connection("intercooler.outlet", "cold_side_pipe.inlet"),
            new Connection("cold_side_pipe.outlet", "throttle_body.inlet"),
            new Connection("oil_source.pressurized", "turbocharger.oil_feed"),
            new Connection("turbocharger.oil_drain", "crankcase.oil_return"),
            new Connection("wastegate.exhaust_inlet", "turbo_manifold.wastegate_port"),
            new Connection("wastegate.actuator", "boost_controller.output"),
            new Connection("blow_off_valve.charge_pipe_port", "cold_side_pipe.bov_port"),
            new Connection("blow_off_valve.pressure_reference", "intake_manifold.reference")
        };

        internal static Validation ValidateSingleTurbo(IEnumerable<string> installedComponents,
            IEnumerable<Connection> connectedPorts)
        {
            HashSet<string> components = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (installedComponents != null)
                foreach (string component in installedComponents)
                    if (!String.IsNullOrEmpty(component)) components.Add(Normalize(component));

            HashSet<string> connections = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (connectedPorts != null)
                foreach (Connection connection in connectedPorts)
                    if (connection != null && connection.From.Length > 0 && connection.To.Length > 0)
                        connections.Add(ConnectionKey(connection.From, connection.To));

            List<string> missingComponents = new List<string>();
            for (int i = 0; i < RequiredComponents.Length; i++)
                if (!components.Contains(RequiredComponents[i])) missingComponents.Add(RequiredComponents[i]);

            List<string> missingConnections = new List<string>();
            for (int i = 0; i < RequiredConnections.Length; i++)
            {
                Connection required = RequiredConnections[i];
                if (!connections.Contains(ConnectionKey(required.From, required.To)))
                    missingConnections.Add(required.From + " -> " + required.To);
            }
            return new Validation(missingComponents, missingConnections);
        }

        private static string ConnectionKey(string from, string to)
        {
            return Normalize(from) + "\n" + Normalize(to);
        }

        private static string Normalize(string value)
        {
            return String.IsNullOrEmpty(value) ? String.Empty : value.Trim().ToLowerInvariant();
        }
    }
}
