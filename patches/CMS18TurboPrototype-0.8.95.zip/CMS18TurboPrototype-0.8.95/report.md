# Patch 0.8.95 — automatic engine identity in the ECU Lab sandbox

## Expansion increment

This patch continues the existing project. It adds a read-only catalog of 58 engine IDs found in installed CMS 2018 vehicle configuration files, using the corresponding English localization labels where available. When the existing ECU Lab sandbox opens, and while it remains open, the plugin reads the active engine ID through its existing engine-root lookup. For recognized I4, I6, V6, and V8 labels, the sandbox layout selection follows that installed engine automatically. Cloned engine-root IDs are normalized. Other recognized layouts are displayed but are not forced into an unsupported sandbox model; an unsupported/unknown identity retains the clearly labeled manual sandbox fallback.

The panel now reports the detected engine and states that bore, stroke, compression, and physical fitment are not exposed by this identity catalog. Those dimensions remain manually entered hypothetical sandbox values. No tune, ECU setting, CMS dyno output, save data, engine compatibility, part fitment, or vehicle performance is written or changed by this feature. No game hook was added for vehicle selection or tuning; the existing `CurrentEngineIdentifier()` path is reused.

A small overlap between the new layout-detection note and the geometry-input row was removed so the panel remains readable. This is a presentation correction only.

## Status against the broader expansion

This is a narrow dependency milestone, not completion of the comprehensive expansion. Automatic identity display/selection exists only inside the isolated ECU Lab simulation sandbox. Actual ECU calibration selection/application, fuel and ignition maps, live boost maps, hardware-aware calibration limits, verified physical turbo installation, engine-specific measured geometry, durability, component shop, full-build save/load, and game-confirmed dyno integration remain partial, missing, or unverified as documented in `docs/EXPANSION-STATUS.md`.

The existing 0.8.94 gearbox radial recovery remains intact: the custom ECU Lab sandbox still opens with F9 and does not modify the car-parts radial menu. 0.8.94 remains installed; this 0.8.95 candidate was not installed and CMS was not launched.

## Verification

- C# plugin build: **PASS** (0.8.95).
- Engine identity catalog: **7/7 PASS**.
- ECU Lab simulation core reference tests: **23/23 PASS**.
- Turbo dependency validator: **5/5 PASS** (standalone model only; not wired to CMS install).
- Calibration schema: **9/9 PASS**.
- ECU map evaluator: **8/8 PASS**.
- Turbo size model: **14/14 PASS**.
- Charge-air model: **11/11 PASS**.
- Turbo operating-point model: **11/11 PASS**.
- Offline source/game-signature/resource validator: **PASS**; it reports installed 0.8.94 and warns that 0.8.95 is review-only.
- CMS launch, F9 interaction, actual engine detection in the running game, saved calibration, dyno changes, and live save/reload: **NOT RUN**.

Built DLL SHA-256: `33C94466DB1B508C5255AEB0402824C394F7666A79C292A5DC5F093DBA9BB2D7`.

## Live check needed

With CMS closed before installation, install the candidate only if you want to test it. Open the ECU Lab sandbox with F9 while a vehicle engine is active. Confirm it displays the correct localized engine name, auto-selects the I4/I6/V6/V8 sandbox layout where applicable, keeps unsupported layouts labeled without misclassifying them, and leaves the neighboring custom gearbox radial action available. Do not interpret sandbox estimates as CMS ECU tuning or dyno results.
