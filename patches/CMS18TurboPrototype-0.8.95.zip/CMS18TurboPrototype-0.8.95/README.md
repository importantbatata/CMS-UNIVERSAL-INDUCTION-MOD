# CMS 2018 Forced Induction Mod — Patch 0.8.95 candidate

This candidate adds automatic installed-engine identity selection to the isolated ECU Lab simulation sandbox. It is not installed. CMS was not launched. See `report.md` for scope, test evidence, and remaining expansion work.
