# CMS 2018 Custom Induction Mod — Patch 0.8.60

This update changes the charge-pipe intake endpoint: if CMS does not expose readable mesh triangles, the route now targets the closest visible throttle/intake renderer bounds before using a collider and inserts slightly farther to close the seam.

**Installed and waiting for a visual check. CMS has not been launched with this patch.** No dyno test has been run. See report.md for the runtime evidence, build hash, rollback copy, and next check.
