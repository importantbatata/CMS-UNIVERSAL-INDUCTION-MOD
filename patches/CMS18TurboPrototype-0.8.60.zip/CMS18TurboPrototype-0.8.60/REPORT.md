# CMS 2018 Custom Induction Mod — Patch 0.8.60

**Date:** 2026-10-31  
**Build:** C# compilation succeeded; patch installed while CMS was closed.  
**Installed DLL SHA-256:** BFBABAD804368A5F8435D77569B032D0787A97E15ED1A5FD78BC35EBD20DB4C5  
**Rollback DLL:** rollback/CMS18TurboPrototype-0.8.59.dll (patch 0.8.59)  
**Status:** Installed; waiting for the user's visual check. CMS has not been launched with 0.8.60. No dyno run has been performed.

## Evidence leading to this change

- The user says the pipe inlet still looks slightly off and the gap/spacing along the tubing did not improve.
- The 0.8.59 runtime log reports that the R4 route targets r4_przepustnica, but the endpoint came from the intake collider because the game mesh triangles were not readable.
- The 0.8.59 route measured 0.34 m between the P-1X outlet and the throttle-body surface, with a -0.46 outlet-axis alignment. The old collider fallback inserted the pipe only 10 mm into that surface.
- CMS loaded 0.8.59 on profile 2 with zero patch errors. The I6 scan found no mounted intake target, so its charge-pipe connection remains unverified.

## Change in 0.8.60

- Added a fallback that finds the closest visible mesh bounds on the selected throttle/intake part when the game does not expose readable mesh triangles.
- The route now uses that renderer-mesh bounds point before falling back to a collider. It inserts the tube 24 mm into a renderer bound (or 30 mm into a collider) to reduce a visible seam.
- Kept the model-derived P-1X outlet, engine-clearance route, stand/car transfer, shops, menu, turbo/supercharger behavior, and power model unchanged.
- Added no new air-filter hose behavior. The R4 stand check is about the charge pipe from the ProCharger outlet to the throttle body.

## Build and installation

- Compiled from src/CMS18TurboPrototype.cs against the local CMS and BepInEx references.
- Installed in BepInEx/plugins; the prior 0.8.59 plugin is saved as the rollback copy listed above.
- The built and installed DLLs have the same SHA-256: BFBABAD804368A5F8435D77569B032D0787A97E15ED1A5FD78BC35EBD20DB4C5.
- CMS was not launched after installation. No live visual, save edit, dyno, or test-script run was performed for 0.8.60.

## Next live check

On the same sandbox profile, inspect the R4 Turbo on the engine stand from the same angle. Check that the charge pipe is attached at the ProCharger outlet and enters the throttle body without a visible gap, clipping, or a sharp kink. If it looks right, transfer the engine into the car and confirm the pipe remains connected. Hold dyno testing until the user accepts the physical routing.
