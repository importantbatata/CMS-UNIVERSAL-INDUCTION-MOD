const fs = require('node:fs');
const path = require('node:path');

const tau = Math.PI * 2;
const positions = [], normals = [], parts = [];
const add = (a, b) => a.map((v, i) => v + b[i]);
const sub = (a, b) => a.map((v, i) => v - b[i]);
const mul = (a, s) => a.map(v => v * s);
const dot = (a, b) => a.reduce((s, v, i) => s + v * b[i], 0);
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const unit = a => mul(a, 1 / Math.hypot(...a));
const lerp = (a, b, t) => a + (b - a) * t;
const ring = (count, shape) => Array.from({ length: count }, (_, i) => shape(i * tau / count));

function part(name) {
  const faces = new Map();
  parts.push({ name, faces });
  return faces;
}

function vertex(position, normal) {
  positions.push(position);
  normals.push(normal);
  return positions.length;
}

function triangle(faces, material, a, b, c) {
  const [p, q, r] = [a, b, c].map(i => positions[i - 1]);
  const normal = add(add(normals[a - 1], normals[b - 1]), normals[c - 1]);
  if (dot(cross(sub(q, p), sub(r, p)), normal) < 0) [b, c] = [c, b];
  if (!faces.has(material)) faces.set(material, []);
  faces.get(material).push([a, b, c]);
}

function join(faces, material, a, b) {
  for (let i = 0; i < a.length; i++) {
    const j = (i + 1) % a.length;
    triangle(faces, material, a[i], b[i], b[j]);
    triangle(faces, material, a[i], b[j], a[j]);
  }
}

// The profile follows the outside from negative to positive X, then returns
// along the bore. Breaks on flat faces keep the machined shoulders crisp.
function turn(name, center, profile, segments = 48, outline = null) {
  const faces = part(name);
  const surface = ([x, radius], angle) => {
    const [y, z] = outline ? outline(x, angle, radius) : [Math.cos(angle), Math.sin(angle)];
    return [x, center[0] + radius * y, center[1] + radius * z];
  };
  const profileNormal = (a, b, index, angle) => {
    const around = sub(surface(profile[index], angle + 0.001), surface(profile[index], angle - 0.001));
    const along = sub(surface(b, angle), surface(a, angle));
    return unit(cross(around, along));
  };
  for (let i = 0; i < profile.length; i++) {
    const j = (i + 1) % profile.length;
    const a = profile[i], b = profile[j];
    if (a[0] === b[0] && a[1] === b[1]) continue;
    const previous = profile[(i + profile.length - 1) % profile.length];
    const next = profile[(j + 1) % profile.length];
    const start = ring(segments, angle => vertex(surface(a, angle), profileNormal(a[3] ? previous : a, b, i, angle)));
    const end = ring(segments, angle => vertex(surface(b, angle), profileNormal(a, b[3] ? next : b, j, angle)));
    join(faces, a[2], start, end);
  }
}

const cast = 'Cast_aluminum';
const machined = 'Machined_aluminum';
const steel = 'Steel';
const pulleyMetal = 'P1X_Pulley';
const seal = 'Dark_gasket';
const fastenerSteel = 'P1X_Fastener';
const pulley = [0, -0.095];

const caseOutline = (x, angle) => {
  const t = Math.max(0, Math.min(1, (-x - 0.08) / 0.17));
  return [Math.cos(angle) * (1 - 0.13 * t), Math.sin(angle) - 0.85 * t];
};

turn('P1X_compact_cast_gearcase', [0, 0], [
  [-0.266, 0.001, steel], [-0.266, 0.047, machined], [-0.261, 0.055, cast, true],
  [-0.245, 0.066, cast, true], [-0.220, 0.076, cast, true], [-0.179, 0.087, cast, true],
  [-0.120, 0.096, cast, true], [-0.078, 0.098, cast, true], [-0.061, 0.090, machined],
  [-0.055, 0.083, machined], [-0.055, 0.001, steel],
], 48, caseOutline);
turn('P1X_drive_bearing', pulley, [
  [-0.302, 0.001, steel], [-0.302, 0.030, steel], [-0.294, 0.037, machined],
  [-0.282, 0.040, cast, true], [-0.258, 0.044, cast], [-0.241, 0.036, cast],
  [-0.241, 0.001, steel],
], 36);

const ribProfile = [[-0.344, 0.043, pulleyMetal], [-0.344, 0.094, pulleyMetal], [-0.342, 0.1008, pulleyMetal]];
for (let rib = 0; rib < 6; rib++) {
  const x = -0.337 + 0.0082 * rib;
  ribProfile.push([x - 0.004, 0.1008, pulleyMetal], [x - 0.002, 0.095, pulleyMetal],
    [x + 0.002, 0.095, pulleyMetal], [x + 0.004, 0.1008, pulleyMetal]);
}
ribProfile.push([-0.288, 0.1008, pulleyMetal], [-0.286, 0.095, pulleyMetal], [-0.286, 0.039, pulleyMetal],
  [-0.307, 0.035, steel], [-0.339, 0.042, steel]);
turn('P1X_six_rib_drive_pulley', pulley, ribProfile, 40);
turn('P1X_pulley_hub', pulley, [
  [-0.349, 0.001, machined], [-0.349, 0.035, machined], [-0.346, 0.043, steel],
  [-0.334, 0.043, steel], [-0.301, 0.034, steel], [-0.301, 0.001, steel],
], 32);
turn('P1X_pulley_flange_bolt', pulley, [
  [-0.356, 0.001, steel], [-0.356, 0.012, machined], [-0.353, 0.016, steel],
  [-0.348, 0.016, steel], [-0.347, 0.018, steel], [-0.344, 0.018, steel], [-0.344, 0.001, steel],
], 6);

turn('P1X_drive_cover_seal', [0, 0], [
  [-0.246, 0.061, seal], [-0.244, 0.067, seal], [-0.242, 0.068, seal],
  [-0.240, 0.067, seal], [-0.239, 0.061, seal],
], 48, caseOutline);

function hardware(name, center, seat, direction, sections, segments, outline) {
  let profile = sections.map(([depth, radius, material]) => [seat + direction * depth, radius, material]);
  if (direction < 0) {
    profile = profile.map(([x, radius], i) => [x, radius, profile[(i + profile.length - 1) % profile.length][2]]).reverse();
  }
  turn(name, center, profile, segments, outline);
}

function hexShape(angle) {
  const sector = tau / 6;
  const faceAngle = ((angle % sector) + sector) % sector - sector * 0.5;
  const radius = Math.cos(sector * 0.5) / Math.cos(faceAngle);
  return [Math.cos(angle) * radius, Math.sin(angle) * radius];
}

const flangeSeats = [[30, 0.098], [120, 0.087], [210, 0.075], [300, 0.064]];
for (const [degrees, seat] of flangeSeats) {
  const angle = degrees * tau / 360;
  const center = [-0.038 + Math.cos(angle) * 0.108, -0.017 + Math.sin(angle) * 0.108];
  hardware('P1X_compressor_washer_' + degrees, center, seat, 1, [
    [-0.004, 0.004, machined], [-0.004, 0.012, machined], [0.001, 0.012, machined],
    [0.0025, 0.011, machined], [0.0025, 0.004, machined],
  ], 24);
  // The 30° and 210° washers seat the two interactive CMS mounting bolts.
  if (degrees === 30 || degrees === 210) continue;
  hardware('P1X_compressor_hex_bolt_' + degrees, center, seat, 1, [
    [-0.002, 0.003, fastenerSteel], [0.001, 0.009, fastenerSteel], [0.007, 0.009, fastenerSteel],
    [0.009, 0.0072, fastenerSteel], [0.009, 0.0006, fastenerSteel],
  ], 6);
}

for (const [i, angle] of [-0.18, 1.56, 3.31].entries()) {
  const center = caseOutline(-0.266, angle).map(coordinate => coordinate * 0.035);
  hardware('P1X_gearcase_socket_screw_' + i, center, -0.266, -1, [
    [-0.003, 0.003, fastenerSteel], [-0.002, 0.009, fastenerSteel],
    [0.003, 0.009, fastenerSteel], [0.005, 0.0078, fastenerSteel],
    [0.005, 0.0047, fastenerSteel], [0.0038, 0.0040, fastenerSteel],
    [0.001, 0.0040, fastenerSteel], [0.001, 0.0005, fastenerSteel],
  ], 24, (_x, a, radius) => radius <= 0.0047 ? hexShape(a) : [Math.cos(a), Math.sin(a)]);
}

const root = __dirname;
const compressorSource = fs.readFileSync(path.join(root, 'P1X_Compressor_Source.obj'), 'utf8').trim().split(/\r?\n/);
const compressorData = {v: [], vt: [], vn: [], faces: []};
const format = v => v.map(n => n.toFixed(6)).join(' ');
for (const line of compressorSource) {
  const [type, ...data] = line.split(' ');
  if (type === 'v') {
    const [x, y, z] = data.map(Number);
    compressorData.v.push('v ' + format([x, -0.038 + (y + 0.038) * 0.92, -0.017 + (z + 0.017) * 0.92]));
  } else if (type === 'vn') {
    const [x, y, z] = data.map(Number);
    compressorData.vn.push('vn ' + format(unit([x, y / 0.92, z / 0.92])));
  } else if (type === 'vt') {
    compressorData.vt.push(line);
  } else if (type !== '#') {
    compressorData.faces.push(line);
  }
}

const lines = ['# P-1X for CMS 2018. X is the shaft axis.',
  '# Pulley center (-0.315, 0, -0.095); belt pitch radius 0.1008.', 'mtllib CMS18_ProCharger_P1X.mtl',
  ...compressorData.v, ...positions.map(p => 'v ' + format(p)),
  ...compressorData.vt, ...positions.map(([x,y,z]) => 'vt ' + format([x * 4.3 - y * 1.7 + z * 2.0, y * 3.1 + z * 3.9])),
  ...compressorData.vn, ...normals.map(n => 'vn ' + format(n)),
  ...compressorData.faces,
];
const offsets = [compressorData.v.length, compressorData.vt.length, compressorData.vn.length];
let triangleCount = compressorData.faces.filter(line => line.startsWith('f ')).length;
for (const { name, faces } of parts) {
  lines.push('o ' + name);
  for (const [material, triangles] of faces) {
    lines.push('usemtl ' + material);
    for (const triangle of triangles)
      lines.push('f ' + triangle.map(vertex => offsets.map(offset => offset + vertex).join('/')).join(' '));
    triangleCount += triangles.length;
  }
}
fs.writeFileSync(path.join(root, 'CMS18_ProCharger_P1X.obj'), lines.join('\n') + '\n');
console.log(triangleCount + ' triangles');
