# Patch 0.8.92 — Restore stock radial action and separate ECU Lab entry

## Root cause

Patch 0.8.91 repurposed CMS's existing car radial **Tune parts** option as the ECU Lab launcher. It also matched the visible title, bypassing the stock handler for the neighboring custom gearbox-tuning action. That removed the normal gearbox-tuning route.

## Repair

- Restored the radial option reader, icon handling, selection, and description callbacks from the known-good 0.8.90 source.
- ECU Lab is appended as its own **Open ECU Lab** car-part radial option.
- Only the exact mod option ID opens the ECU Lab panel; CMS's stock **Tune parts** handler remains untouched.
- The engine-stand forced-induction menu path remains intact.
- Kept the one-time **$3,500 per-profile** simulation-sandbox unlock. The sandbox does not write a CMS ECU calibration or change CMS horsepower/dyno output.

## Verification

| Check | Result |
|---|---|
| C# plugin build | PASS — version 0.8.92 |
| Offline project validator | PASS — requires separate ECU Lab option and rejects the old stock-action interception |
| ECU Lab simulation reference checks | PASS — 23 assertions for the ported calculation subset |
| Installed game plugin | NOT UPDATED — waiting for a confirmed closed game |
| Live radial click and gearbox-tuning route | NOT RUN — requires in-game confirmation |
| ECU Lab result in CMS | NOT CLAIMED — the screenshot showed no active engine and blank bore/stroke inputs; the sandbox asks for valid geometry before calculating |

Built DLL SHA-256: `148C64515AB0E802E8C3A6FC2421F6CF02691A52B4DF63647596E9EC9B762C75`.

## Live test steps

1. Close CMS and install patch 0.8.92.
2. Open the same car-part radial menu.
3. Confirm the stock **Tune parts** option is present and still opens custom gearbox tuning.
4. Confirm **Open ECU Lab** appears as a separate option and opens the simulation panel.
5. In the sandbox, select an engine layout and enter valid bore and stroke values; its calculation is independent of CMS dyno/ECU behavior.
6. If either radial action is missing or routed incorrectly, capture the menu and latest BepInEx log.

## Files changed

- `src/CMS18TurboPrototype.cs` — restores native Tune parts behavior and adds a separate exact-ID ECU Lab action.
- `tools/validate_build.ps1` — validates the distinct option and protects the native Tune parts path.
- `CMS18TurboPrototype.dll` — rebuilt plugin, version 0.8.92.
- `README.md` — current patch and live-test status.
