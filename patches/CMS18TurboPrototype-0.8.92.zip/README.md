# CMS 2018 Turbo Prototype 0.8.92

Patch 0.8.92 restores the stock car-part radial **Tune parts** entry and adds ECU Lab as a separate radial choice. Patch 0.8.91 intercepted the native Tune parts action and removed the adjacent custom-gearbox action; this patch restores the native action and keeps ECU Lab separate. Selecting the new ECU Lab option opens the existing ECU Lab simulation sandbox. The sandbox remains separate from CMS engine tuning, horsepower, and dyno calculations. Its one-time $3,500 profile unlock remains available.

With CMS closed, place `CMS18TurboPrototype.dll` in `Car Mechanic Simulator 2018/BepInEx/plugins/`, replacing the prior plugin only after keeping a rollback copy. See `report.md` for verification and live-test steps. This patch has not been live-tested in CMS.

