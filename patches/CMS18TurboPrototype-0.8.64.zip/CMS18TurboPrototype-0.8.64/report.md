# CMS 2018 Custom Induction Mod — Patch 0.8.64

**Date:** 2026-11-01  
**Status:** Installed with CMS closed; awaiting live verification. CMS was not launched.  
**Build:** C# compilation succeeded.  
**Installed and package DLL SHA-256:** `88C389529BF778FFDEB344BC97B4FAC8A13BB7C4BFADE3E85BA6974E1023DBBD`

## Major bug diagnosis

The 0.8.63 BepInEx log records a Harmony setup failure while resolving `CarEngineHelper..ctor(CarLoader)`: Harmony `AccessTools.Method` does not resolve constructors. The outer patch-registration block then stopped, so the later `CarLoader.SetEngine`, engine transfer, shop and visual restoration hooks were never installed. That explains why the ProCharger could appear on the stand, then disappear after the engine went into the car. The dyno screenshot’s changed factory output was the earlier independent symptom from that same incomplete setup and its overly broad engine-spec hook.

Patch 0.8.64 resolves `.ctor` through reflection’s constructor lookup and handles patch failures individually, allowing later hooks to register even if a target method is unavailable. It retains the 0.8.63 measured-power scoping change. The explicit intended result is that saved induction kit visuals are restored when the engine is transferred into or loaded in a car.

## Verification / next live test

Build compilation succeeded. No automated test, CMS launch, or dyno test was run. First verify the game starts without a Harmony setup exception, then transfer the existing P-1X-equipped I4 engine from stand to car and confirm the blower remains visible and selectable in the bay. Do not dyno-test until this visual restoration passes. I6 radiator clearance remains a separate open issue.

## Rollback

`CMS18TurboPrototype-0.8.63-rollback.dll` restores the prior installed build. Keep user saves unchanged.

