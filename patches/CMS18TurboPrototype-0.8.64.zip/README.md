# Patch 0.8.64

See [report.md](report.md) for the 0.8.63 transfer failure diagnosis, code fix, verification, and live test steps. The game has not been launched with this build.
