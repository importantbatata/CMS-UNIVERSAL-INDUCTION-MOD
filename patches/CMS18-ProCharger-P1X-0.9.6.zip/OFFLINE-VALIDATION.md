# ProCharger P-1X 0.9.6 offline candidate

Engine transfers now require the kit identity recorded in the engine group. The game records a tuned part in the NormalID field. A boost setting alone cannot create a kit, and swapping to a bare engine clears the old car's fitted-kit record. The post-transfer check stops when the saved kit record is cleared.

Removal resolves the fitted part's engine stand or owning car before transferring it into inventory. The radial description uses the index supplied by the game.

Offline validation covered 30 hook signatures, 16 managed behavior checks, 11 charge-air checks, and the embedded 7,282-triangle OBJ. The OBJ matches v0.9.5 byte for byte. Live wheel input, inventory notifications, engine transfers, save and reload, and visual fit still need an in-game pass.
