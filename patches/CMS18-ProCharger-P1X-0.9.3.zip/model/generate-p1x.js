const fs = require('node:fs');
const path = require('node:path');

const tau = Math.PI * 2;
const positions = [], normals = [], parts = [];
const add = (a, b) => a.map((v, i) => v + b[i]);
const sub = (a, b) => a.map((v, i) => v - b[i]);
const mul = (a, s) => a.map(v => v * s);
const dot = (a, b) => a.reduce((s, v, i) => s + v * b[i], 0);
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const unit = a => mul(a, 1 / Math.hypot(...a));
const lerp = (a, b, t) => a + (b - a) * t;
const ring = (count, shape) => Array.from({ length: count }, (_, i) => shape(i * tau / count));

function part(name) {
  const faces = new Map();
  parts.push({ name, faces });
  return faces;
}

function vertex(position, normal) {
  positions.push(position);
  normals.push(normal);
  return positions.length;
}

function triangle(faces, material, a, b, c) {
  const [p, q, r] = [a, b, c].map(i => positions[i - 1]);
  const normal = add(add(normals[a - 1], normals[b - 1]), normals[c - 1]);
  if (dot(cross(sub(q, p), sub(r, p)), normal) < 0) [b, c] = [c, b];
  if (!faces.has(material)) faces.set(material, []);
  faces.get(material).push([a, b, c]);
}

function join(faces, material, a, b) {
  for (let i = 0; i < a.length; i++) {
    const j = (i + 1) % a.length;
    triangle(faces, material, a[i], b[i], b[j]);
    triangle(faces, material, a[i], b[j], a[j]);
  }
}

// The profile follows the outside from negative to positive X, then returns
// along the bore. Breaks on flat faces keep the machined shoulders crisp.
function turn(name, center, profile, segments = 48, outline = null) {
  const faces = part(name);
  const surface = ([x, radius], angle) => {
    const [y, z] = outline ? outline(x, angle) : [Math.cos(angle), Math.sin(angle)];
    return [x, center[0] + radius * y, center[1] + radius * z];
  };
  const profileNormal = (a, b, index, angle) => {
    const around = sub(surface(profile[index], angle + 0.001), surface(profile[index], angle - 0.001));
    const along = sub(surface(b, angle), surface(a, angle));
    return unit(cross(around, along));
  };
  for (let i = 0; i < profile.length; i++) {
    const j = (i + 1) % profile.length;
    const a = profile[i], b = profile[j];
    if (a[0] === b[0] && a[1] === b[1]) continue;
    const previous = profile[(i + profile.length - 1) % profile.length];
    const next = profile[(j + 1) % profile.length];
    const start = ring(segments, angle => vertex(surface(a, angle), profileNormal(a[3] ? previous : a, b, i, angle)));
    const end = ring(segments, angle => vertex(surface(b, angle), profileNormal(a, b[3] ? next : b, j, angle)));
    join(faces, a[2], start, end);
  }
}

const cast = 'P1X_Cast';
const machined = 'P1X_Machined';
const steel = 'P1X_Steel';
const darkSteel = 'P1X_Pulley';
const seal = 'Dark_gasket';
const bore = 'Dark_inlet';
const compressor = [-0.0378, -0.0173];

function compressorScroll() {
  const faces = part('P1X_cast_scroll_and_discharge');
  const stations = [];
  const addStation = (center, radial, depth, width, material) => stations.push({ center, radial, depth, width, material });
  const start = 0.58;
  for (let i = 0; i <= 72; i++) {
    const progress = i / 72;
    const angle = lerp(start, tau, progress);
    const growth = progress * progress * (3 - 2 * progress);
    const radial = [0, Math.cos(angle), -Math.sin(angle)];
    const distance = lerp(0.104, 0.154, growth);
    const center = add([0.027, ...compressor], mul(radial, distance));
    addStation(center, radial, lerp(0.048, 0.067, growth), lerp(0.051, 0.066, growth), cast);
  }
  const last = stations.at(-1).center;
  for (const [z, depth, width, material] of [
    [-0.052, 0.067, 0.065, cast], [-0.093, 0.065, 0.063, cast],
    [-0.155, 0.063, 0.063, cast], [-0.190, 0.063, 0.063, cast],
    [-0.196, 0.068, 0.068, cast], [-0.207, 0.069, 0.069, machined],
    [-0.217, 0.066, 0.066, machined], [-0.219, 0.060, 0.060, machined],
    [-0.215, 0.054, 0.054, machined], [-0.205, 0.052, 0.052, bore],
    [-0.159, 0.051, 0.051, bore], [-0.158, 0.001, 0.001, bore],
  ]) addStation([last[0], last[1], z], [0, 1, 0], depth, width, material);

  const point = (i, a) => {
    const { center, radial, depth, width } = stations[i];
    return add(add(center, [depth * Math.cos(a), 0, 0]), mul(radial, width * Math.sin(a)));
  };
  const rings = stations.map((_, i) => ring(36, a => {
    const along = sub(point(Math.min(i + 1, stations.length - 1), a), point(Math.max(i - 1, 0), a));
    const around = sub(point(i, a + 0.001), point(i, a - 0.001));
    return vertex(point(i, a), unit(cross(along, around)));
  }));
  // The small end of the scroll meets the cast backplate. Close both ends
  // to keep the interior dark when inspecting the model close up.
  for (let i = 1; i < rings.length; i++) join(faces, stations[i].material, rings[i - 1], rings[i]);
  for (const [i, normal, material] of [[0, [0, Math.sin(start), Math.cos(start)], cast], [rings.length - 1, [0, 0, -1], bore]]) {
    const center = vertex(stations[i].center, normal);
    const rim = rings[i].map(index => vertex(positions[index - 1], normal));
    for (let j = 0; j < rim.length; j++) triangle(faces, material, center, rim[j], rim[(j + 1) % rim.length]);
  }
}

compressorScroll();
turn('P1X_cast_backplate_and_bellmouth', compressor, [
  [-0.075, 0.078, machined], [-0.066, 0.129, cast], [-0.056, 0.146, cast, true],
  [-0.034, 0.153, cast, true], [0.017, 0.150, cast, true], [0.045, 0.133, cast, true],
  [0.074, 0.103, cast, true], [0.098, 0.087, cast, true], [0.131, 0.078, machined, true],
  [0.157, 0.078, machined], [0.163, 0.083, machined], [0.173, 0.083, machined, true],
  [0.179, 0.078, machined, true], [0.179, 0.070, machined], [0.174, 0.065, machined, true],
  [0.159, 0.061, machined, true], [0.133, 0.058, machined, true], [0.109, 0.058, bore],
  [0.089, 0.061, bore], [0.086, 0.002, bore], [-0.075, 0.002, machined],
], 64);
turn('P1X_impeller_hub', compressor, [
  [0.087, 0.056, darkSteel], [0.102, 0.056, steel], [0.109, 0.027, steel, true],
  [0.130, 0.014, machined, true], [0.138, 0.009, machined], [0.139, 0.001, steel], [0.087, 0.001, steel],
]);

function impeller() {
  const faces = part('P1X_curved_impeller_vanes');
  for (let vane = 0; vane < 14; vane++) {
    const angle = vane * tau / 14;
    const splitter = vane % 2 === 1;
    const bladePoint = (t, side, top) => {
      const radius = lerp(splitter ? 0.031 : 0.015, 0.057, t);
      const a = angle + 0.69 * t ** 1.28 + side * 0.0012 / radius;
      const root = 0.101 + (1 - t) ** 1.35 * (splitter ? 0.013 : 0.025);
      return [root + top * (0.004 + 0.009 * Math.sin(Math.PI * t)), compressor[0] + radius * Math.cos(a), compressor[1] + radius * Math.sin(a)];
    };
    const section = t => [[-1, 0], [-1, 1], [1, 1], [1, 0]].map(([side, top]) => bladePoint(t, side, top));
    let a = section(0);
    for (let i = 1; i <= 9; i++) {
      const b = section(i / 9);
      for (let j = 0; j < 4; j++) {
        const k = (j + 1) % 4;
        const normal = unit(cross(sub(b[j], a[j]), sub(a[k], a[j])));
        const [p, q, r, s] = [a[j], b[j], b[k], a[k]].map(p => vertex(p, normal));
        triangle(faces, j === 1 ? machined : steel, p, q, r);
        triangle(faces, j === 1 ? machined : steel, p, r, s);
      }
      a = b;
    }
  }
}
impeller();

const timingOutline = (x, a) => {
  const t = Math.max(0, Math.min(1, (-x - 0.10) / 0.20));
  const [y, z] = [Math.cos(a), Math.sin(a)];
  // The rear cover grows downward toward the offset pulley bearing.
  const lobe = 1 + 0.22 * Math.max(0, -z) ** 2;
  return [y * lobe * (1 - 0.10 * t), z * lobe - 0.57 * t];
};
turn('P1X_cast_gearcase', [0, 0], [
  [-0.324, 0.049, machined], [-0.322, 0.069, cast, true], [-0.311, 0.089, cast, true],
  [-0.284, 0.098, cast, true], [-0.238, 0.102, cast, true], [-0.161, 0.105, cast, true],
  [-0.099, 0.107, cast, true], [-0.072, 0.106, cast, true], [-0.061, 0.097, machined],
  [-0.056, 0.096, machined], [-0.051, 0.088, machined], [-0.051, 0.002, steel], [-0.324, 0.002, steel],
], 64, timingOutline);
turn('P1X_timing_cover_seam', [0, 0], [
  [-0.297, 0.086, seal], [-0.296, 0.0963, seal], [-0.291, 0.098, seal],
  [-0.289, 0.088, seal],
], 64, timingOutline);

const pulley = [0, -0.095];
turn('P1X_drive_bearing_and_shaft', pulley, [
  [-0.397, 0.001, steel], [-0.397, 0.037, steel], [-0.379, 0.043, machined],
  [-0.368, 0.050, machined, true], [-0.346, 0.050, cast], [-0.340, 0.057, cast, true],
  [-0.313, 0.057, cast, true], [-0.299, 0.050, cast], [-0.299, 0.001, steel],
]);
const ribProfile = [[-0.434, 0.055, darkSteel], [-0.434, 0.094, darkSteel], [-0.432, 0.1008, darkSteel]];
for (let rib = 0; rib < 6; rib++) {
  const x = -0.427 + 0.0082 * rib;
  ribProfile.push([x - 0.004, 0.1008, darkSteel], [x - 0.0026, 0.095, darkSteel],
    [x - 0.0011, 0.0948, darkSteel], [x + 0.0011, 0.0948, darkSteel],
    [x + 0.0026, 0.095, darkSteel], [x + 0.004, 0.1008, darkSteel]);
}
ribProfile.push([-0.378, 0.1008, darkSteel], [-0.376, 0.095, darkSteel], [-0.376, 0.044, darkSteel],
  [-0.382, 0.042, darkSteel], [-0.426, 0.042, darkSteel], [-0.426, 0.055, darkSteel]);
turn('P1X_six_rib_drive_sheave', pulley, ribProfile, 48);
turn('P1X_recessed_drive_hub', pulley, [
  [-0.433, 0.001, steel], [-0.433, 0.031, machined], [-0.431, 0.042, machined],
  [-0.425, 0.045, darkSteel], [-0.379, 0.045, darkSteel], [-0.374, 0.038, darkSteel], [-0.374, 0.001, steel],
]);

function fastener(name, center, x, radius, towardFront) {
  const direction = towardFront ? 1 : -1;
  const profile = [[x - direction * 0.003, 0.001, steel], [x - direction * 0.003, radius * 1.13, steel],
    [x, radius * 1.13, steel], [x, radius, steel], [x + direction * radius * 0.48, radius, steel],
    [x + direction * radius * 0.61, radius * 0.76, machined], [x + direction * radius * 0.61, 0.001, steel]];
  if (!towardFront) profile.reverse();
  turn(name, center, profile, 6);
}
fastener('P1X_pulley_center_flange_bolt', pulley, -0.435, 0.018, false);

for (let i = 0; i < 6; i++) {
  const a = (i + 0.5) * tau / 6;
  const center = [Math.cos(a) * 0.072, -0.060 + Math.sin(a) * 0.078];
  turn(`P1X_cover_boss_${i}`, center, [
    [-0.323, 0.001, cast], [-0.323, 0.013, cast], [-0.320, 0.016, cast],
    [-0.283, 0.019, cast], [-0.281, 0.001, cast],
  ], 20);
  fastener(`P1X_cover_bolt_${i}`, center, -0.324, 0.0085, false);
}

for (const side of [-1, 1]) {
  const center = [side * 0.105, -0.132];
  turn(`P1X_cast_mount_ear_${side}`, center, [
    [-0.200, 0.001, cast], [-0.200, 0.010, cast], [-0.194, 0.020, cast, true], [-0.173, 0.023, cast, true],
    [-0.100, 0.024, cast, true], [-0.077, 0.022, cast, true], [-0.069, 0.018, machined],
    [-0.068, 0.001, machined],
  ], 24);
  fastener(`P1X_mount_flange_bolt_${side}`, center, -0.068, 0.013, true);
  turn(`P1X_mount_gusset_${side}`, [side * 0.087, -0.105], [
    [-0.238, 0.001, cast], [-0.226, 0.014, cast, true], [-0.185, 0.033, cast, true],
    [-0.105, 0.039, cast, true], [-0.085, 0.029, cast, true], [-0.076, 0.001, cast],
  ], 20, (_x, a) => [0.65 * Math.cos(a), Math.sin(a)]);
}

for (let i = 0; i < 5; i++) {
  const a = (i + 0.4) * tau / 5;
  const center = [compressor[0] + 0.124 * Math.cos(a), compressor[1] + 0.124 * Math.sin(a)];
  fastener(`P1X_backplate_retainer_${i}`, center, -0.068, 0.010, false);
}

const format = v => v.map(n => n.toFixed(6)).join(' ');
const lines = ['# Original P-1X model for CMS 2018. X is the shaft axis.',
  '# Pulley center (-0.405, 0, -0.095); belt pitch radius 0.1008.', 'mtllib CMS18_ProCharger_P1X.mtl'];
lines.push(...positions.map(p => `v ${format(p)}`), ...normals.map(n => `vn ${format(n)}`));
for (const [x, y, z] of positions) lines.push(`vt ${format([x * 4.3 - y * 1.7 + z * 2.0, y * 3.1 + z * 3.9])}`);
let triangleCount = 0;
for (const { name, faces } of parts) {
  lines.push(`o ${name}`);
  for (const [material, triangles] of faces) {
    lines.push(`usemtl ${material}`);
    for (const t of triangles) lines.push(`f ${t.map(i => `${i}/${i}/${i}`).join(' ')}`);
    triangleCount += triangles.length;
  }
}
const output = path.join(__dirname, 'CMS18_ProCharger_P1X.obj');
fs.writeFileSync(output, `${lines.join('\n')}\n`);
console.log(`${parts.length} objects, ${positions.length} vertices, ${triangleCount} triangles`);
