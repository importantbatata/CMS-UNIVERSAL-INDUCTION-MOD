# CMS 2018 Turbo Prototype 0.8.90

Adds an **ECU Lab** action to the stock car-part radial menu, separate from vanilla **Tune parts**. It opens the ECU Lab simulation sandbox and costs $3,500 once per CMS profile. The simulator does not flash a real ECU or change CMS engine power/dyno output.

Install by placing `CMS18TurboPrototype.dll` in `Car Mechanic Simulator 2018/BepInEx/plugins/`. Do not replace the plugin while CMS is running. See `report.md` for scope, checks, and live-test steps.

Installed with a rollback backup; CMS was not launched or live-tested. DLL SHA-256: `8EE19134A1194CED61B75684069E00251E354CA347369523ADD67E320C7B3E26`.


