# Patch 0.8.90 — ECU Lab radial entry and profile unlock

## User-visible change

Adds a separate **ECU Lab** action to the stock `!PartSelect` car-part radial menu. The vanilla **Tune parts** choice remains in place. Selecting ECU Lab opens the existing embedded ECU Lab simulation panel. Its first screen offers one $3,500 purchase using the active CMS profile's player funds. The unlock is recorded per profile, so a completed purchase is not charged again for that profile.

After unlock, the panel displays the detected CMS engine identifier when the game exposes one and presents the existing simulator's engine-geometry and charge-temperature sandbox inputs. It explicitly labels the tool as a simulation sandbox. It does not install or unlock an actual game ECU, write a CMS calibration, or change CMS horsepower or dyno results.

## Implementation details

- Added `cms18_open_ecu_lab` as its own radial option; it does not replace or intercept the stock `Tune parts` option.
- Added a radial icon copied from a stock tuning-related menu icon, with a safe fallback to another existing radial icon.
- The radial selection closes the stock radial and opens the plugin panel. The plugin cursor lock is paused while the custom panel owns mouse input and the previous cursor state is restored on close or plugin shutdown.
- Access cost is $3,500. The transaction uses CMS `GlobalData.GetPlayerMoney`, `AddPlayerMoney`, and `Save`. Insufficient funds block the transaction; if CMS reports that saving the charge failed, the code attempts a refund.
- Unlock state is stored in the profile-scoped PlayerPrefs namespace already used by this plugin.
- UI and menu descriptions distinguish the sandbox from real ECU flashing and live CMS performance tuning.

## Verification

| Check | Result |
|---|---|
| C# plugin build | **PASS** — version 0.8.90; no compiler warnings |
| ECU Lab JavaScript-reference/safety assertions | **PASS** — 23 assertions for the already ported calculation subset |
| Offline CMS project validator | **PASS** — radial/unlock source check and existing project checks pass |
| CMS installation | **INSTALLED** — previous plugin backed up to `build/installed-backups/CMS18TurboPrototype-20261105-183641.dll` |
| CMS launch / radial-menu interaction / actual currency transaction | **NOT RUN** — installed only; game remains closed |
| Live unlock persistence and refund behavior | **NOT RUN** — requires in-game test |

The offline checks cannot prove the game displays the new radial entry, its copied icon is the best match, or CMS's runtime money-save behavior succeeds. Do not treat those as live-verified.

## Changed project files

- `src/CMS18TurboPrototype.cs` — version 0.8.90; ECU Lab radial option, UI entry/unlock, profile preference, CMS-funds transaction/refund, cursor ownership, localization, and icon selection.
- `tools/validate_build.ps1` — updated cursor assertion for both overlays and added checks for the ECU Lab radial/unlock wiring.
- `README.md` — patch 0.8.90 summary and status.

## Live test steps

1. Start CMS with the patch installed and use a disposable/test profile if possible.
2. Open the car-part radial menu shown in the user's screenshot.
3. Confirm **Tune parts** still appears and works as before; confirm the separate **ECU Lab** action appears.
4. Select ECU Lab. With no unlock, confirm the panel states the $3,500 price and available funds.
5. If using the test profile, purchase once and confirm exactly $3,500 is deducted and the sandbox opens.
6. Close/reopen the panel and verify it does not charge a second time.
7. Exit/reload the same profile and verify the unlock persists.
8. Check BepInEx log for `Opened the ECU Lab simulation sandbox` and `Unlocked ECU Lab simulation sandbox`.

If checking insufficient-funds/refund behavior, use a disposable test profile and do not alter the user's primary save.

