# CMS 2018 ProCharger P-1X — patch 0.9.0

## Scope

This is the existing forced-induction mod, narrowed to its ProCharger P-1X implementation. The BepInEx plugin keeps its original GUID and existing P-1X part IDs. The active UI and custom shop list no longer offer the mod's generic turbo or Roots-supercharger kits. ECU Lab has no active source, UI, or build integration.

## Included

- Standard P-1X Main Shop product and high-boost Tuning Shop product.
- Engine-stand radial action and single-kit selection UI.
- Universal mount and P-1X model, with existing belt, bracket, inlet, and charge-pipe visual construction.
- Two mounting-bolt objects now use the verified CMS `MountObject` unscrew flow and the dedicated mount-object raycast layer. The visible bolt heads remain exposed while the P-1X body is hidden during removal.
- Boost target display and the P-1X speed-squared compressor approximation.
- P-1X component limits: 20 PSI street kit, 32 PSI high-boost kit, 65,000 rpm modeled impeller ceiling, 4.10:1 step-up ratio, and 950 hp clamp.
- Existing dyno torque/power hooks scoped to an installed custom P-1X part.

The performance curve is a bounded game approximation. It is not a live fluid simulation or a verified manufacturer compressor map.

## Legacy save handling

Old numeric turbo/Roots settings map to Off. Old custom kit IDs remain recognized only for compatibility with saved `PartScript` records; they do not activate boost and are excluded from the shop and mount selector. They are not converted into P-1X parts.

## Validation

Patch 0.9.0 compiles and passes the offline P-1X, charge-air, and CMS-signature checks (11/11, 11/11, and 21 checks). The screw repair matches the inspected native `MountObject` and `GameScript.SelectToUnMount` path, but no in-game click test occurred. Installation/removal, radial-menu behavior, shop transactions, engine transfer, save/load, and dyno results remain unverified for this build.

## Play without the mod

The active game plugin was moved out of `BepInEx/plugins`. Start CMS 2018 from Steam. The original DLL and full pre-0.9 source snapshot are stored under `build/` for rollback.
