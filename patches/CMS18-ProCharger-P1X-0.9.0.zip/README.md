# CMS 2018 ProCharger P-1X — patch 0.9.0

A focused BepInEx/Harmony add-on for Car Mechanic Simulator 2018. This release keeps the existing P-1X kit and retires the mod's turbocharger, Roots-supercharger, and ECU Lab features.

## Current game state

The mod DLL is currently removed from the active game plugin folder so the game can be played without this mod. The game has not been launched by this project. Launch CMS 2018 normally through Steam for unmodded play. This only disables this plugin; any other BepInEx plugins remain installed.

The previous installed plugin is preserved at `build/installed-disabled-backups/CMS18TurboPrototype-disabled-20261111.dll`. Patch 0.9.0 is a built review candidate and has not been installed. The clean package is [CMS18-ProCharger-P1X-0.9.0.zip](build/release_0.9.0/CMS18-ProCharger-P1X-0.9.0.zip); see the [patch report](build/release_0.9.0/report.md).

## Patch 0.9.0

- Limits the mod's choices and custom shop registrations to standard and high-boost ProCharger P-1X kits.
- Keeps the existing engine-stand radial entry, shop integration, universal P-1X mount, model, boost display, and dyno hooks.
- Uses the P-1X-specific centrifugal speed curve and bounded pressure/power ratings already present in the project; it does not expose generic turbo size selection.
- Adds two runtime P-1X mounting fasteners through CMS's verified `MountObject` workflow. They use the game's bolt raycast layer and unscrew speed field; the fastener renderers stay visible during part removal.
- Migrates saved non-ProCharger mode selections to Off. The stable plugin GUID and P-1X part IDs remain unchanged.
- Keeps legacy turbo/Roots identifiers only to safely recognize old saved custom parts. Those retired parts are not sold, selectable, or applied to performance. They are filtered out of the universal-mount selector.
- Removes ECU Lab from the active plugin source, build inputs, and runtime UI.
- Moves old turbo/Roots source, models, tests, and the pre-0.9 project snapshot into `build/source-backups/` for recovery.

## Parts

| Part | CMS shop | Price | Modeled limit |
|---|---|---:|---:|
| ProCharger P-1X | Main Shop | $12,500 | 20 PSI boost target |
| ProCharger P-1X High-Boost | Tuning Shop | $24,900 | 32 PSI boost target |

The plugin uses the stock `turbo_2` CMS prefab as its verified item/mount host and embeds the P-1X OBJ for the custom visual. P-1X values such as 65,000 rpm, 4.10:1 internal step-up ratio, 32 PSI, and 950 hp are component-model bounds; the in-game dyno model remains an estimate, not a manufacturer-map or full thermodynamic simulation.

## Build and offline validation

From this project directory in Windows PowerShell:

```powershell
.\build.ps1
.\tools\test_charge_air_model.ps1
.\tools\test_power_curves.ps1
.\tools\validate_build.ps1
```

The scripts compile against the local CMS/BepInEx assemblies, check the bounded charge-air/P-1X calculations, inspect verified game method signatures (including bolt unmount selection), and confirm that the build embeds only the P-1X custom mesh. Latest checks: charge-air 11/11; P-1X behavior/source 11/11; CMS API validator 21 checks. They do not launch the game or prove live installation, shop, save/load, or dyno behavior.

## Install when you choose to test

Close CMS first, then copy `build/CMS18TurboPrototype.dll` to the game's `BepInEx/plugins/CMS18TurboPrototype.dll`. Do not copy it there while you want to play without this mod. Existing vehicle saves are not modified by the build process. Back up a save before testing old vehicles that contain retired custom turbo/Roots kit IDs.

To return to the previous installed plugin, copy the dated backup DLL above into `BepInEx/plugins/CMS18TurboPrototype.dll` while CMS is closed.

## Status and limits

Build and offline checks passed for patch 0.9.0. The screw repair is based on the game's inspected `MountObject` and `GameScript.SelectToUnMount` implementation, but actual clicking and unscrewing still require in-game testing. CMS was not launched. The P-1X visual alignment, radial selection, shop purchase, dyno response, engine transfer, and save/load also remain unverified in game.

Patch 0.9.0 is intentionally ProCharger-only. Turbocharging, twin-turbo, Roots/twin-screw superchargers, ECU Lab, editable ECU maps, standalone engine durability/failure simulation, and component-by-component turbo plumbing are not part of this build.
