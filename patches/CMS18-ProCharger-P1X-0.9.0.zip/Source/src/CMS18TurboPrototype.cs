using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace CMS18TurboPrototype
{
    public enum InductionMode
    {
        Off = 0,
        // Values 1 and 2 are retained because 0.8.x persisted these integers.
        // ReadMode now migrates both retired configurations to Off.
        Turbo = 1,
        Supercharger = 2,
        Procharger = 3
    }

    internal static class PluginInfo
    {
        internal const string Version = "0.9.0";
    }

    [BepInPlugin("local.cms18.turboproto", "CMS 2018 ProCharger P-1X", PluginInfo.Version)]
    public sealed class TurboPrototypePlugin : BaseUnityPlugin
    {
        private const string AddForcedInductionPieOption = "cms18_add_forced_induction";
        // Keep the click callback type local to this plugin, then adapt it to
        // Button.onClick's UnityAction in the listener.
        private delegate void MainMenuClickCallback();

        private const string GlobalModeKey = "Mode";
        private const string GlobalPsiKey = "BoostPsi";
        private const string GroupModePrefix = "GroupMode.";
        private const string GroupPsiPrefix = "GroupPsi.";
        private const string EngineModePrefix = "EngineMode.";
        private const string EnginePsiPrefix = "EnginePsi.";
        private const string CarModePrefix = "CarMode.";
        private const string CarPsiPrefix = "CarPsi.";
        private const string MetaModeKey = "cms18_induction_mode";
        private const string MetaPsiKey = "cms18_boost_psi";
        private const string ProchargerPartId = "cms18_procharger_p1x";
        private const string ProchargerHighBoostPartId = "cms18_procharger_p1x_highboost";
        // Keep aliases only to load/remove parts saved by pre-0.9 builds. They are
        // excluded from shops, selectors, and the performance activation path.
        private const string RetiredTurboKitPartId = "cms18_turbo_kit";
        private const string RetiredRootsKitPartId = "cms18_supercharger_kit";
        private const string UniversalMountPartId = "cms18_universal_induction_mount";
        private const string UniversalMountDisplayName = "CMS18 Universal Induction Mount";
        private const int PartSelectionLayer = 16;
        // CMS Raycast.Init assigns 32768 (1 << 15) to mountObjectsRaycastMask.
        // Bolt colliders must use this layer; the parent part itself uses layer 16.
        private const int MountObjectSelectionLayer = 15;
        private const string VirtualMountAnchorName = "CMS18 Induction Mount Fasteners";
        private const string ProchargerMountFastenerPrefix = "CMS18 Induction Mount Bolt ";
        private const string ProchargerBasePartId = "turbo_2";
        // Published P-1X limits: ProCharger Supercharger Specs (02/2026).
        // At peak engine RPM, the boost target sets a pulley ratio that stays
        // inside this impeller speed limit; centrifugal pressure rise follows N^2.
        private const float P1XMaxBoostPsi = 32.0f;
        private const float P1XStreetMaxBoostPsi = 20.0f;
        private const float P1XHighBoostDefaultPsi = 24.0f;
        private const float P1XMaxFlowCfm = 1275.0f;
        private const float P1XMaxSuperchargedHp = 950.0f;
        private const float P1XMaxImpellerRpm = 65000.0f;
        private const float P1XInternalStepUpRatio = 4.10f;
        // The P-1X OBJ is authored at 0.4 game-world meters per model unit.
        // This is checked against the 9-inch volute and 3.75-inch inlet geometry.
        private const float ProchargerModelUnitScale = 0.40f;
        private const float ProchargerOutletHoseDiameterMeters = 0.0762f;
        private const float ProchargerInletHoseInnerDiameterMeters = 0.09525f;
        private const float ProchargerInletHoseWallThicknessMeters = 0.004f;
        private const float ProchargerChargePipeClampWidthMeters = 0.010f;
        // A common ProCharger street-system drive uses the factory six-rib belt.
        private const float ProchargerDriveBeltWidthMeters = 0.0213f;
        private const float ProchargerDriveBeltThicknessMeters = 0.0034f;
        private const float SeaLevelAirDensityLbPerCubicFoot = 0.076f;
        private const float EstimatedHorsepowerPerLbPerMinute = 10.0f;
        private const float PsiPerAtmosphere = 14.7f;
        private const float PsiPerInchOfMercury = 2.03602f;
        private const float MaxManifoldVacuumPsi = 20.0f / PsiPerInchOfMercury;
        private const float BoostGaugeMinimumPsi = -10.0f;
        private const float BoostGaugeMaximumPsi = 32.0f;
        private static readonly Vector3 ProchargerDrivePulleyCenter = new Vector3(-0.405f, 0.0f, -0.095f);
        private static readonly Vector3 ProchargerModelBoundsCenter = new Vector3(-0.1315f, 0.027f, 0.018f);
        // Charge-pipe socket data is recovered from the named outlet bore and bead
        // geometry in the embedded OBJ when it is loaded. These values are safe
        // fallbacks only; runtime ports are measured from the asset mesh.
        private static Vector3 ProchargerChargePipeOutlet = new Vector3(0.0203f, 0.2817f, 0.2310f);
        private static Vector3 ProchargerChargePipeDirection = new Vector3(0.1690f, 0.8452f, 0.5071f);
        private static float ProchargerChargePipeOuterRadiusModel = 0.09525f;
        private static float ProchargerChargePipeInnerRadiusModel = 0.083f;
        private static readonly Vector3 ProchargerInletHoseMouth = new Vector3(0.168f, 0.000f, 0.000f);
        private const string InstalledInductionVisualName = "CMS18 Universal Induction Installed Model";
        private const string InstalledKitModePrefix = "InstalledKit.";
        private const float ContextRefreshSeconds = 3.0f;
        private const float VisualRefreshSeconds = 4.0f;
        private const float UiTextRefreshSeconds = 0.15f;
        private const float MainMenuModsRefreshSeconds = 0.75f;
        private static readonly InductionMode[] ModeButtons =
        {
            InductionMode.Off, InductionMode.Procharger
        };
        private static readonly float[] StandModeButtonWidths = { 64.0f, 176.0f };
        private static readonly float[] GaugeModeButtonWidths = { 46.0f, 122.0f };
        private static readonly float[] BoostGaugeMajorPsiMarks = { -10.0f, 0.0f, 10.0f, 20.0f, 30.0f };
        private static readonly string[] BoostGaugeMajorLabels = { "20", "0", "10", "20", "30" };

        public static TurboPrototypePlugin Instance;

        private Harmony harmony;
        private InductionMode selectedMode = InductionMode.Off;
        private float selectedBoostPsi = 8.0f;
        private string standGroupKey = string.Empty;
        private string standGroupName = string.Empty;
        private int standGroupUid;
        private NewGroupItem standGroup;
        private bool standOccupied;
        private string activeCarKey = string.Empty;
        private VPVehicleController activeController;
        private InductionMode activeMode = InductionMode.Off;
        private float activeBoostPsi = 8.0f;
        private VehiclePhysics.Engine lastEngine;
        private bool dynoTorqueSampling;
        private bool dynoMeasuredSpecsContext;
        private GUIStyle uiPanelStyle;
        private GUIStyle uiHeaderBarStyle;
        private GUIStyle uiAccentStyle;
        private GUIStyle uiHeaderTextStyle;
        private GUIStyle uiBodyTextStyle;
        private GUIStyle uiMutedTextStyle;
        private GUIStyle uiButtonStyle;
        private GUIStyle uiSelectedButtonStyle;
        private GUIStyle uiSliderStyle;
        private GUIStyle uiSliderThumbStyle;
        private GUIStyle uiGaugeTrackStyle;
        private GUIStyle uiGaugeFillStyle;
        private GUIStyle uiGaugeTickStyle;
        private GUIStyle uiGaugeWarnTickStyle;
        private GUIStyle uiGaugeDangerTickStyle;
        private GUIStyle uiGaugeNeedleStyle;
        private Texture2D boostGaugeFaceTexture;
        private readonly List<Texture2D> uiTextures = new List<Texture2D>();
        private float lastRpm;
        private float lastThrottle;
        private float lastNetTorque;
        private float currentSpool;
        private float spoolTarget;
        private float liveBoostPsi;
        private bool dynoPowerDiagnosticLogged;
        private bool dynoSpecsDiagnosticLogged;
        private float nextContextRefresh;
        private float nextVisualRefresh;
        private float nextMainMenuModsRefresh;
        private GameObject mainMenuModsButton;
        private GameObject mainMenuExitButton;
        private GameObject mainMenuModsPanel;
        private HorizontalItemsMove mainMenuHorizontalItems;
        private string lastMainMenuProbeState = String.Empty;
        private GameObject visualRoot;
        private InductionMode visualMode;
        private InductionMode standNativeMode;
        private bool standHasNativeInduction;
        private bool standHasHighBoostProcharger;
        private bool showInductionChooser;
        private bool chooserCursorStateCaptured;
        private bool chooserPreviousCursorVisible;
        private CursorLockMode chooserPreviousCursorLockState;
        private Cursor3D chooserGameCursor;
        private bool chooserPreviousGameCursorVisible;
        private InductionMode pendingChooserMode = InductionMode.Procharger;
        private float pendingChooserPsi = 8.0f;
        private bool cachedCarburetedContext;
        private float nextCarburetorProbe;
        private bool activeHasNativeInduction;
        private bool activeHasCustomInduction;
        private bool activeHasHighBoostProcharger;
        private string activeNativePartId = string.Empty;
        private readonly Dictionary<InductionMode, Mesh> inductionModelMeshes = new Dictionary<InductionMode, Mesh>();
        private readonly Dictionary<InductionMode, Material[]> inductionModelMaterials = new Dictionary<InductionMode, Material[]>();
        private readonly HashSet<InductionMode> inductionModelLoadAttempted = new HashSet<InductionMode>();
        private Material prochargerDriveBeltMaterial;
        private Material prochargerBracketMaterial;
        private Material prochargerChargePipeMaterial;
        private Material prochargerInletHoseMaterial;
        private string status = "Waiting for an engine stand or driving test scene";
        private int settingsProfile;
        private GameInventory registeredShopInventory;
        private bool inductionShopItemsRegistered;
        private bool shopRegistrationWarningLogged;
        private string lastShopReadinessDiagnostic = String.Empty;
        private readonly HashSet<string> loggedShopQueryStates = new HashSet<string>();
        private NewGroupItem pendingInstallGroup;
        private string pendingInstallGroupName;
        private CarLoader pendingInstallLoader;
        private InductionMode pendingInstallMode;
        private float pendingInstallPsi;
        private bool pendingSwapObserved;
        private bool pendingHasUniversalMount;
        private bool radialMenuActionAddedLogged;
        private bool radialMenuDiagnosticLogged;
        private float nextUiTextRefresh;
        private string cachedStandEngineText = "Engine: waiting";
        private string cachedStandBoostText = "Target boost  8.0 psi";
        private string cachedStandStatusText = "Waiting for an engine stand or driving test scene";
        private string cachedGaugeBoostText = "MAP  0.0 psi";
        private string cachedGaugeMapText = "MAP 14.7 psia  |  PR 1.00";
        private string cachedGaugePowerText = "0 rpm    |    0 estimated hp";
        private string cachedGaugeAirflowText = "Estimated airflow  0.0 lb/min";
        private string cachedGaugeTargetText = "Target boost  8.0 psi";
        private string cachedGaugeRatingText = "Manifold pressure estimate";
        private readonly Dictionary<int, List<ProchargerRendererState>> prochargerRendererStates = new Dictionary<int, List<ProchargerRendererState>>();
        private int harmonyPatchFailures;
        private readonly Dictionary<int, List<ProchargerRendererState>> standPreviewRendererStates = new Dictionary<int, List<ProchargerRendererState>>();
        private readonly HashSet<BoxCollider> standPreviewHitboxes = new HashSet<BoxCollider>();
        private readonly HashSet<PartScript> mountedProchargerParts = new HashSet<PartScript>();
        private readonly Dictionary<int, InductionMode> mountedVisualModes = new Dictionary<int, InductionMode>();
        private readonly Dictionary<int, BoxCollider> mountedSelectionHitboxes = new Dictionary<int, BoxCollider>();
        private readonly HashSet<int> checkedStandMountRoots = new HashSet<int>();
        private readonly HashSet<int> loggedEngineLayoutRoots = new HashSet<int>();

        private struct ProchargerRendererState
        {
            public Renderer renderer;
            public bool enabled;

            public ProchargerRendererState(Renderer target)
            {
                renderer = target;
                enabled = target != null && target.enabled;
            }
        }

        private sealed class InstallTrackingEnumerator : IEnumerator
        {
            private readonly IEnumerator inner;
            private readonly TurboPrototypePlugin owner;
            private readonly NewGroupItem group;
            private readonly CarLoader loader;
            private readonly bool engineSwap;
            private bool finalized;

            internal InstallTrackingEnumerator(IEnumerator routine, TurboPrototypePlugin plugin, NewGroupItem installGroup, CarLoader targetLoader, bool isEngineSwap)
            {
                inner = routine;
                owner = plugin;
                group = installGroup;
                loader = targetLoader;
                engineSwap = isEngineSwap;
            }

            public object Current
            {
                get { return inner.Current; }
            }

            public bool MoveNext()
            {
                try
                {
                    if (inner.MoveNext()) return true;
                }
                catch
                {
                    FinalizeRoutine(false);
                    throw;
                }
                FinalizeRoutine(true);
                return false;
            }

            public void Reset()
            {
                inner.Reset();
                finalized = false;
            }

            private void FinalizeRoutine(bool succeeded)
            {
                if (finalized) return;
                finalized = true;
                if (owner == null || group == null) return;
                try
                {
                    if (succeeded)
                    {
                        if (engineSwap) owner.CompleteEngineInstall(loader, group);
                        else owner.CompleteActionInsert(group);
                    }
                    else
                    {
                        string reason = engineSwap
                            ? "Engine swap routine failed before completion"
                            : "Engine install action failed before completion";
                        owner.AbortPendingInstall(group, reason);
                    }
                }
                catch (Exception exception)
                {
                    // Bookkeeping must never turn a successful vanilla coroutine
                    // into a failed engine installation.
                    try { Debug.LogError("CMS 2018 ProCharger P-1X install bookkeeping failed: " + exception); }
                    catch { }
                }
            }
        }

        private void Awake()
        {
            Instance = this;
            settingsProfile = ReadSelectedProfile(0);
            selectedMode = ReadMode(PlayerPrefs.GetInt(PrefKey(GlobalModeKey), 0));
            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(PlayerPrefs.GetFloat(PrefKey(GlobalPsiKey), 8.0f), P1XMaxBoostPsi, 8.0f);

            try
            {
                harmony = new Harmony("local.cms18.turboproto");
                Patch(typeof(VehiclePhysics.Engine), "CalculateTorque", new Type[] { typeof(float), typeof(float) }, null, "TorquePostfix");
                Patch(typeof(VehiclePhysics.Engine), "CalculatePowerInKw", new Type[] { typeof(float) }, null, "PowerPostfix");
                // EngineSpecs is intentionally not patched. CMS reuses it for factory,
                // showroom and dyno values; changing it here contaminated every car's
                // factory baseline. Dyno torque charts remain sampled on the active car.
                Patch(typeof(GameScript), "GetGroupOnEngineStand", Type.EmptyTypes, null, "StandGroupPostfix");
                Patch(typeof(GameScript), "SetGroupOnEngineStand", new Type[] { typeof(NewGroupItem) }, "SetStandGroupPrefix", null);
                // Add the option to the result from CMS's menu-config reader. This is
                // the earliest stable point: PreparePieMenu immediately passes this
                // array to PrepareIcons, so the stock menu builds the new action itself.
                Patch(typeof(PieMenuController), "ReadOptionsFromIni", new Type[] { typeof(string) }, null, "InductionPieOptionsReadPostfix");
                Patch(typeof(Cursor3D), "Update", Type.EmptyTypes, "Cursor3DUpdatePrefix", null);
                Patch(typeof(PieMenuController), "PrepareIcons", new Type[] { typeof(string[]) }, "InductionPieIconsPreparePrefix", "InductionPieIconsPreparedPostfix");
                Patch(typeof(PieMenuController), "CheckSelectedOption", Type.EmptyTypes, "InductionPieMenuSelectionPrefix", null);
                Patch(typeof(PieMenuController), "SetPieMenuDescription", new Type[] { typeof(int) }, null, "InductionPieDescriptionPostfix");
                Patch(typeof(GameManager), "CheckOptionIsAvaiable", new Type[] { typeof(string) }, "InductionPieOptionAvailablePrefix", null);
                Patch(typeof(GameManager), "ActionInsertEngineToCar", new Type[] { typeof(NewGroupItem) }, "InsertEnginePrefix", "InsertEnginePostfix");
                Patch(typeof(CarLoader), "SwapEngine", new Type[] { typeof(NewGroupItem) }, "SwapEnginePrefix", "SwapEnginePostfix");
                Patch(typeof(CarLoader), "SetEngine", Type.EmptyTypes, null, "SetEnginePostfix");
                Patch(typeof(GameInventory), "GetGO", new Type[] { typeof(string) }, "InductionGetGOPrefix", null);
                Patch(typeof(GameInventory), "GetGO2", new Type[] { typeof(string) }, "InductionGetGO2Prefix", null);
                Patch(typeof(GameInventory), "IsTuning", new Type[] { typeof(string), typeof(string) }, "InductionIsTuningPrefix", null);
                Patch(typeof(GameScript), "IsPartAccessible", new Type[] { typeof(string) }, "InductionIsPartAccessiblePrefix", null);
                Patch(typeof(Inventory), "GetItems", new Type[] { typeof(string) }, null, "InductionInventoryGetItemsPostfix");
                Patch(typeof(PartScript), "TunePart", new Type[] { typeof(string), typeof(bool) }, "InductionTunePartPrefix", "InductionTunePartPostfix");
                Patch(typeof(GameInventory), "GetThumb", new Type[] { typeof(string) }, null, "InductionShopThumbPostfix");
                Patch(typeof(GameInventory), "GetItemLocalizeName", new Type[] { typeof(string) }, null, "InductionShopNamePostfix");
                Patch(typeof(GameInventory), "GetIOLocalizedName", new Type[] { typeof(InteractiveObject) }, null, "InductionIOLocalizedNamePostfix");
                Patch(typeof(GameInventory), "GetItems", new Type[] { typeof(string) }, null, "InductionShopGetItemsPostfix");
                Patch(typeof(Localization), "Get", new Type[] { typeof(string) }, null, "InductionLocalizationPostfix");
                Patch(typeof(UIManager), "CreateShop", Type.EmptyTypes, "ShopCreatePrefix", null);
                Patch(typeof(DynoManager), "PrepareDyno", Type.EmptyTypes, null, "DynoPreparePostfix");
                Patch(typeof(CarEngineHelper), "DrawPowerTorqueChart", null, "DynoTorqueChartPrefix", "DynoTorqueChartPostfix");
                Logger.LogInfo("CMS 2018 ProCharger P-1X " + PluginInfo.Version + " loaded for save profile " + settingsProfile + ". P-1X shop, installation, visual, boost, and dyno hooks are active. Factory engine specifications are left untouched. Patch errors=" + harmonyPatchFailures + ".");
                if (harmonyPatchFailures > 0)
                    status = harmonyPatchFailures + " Harmony patch(es) failed; see BepInEx LogOutput.log";
            }
            catch (Exception exception)
            {
                status = "Harmony patch setup failed; see BepInEx LogOutput.log";
                Logger.LogError(status + ": " + exception);
            }
        }

        private void Patch(Type targetType, string targetName, Type[] argumentTypes, string prefixName, string postfixName, string finalizerName = null)
        {
            MethodBase original = null;
            try
            {
                if (targetName == ".ctor")
                {
                    original = targetType.GetConstructor(
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                        null, argumentTypes ?? Type.EmptyTypes, null);
                }
                else
                {
                    original = argumentTypes == null
                        ? AccessTools.Method(targetType, targetName)
                        : AccessTools.Method(targetType, targetName, argumentTypes);
                }
                if (System.Object.ReferenceEquals(original, null))
                    throw new MissingMethodException(targetType.FullName, targetName);

                HarmonyMethod prefix = prefixName == null ? null : CreateHarmonyMethod(prefixName);
                HarmonyMethod postfix = postfixName == null ? null : CreateHarmonyMethod(postfixName);
                HarmonyMethod finalizer = finalizerName == null ? null : CreateHarmonyMethod(finalizerName);
                harmony.Patch(original, prefix, postfix, null, finalizer, null);
                Logger.LogInfo("Patched " + original.DeclaringType.FullName + "." + original.Name);
            }
            catch (Exception exception)
            {
                harmonyPatchFailures++;
                string target = System.Object.ReferenceEquals(original, null)
                    ? targetType.FullName + "." + targetName
                    : original.DeclaringType.FullName + "." + original.Name;
                Logger.LogError("Could not patch " + target + "; remaining patches will still be attempted: " + exception);
            }
        }

        private static HarmonyMethod CreateHarmonyMethod(string methodName)
        {
            MethodInfo method = AccessTools.Method(typeof(TurboPrototypeHooks), methodName);
            if (System.Object.ReferenceEquals(method, null)) method = AccessTools.Method(typeof(TurboPrototypePlugin), methodName);
            if (System.Object.ReferenceEquals(method, null)) throw new MissingMethodException("CMS18TurboPrototype hook", methodName);
            return new HarmonyMethod(method);
        }

        private void Update()
        {
            // Keep the menu entry independent of garage/car refresh work. A stale
            // part object or scene transition must not prevent the Mods tab from
            // being added while the main menu is active.
            if (Time.unscaledTime >= nextMainMenuModsRefresh)
            {
                nextMainMenuModsRefresh = Time.unscaledTime + MainMenuModsRefreshSeconds;
                try { EnsureMainMenuModsEntry(); }
                catch (Exception exception)
                {
                    LogMainMenuProbe("Mods entry refresh failed: " + exception.GetType().Name + ": " + exception.Message);
                }
            }

            if (Time.unscaledTime >= nextContextRefresh)
            {
                nextContextRefresh = Time.unscaledTime + ContextRefreshSeconds;
                RefreshProfileContext();
                RefreshStandContext();
                RefreshCarContext();
                EnsureProchargerShopRegistration();
                RefreshMountedProchargerVisuals();
            }

            if (Input.GetKeyDown(KeyCode.F8))
            {
                CycleMode();
            }

            AdvanceSpool(Time.deltaTime);

            if (Time.unscaledTime >= nextUiTextRefresh)
            {
                nextUiTextRefresh = Time.unscaledTime + UiTextRefreshSeconds;
                RefreshUiTextCache();
            }

            if (Time.unscaledTime >= nextVisualRefresh)
            {
                nextVisualRefresh = Time.unscaledTime + VisualRefreshSeconds;
                EnsureVisual();
            }

            if (mainMenuModsPanel != null && Input.GetKeyDown(KeyCode.Escape)) CloseMainMenuModsPanel();
        }

        private void LateUpdate()
        {
            KeepChooserCursorAvailable();
        }

        private void OpenInductionChooser()
        {
            CaptureOverlayCursorState();
            showInductionChooser = true;
            KeepChooserCursorAvailable();
        }

        private void CaptureOverlayCursorState()
        {
            if (!chooserCursorStateCaptured)
            {
                chooserPreviousCursorVisible = Cursor.visible;
                chooserPreviousCursorLockState = Cursor.lockState;
                chooserGameCursor = Cursor3D.Get();
                chooserPreviousGameCursorVisible = IsGameCursorGraphicVisible(chooserGameCursor);
                chooserCursorStateCaptured = true;
            }
            if (chooserGameCursor != null) chooserGameCursor.ShowCursor(false);
        }

        private static bool IsGameCursorGraphicVisible(Cursor3D gameCursor)
        {
            if (gameCursor == null) return false;
            try
            {
                FieldInfo cursorField = AccessTools.Field(typeof(Cursor3D), "Cursor");
                RectTransform cursor = System.Object.ReferenceEquals(cursorField, null)
                    ? null : cursorField.GetValue(gameCursor) as RectTransform;
                return cursor != null && cursor.gameObject.activeSelf;
            }
            catch { return false; }
        }

        private void KeepChooserCursorAvailable()
        {
            if (!showInductionChooser) return;
            if (Cursor.lockState != CursorLockMode.None) Cursor.lockState = CursorLockMode.None;
            if (!Cursor.visible) Cursor.visible = true;
        }

        private void CloseInductionChooser()
        {
            showInductionChooser = false;
            RestoreOverlayCursorIfClosed();
        }

        private void RestoreOverlayCursorIfClosed()
        {
            if (showInductionChooser) return;
            if (!chooserCursorStateCaptured) return;
            Cursor.lockState = chooserPreviousCursorLockState;
            Cursor.visible = chooserPreviousCursorVisible;
            if (chooserGameCursor != null) chooserGameCursor.ShowCursor(chooserPreviousGameCursorVisible);
            chooserGameCursor = null;
            chooserCursorStateCaptured = false;
        }

        private void EnsureMainMenuModsEntry()
        {
            // The menu row is stable after registration. Do not keep reconfiguring
            // its Button/LayoutElement on a timer; the native HorizontalLayoutGroup
            // can relayout the row while those values are rewritten.
            if (mainMenuModsButton != null && mainMenuExitButton != null
                && mainMenuHorizontalItems != null
                && mainMenuModsButton.transform.parent == mainMenuExitButton.transform.parent
                && mainMenuHorizontalItems.items != null
                && Array.IndexOf(mainMenuHorizontalItems.items, mainMenuModsButton) >= 0)
                return;

            MainMenuManager manager = UnityEngine.Object.FindObjectOfType<MainMenuManager>();
            if (manager == null)
            {
                LogMainMenuProbe("MainMenuManager is not present in the active scene yet.");
                return;
            }
            Button exitButton = ReadComponentReference<Button>(manager, "ButtonQuit");
            HorizontalItemsMove horizontal = ReadComponentReference<HorizontalItemsMove>(manager, "horizontalItemsMove");
            if (exitButton == null || horizontal == null || horizontal.items == null || horizontal.items.Length == 0)
            {
                LogMainMenuProbe("MainMenuManager found, but Exit or the horizontal menu row is not ready. Exit="
                    + (exitButton != null) + ", row=" + (horizontal != null) + ", items="
                    + (horizontal == null || horizontal.items == null ? "unavailable" : horizontal.items.Length.ToString(CultureInfo.InvariantCulture)) + ".");
                return;
            }

            GameObject modsButton = null;
            for (int i = 0; i < horizontal.items.Length; i++)
            {
                GameObject item = horizontal.items[i];
                if (item != null && String.Equals(item.name, "CMS18_ModsMenuItem", StringComparison.Ordinal))
                {
                    if (modsButton == null) modsButton = item;
                    else UnityEngine.Object.Destroy(item);
                }
            }

            // A failed prior refresh can leave the cloned object in the UI hierarchy
            // before it is added to horizontal.items. Reuse it instead of cloning Exit
            // again on every Update tick.
            Transform[] rowChildren = exitButton.transform.parent.GetComponentsInChildren<Transform>(true);
            for (int i = 0; i < rowChildren.Length; i++)
            {
                Transform child = rowChildren[i];
                if (child == null || !String.Equals(child.name, "CMS18_ModsMenuItem", StringComparison.Ordinal)) continue;
                if (modsButton == null) modsButton = child.gameObject;
                else if (child.gameObject != modsButton) UnityEngine.Object.Destroy(child.gameObject);
            }

            int exitIndex = Array.IndexOf(horizontal.items, exitButton.gameObject);
            if (exitIndex < 0)
            {
                LogMainMenuProbe("The Exit button was not found in the horizontal menu item list.");
                return;
            }

            try
            {
                bool created = modsButton == null;
                if (created)
                    modsButton = UnityEngine.Object.Instantiate(exitButton.gameObject,
                        exitButton.transform.parent, false);
                if (modsButton == null) return;
                modsButton.name = "CMS18_ModsMenuItem";
                ConfigureMainMenuStyledButton(modsButton, "Mods", ToggleMainMenuModsPanel);

                // SetSiblingIndex moves a child even when asked to use Exit's
                // current index. Reapplying the same index therefore swaps Mods
                // from before Exit to after it on alternating refreshes.
                int exitSiblingIndex = exitButton.transform.GetSiblingIndex();
                int modsSiblingIndex = modsButton.transform.GetSiblingIndex();
                if (modsSiblingIndex > exitSiblingIndex)
                    modsButton.transform.SetSiblingIndex(exitSiblingIndex);
                else if (modsSiblingIndex < exitSiblingIndex - 1)
                    modsButton.transform.SetSiblingIndex(exitSiblingIndex - 1);
                int modsIndex = Array.IndexOf(horizontal.items, modsButton);
                int modsOccurrences = 0;
                for (int i = 0; i < horizontal.items.Length; i++)
                    if (horizontal.items[i] != null
                        && String.Equals(horizontal.items[i].name, "CMS18_ModsMenuItem", StringComparison.Ordinal))
                        modsOccurrences++;
                if (modsIndex != exitIndex - 1 || modsOccurrences != 1)
                {
                    int selectedIndex = ReadComponentValue<int>(horizontal, "selectedObjectIndex", 0);
                    GameObject selectedItem = selectedIndex >= 0 && selectedIndex < horizontal.items.Length
                        ? horizontal.items[selectedIndex] : null;
                    List<GameObject> normalizedItems = new List<GameObject>(horizontal.items.Length + 1);
                    for (int i = 0; i < horizontal.items.Length; i++)
                    {
                        GameObject current = horizontal.items[i];
                        if (current == modsButton
                            || (current != null && String.Equals(current.name, "CMS18_ModsMenuItem", StringComparison.Ordinal))) continue;
                        normalizedItems.Add(current);
                    }
                    int normalizedExitIndex = normalizedItems.IndexOf(exitButton.gameObject);
                    if (normalizedExitIndex < 0) throw new InvalidOperationException("Exit disappeared while rebuilding the menu item list.");
                    normalizedItems.Insert(normalizedExitIndex, modsButton);
                    horizontal.items = normalizedItems.ToArray();
                    if (selectedItem != null)
                    {
                        int newSelectedIndex = Array.IndexOf(horizontal.items, selectedItem);
                        if (newSelectedIndex >= 0)
                            SetComponentValue(horizontal, "selectedObjectIndex", newSelectedIndex);
                    }
                }
                mainMenuModsButton = modsButton;
                mainMenuExitButton = exitButton.gameObject;
                mainMenuHorizontalItems = horizontal;
                LogMainMenuProbe("One Mods item is registered immediately before Exit; Credits remains in place.");
            }
            catch (Exception exception)
            {
                if (modsButton != null && Array.IndexOf(horizontal.items, modsButton) < 0)
                    UnityEngine.Object.Destroy(modsButton);
                LogMainMenuProbe("Mods item refresh failed: " + exception.GetType().Name + ": " + exception.Message);
            }
        }

        private static GameObject CreateMainMenuStyledButton(GameObject template, Transform parent,
            string objectName, string caption, MainMenuClickCallback onClick)
        {
            if (template == null || parent == null) return null;
            GameObject item = UnityEngine.Object.Instantiate(template, parent, false);
            item.name = objectName;
            ConfigureMainMenuStyledButton(item, caption, onClick);
            return item;
        }

        private static void ConfigureMainMenuStyledButton(GameObject item, string caption,
            MainMenuClickCallback onClick)
        {
            if (item == null) return;
            Button originalButton = item.GetComponent<Button>();
            Graphic targetGraphic = originalButton == null ? null : originalButton.targetGraphic;
            Button.Transition transition = originalButton == null ? Button.Transition.ColorTint : originalButton.transition;
            ColorBlock colors = originalButton == null ? ColorBlock.defaultColorBlock : originalButton.colors;
            Button[] copiedButtons = item.GetComponentsInChildren<Button>(true);
            for (int i = 0; i < copiedButtons.Length; i++)
                if (copiedButtons[i] != null) copiedButtons[i].enabled = false;

            // The cloned Exit item already owns a Button. Adding a second one fails in
            // Unity; configure the clone's existing component and replace its Quit event.
            Button freshButton = originalButton;
            if (freshButton == null) freshButton = item.GetComponentInChildren<Button>(true);
            if (freshButton == null) freshButton = item.AddComponent<Button>();
            if (targetGraphic == null) targetGraphic = item.GetComponentInChildren<Graphic>(true);
            freshButton.enabled = true;
            freshButton.targetGraphic = targetGraphic;
            freshButton.transition = transition;
            freshButton.colors = colors;
            freshButton.navigation = Navigation.defaultNavigation;
            freshButton.interactable = true;
            freshButton.onClick = new Button.ButtonClickedEvent();
            freshButton.onClick.AddListener(delegate { if (onClick != null) onClick(); });
            if (item.GetComponent<MenuItemHorizontal>() == null)
                item.AddComponent<MenuItemHorizontal>();

            Text[] labels = item.GetComponentsInChildren<Text>(true);
            LayoutElement layout = item.GetComponent<LayoutElement>();
            float preferredWidth = 0.0f;
            for (int i = 0; i < labels.Length; i++)
            {
                if (labels[i] == null) continue;
                labels[i].text = caption;
                preferredWidth = Mathf.Max(preferredWidth, labels[i].preferredWidth + 24.0f);
            }
            if (layout != null) layout.preferredWidth = Mathf.Max(layout.preferredWidth, preferredWidth);
            RectTransform itemRect = item.GetComponent<RectTransform>();
            if (itemRect != null && (layout == null || layout.preferredWidth <= 0.0f))
                itemRect.sizeDelta = new Vector2(Mathf.Max(itemRect.sizeDelta.x, preferredWidth), itemRect.sizeDelta.y);
        }

        private void LogMainMenuProbe(string state)
        {
            if (String.Equals(lastMainMenuProbeState, state, StringComparison.Ordinal)) return;
            lastMainMenuProbeState = state;
            Logger.LogInfo("Main-menu Mods diagnostic: " + state);
        }

        private void ToggleMainMenuModsPanel()
        {
            if (mainMenuModsPanel != null) CloseMainMenuModsPanel();
            else OpenMainMenuModsPanel();
        }

        private void OpenMainMenuModsPanel()
        {
            if (mainMenuModsButton == null) return;
            Canvas canvas = mainMenuModsButton.GetComponentInParent<Canvas>();
            if (canvas == null) return;

            SetComponentValue(mainMenuHorizontalItems, "canMove", false);
            GameObject overlay = new GameObject("CMS18 BepInEx Mods Overlay", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            overlay.transform.SetParent(canvas.transform, false);
            overlay.transform.SetAsLastSibling();
            RectTransform overlayRect = overlay.GetComponent<RectTransform>();
            overlayRect.anchorMin = Vector2.zero;
            overlayRect.anchorMax = Vector2.one;
            overlayRect.offsetMin = Vector2.zero;
            overlayRect.offsetMax = Vector2.zero;
            Image overlayImage = overlay.GetComponent<Image>();
            overlayImage.color = new Color(0.0f, 0.0f, 0.0f, 0.78f);
            overlayImage.raycastTarget = true;
            mainMenuModsPanel = overlay;

            RectTransform canvasRect = canvas.transform as RectTransform;
            float canvasWidth = canvasRect == null ? Screen.width : canvasRect.rect.width;
            float canvasHeight = canvasRect == null ? Screen.height : canvasRect.rect.height;
            float panelWidth = Mathf.Min(canvasWidth * 0.78f, 1040.0f);
            float panelHeight = Mathf.Min(canvasHeight * 0.76f, 720.0f);

            GameObject panel = CreateMenuPanelElement(overlay.transform, "Panel",
                new Color(0.055f, 0.065f, 0.075f, 0.97f));
            RectTransform panelRect = panel.GetComponent<RectTransform>();
            panelRect.anchorMin = new Vector2(0.5f, 0.5f);
            panelRect.anchorMax = new Vector2(0.5f, 0.5f);
            panelRect.pivot = new Vector2(0.5f, 0.5f);
            panelRect.sizeDelta = new Vector2(panelWidth, panelHeight);
            panelRect.anchoredPosition = Vector2.zero;

            GameObject accent = CreateMenuPanelElement(panel.transform, "Orange Accent", new Color(1.0f, 0.58f, 0.0f, 1.0f));
            SetMenuRect(accent.GetComponent<RectTransform>(), new Vector2(0.0f, 0.975f), Vector2.one,
                new Vector2(0.0f, -3.0f), Vector2.zero);

            Text templateText = FindMainMenuTemplateText();
            Text title = CreateMenuText(panel.transform, "Mods Title", templateText, "BepInEx Mods", 30,
                FontStyle.Bold, Color.white, TextAnchor.MiddleLeft);
            SetMenuRect(title.rectTransform, new Vector2(0.055f, 0.865f), new Vector2(0.78f, 0.96f),
                Vector2.zero, Vector2.zero);

            Text summary = CreateMenuText(panel.transform, "Mods Summary", templateText, "Loaded by BepInEx", 16,
                FontStyle.Normal, new Color(0.72f, 0.75f, 0.78f, 1.0f), TextAnchor.MiddleLeft);
            SetMenuRect(summary.rectTransform, new Vector2(0.055f, 0.80f), new Vector2(0.94f, 0.86f),
                Vector2.zero, Vector2.zero);

            GameObject scrollObject = new GameObject("Mods Scroll View", typeof(RectTransform), typeof(ScrollRect));
            scrollObject.transform.SetParent(panel.transform, false);
            RectTransform scrollRectTransform = scrollObject.GetComponent<RectTransform>();
            SetMenuRect(scrollRectTransform, new Vector2(0.045f, 0.17f), new Vector2(0.955f, 0.77f),
                Vector2.zero, Vector2.zero);
            ScrollRect scroll = scrollObject.GetComponent<ScrollRect>();
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.inertia = true;
            scroll.scrollSensitivity = 34.0f;
            scroll.movementType = ScrollRect.MovementType.Clamped;

            GameObject viewport = CreateMenuPanelElement(scrollObject.transform, "Viewport",
                new Color(0.0f, 0.0f, 0.0f, 0.23f));
            RectTransform viewportRect = viewport.GetComponent<RectTransform>();
            viewportRect.anchorMin = Vector2.zero;
            viewportRect.anchorMax = Vector2.one;
            viewportRect.offsetMin = Vector2.zero;
            viewportRect.offsetMax = Vector2.zero;
            Mask mask = viewport.AddComponent<Mask>();
            mask.showMaskGraphic = false;
            scroll.viewport = viewportRect;

            GameObject content = new GameObject("Mods List", typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            content.transform.SetParent(viewport.transform, false);
            RectTransform contentRect = content.GetComponent<RectTransform>();
            contentRect.anchorMin = new Vector2(0.0f, 1.0f);
            contentRect.anchorMax = new Vector2(1.0f, 1.0f);
            contentRect.pivot = new Vector2(0.5f, 1.0f);
            contentRect.anchoredPosition = Vector2.zero;
            contentRect.sizeDelta = new Vector2(0.0f, 0.0f);
            VerticalLayoutGroup layoutGroup = content.GetComponent<VerticalLayoutGroup>();
            layoutGroup.spacing = 5.0f;
            layoutGroup.padding = new RectOffset(10, 10, 10, 10);
            layoutGroup.childForceExpandWidth = true;
            layoutGroup.childForceExpandHeight = false;
            layoutGroup.childControlWidth = true;
            layoutGroup.childControlHeight = true;
            ContentSizeFitter fitter = content.GetComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            scroll.content = contentRect;

            List<BepInEx.PluginInfo> plugins = new List<BepInEx.PluginInfo>();
            foreach (KeyValuePair<string, BepInEx.PluginInfo> entry in BepInEx.Bootstrap.Chainloader.PluginInfos)
                if (entry.Value != null && entry.Value.Metadata != null) plugins.Add(entry.Value);
            plugins.Sort(delegate(BepInEx.PluginInfo left, BepInEx.PluginInfo right)
            {
                return String.Compare(left.Metadata.Name, right.Metadata.Name, StringComparison.OrdinalIgnoreCase);
            });
            summary.text = plugins.Count.ToString(CultureInfo.InvariantCulture) + " BepInEx mods loaded";
            if (plugins.Count == 0)
            {
                AddModListRow(content.transform, templateText, "No BepInEx plugins are loaded.", String.Empty, 0);
            }
            else
            {
                for (int i = 0; i < plugins.Count; i++)
                {
                    BepInEx.BepInPlugin metadata = plugins[i].Metadata;
                    string version = metadata.Version == null ? "unknown" : metadata.Version.ToString();
                    AddModListRow(content.transform, templateText, metadata.Name + "  v" + version, metadata.GUID, i);
                }
            }

            GameObject closeButton = CreateMainMenuStyledButton(mainMenuExitButton, panel.transform,
                "CMS18_ModsCloseButton", "Back", CloseMainMenuModsPanel);
            if (closeButton != null)
            {
                RectTransform closeRect = closeButton.GetComponent<RectTransform>();
                closeRect.anchorMin = new Vector2(0.79f, 0.035f);
                closeRect.anchorMax = new Vector2(0.95f, 0.13f);
                closeRect.offsetMin = Vector2.zero;
                closeRect.offsetMax = Vector2.zero;
            }
        }

        private static GameObject CreateMenuPanelElement(Transform parent, string name, Color color)
        {
            GameObject element = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            element.transform.SetParent(parent, false);
            Image image = element.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = true;
            return element;
        }

        private static Text CreateMenuText(Transform parent, string name, Text template, string value, int size,
            FontStyle style, Color color, TextAnchor alignment)
        {
            GameObject textObject = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
            textObject.transform.SetParent(parent, false);
            Text text = textObject.GetComponent<Text>();
            text.font = template != null && template.font != null ? template.font : Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = size;
            text.fontStyle = style;
            text.color = color;
            text.alignment = alignment;
            text.text = value;
            text.raycastTarget = false;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            return text;
        }

        private static void AddModListRow(Transform content, Text template, string title, string detail, int index)
        {
            Color rowColor = (index & 1) == 0
                ? new Color(0.11f, 0.125f, 0.14f, 0.88f)
                : new Color(0.085f, 0.10f, 0.115f, 0.88f);
            GameObject row = CreateMenuPanelElement(content, "Mod Row " + index.ToString(CultureInfo.InvariantCulture), rowColor);
            LayoutElement rowLayout = row.AddComponent<LayoutElement>();
            rowLayout.preferredHeight = String.IsNullOrEmpty(detail) ? 48.0f : 58.0f;
            rowLayout.minHeight = rowLayout.preferredHeight;

            Text nameText = CreateMenuText(row.transform, "Mod Name", template, title, 18, FontStyle.Bold,
                new Color(0.93f, 0.94f, 0.95f, 1.0f), TextAnchor.MiddleLeft);
            SetMenuRect(nameText.rectTransform, String.IsNullOrEmpty(detail) ? Vector2.zero : new Vector2(0.025f, 0.38f),
                Vector2.one, new Vector2(10.0f, 3.0f), new Vector2(-10.0f, -2.0f));

            if (!String.IsNullOrEmpty(detail))
            {
                Text detailText = CreateMenuText(row.transform, "Mod Identifier", template, detail, 12, FontStyle.Normal,
                    new Color(0.61f, 0.66f, 0.70f, 1.0f), TextAnchor.MiddleLeft);
                SetMenuRect(detailText.rectTransform, new Vector2(0.025f, 0.03f), new Vector2(0.98f, 0.40f),
                    new Vector2(10.0f, 0.0f), new Vector2(-10.0f, 0.0f));
            }
        }

        private static void SetMenuRect(RectTransform rect, Vector2 anchorMin, Vector2 anchorMax,
            Vector2 offsetMin, Vector2 offsetMax)
        {
            if (rect == null) return;
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = offsetMin;
            rect.offsetMax = offsetMax;
        }

        private Text FindMainMenuTemplateText()
        {
            GameObject source = mainMenuExitButton != null ? mainMenuExitButton : mainMenuModsButton;
            return source == null ? null : source.GetComponentInChildren<Text>(true);
        }

        private void CloseMainMenuModsPanel()
        {
            if (mainMenuModsPanel != null)
            {
                mainMenuModsPanel.SetActive(false);
                UnityEngine.Object.Destroy(mainMenuModsPanel);
                mainMenuModsPanel = null;
            }
            SetComponentValue(mainMenuHorizontalItems, "canMove", true);
        }

        private static int ReadComponentValue<T>(object instance, string fieldName, int fallback)
        {
            if (instance == null) return fallback;
            FieldInfo field = AccessTools.Field(instance.GetType(), fieldName);
            // Avoid Type.op_Inequality: the CMS 2018 Mono runtime is missing it.
            if (System.Object.ReferenceEquals(field, null)
                || !System.Object.ReferenceEquals(field.FieldType, typeof(T))) return fallback;
            object value = field.GetValue(instance);
            return value is int ? (int)value : fallback;
        }

        private static void SetComponentValue(object instance, string fieldName, object value)
        {
            if (instance == null) return;
            FieldInfo field = AccessTools.Field(instance.GetType(), fieldName);
            if (!System.Object.ReferenceEquals(field, null) && (value == null || field.FieldType.IsInstanceOfType(value))) field.SetValue(instance, value);
        }

        private void RefreshUiTextCache()
        {
            cachedStandEngineText = "Engine: " + (String.IsNullOrEmpty(standGroupName) ? "waiting" : standGroupName);
            float selectedBoostLimit = GetCurrentControlBoostLimit();
            cachedStandBoostText = "Target " + selectedBoostPsi.ToString("F1") + " / "
                + selectedBoostLimit.ToString("F0") + " psi";
            string shortStatus = String.IsNullOrEmpty(status) ? "Ready" : status;
            cachedStandStatusText = shortStatus.Length > 62 ? shortStatus.Substring(0, 59) + "..." : shortStatus;
            cachedGaugeBoostText = liveBoostPsi >= 0.0f
                ? "MANIFOLD  +" + liveBoostPsi.ToString("F1") + " psi"
                : "VACUUM  " + (Mathf.Abs(liveBoostPsi) * PsiPerInchOfMercury).ToString("F1") + " inHg";
            float manifoldAbsolutePsi = Mathf.Max(0.1f, PsiPerAtmosphere + liveBoostPsi);
            float pressureRatio = manifoldAbsolutePsi / PsiPerAtmosphere;
            cachedGaugeMapText = "MAP " + manifoldAbsolutePsi.ToString("F1") + " psia  |  PR " + pressureRatio.ToString("F2");
            float horsepower = lastNetTorque * lastRpm / 7127.0f;
            float estimatedAirflow = Mathf.Max(0.0f, horsepower) / EstimatedHorsepowerPerLbPerMinute;
            cachedGaugePowerText = lastRpm.ToString("F0") + " rpm  |  " + horsepower.ToString("F0") + " est. hp  |  " + lastNetTorque.ToString("F0") + " Nm";
            cachedGaugeAirflowText = activeMode == InductionMode.Procharger
                ? "Flow est. " + estimatedAirflow.ToString("F1") + " lb/min  ("
                    + (estimatedAirflow / SeaLevelAirDensityLbPerCubicFoot).ToString("F0") + "/"
                    + P1XMaxFlowCfm.ToString("F0") + " CFM)"
                : "Flow estimate  " + estimatedAirflow.ToString("F1") + " lb/min";
            if (activeMode == InductionMode.Procharger && lastEngine != null && lastEngine.settings != null)
            {
                float activeTarget = ProchargerMath.NormalizeBoostPsi(PsiForActiveCar(), GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger), 8.0f);
                float impellerRpm = CalculateP1XImpellerRpm(lastEngine.settings, lastRpm, activeTarget);
                cachedGaugeTargetText = "Target " + activeTarget.ToString("F1") + " psi  |  P-1X "
                    + (impellerRpm / 1000.0f).ToString("F1") + "/" + (P1XMaxImpellerRpm / 1000.0f).ToString("F0") + "k rpm";
            }
            else
            {
                cachedGaugeTargetText = "Boost target  " + PsiForActiveCar().ToString("F1") + " psi";
            }
            cachedGaugeRatingText = activeMode == InductionMode.Procharger
                ? (activeHasHighBoostProcharger ? "High-Boost target ceiling " : "Street-kit target ceiling ")
                    + GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger).ToString("F0") + " psi; P-1X unit: "
                    + P1XMaxSuperchargedHp.ToString("F0") + " hp / " + P1XMaxFlowCfm.ToString("F0") + " CFM / 65k rpm"
                : "Generic compressor estimate; no exact map loaded";
        }

        private void EnsureProchargerShopRegistration()
        {
            GameInventory[] candidates = UnityEngine.Object.FindObjectsOfType<GameInventory>();
            GameInventory inventory = null;
            for (int i = 0; i < candidates.Length; i++)
            {
                GameInventory candidate = candidates[i];
                if (candidate != null && candidate.IsReady && HasPartPropertyList(candidate))
                {
                    try
                    {
                        GameInventory.PartProperty template = candidate.GetItemProperty(ProchargerBasePartId);
                        if (IsValidProchargerShopTemplate(template))
                        {
                            inventory = candidate;
                            break;
                        }
                    }
                    catch (Exception) { }
                }
            }
            if (inventory == null)
            {
                GameInventory candidate = candidates.Length > 0 ? candidates[0] : null;
                string readiness = candidate == null ? "no active GameInventory" : "GameInventory ready="
                    + candidate.IsReady + ", partsFlag=" + candidate.IsReadyFillPartPropertyList
                    + ", catalog=" + HasPartPropertyList(candidate) + ", turbo_2=" + HasValidTurboTemplate(candidate);
                if (!String.Equals(lastShopReadinessDiagnostic, readiness, StringComparison.Ordinal))
                {
                    lastShopReadinessDiagnostic = readiness;
                    Logger.LogInfo("Shop catalog waiting for the active inventory: " + readiness + ".");
                }
                return;
            }
            lastShopReadinessDiagnostic = String.Empty;
            if (registeredShopInventory != inventory)
            {
                registeredShopInventory = inventory;
                inductionShopItemsRegistered = false;
                shopRegistrationWarningLogged = false;
            }
            if (inductionShopItemsRegistered && HasRegisteredShopProducts(inventory)) return;

            try
            {
                GameInventory.PartProperty turboTemplate = inventory.GetItemProperty(ProchargerBasePartId);
                if (!IsValidProchargerShopTemplate(turboTemplate))
                {
                    if (!shopRegistrationWarningLogged)
                    {
                        shopRegistrationWarningLogged = true;
                        Logger.LogWarning("Could not register the ProCharger shop item because the stock turbo_2 Engine shop definition was not ready.");
                    }
                    return;
                }

                RegisterInductionProperty(inventory, turboTemplate, UniversalMountPartId,
                    "Universal Induction Mount", "CMS18", "CMS18Internal", 0);
                RegisterInductionProperty(inventory, turboTemplate, ProchargerPartId,
                    "ProCharger P-1X", "ProCharger", "MainShop", 12500);
                RegisterInductionProperty(inventory, turboTemplate, ProchargerHighBoostPartId,
                    "ProCharger P-1X High-Boost (32 PSI)", "ProCharger", "TuningShop", 24900);
                inductionShopItemsRegistered = HasShopProperty(inventory, ProchargerPartId, "MainShop")
                    && HasShopProperty(inventory, ProchargerHighBoostPartId, "TuningShop");
                if (inductionShopItemsRegistered)
                {
                    status = "Standard P-1X registered in Main Shop; high-boost P-1X registered in Tuning Shop";
                    Logger.LogInfo(status + "; high-boost P-1X is $24,900 and the internal mount is hidden from shops.");
                }
            }
            catch (Exception exception)
            {
                if (!shopRegistrationWarningLogged)
                {
                    shopRegistrationWarningLogged = true;
                    Logger.LogWarning("Could not register the ProCharger shop item: " + exception);
                }
            }
        }

        private static bool HasRegisteredShopProducts(GameInventory inventory)
        {
            return HasShopProperty(inventory, ProchargerPartId, "MainShop")
                && HasShopProperty(inventory, ProchargerHighBoostPartId, "TuningShop");
        }

        private static bool HasPartPropertyList(GameInventory inventory)
        {
            if (inventory == null) return false;
            FieldInfo field = AccessTools.Field(typeof(GameInventory), "partPropertyList");
            // Avoid FieldInfo.op_Inequality: the CMS 2018 Mono runtime is missing it.
            return !System.Object.ReferenceEquals(field, null) && field.GetValue(inventory) is IList;
        }

        private static bool HasValidTurboTemplate(GameInventory inventory)
        {
            if (inventory == null || !HasPartPropertyList(inventory)) return false;
            try { return IsValidProchargerShopTemplate(inventory.GetItemProperty(ProchargerBasePartId)); }
            catch { return false; }
        }

        private static bool HasShopProperty(GameInventory inventory, string id, string shopName)
        {
            if (inventory == null) return false;
            GameInventory.PartProperty property = inventory.GetItemProperty(id);
            // GetItemProperty returns an unregistered placeholder, rather than null,
            // for unknown IDs. Require the actual catalog fields before accepting it.
            return property != null
                && String.Equals(property.ID, id, StringComparison.Ordinal)
                && String.Equals(property.ShopName, shopName, StringComparison.Ordinal)
                && String.Equals(property.ShopGroup, "Engine", StringComparison.Ordinal);
        }

        public void EnsureShopCatalogReady()
        {
            EnsureProchargerShopRegistration();
        }

        private static void RegisterInductionProperty(GameInventory inventory, GameInventory.PartProperty template,
            string id, string localizedName, string brand, string shopName, int price)
        {
            // GetItemProperty constructs a non-null placeholder for unknown IDs and
            // copies the ID into ShopName/ShopGroup. Only an actual catalog row should
            // suppress registration.
            if (HasShopProperty(inventory, id, shopName)) return;
            // CMS shop-card creation calls SteamScript.GetDLC and hides rows
            // whose list is empty. DLC id 0 is the game's base-game sentinel
            // (GetDLC(0) checks id -1), so mod-added products remain visible.
            int[] dlc = new int[] { 0 };
            GameInventory.PartProperty property = new GameInventory.PartProperty(id, price, template.PartGroup,
                template.ShopGroup, template.ExamineGroup, template.RepairGroup, template.SpecialGroup,
                dlc, template.TuningValue, false, localizedName, brand, shopName);
            inventory.AddToPartPropertyList(property.ID, property.Price, property.PartGroup, property.ShopGroup,
                property.ExamineGroup, property.RepairGroup, property.SpecialGroup, property.DLC,
                property.TuningValue, property.IsBody, property.LocalizedName, property.Brand, property.ShopName);
        }

        internal static bool IsValidProchargerShopTemplate(GameInventory.PartProperty template)
        {
            return template != null
                && String.Equals(template.ID, ProchargerBasePartId, StringComparison.Ordinal)
                && String.Equals(template.ShopName, "MainShop", StringComparison.Ordinal)
                && String.Equals(template.ShopGroup, "Engine", StringComparison.Ordinal);
        }

        internal static GameInventory.PartProperty CreateProchargerShopProperty(GameInventory.PartProperty turboTemplate)
        {
            if (turboTemplate == null) throw new ArgumentNullException("turboTemplate");
            int[] dlc = new int[] { 0 };
            long scaledPrice = (long)Math.Max(0, turboTemplate.Price) * 2L;
            int price = (int)Math.Min(Int32.MaxValue, Math.Max(12500L, scaledPrice));
            return new GameInventory.PartProperty(ProchargerPartId, price, turboTemplate.PartGroup,
                turboTemplate.ShopGroup, turboTemplate.ExamineGroup, turboTemplate.RepairGroup,
                turboTemplate.SpecialGroup, dlc, turboTemplate.TuningValue, false,
                "ProCharger P-1X", "ProCharger", turboTemplate.ShopName);
        }

        internal static GameInventory.PartProperty CreateProchargerHighBoostShopProperty(GameInventory.PartProperty turboTemplate)
        {
            if (turboTemplate == null) throw new ArgumentNullException("turboTemplate");
            int[] dlc = new int[] { 0 };
            return new GameInventory.PartProperty(ProchargerHighBoostPartId, 24900, turboTemplate.PartGroup,
                turboTemplate.ShopGroup, turboTemplate.ExamineGroup, turboTemplate.RepairGroup,
                turboTemplate.SpecialGroup, dlc, turboTemplate.TuningValue, false,
                "ProCharger P-1X High-Boost (32 PSI)", "ProCharger", "TuningShop");
        }

        internal static bool IsProchargerPartId(string partId)
        {
            return IsCustomPartId(partId, ProchargerPartId)
                || IsCustomPartId(partId, ProchargerHighBoostPartId);
        }

        internal static bool IsHighBoostProchargerPartId(string partId)
        {
            return IsCustomPartId(partId, ProchargerHighBoostPartId);
        }

        internal static string NormalizeProchargerTuneId(string partId)
        {
            return NormalizeInductionTuneId(partId);
        }

        internal static bool IsInductionPartId(string partId)
        {
            return IsProchargerPartId(partId) || IsRetiredKitPartId(partId);
        }

        internal static bool IsRetiredKitPartId(string partId)
        {
            return IsCustomPartId(partId, RetiredTurboKitPartId)
                || IsCustomPartId(partId, RetiredRootsKitPartId);
        }

        internal static InductionMode ModeForInductionPartId(string partId)
        {
            if (IsProchargerPartId(partId)) return InductionMode.Procharger;
            return InductionMode.Off;
        }

        internal static string NormalizeInductionTuneId(string partId)
        {
            return IsInductionPartId(partId) ? ProchargerBasePartId : partId;
        }

        private static bool IsCustomPartId(string partId, string baseId)
        {
            if (String.IsNullOrEmpty(partId) || String.IsNullOrEmpty(baseId)) return false;
            string id = partId.Trim();
            if (String.Equals(id, baseId, StringComparison.OrdinalIgnoreCase)) return true;
            string prefix = baseId + "(";
            if (!id.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || !id.EndsWith(")", StringComparison.Ordinal)) return false;
            int digitCount = id.Length - prefix.Length - 1;
            if (digitCount <= 0) return false;
            for (int i = 0; i < digitCount; i++)
            {
                char digit = id[prefix.Length + i];
                if (digit < '0' || digit > '9') return false;
            }
            return true;
        }
        private void RefreshStandContext()
        {
            try
            {
                GameScript game = GameScript.Get();
                if (game == null || game.EngineStandIsEmpty())
                {
                    standOccupied = false;
                    standHasNativeInduction = false;
                    standHasHighBoostProcharger = false;
                    standNativeMode = InductionMode.Off;
                    standGroup = null;
                    standGroupKey = string.Empty;
                    standGroupName = string.Empty;
                    standGroupUid = 0;
                    return;
                }

                // The belt-drive mount is a gameplay part and must exist even before the
                // shop catalog has been initialized; otherwise P-1X falls back to the
                // factory turbo slot and routes its pipe through the engine.
                EnsureUniversalMountOnStand(game);
                NewGroupItem group = game.GetGroupOnEngineStand();
                if (group == null || group.ItemList == null || group.ItemList.Count == 0)
                {
                    standOccupied = false;
                    standHasNativeInduction = false;
                    standHasHighBoostProcharger = false;
                    standNativeMode = InductionMode.Off;
                    standGroup = null;
                    standGroupKey = string.Empty;
                    standGroupName = string.Empty;
                    standGroupUid = 0;
                    return;
                }

                string key = BuildGroupKey(group);
                bool changed = !String.Equals(key, standGroupKey, StringComparison.Ordinal) || group.UId != standGroupUid;
                standOccupied = true;
                standGroup = group;
                standGroupKey = key;
                standGroupName = String.IsNullOrEmpty(group.GroupName) ? "engine group" : group.GroupName;
                standGroupUid = group.UId;
                RefreshStandPartDetection(game);

                if (changed)
                {
                    checkedStandMountRoots.Clear();
                    InductionMode mode;
                    float psi;
                    if (TryReadGroupSettings(group, out mode, out psi))
                    {
                        selectedMode = mode;
                        selectedBoostPsi = psi;
                    }
                    else if (TryReadStoredGroupSettings(group, out mode, out psi))
                    {
                        selectedMode = mode;
                        selectedBoostPsi = psi;
                    }
                    else
                    {
                        selectedMode = InductionMode.Off;
                        selectedBoostPsi = 8.0f;
                    }
                    selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(selectedBoostPsi,
                        GetMaximumBoostPsi(selectedMode, standHasHighBoostProcharger), 8.0f);

                    SaveGlobalSettings();
                    status = "Engine stand ready: " + standGroupName;
                }
            }
            catch (Exception exception)
            {
                standOccupied = false;
                standGroup = null;
                standGroupKey = string.Empty;
                standGroupName = string.Empty;
                standGroupUid = 0;
                Logger.LogWarning("Could not inspect the engine stand: " + exception.Message);
            }
        }

        private void RefreshCarContext()
        {
            try
            {
                VPVehicleController linkedController;
                CarLoader loader = FindActiveCarLoader(out linkedController);
                activeController = linkedController;
                string key = string.Empty;
                if (loader != null)
                {
                    key = BuildCarIdentityKey(loader);
                }

                if (!String.Equals(key, activeCarKey, StringComparison.Ordinal))
                {
                    activeCarKey = key;
                    if (!standOccupied && !String.IsNullOrEmpty(activeCarKey))
                    {
                        if (PlayerPrefs.HasKey(PrefKey(CarModePrefix + activeCarKey)))
                        {
                            selectedMode = ReadMode(PlayerPrefs.GetInt(PrefKey(CarModePrefix + activeCarKey), 0));
                            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(PlayerPrefs.GetFloat(PrefKey(CarPsiPrefix + activeCarKey), 8.0f), P1XMaxBoostPsi, 8.0f);
                            SaveGlobalSettings();
                            status = "Loaded induction settings for " + activeCarKey;
                        }
                        else if (TryLoadEngineAlias(loader, out selectedMode, out selectedBoostPsi))
                        {
                            SaveCarSettings(activeCarKey, selectedMode, selectedBoostPsi);
                            status = "Restored P-1X setup from the installed engine";
                        }
                        else
                        {
                            selectedMode = InductionMode.Off;
                            selectedBoostPsi = 8.0f;
                            SaveGlobalSettings();
                        }
                    }
                    UpdateEffectiveSettings();
                }
                else if (!String.IsNullOrEmpty(activeCarKey))
                {
                    // Parts can be mounted or removed without changing the car scene.
                    // Recheck at the existing context-refresh interval so native shop parts
                    // can switch the automatic induction mode immediately.
                    UpdateEffectiveSettings();
                }
            }
            catch (Exception exception)
            {
                activeController = null;
                Logger.LogWarning("Could not inspect the active car: " + exception.Message);
            }
        }
        private void CycleMode()
        {
            SetMode(selectedMode == InductionMode.Procharger ? InductionMode.Off : InductionMode.Procharger);
        }

        private void SetMode(InductionMode mode)
        {
            if (mode != InductionMode.Off && mode != InductionMode.Procharger)
            {
                status = "This build supports the ProCharger P-1X only.";
                Logger.LogInfo(status);
                return;
            }
            if (selectedMode != mode)
            {
                currentSpool = 0.0f;
                liveBoostPsi = 0.0f;
            }
            selectedMode = mode;
            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(selectedBoostPsi, GetMaximumBoostPsi(mode, standOccupied ? standHasHighBoostProcharger : activeHasHighBoostProcharger), 8.0f);
            SaveGlobalSettings();
            UpdateEffectiveSettings();
            if (standOccupied && standGroup != null)
            {
                SaveGroupSettings(standGroup, mode, selectedBoostPsi);
                SaveGroupKitSelection(standGroup, mode);
                AnnotateGroup(standGroup, mode, selectedBoostPsi);
                RegisterEngineAliases(standGroup, mode, selectedBoostPsi);
                status = ModeName(mode) + " selected for " + standGroupName;
            }
            else if (!String.IsNullOrEmpty(activeCarKey))
            {
                SaveCarSettings(activeCarKey, mode, selectedBoostPsi);
                status = ModeName(mode) + " selected for " + activeCarKey;
            }
            else
            {
                status = ModeName(mode) + " selected; choose an engine on the stand to attach it to that engine";
            }

            RemoveVisual();
            EnsureVisual();
            Logger.LogInfo(status);
        }

        private void SaveGroupKitSelection(NewGroupItem group, InductionMode mode)
        {
            // Installed-kit state belongs to a specific car key. Group keys are
            // shared by engine builds and must never persist a fitted kit.
        }

        private static string KitIdForMode(InductionMode mode)
        {
            if (mode == InductionMode.Procharger) return ProchargerPartId;
            return String.Empty;
        }
        private void SetBoostPsi(float psi)
        {
            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(psi, GetCurrentControlBoostLimit(), selectedBoostPsi);
            SaveGlobalSettings();
            UpdateEffectiveSettings();
            if (standOccupied && standGroup != null)
            {
                SaveGroupSettings(standGroup, selectedMode, selectedBoostPsi);
                AnnotateGroup(standGroup, selectedMode, selectedBoostPsi);
                RegisterEngineAliases(standGroup, selectedMode, selectedBoostPsi);
            }
            else if (!String.IsNullOrEmpty(activeCarKey))
            {
                SaveCarSettings(activeCarKey, selectedMode, selectedBoostPsi);
            }
        }

        private void SaveGlobalSettings()
        {
            PlayerPrefs.SetInt(PrefKey(GlobalModeKey), (int)selectedMode);
            PlayerPrefs.SetFloat(PrefKey(GlobalPsiKey), selectedBoostPsi);
        }

        private static float GetMaximumBoostPsi(InductionMode mode, bool highBoostProcharger)
        {
            if (mode == InductionMode.Procharger && highBoostProcharger) return P1XMaxBoostPsi;
            return P1XStreetMaxBoostPsi;
        }

        private float GetCurrentControlBoostLimit()
        {
            return standOccupied
                ? GetMaximumBoostPsi(selectedMode, standHasHighBoostProcharger)
                : GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger);
        }

        private void SaveGroupSettings(NewGroupItem group, InductionMode mode, float psi)
        {
            string key = BuildGroupKey(group);
            PlayerPrefs.SetInt(PrefKey(GroupModePrefix + key), (int)mode);
            PlayerPrefs.SetFloat(PrefKey(GroupPsiPrefix + key), psi);
            SaveGlobalSettings();
            PlayerPrefs.Save();
        }

        private bool TryReadStoredGroupSettings(NewGroupItem group, out InductionMode mode, out float psi)
        {
            mode = InductionMode.Off;
            psi = 8.0f;
            if (group == null) return false;

            string currentKey = BuildGroupKey(group);
            string storedKey = currentKey;
            if (!PlayerPrefs.HasKey(PrefKey(GroupModePrefix + storedKey)))
            {
                string legacyKey = BuildLegacyGroupKey(group);
                if (String.IsNullOrEmpty(legacyKey) || String.Equals(legacyKey, currentKey, StringComparison.Ordinal)
                    || !PlayerPrefs.HasKey(PrefKey(GroupModePrefix + legacyKey))) return false;
                storedKey = legacyKey;
            }

            mode = ReadMode(PlayerPrefs.GetInt(PrefKey(GroupModePrefix + storedKey), 0));
            psi = ProchargerMath.NormalizeBoostPsi(PlayerPrefs.GetFloat(PrefKey(GroupPsiPrefix + storedKey), 8.0f), P1XMaxBoostPsi, 8.0f);
            if (!String.Equals(storedKey, currentKey, StringComparison.Ordinal))
            {
                PlayerPrefs.SetInt(PrefKey(GroupModePrefix + currentKey), (int)mode);
                PlayerPrefs.SetFloat(PrefKey(GroupPsiPrefix + currentKey), psi);
                PlayerPrefs.Save();
            }
            return true;
        }

        private void SaveCarSettings(string carKey, InductionMode mode, float psi)
        {
            if (String.IsNullOrEmpty(carKey)) return;
            PlayerPrefs.SetInt(PrefKey(CarModePrefix + carKey), (int)mode);
            PlayerPrefs.SetFloat(PrefKey(CarPsiPrefix + carKey), psi);
            SaveGlobalSettings();
            PlayerPrefs.Save();
            UpdateEffectiveSettings();
        }
        private static string BuildGroupKey(NewGroupItem group)
        {
            if (group == null) return string.Empty;
            string groupName = NormalizeKey(group.GroupName);
            if (!String.IsNullOrEmpty(groupName)) return groupName;
            string itemKey = string.Empty;
            if (group.ItemList != null && group.ItemList.Count > 0)
            {
                NewInventoryItem item = group.ItemList[0];
                if (item != null)
                {
                    itemKey = NormalizeKey(GetNormalId(item));
                }
            }
            return itemKey;
        }

        private static string BuildLegacyGroupKey(NewGroupItem group)
        {
            if (group == null) return string.Empty;
            string itemKey = string.Empty;
            if (group.ItemList != null && group.ItemList.Count > 0)
            {
                NewInventoryItem item = group.ItemList[0];
                if (item != null) itemKey = NormalizeKey(GetNormalId(item));
            }
            return NormalizeKey(group.GroupName) + "_" + itemKey;
        }

        private static T ReadComponentReference<T>(object instance, string fieldName) where T : class
        {
            if (instance == null) return null;
            FieldInfo field = AccessTools.Field(instance.GetType(), fieldName);
            return System.Object.ReferenceEquals(field, null) ? null : field.GetValue(instance) as T;
        }

        private CarLoader FindActiveCarLoader(out VPVehicleController controller)
        {
            controller = null;
            PrepareCarPhysics setup = PrepareCarPhysics.Get();
            CarLoader setupLoader = null;
            if (setup != null)
            {
                controller = ReadComponentReference<VPVehicleController>(setup, "vpVehicleController");
                setupLoader = ReadComponentReference<CarLoader>(setup, "carLoader");
                if (controller != null && setupLoader != null) return setupLoader;
            }

            DynoManager dyno = DynoManager.Get();
            CarLoader dynoLoader = ReadComponentReference<CarLoader>(dyno, "carLoader");
            if (dynoLoader != null)
            {
                controller = null;
                return dynoLoader;
            }
            return setupLoader;
        }

        private string PrefKey(string key)
        {
            return "CMS18Turbo.Profile" + settingsProfile.ToString() + "." + key;
        }

        private void EnsureUniversalMountOnStand(GameScript game)
        {
            if (game == null) return;
            try
            {
                List<GameObject> objects = game.GetObjectsOnEngineStand();
                if (objects == null || objects.Count == 0) return;
                GameObject target = null;
                for (int i = 0; i < objects.Count; i++)
                {
                    GameObject candidate = objects[i];
                    if (candidate == null || candidate.GetComponentInChildren<PartScript>(true) == null) continue;
                    target = FindEngineContainer(candidate);
                    if (target == null) target = candidate;
                    break;
                }
                if (target == null) return;
                int rootId = target.GetInstanceID();
                if (checkedStandMountRoots.Contains(rootId)) return;
                string key = !String.IsNullOrEmpty(standGroupKey) ? standGroupKey : standGroupName;
                EnsureUniversalMount(target, key);
                checkedStandMountRoots.Add(rootId);
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not add the universal induction mount to the engine stand: " + exception.Message);
            }
        }

        private static GameObject FindEngineContainer(GameObject part)
        {
            Transform current = part == null ? null : part.transform;
            while (current != null)
            {
                if (current.name.StartsWith("engine_", StringComparison.OrdinalIgnoreCase)) return current.gameObject;
                current = current.parent;
            }
            return null;
        }

        private PartScript EnsureUniversalMount(GameObject engineRoot, string engineKey)
        {
            if (engineRoot == null) return null;
            PartScript[] existingParts = engineRoot.GetComponentsInChildren<PartScript>(true);
            for (int i = 0; i < existingParts.Length; i++)
            {
                PartScript existing = existingParts[i];
                if (existing != null && IsUniversalMountId(existing.GetID()))
                {
                    InitializeVirtualMountPart(existing);
                    existing.gameObject.layer = PartSelectionLayer;
                    SetPartField(existing, "canBeUnmount", true);
                    SetPartField(existing, "canUnmountSingle", true);
                    Collider[] existingColliders = existing.GetComponents<Collider>();
                    for (int colliderIndex = 0; colliderIndex < existingColliders.Length; colliderIndex++)
                        if (existingColliders[colliderIndex] != null) existingColliders[colliderIndex].enabled = true;
                    PositionUniversalMountNearDrivePulley(engineRoot, existing.transform);
                    return existing;
                }
            }

            GameObject mountObject = new GameObject(UniversalMountDisplayName + "(0)");
            string selectableLayerSource;
            mountObject.layer = FindSelectablePartLayer(engineRoot, out selectableLayerSource);
            mountObject.transform.SetParent(engineRoot.transform, false);
            mountObject.transform.localRotation = Quaternion.identity;
            mountObject.transform.localScale = Vector3.one;
            BoxCollider collider = mountObject.AddComponent<BoxCollider>();
            collider.enabled = true;
            collider.size = new Vector3(0.28f, 0.18f, 0.18f);
            PositionUniversalMountNearDrivePulley(engineRoot, mountObject.transform);

            PartScript mount = mountObject.AddComponent<PartScript>();
            mount.SetID(UniversalMountPartId);
            mount.SetTunedID(String.Empty);
            InitializeVirtualMountPart(mount);
            Logger.LogInfo("Universal induction mount uses selectable part layer " + mountObject.layer
                + " copied from " + selectableLayerSource + ".");
            Logger.LogInfo("Added a universal induction mount to " + engineRoot.name + ".");
            return mount;
        }

        private static int FindSelectablePartLayer(GameObject engineRoot, out string sourceName)
        {
            sourceName = "CMS part-selection raycast layer 16";
            return PartSelectionLayer;
        }

        private void PositionUniversalMountNearDrivePulley(GameObject engineRoot, Transform mount)
        {
            if (engineRoot == null || mount == null) return;
            Transform engineTransform = engineRoot.transform;
            PartScript crankPulley = FindCrankPulleyPart(engineRoot);
            Vector3 crankCenterWorld;
            Vector3 pulleyAxisWorld = engineTransform.right;
            float crankRadius = 0.075f;
            Bounds pulleyBounds = new Bounds(Vector3.zero, Vector3.zero);
            Bounds localPulleyBounds = new Bounds(Vector3.zero, Vector3.zero);
            bool hasExactMeshBounds = false;
            bool hasLocalBounds = false;
            bool hasPulley = crankPulley != null && TryGetPartWorldBounds(crankPulley, out pulleyBounds);
            if (hasPulley)
            {
                hasExactMeshBounds = TryGetPartLocalMeshBounds(crankPulley, out localPulleyBounds);
                hasLocalBounds = hasExactMeshBounds || TryGetLocalRendererBounds(
                    crankPulley.GetComponentsInChildren<Renderer>(true), crankPulley.transform, out localPulleyBounds);
                if (hasLocalBounds)
                {
                    crankCenterWorld = crankPulley.transform.TransformPoint(localPulleyBounds.center);
                    crankRadius = EstimatePulleyRadiusWorld(localPulleyBounds.size, crankPulley.transform);
                }
                else
                {
                    crankCenterWorld = pulleyBounds.center;
                    float[] worldDimensions = { pulleyBounds.size.x, pulleyBounds.size.y, pulleyBounds.size.z };
                    Array.Sort(worldDimensions);
                    crankRadius = Mathf.Clamp(worldDimensions[1] * 0.5f, 0.045f, 0.16f);
                }
                Vector3 localAxisSize = hasLocalBounds ? localPulleyBounds.size : pulleyBounds.size;
                pulleyAxisWorld = SmallestLocalBoundsAxis(localAxisSize, crankPulley.transform);
                if (Vector3.Dot(pulleyAxisWorld, engineTransform.right) < 0.0f) pulleyAxisWorld = -pulleyAxisWorld;
            }
            else
            {
                Bounds engineBounds;
                if (TryGetLocalRendererBounds(engineRoot.GetComponentsInChildren<Renderer>(true), engineTransform, out engineBounds))
                {
                    Vector3 localCenter = EstimateFrontDriveCenter(engineBounds);
                    localCenter.z = engineBounds.max.z;
                    crankCenterWorld = engineTransform.TransformPoint(localCenter);
                }
                else
                {
                    crankCenterWorld = engineTransform.position;
                }
                Logger.LogWarning("Could not identify a crank-pulley part on " + engineRoot.name + "; placing the induction mount from engine bounds.");
                LogEnginePartLayout(engineRoot);
            }

            if (pulleyAxisWorld.sqrMagnitude < 0.0001f) pulleyAxisWorld = engineTransform.right;
            pulleyAxisWorld.Normalize();
            Quaternion alignedRotation = Quaternion.FromToRotation(engineTransform.right, pulleyAxisWorld) * engineTransform.rotation;
            mount.rotation = alignedRotation;

            Vector3 upWorld = engineTransform.up - pulleyAxisWorld * Vector3.Dot(engineTransform.up, pulleyAxisWorld);
            if (upWorld.sqrMagnitude < 0.0001f) upWorld = engineTransform.forward - pulleyAxisWorld * Vector3.Dot(engineTransform.forward, pulleyAxisWorld);
            upWorld.Normalize();
            float centerSpacing = Mathf.Max(0.14f, crankRadius + 0.075f);
            Vector3 desiredChargerPulleyWorld = crankCenterWorld + upWorld * centerSpacing;
            // Keep mount placement in lockstep with the measured 0.4 m/model-unit
            // scale used by the P-1X visual and its belt/bracket geometry.
            const float approximateModelScale = ProchargerModelUnitScale;
            // Keep the model in its authored orientation. The old 180-degree flip
            // put the compressor body on the block side of its drive pulley.
            Quaternion modelRotation = Quaternion.identity;
            Vector3 pulleyOffset = modelRotation * ((ProchargerDrivePulleyCenter - ProchargerModelBoundsCenter) * approximateModelScale);
            Vector3 mountWorld = desiredChargerPulleyWorld - mount.rotation * pulleyOffset;
            mount.position = mountWorld;

            if (hasPulley)
                Logger.LogInfo("Placed the universal induction mount beside " + crankPulley.GetID() + " on " + engineRoot.name
                    + "; crank=" + engineTransform.InverseTransformPoint(crankCenterWorld).ToString("F3")
                    + ", axis=" + engineTransform.InverseTransformDirection(pulleyAxisWorld).ToString("F3")
                    + ", mount=" + engineTransform.InverseTransformPoint(mount.position).ToString("F3")
                    + ", radius=" + crankRadius.ToString("F3")
                    + ", cmsUnmountedFlag=" + crankPulley.IsUnmounted()
                    + ", pulleyBounds=" + (hasExactMeshBounds ? "mesh" : "renderer")
                    + (hasLocalBounds ? localPulleyBounds.size.ToString("F3") : "unavailable") + ".");
        }

        private static PartScript FindCrankPulleyPart(GameObject engineRoot)
        {
            if (engineRoot == null) return null;
            PartScript[] parts = engineRoot.GetComponentsInChildren<PartScript>(true);
            PartScript best = null;
            int bestScore = Int32.MaxValue;
            float lowestY = Single.MaxValue;
            for (int i = 0; i < parts.Length; i++)
            {
                PartScript part = parts[i];
                if (part == null || IsUniversalMountId(part.GetID())) continue;
                // During engine transfer CMS can mark an intact mesh unmounted. This finder
                // only chooses a visual placement reference; it must not infer install state.
                bool cmsUnmounted = part.IsUnmounted();
                if (cmsUnmounted && !HasVisiblePartGeometry(part)) continue;
                string id = (part.GetID() ?? String.Empty) + " " + (part.GetTunedID() ?? String.Empty) + " " + part.gameObject.name;
                int score = ScoreCrankPulleyCandidate(id);
                if (score == Int32.MaxValue) continue;
                int effectiveScore = score * 2 + (cmsUnmounted ? 1 : 0);
                Vector3 localCenter = engineRoot.transform.InverseTransformPoint(part.transform.position);
                if (effectiveScore < bestScore || (effectiveScore == bestScore && localCenter.y < lowestY))
                {
                    best = part;
                    bestScore = effectiveScore;
                    lowestY = localCenter.y;
                }
            }
            return best;
        }

        private static bool HasVisiblePartGeometry(PartScript part)
        {
            if (part == null || part.gameObject == null || !part.gameObject.activeInHierarchy) return false;
            Renderer[] renderers = part.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null || !renderer.enabled || !renderer.gameObject.activeInHierarchy) continue;
                Bounds bounds = renderer.bounds;
                if (bounds.size.sqrMagnitude > 0.000001f) return true;
            }
            return false;
        }

        internal static int ScoreCrankPulleyCandidate(string partId)
        {
            if (String.IsNullOrEmpty(partId)) return Int32.MaxValue;
            string id = partId.ToLowerInvariant();
            bool pulley = id.Contains("pulley") || id.Contains("kolo_pasowe") || id.Contains("kolo pasowe");
            bool crankshaftPulley = pulley && (id.Contains("crank") || id.Contains("walu") || id.Contains("wału"));
            bool balancer = id.Contains("balancer") || id.Contains("harmonic");
            if (crankshaftPulley) return 0;
            if (balancer) return 1;
            if (pulley) return 2;
            return Int32.MaxValue;
        }

        private static Vector3 EstimateFrontDriveCenter(Bounds engineBounds)
        {
            Vector3 center = engineBounds.center;
            // Keep the visual hardware above the radiator/crossmember area. This is a
            // fallback only; a detected crank pulley always takes precedence.
            center.y = engineBounds.min.y + Mathf.Clamp(engineBounds.size.y * 0.32f, 0.18f, 0.26f);
            return center;
        }

        private void LogEnginePartLayout(GameObject engineRoot)
        {
            if (engineRoot == null || !loggedEngineLayoutRoots.Add(engineRoot.GetInstanceID())) return;
            Transform root = engineRoot.transform;
            PartScript[] parts = engineRoot.GetComponentsInChildren<PartScript>(true);
            Bounds engineBounds;
            string boundsText = TryGetLocalRendererBounds(engineRoot.GetComponentsInChildren<Renderer>(true), root, out engineBounds)
                ? " center=" + engineBounds.center.ToString("F3") + " size=" + engineBounds.size.ToString("F3")
                : " bounds=unavailable";
            Logger.LogInfo("Engine layout diagnostic for " + engineRoot.name + ": " + parts.Length + " PartScript objects;" + boundsText);
            for (int i = 0; i < parts.Length; i++)
            {
                PartScript part = parts[i];
                if (part == null) continue;
                Vector3 localPosition = root.InverseTransformPoint(part.transform.position);
                Bounds partBounds;
                string partBoundsText = TryGetPartWorldBounds(part, out partBounds)
                    ? " worldSize=" + partBounds.size.ToString("F3") + " localCenter=" + root.InverseTransformPoint(partBounds.center).ToString("F3")
                    : " noRendererBounds";
                Logger.LogInfo("Engine part candidate: id=" + part.GetID() + ", tuned=" + part.GetTunedID()
                    + ", object=" + part.gameObject.name + ", unmounted=" + part.IsUnmounted()
                    + ", local=" + localPosition.ToString("F3") + partBoundsText);
            }
        }

        private static bool TryGetPartWorldBounds(PartScript part, out Bounds bounds)
        {
            bounds = new Bounds(Vector3.zero, Vector3.zero);
            if (part == null) return false;
            Renderer[] renderers = part.GetComponentsInChildren<Renderer>(true);
            bool initialized = false;
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null || renderer.bounds.size.sqrMagnitude < 0.000001f) continue;
                if (!initialized)
                {
                    bounds = renderer.bounds;
                    initialized = true;
                }
                else
                {
                    bounds.Encapsulate(renderer.bounds);
                }
            }
            return initialized;
        }

        private static bool TryGetPartLocalMeshBounds(PartScript part, out Bounds bounds)
        {
            bounds = new Bounds(Vector3.zero, Vector3.zero);
            if (part == null) return false;
            Renderer[] renderers = part.GetComponentsInChildren<Renderer>(true);
            bool initialized = false;
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null) continue;
                Mesh mesh = null;
                MeshFilter filter = renderer.GetComponent<MeshFilter>();
                if (filter != null) mesh = filter.sharedMesh;
                if (mesh == null)
                {
                    SkinnedMeshRenderer skinned = renderer as SkinnedMeshRenderer;
                    if (skinned != null) mesh = skinned.sharedMesh;
                }
                if (mesh == null || mesh.bounds.size.sqrMagnitude < 0.000001f) continue;

                Bounds meshBounds = mesh.bounds;
                for (int corner = 0; corner < 8; corner++)
                {
                    Vector3 meshPoint = new Vector3(
                        (corner & 1) == 0 ? meshBounds.min.x : meshBounds.max.x,
                        (corner & 2) == 0 ? meshBounds.min.y : meshBounds.max.y,
                        (corner & 4) == 0 ? meshBounds.min.z : meshBounds.max.z);
                    Vector3 localPoint = part.transform.InverseTransformPoint(renderer.transform.TransformPoint(meshPoint));
                    if (!initialized)
                    {
                        bounds = new Bounds(localPoint, Vector3.zero);
                        initialized = true;
                    }
                    else bounds.Encapsulate(localPoint);
                }
            }
            return initialized;
        }

        private static float EstimatePulleyRadiusWorld(Vector3 localBoundsSize, Transform pulleyTransform)
        {
            int shaftAxis = localBoundsSize.x <= localBoundsSize.y && localBoundsSize.x <= localBoundsSize.z ? 0
                : localBoundsSize.y <= localBoundsSize.x && localBoundsSize.y <= localBoundsSize.z ? 1 : 2;
            Vector3 firstRadialAxis = shaftAxis == 0 ? Vector3.up : Vector3.right;
            Vector3 secondRadialAxis = shaftAxis == 2 ? Vector3.up : Vector3.forward;
            if (shaftAxis == 1) secondRadialAxis = Vector3.forward;
            float firstDiameter = shaftAxis == 0 ? localBoundsSize.y : localBoundsSize.x;
            float secondDiameter = shaftAxis == 2 ? localBoundsSize.y : localBoundsSize.z;
            float firstScale = pulleyTransform == null ? 1.0f : pulleyTransform.TransformVector(firstRadialAxis).magnitude;
            float secondScale = pulleyTransform == null ? 1.0f : pulleyTransform.TransformVector(secondRadialAxis).magnitude;
            return Mathf.Clamp((firstDiameter * firstScale + secondDiameter * secondScale) * 0.25f, 0.045f, 0.16f);
        }

        private static Vector3 SmallestLocalBoundsAxis(Vector3 size, Transform localToWorld)
        {
            Vector3 localAxis = size.x <= size.y && size.x <= size.z ? Vector3.right
                : size.y <= size.x && size.y <= size.z ? Vector3.up : Vector3.forward;
            Vector3 worldAxis = localToWorld == null ? Vector3.right : localToWorld.TransformDirection(localAxis);
            return worldAxis.sqrMagnitude < 0.0001f ? Vector3.right : worldAxis.normalized;
        }

        private void InitializeVirtualMountPart(PartScript part)
        {
            if (part == null) return;
            Transform installedVisual = part.transform.Find(InstalledInductionVisualName);
            bool prochargerInstalled = IsProchargerPartId(part.GetTunedID()) && installedVisual != null;
            SetPartField(part, "canBeUnmount", true);
            SetPartField(part, "canUnmountSingle", true);
            SetPartField(part, "unmounted", false);
            SetPartField(part, "forInventory", false);
            SetPartField(part, "oneClickUnmount", !prochargerInstalled);
            // The universal mount is an internal visual anchor, not a physical
            // four-bolt part. Keep selection on its PartScript root only.
            Transform anchor = part.transform.Find(VirtualMountAnchorName);
            if (anchor == null)
            {
                GameObject anchorObject = new GameObject(VirtualMountAnchorName);
                anchorObject.layer = part.gameObject.layer;
                anchorObject.transform.SetParent(part.transform, false);
                anchorObject.transform.localPosition = new Vector3(0.0f, -0.045f, 0.0f);
                anchorObject.transform.localRotation = Quaternion.identity;
                anchorObject.transform.localScale = Vector3.one;
                anchor = anchorObject.transform;
            }
            anchor.gameObject.layer = part.gameObject.layer;

            // Older builds put a large invisible MountObject and synthetic
            // bolt heads here. Neither should become a game unscrew task.
            MountObject legacyMountObject = anchor.GetComponent<MountObject>();
            if (legacyMountObject != null)
            {
                legacyMountObject.SetCanBeUnmount(false);
                UnityEngine.Object.Destroy(legacyMountObject);
            }
            Collider[] legacyColliders = anchor.GetComponents<Collider>();
            for (int i = 0; i < legacyColliders.Length; i++)
            {
                if (legacyColliders[i] == null) continue;
                legacyColliders[i].enabled = false;
                UnityEngine.Object.Destroy(legacyColliders[i]);
            }

            if (prochargerInstalled)
            {
                EnsureProchargerMountFasteners(part, installedVisual);
                SetEmptyArrayPartField(part, "unblockOnUnmount");
                SetEmptyArrayPartField(part, "unblockOnUnmountName");
                SetEmptyArrayPartField(part, "enableOnUnmount");
                SetEmptyArrayPartField(part, "disableOnUnmount");
                SetEmptyListPartField(part, "blockedBy");
                SetEmptyListPartField(part, "unmountWith");
                AddUnmountVisibilityTargets(part, installedVisual);
                return;
            }

            Transform[] oldFasteners = part.GetComponentsInChildren<Transform>(true);
            for (int i = oldFasteners.Length - 1; i >= 0; i--)
            {
                Transform oldFastener = oldFasteners[i];
                if (oldFastener == null || oldFastener == part.transform
                    || !oldFastener.name.StartsWith(ProchargerMountFastenerPrefix, StringComparison.Ordinal)) continue;
                oldFastener.gameObject.SetActive(false);
                UnityEngine.Object.Destroy(oldFastener.gameObject);
            }
            SetPartField(part, "MountObjects", new MountObject[0]);
            SetEmptyArrayPartField(part, "unblockOnUnmount");
            SetEmptyArrayPartField(part, "unblockOnUnmountName");
            SetEmptyArrayPartField(part, "enableOnUnmount");
            SetEmptyArrayPartField(part, "disableOnUnmount");
            SetEmptyArrayPartField(part, "hideWhenUnmontingMounting");
            SetEmptyListPartField(part, "blockedBy");
            SetEmptyListPartField(part, "unmountWith");
        }

        private static void SetPartField(PartScript part, string fieldName, object value)
        {
            FieldInfo field = AccessTools.Field(typeof(PartScript), fieldName);
            if (!System.Object.ReferenceEquals(field, null) && (value == null || field.FieldType.IsInstanceOfType(value)))
                field.SetValue(part, value);
        }

        private bool EnsureProchargerMountFasteners(PartScript part, Transform visualRoot)
        {
            if (part == null || visualRoot == null || !IsUniversalMountId(part.GetID())) return false;

            List<MountObject> fasteners = new List<MountObject>(2);
            for (int index = 0; index < 2; index++)
            {
                string fastenerName = ProchargerMountFastenerPrefix + index;
                Transform existing = visualRoot.Find(fastenerName);
                MountObject mountObject = existing == null ? null : existing.GetComponent<MountObject>();
                if (mountObject == null)
                {
                    if (existing != null)
                    {
                        existing.gameObject.SetActive(false);
                        UnityEngine.Object.Destroy(existing.gameObject);
                    }
                    mountObject = CreateProchargerMountFastener(visualRoot, fastenerName, index);
                }
                if (mountObject == null) continue;
                mountObject.gameObject.layer = MountObjectSelectionLayer;
                mountObject.transform.SetParent(visualRoot, true);
                Transform[] descendants = mountObject.GetComponentsInChildren<Transform>(true);
                for (int childIndex = 0; childIndex < descendants.Length; childIndex++)
                    if (descendants[childIndex] != null) descendants[childIndex].gameObject.layer = MountObjectSelectionLayer;
                fasteners.Add(mountObject);
            }

            if (fasteners.Count != 2)
            {
                SetPartField(part, "MountObjects", fasteners.ToArray());
                SetPartField(part, "oneClickUnmount", true);
                Logger.LogWarning("P-1X mounting bolts could not be initialized; retaining one-click removal to avoid a broken part.");
                return false;
            }

            SetPartField(part, "MountObjects", fasteners.ToArray());
            SetPartField(part, "oneClickUnmount", false);
            return true;
        }

        private MountObject CreateProchargerMountFastener(Transform visualRoot, string objectName, int index)
        {
            if (visualRoot == null) return null;
            GameObject fastener = new GameObject(objectName);
            fastener.layer = MountObjectSelectionLayer;
            fastener.transform.SetParent(visualRoot, false);
            fastener.transform.localPosition = new Vector3(-0.151f, index == 0 ? -0.135f : 0.135f, -0.14f);
            fastener.transform.localRotation = Quaternion.identity;
            fastener.transform.localScale = Vector3.one;

            BoxCollider hitbox = fastener.AddComponent<BoxCollider>();
            hitbox.center = Vector3.zero;
            hitbox.size = new Vector3(0.024f, 0.030f, 0.030f);
            hitbox.enabled = true;

            GameObject head = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            head.name = "P-1X mounting bolt head";
            head.layer = MountObjectSelectionLayer;
            head.transform.SetParent(fastener.transform, false);
            head.transform.localPosition = Vector3.zero;
            head.transform.localRotation = Quaternion.Euler(0.0f, 0.0f, 90.0f);
            head.transform.localScale = new Vector3(0.038f, 0.006f, 0.038f);
            Collider[] headColliders = head.GetComponents<Collider>();
            for (int colliderIndex = 0; colliderIndex < headColliders.Length; colliderIndex++)
            {
                if (headColliders[colliderIndex] == null) continue;
                headColliders[colliderIndex].enabled = false;
                UnityEngine.Object.Destroy(headColliders[colliderIndex]);
            }
            MeshRenderer headRenderer = head.GetComponent<MeshRenderer>();
            if (headRenderer != null)
            {
                Material material = GetProchargerDriveMaterial(false);
                if (material != null) headRenderer.sharedMaterial = material;
                headRenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
                ConfigureInductionRenderer(headRenderer);
            }

            GameObject slot = GameObject.CreatePrimitive(PrimitiveType.Cube);
            slot.name = "P-1X mounting bolt slot";
            slot.layer = MountObjectSelectionLayer;
            slot.transform.SetParent(fastener.transform, false);
            slot.transform.localPosition = new Vector3(-0.0045f, 0.0f, 0.0f);
            slot.transform.localRotation = Quaternion.identity;
            slot.transform.localScale = new Vector3(0.0025f, 0.022f, 0.0028f);
            Collider[] slotColliders = slot.GetComponents<Collider>();
            for (int colliderIndex = 0; colliderIndex < slotColliders.Length; colliderIndex++)
            {
                if (slotColliders[colliderIndex] == null) continue;
                slotColliders[colliderIndex].enabled = false;
                UnityEngine.Object.Destroy(slotColliders[colliderIndex]);
            }
            MeshRenderer slotRenderer = slot.GetComponent<MeshRenderer>();
            if (slotRenderer != null)
            {
                Material material = GetProchargerDriveMaterial(true);
                if (material != null) slotRenderer.sharedMaterial = material;
                ConfigureInductionRenderer(slotRenderer);
            }

            MountObject mountObject = fastener.AddComponent<MountObject>();
            FieldInfo speedField = AccessTools.Field(typeof(MountObject), "toolSpeed");
            if (System.Object.ReferenceEquals(speedField, null))
            {
                fastener.SetActive(false);
                UnityEngine.Object.Destroy(fastener);
                Logger.LogWarning("The verified CMS MountObject.toolSpeed field was unavailable; P-1X fastener interaction was not enabled.");
                return null;
            }
            speedField.SetValue(mountObject, 1.35f);
            mountObject.SetFullMountPosition();
            mountObject.SetCanBeUnmount(false);
            return mountObject;
        }

        private static bool IsMountObjectRenderer(Renderer renderer)
        {
            Transform current = renderer == null ? null : renderer.transform;
            while (current != null)
            {
                if (current.GetComponent<MountObject>() != null) return true;
                current = current.parent;
            }
            return false;
        }

        private static void SetEmptyArrayPartField(PartScript part, string fieldName)
        {
            FieldInfo field = AccessTools.Field(typeof(PartScript), fieldName);
            if (System.Object.ReferenceEquals(field, null) || !field.FieldType.IsArray) return;
            field.SetValue(part, Array.CreateInstance(field.FieldType.GetElementType(), 0));
        }

        private static void SetEmptyListPartField(PartScript part, string fieldName)
        {
            FieldInfo field = AccessTools.Field(typeof(PartScript), fieldName);
            if (System.Object.ReferenceEquals(field, null)) return;
            if (field.FieldType.IsAssignableFrom(typeof(List<PartScript>))) field.SetValue(part, new List<PartScript>());
        }

        private GameObject CreateUniversalMountPrefab(bool inventoryPreview)
        {
            GameObject mountObject = new GameObject(UniversalMountDisplayName + "(0)");
            mountObject.transform.localScale = Vector3.one;
            BoxCollider collider = mountObject.AddComponent<BoxCollider>();
            collider.size = new Vector3(0.28f, 0.18f, 0.18f);
            collider.enabled = !inventoryPreview;
            PartScript mount = mountObject.AddComponent<PartScript>();
            mount.SetID(UniversalMountPartId);
            mount.SetTunedID(String.Empty);
            InitializeVirtualMountPart(mount);
            SetPartField(mount, "forInventory", inventoryPreview);
            return mountObject;
        }

        private static int ReadSelectedProfile(int fallback)
        {
            try
            {
                ProfileManager manager = ProfileManager.Get();
                return manager == null ? fallback : manager.GetSelectedProfile();
            }
            catch
            {
                return fallback;
            }
        }

        private void RefreshProfileContext()
        {
            int profile = ReadSelectedProfile(settingsProfile);
            if (profile == settingsProfile) return;

            settingsProfile = profile;
            checkedStandMountRoots.Clear();
            activeCarKey = string.Empty;
            standGroupKey = string.Empty;
            standGroupName = string.Empty;
            standGroupUid = 0;
            selectedMode = ReadMode(PlayerPrefs.GetInt(PrefKey(GlobalModeKey), 0));
            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(PlayerPrefs.GetFloat(PrefKey(GlobalPsiKey), 8.0f), P1XMaxBoostPsi, 8.0f);
            status = "Loaded induction settings for save profile " + settingsProfile;
            Logger.LogInfo(status);
            UpdateEffectiveSettings();
        }

        private static string GetNormalId(NewInventoryItem item)
        {
            if (item == null) return string.Empty;
            try
            {
                if (item.extraParameters != null && item.extraParameters.ContainsKey("NormalID"))
                {
                    object value = item.extraParameters.GetFromKey("NormalID");
                    if (value != null && !String.IsNullOrEmpty(value.ToString())) return value.ToString();
                }
            }
            catch { }
            return item.ID;
        }

        private static string NormalizeKey(string value)
        {
            if (String.IsNullOrEmpty(value)) return string.Empty;
            string normalized = value.Replace("(Clone)", string.Empty).Trim().ToLowerInvariant();
            normalized = normalized.Replace(' ', '_').Replace('/', '_').Replace('\\', '_');
            return normalized;
        }

        private static string BuildCarIdentityKey(CarLoader loader)
        {
            if (loader == null) return string.Empty;
            try
            {
                // GetSaveName() returns the Unity object name (for example
                // "#carloader5"), which CMS reuses for unrelated cars. Prefer the
                // saved factory plate: custom front/rear plates can be changed by
                // the player and would otherwise change the settings key mid-save.
                // If no factory plate exists, use the visible plates as a fallback.
                string plate = ReadCarLoaderString(loader, "factoryLicensePlateNumber");
                if (String.IsNullOrEmpty(plate)) plate = ReadCarLoaderString(loader, "licensePlateNumberRear");
                if (String.IsNullOrEmpty(plate)) plate = ReadCarLoaderString(loader, "licensePlateNumberFront");
                if (String.IsNullOrEmpty(plate)) return string.Empty;

                string model = string.Empty;
                try { model = NormalizeKey(loader.GetNameWithSufix()); }
                catch { }
                if (String.IsNullOrEmpty(model))
                {
                    try { model = NormalizeKey(loader.GetName()); }
                    catch { }
                }
                string normalizedPlate = NormalizeKey(plate);
                if (String.IsNullOrEmpty(normalizedPlate)) return string.Empty;
                return String.IsNullOrEmpty(model) ? "plate_" + normalizedPlate : model + "_plate_" + normalizedPlate;
            }
            catch { return string.Empty; }
        }

        private static string ReadCarLoaderString(CarLoader loader, string fieldName)
        {
            if (loader == null || String.IsNullOrEmpty(fieldName)) return string.Empty;
            try
            {
                FieldInfo field = typeof(CarLoader).GetField(fieldName,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                object value = System.Object.ReferenceEquals(field, null) ? null : field.GetValue(loader);
                return value == null ? string.Empty : value.ToString().Trim();
            }
            catch { return string.Empty; }
        }

        private static InductionMode ReadMode(int value)
        {
            // Value 3 is the original P-1X mode and remains save-compatible.
            // Old turbo and Roots selections are deliberately migrated to Off.
            return value == (int)InductionMode.Procharger
                ? InductionMode.Procharger : InductionMode.Off;
        }

        private static string ModeName(InductionMode mode)
        {
            if (mode == InductionMode.Procharger) return "ProCharger P-1X";
            return "Off";
        }

        private bool TryReadGroupSettings(NewGroupItem group, out InductionMode mode, out float psi)
        {
            mode = InductionMode.Off;
            psi = 8.0f;
            if (group == null || group.ItemList == null) return false;

            for (int i = 0; i < group.ItemList.Count; i++)
            {
                NewInventoryItem item = group.ItemList[i];
                if (item == null || item.extraParameters == null) continue;
                try
                {
                    if (!item.extraParameters.ContainsKey(MetaModeKey)) continue;
                    object modeValue = item.extraParameters.GetFromKey(MetaModeKey);
                    object psiValue = item.extraParameters.GetFromKey(MetaPsiKey);
                    mode = ReadMode(Convert.ToInt32(modeValue));
                    if (psiValue != null) psi = ProchargerMath.NormalizeBoostPsi(Convert.ToSingle(psiValue), P1XMaxBoostPsi, 8.0f);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            return false;
        }

        private void AnnotateGroup(NewGroupItem group, InductionMode mode, float psi)
        {
            if (group == null || group.ItemList == null || group.ItemList.Count == 0) return;
            try
            {
                NewInventoryItem item = group.ItemList[0];
                if (item == null) return;
                if (item.extraParameters == null) item.extraParameters = new NewHash();
                System.Collections.Hashtable table = item.extraParameters.GetHashTable();
                table[MetaModeKey] = (int)mode;
                table[MetaPsiKey] = psi;
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not attach induction settings to the engine group: " + exception.Message);
            }
        }

        private void RegisterEngineAliases(NewGroupItem group, InductionMode mode, float psi)
        {
            // Never persist induction by engine prefab/group name: that key is shared
            // by every car using the same engine and caused cross-car installation.
        }

        private void SaveEngineAlias(string key, InductionMode mode, float psi)
        {
            if (String.IsNullOrEmpty(key)) return;
            PlayerPrefs.SetInt(PrefKey(EngineModePrefix + key), (int)mode);
            PlayerPrefs.SetFloat(PrefKey(EnginePsiPrefix + key), psi);
        }

        private bool TryLoadEngineAlias(CarLoader loader, out InductionMode mode, out float psi)
        {
            mode = InductionMode.Off;
            psi = 8.0f;
            // Engine aliases are shared by every car using a given engine prefab.
            // Reading them caused a kit selected for one car to leak into others.
            return false;
        }

        private bool IsActiveCarLoader(CarLoader loader)
        {
            if (loader == null) return false;
            VPVehicleController ignored;
            return System.Object.ReferenceEquals(loader, FindActiveCarLoader(out ignored));
        }

        private void RecordPendingInstall(NewGroupItem group)
        {
            if (group == null) return;
            InductionMode mode;
            float psi;
            if (!TryReadGroupSettings(group, out mode, out psi)
                && !TryReadStoredGroupSettings(group, out mode, out psi))
            {
                mode = selectedMode;
                psi = selectedBoostPsi;
            }
            pendingInstallGroup = group;
            pendingInstallGroupName = group.GroupName;
            pendingInstallLoader = null;
            pendingInstallMode = mode;
            pendingInstallPsi = psi;
            pendingSwapObserved = false;
            string groupKitId = FindInductionKitId(group);
            if (!IsInductionPartId(groupKitId) && mode != InductionMode.Off)
                groupKitId = KitIdForMode(mode);
            pendingHasUniversalMount = mode != InductionMode.Off
                || GroupContainsUniversalMount(group)
                || IsInductionPartId(groupKitId);
            PlayerPrefs.Save();
            try
            {
                ToolsMoveManager manager = ToolsMoveManager.Get();
                if (manager != null) pendingInstallLoader = manager.GetConnectedCarLoader(IOSpecialType.EngineCrane);
            }
            catch { }
            EnsureMountForSameEngineTransfer(group);
            AnnotateGroup(group, mode, psi);
            RegisterEngineAliases(group, mode, psi);
            status = "Installing " + ModeName(mode) + " engine setup";
            Logger.LogInfo(status + " for group " + group.GroupName);
        }

        private static bool GroupContainsUniversalMount(NewGroupItem group)
        {
            if (group == null || group.ItemList == null) return false;
            for (int i = 0; i < group.ItemList.Count; i++)
            {
                NewInventoryItem item = group.ItemList[i];
                if (item == null) continue;
                if (IsUniversalMountId(item.ID) || IsUniversalMountId(GetNormalId(item))) return true;
            }
            return false;
        }

        private static string FindUniversalMountKitId(NewGroupItem group)
        {
            if (group == null || group.ItemList == null) return String.Empty;
            for (int i = 0; i < group.ItemList.Count; i++)
            {
                NewInventoryItem item = group.ItemList[i];
                if (item == null) continue;
                string normalId = GetNormalId(item);
                if (!IsUniversalMountId(item.ID) && !IsUniversalMountId(normalId)) continue;
                if (IsInductionPartId(item.ID)) return item.ID;
                if (IsInductionPartId(normalId)) return normalId;
            }
            return String.Empty;
        }

        private static string FindInductionKitId(NewGroupItem group)
        {
            if (group == null || group.ItemList == null) return String.Empty;
            for (int i = 0; i < group.ItemList.Count; i++)
            {
                NewInventoryItem item = group.ItemList[i];
                if (item == null) continue;
                if (IsInductionPartId(item.ID)) return item.ID;
                string normalId = GetNormalId(item);
                if (IsInductionPartId(normalId)) return normalId;
            }
            return String.Empty;
        }

        private void EnsureMountForSameEngineTransfer(NewGroupItem group)
        {
            if (!pendingHasUniversalMount || pendingSwapObserved || pendingInstallLoader == null || group == null) return;
            try
            {
                GameObject engine = pendingInstallLoader.GetEngine();
                if (engine == null || !String.Equals(engine.name, group.GroupName, StringComparison.Ordinal)) return;
                PartScript mount = EnsureUniversalMount(engine, group.GroupName);
                string kitId = FindUniversalMountKitId(group);
                if (!IsInductionPartId(kitId)) kitId = KitIdForMode(pendingInstallMode);
                if (mount != null && IsInductionPartId(kitId))
                {
                    ConfigureMountedInductionPart(mount, kitId);
                    PrepareUniversalMountForInstalledKit(engine, mount);
                }
                Logger.LogInfo("Prepared the " + (IsInductionPartId(kitId) ? kitId : "universal mount")
                    + " before inserting the existing " + engine.name + " engine.");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not prepare the universal mount for the existing engine; vanilla installation will continue: " + exception.Message);
            }
        }

        private void EnsureMountForEngineSwap(CarLoader loader)
        {
            if (!pendingSwapObserved || !pendingHasUniversalMount || pendingInstallGroup == null
                || loader == null || loader != pendingInstallLoader) return;
            try
            {
                GameObject engine = loader.GetEngine();
                if (engine == null || !String.Equals(engine.name, pendingInstallGroupName, StringComparison.Ordinal)) return;
                PartScript mount = EnsureUniversalMount(engine, pendingInstallGroupName);
                string kitId = FindUniversalMountKitId(pendingInstallGroup);
                if (!IsInductionPartId(kitId)) kitId = KitIdForMode(pendingInstallMode);
                if (mount != null && IsInductionPartId(kitId))
                {
                    ConfigureMountedInductionPart(mount, kitId);
                    PrepareUniversalMountForInstalledKit(engine, mount);
                    Logger.LogInfo("Restored " + kitId + " on the transferred " + engine.name + " engine.");
                }
                Logger.LogInfo("Prepared the universal mount before transferring the replacement " + engine.name + " engine.");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not prepare the universal mount for the replacement engine; vanilla installation will continue: " + exception.Message);
            }
        }

        private bool PendingInstallMatches(NewGroupItem group)
        {
            return group != null
                && (System.Object.ReferenceEquals(group, pendingInstallGroup)
                    || String.Equals(group.GroupName, pendingInstallGroupName, StringComparison.Ordinal));
        }

        private void MarkPendingEngineSwap(NewGroupItem group)
        {
            if (PendingInstallMatches(group)) pendingSwapObserved = true;
        }

        private IEnumerator TrackActionInsertRoutine(IEnumerator routine, NewGroupItem group)
        {
            if (routine == null) return null;
            return new InstallTrackingEnumerator(routine, this, group, null, false);
        }

        private IEnumerator TrackEngineSwapRoutine(IEnumerator routine, CarLoader loader, NewGroupItem group)
        {
            if (routine == null) return null;
            return new InstallTrackingEnumerator(routine, this, group, loader, true);
        }

        private void CompleteActionInsert(NewGroupItem group)
        {
            if (!PendingInstallMatches(group) || pendingSwapObserved) return;
            CompleteEngineInstall(pendingInstallLoader, group);
        }

        private void CompleteEngineInstall(CarLoader loader, NewGroupItem group)
        {
            if (!PendingInstallMatches(group)) return;
            if (loader == null) loader = pendingInstallLoader;
            if (loader == null)
            {
                AbortPendingInstall(group, "Engine install target could not be resolved; settings remain with the engine group");
                return;
            }

            GameObject installedEngine = null;
            try
            {
                if (loader != null) installedEngine = loader.GetEngine();
            }
            catch { }
            if (installedEngine == null || !String.Equals(installedEngine.name, group.GroupName, StringComparison.Ordinal))
            {
                AbortPendingInstall(group, "Engine setup transfer did not complete; settings remain with the engine group");
                return;
            }
            RecordInstalledCar(loader, group);
        }

        private IEnumerator RecoverPendingEngineInstallAfterSetEngine(CarLoader loader)
        {
            NewGroupItem group = pendingInstallGroup;
            if (loader == null || group == null || !pendingHasUniversalMount) yield break;

            // The engine crane can begin its transfer before the connected loader is
            // exposed by ToolsMoveManager. Resolve it again from the exact crane, then
            // wait for CMS to finish assigning the transferred engine. This closes the
            // gap where the stand contains the kit but the in-car engine does not.
            if (pendingInstallLoader == null)
            {
                try
                {
                    ToolsMoveManager manager = ToolsMoveManager.Get();
                    if (manager != null)
                        pendingInstallLoader = manager.GetConnectedCarLoader(IOSpecialType.EngineCrane);
                }
                catch { }
            }
            if (!System.Object.ReferenceEquals(loader, pendingInstallLoader)) yield break;

            for (int frame = 0; frame < 120; frame++)
            {
                if (!PendingInstallMatches(group) || !System.Object.ReferenceEquals(loader, pendingInstallLoader))
                    yield break;

                GameObject engine = null;
                try { engine = loader.GetEngine(); }
                catch { }
                if (engine != null && String.Equals(engine.name, group.GroupName, StringComparison.Ordinal))
                {
                    Logger.LogInfo("Confirmed transferred engine " + engine.name
                        + " on its recorded car loader; completing induction-kit restoration.");
                    CompleteEngineInstall(loader, group);
                    yield break;
                }
                yield return null;
            }

            if (PendingInstallMatches(group))
                AbortPendingInstall(group, "Engine transfer did not expose the expected engine on its recorded car loader; induction setup was not attached");
        }

        private void AbortPendingInstall(NewGroupItem group, string reason)
        {
            if (!PendingInstallMatches(group)) return;
            pendingInstallGroup = null;
            pendingInstallGroupName = string.Empty;
            pendingInstallLoader = null;
            pendingSwapObserved = false;
            pendingHasUniversalMount = false;
            status = reason;
            Logger.LogWarning(status);
        }

        private void RecordInstalledCar(CarLoader loader, NewGroupItem group)
        {
            if (loader == null || group == null) return;
            if (!PendingInstallMatches(group)) return;

            string carKey = BuildCarIdentityKey(loader);
            if (!String.IsNullOrEmpty(carKey))
            {
                SaveCarSettings(carKey, pendingInstallMode, pendingInstallPsi);
                string storedKit = FindInductionKitId(group);
                if (!IsInductionPartId(storedKit)) storedKit = KitIdForMode(pendingInstallMode);
                if (IsInductionPartId(storedKit))
                    PlayerPrefs.SetString(PrefKey(InstalledKitModePrefix + carKey), storedKit);
                RegisterEngineAliases(group, pendingInstallMode, pendingInstallPsi);
                selectedMode = pendingInstallMode;
                selectedBoostPsi = pendingInstallPsi;
                activeCarKey = carKey;
                PlayerPrefs.Save();
            }
            // Visual reattachment is safe after the verified transfer even if the
            // car's persistent plate fields are not populated yet. Only persistence
            // above is conditional on having a durable per-car identity.
            RestoreTransferredInductionKit(loader, group, carKey);
            if (!String.IsNullOrEmpty(carKey))
            {
                try { StartCoroutine(ReconcileTransferredInductionKit(loader, group, carKey)); }
                catch (Exception exception)
                {
                    Logger.LogWarning("Could not schedule the brief post-transfer induction check: " + exception.Message);
                }
            }
            UpdateEffectiveSettings();
            status = String.IsNullOrEmpty(carKey)
                ? ModeName(pendingInstallMode) + " setup restored on transferred engine; car identity unavailable"
                : ModeName(pendingInstallMode) + " setup linked to car " + carKey;
            Logger.LogInfo(status);
            pendingInstallGroup = null;
            pendingInstallGroupName = string.Empty;
            pendingInstallLoader = null;
            pendingSwapObserved = false;
            pendingHasUniversalMount = false;
        }

        private void RestoreTransferredInductionKit(CarLoader loader, NewGroupItem group, string carKey)
        {
            if (loader == null || group == null) return;
            try
            {
                GameObject engine = loader.GetEngine();
                if (engine == null || !String.Equals(engine.name, group.GroupName, StringComparison.Ordinal)) return;

                string kitId = FindInductionKitId(group);
                if (!IsInductionPartId(kitId) && !String.IsNullOrEmpty(carKey))
                    kitId = PlayerPrefs.GetString(PrefKey(InstalledKitModePrefix + carKey), String.Empty);
                if (!IsInductionPartId(kitId)) kitId = KitIdForMode(pendingInstallMode);

                PartScript mount = FindMountedInductionPart(engine, kitId);
                if (!IsInductionPartId(kitId) && mount != null && IsInductionPartId(mount.GetTunedID()))
                    kitId = mount.GetTunedID();
                if (!IsInductionPartId(kitId))
                {
                    return;
                }
                if (mount == null)
                {
                    mount = EnsureUniversalMount(engine, carKey);
                    if (mount == null)
                    {
                        Logger.LogWarning("The transferred engine " + engine.name + " could not create its universal induction mount.");
                        return;
                    }
                }

                ConfigureMountedInductionPart(mount, kitId);
                PrepareUniversalMountForInstalledKit(engine, mount);
                PlayerPrefs.SetString(PrefKey(InstalledKitModePrefix + carKey), kitId);
                PlayerPrefs.Save();
                Logger.LogInfo("Restored the " + kitId + " visual and mount on car " + carKey + " after engine transfer.");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("The engine transfer completed, but its induction kit visual could not be restored: " + exception.Message);
            }
        }

        private IEnumerator ReconcileTransferredInductionKit(CarLoader loader, NewGroupItem group, string expectedCarKey)
        {
            // CMS can replace the engine GameObject again after the crane coroutine
            // reports completion. The first mount restore may then belong to a
            // temporary engine instance. Recheck briefly on this exact loader and
            // reattach only while its durable car identity still matches.
            for (int frame = 0; frame < 120; frame += 6)
            {
                for (int waitFrame = 0; waitFrame < 6; waitFrame++) yield return null;
                if (loader == null || group == null) yield break;

                string currentCarKey = BuildCarIdentityKey(loader);
                if (String.IsNullOrEmpty(currentCarKey)
                    || !String.Equals(currentCarKey, expectedCarKey, StringComparison.Ordinal))
                    yield break;

                GameObject engine = null;
                try { engine = loader.GetEngine(); }
                catch { }
                if (engine == null || !String.Equals(engine.name, group.GroupName, StringComparison.Ordinal))
                    continue;

                string kitId = FindInductionKitId(group);
                if (!IsInductionPartId(kitId))
                    kitId = PlayerPrefs.GetString(PrefKey(InstalledKitModePrefix + expectedCarKey), String.Empty);
                if (!IsInductionPartId(kitId)) yield break;

                PartScript mount = FindMountedInductionPart(engine, kitId);
                Transform visual = mount == null ? null : mount.transform.Find(InstalledInductionVisualName);
                bool attachedToCurrentEngine = mount != null
                    && mount.transform.IsChildOf(engine.transform)
                    && mount.gameObject.activeInHierarchy
                    && visual != null
                    && visual.gameObject.activeInHierarchy;
                if (!attachedToCurrentEngine)
                {
                    RestoreTransferredInductionKit(loader, group, expectedCarKey);
                    Logger.LogInfo("Reconciled the induction mount against the final engine instance on car "
                        + expectedCarKey + ".");
                }

                // Continue for a short stabilization window in case another CMS
                // engine-object replacement occurs immediately after this frame.
            }
            Logger.LogInfo("Post-transfer induction check finished for car " + expectedCarKey + ".");
        }

        private IEnumerator RestoreInstalledKitAfterCarLoad(CarLoader loader)
        {
            yield return new WaitForEndOfFrame();
            if (loader == null) yield break;
            try
            {
                GameObject engine = loader.GetEngine();
                if (engine == null) yield break;
                string carKey = BuildCarIdentityKey(loader);
                // A transferred induction kit is represented by a runtime mount and
                // can be absent from the vanilla part list after CMS reloads the car.
                // Restore from the durable model/plate key, never from Unity's reused
                // CarLoader object name. If no stable identity exists, only a kit
                // already present on the actual engine is eligible for restoration.
                InductionMode fittedMode;
                string fittedKitId;
                bool hasMountedCustomKit = TryDetectMountedInduction(loader, out fittedMode, out fittedKitId)
                    && IsInductionPartId(fittedKitId);
                string kitId = !String.IsNullOrEmpty(carKey)
                    ? PlayerPrefs.GetString(PrefKey(InstalledKitModePrefix + carKey), String.Empty)
                    : String.Empty;
                if (!IsInductionPartId(kitId) && hasMountedCustomKit) kitId = fittedKitId;
                if (!IsInductionPartId(kitId)) yield break;
                PartScript mount = FindMountedInductionPart(engine, kitId);
                if (!IsInductionPartId(kitId) && mount != null)
                {
                    kitId = IsInductionPartId(mount.GetTunedID()) ? mount.GetTunedID() : mount.GetIDWithTuned();
                }
                if (!IsInductionPartId(kitId)) yield break;

                // A synthetic mount is not part of a vanilla car save. Recreate it
                // from the profile-scoped kit record when the engine is loaded again.
                if (mount == null) mount = EnsureUniversalMount(engine, carKey);
                if (mount == null) yield break;

                ConfigureMountedInductionPart(mount, kitId);
                PrepareUniversalMountForInstalledKit(engine, mount);
                if (!String.IsNullOrEmpty(carKey))
                    PlayerPrefs.SetString(PrefKey(InstalledKitModePrefix + carKey), kitId);
                PlayerPrefs.Save();
                Logger.LogInfo("Restored the saved " + kitId + " visual on loaded car " + carKey + ".");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not restore a saved induction kit after loading a car: " + exception.Message);
            }
        }

        private static PartScript FindMountedInductionPart(GameObject engine, string kitId)
        {
            if (engine == null) return null;
            PartScript fallbackMount = null;
            PartScript[] parts = engine.GetComponentsInChildren<PartScript>(true);
            for (int i = 0; i < parts.Length; i++)
            {
                PartScript candidate = parts[i];
                if (candidate == null || candidate.IsUnmounted()) continue;
                bool universalMount = IsUniversalMountId(candidate.GetID()) || IsUniversalMountId(candidate.GetTunedID());
                string tunedId = candidate.GetTunedID();
                string combinedId = candidate.GetIDWithTuned();
                if (IsInductionPartId(tunedId) && (!IsInductionPartId(kitId)
                    || String.Equals(tunedId, kitId, StringComparison.OrdinalIgnoreCase))) return candidate;
                if (IsInductionPartId(combinedId) && (!IsInductionPartId(kitId)
                    || String.Equals(combinedId, kitId, StringComparison.OrdinalIgnoreCase))) return candidate;
                if (universalMount && fallbackMount == null) fallbackMount = candidate;
            }
            return fallbackMount;
        }

        private void PrepareUniversalMountForInstalledKit(GameObject engine, PartScript mount)
        {
            if (engine == null || mount == null || !IsUniversalMountId(mount.GetID())) return;

            // CMS disables a part's collider and marks it unmounted while it is being
            // previewed for removal. A saved kit means this runtime-only anchor should
            // be mounted again when the engine is transferred or loaded.
            if (!mount.gameObject.activeSelf) mount.gameObject.SetActive(true);
            SetPartField(mount, "unmounted", false);
            SetPartField(mount, "canBeUnmount", true);
            SetPartField(mount, "canUnmountSingle", true);
            SetPartField(mount, "forInventory", false);

            // Re-evaluate after transfer/load, when the engine carries its full
            // pulley and intake assembly. Pre-transfer bounds can be incomplete.
            PositionUniversalMountNearDrivePulley(engine, mount.transform);

            string sourceName;
            mount.gameObject.layer = FindSelectablePartLayer(engine, out sourceName);
            Collider[] colliders = mount.GetComponents<Collider>();
            for (int i = 0; i < colliders.Length; i++)
                if (colliders[i] != null) colliders[i].enabled = true;

            Transform visual = mount.transform.Find(InstalledInductionVisualName);
            if (visual != null)
            {
                if (!visual.gameObject.activeSelf) visual.gameObject.SetActive(true);
                Renderer[] renderers = visual.GetComponentsInChildren<Renderer>(true);
                int enabledRenderers = 0;
                for (int i = 0; i < renderers.Length; i++)
                {
                    if (renderers[i] == null) continue;
                    if (!renderers[i].gameObject.activeSelf) renderers[i].gameObject.SetActive(true);
                    renderers[i].enabled = true;
                    if (renderers[i].enabled && renderers[i].gameObject.activeInHierarchy) enabledRenderers++;
                }
                EnsureProchargerMountFasteners(mount, visual);
                AddUnmountVisibilityTargets(mount, visual);
                UpdateMountedInductionSelectionCollider(mount, visual);
                Logger.LogInfo("Verified induction visual visibility after transfer: mountActive="
                    + mount.gameObject.activeInHierarchy + ", visualActive=" + visual.gameObject.activeInHierarchy
                    + ", renderers=" + enabledRenderers + "/" + renderers.Length + ", engine=" + engine.name + ".");
            }
            else
            {
                Logger.LogWarning("The transferred universal mount has no " + InstalledInductionVisualName
                    + " child visual on " + engine.name + ".");
            }
            Logger.LogInfo("Reactivated the saved induction mount on " + engine.name + " at selectable layer "
                + mount.gameObject.layer + " (source part " + sourceName + ").");
        }
        private void UpdateEffectiveSettings()
        {
            if (standOccupied)
            {
                activeHasNativeInduction = false;
                activeHasCustomInduction = false;
                activeHasHighBoostProcharger = false;
                activeNativePartId = string.Empty;
                activeMode = InductionMode.Off;
                activeBoostPsi = selectedBoostPsi;
            }
            else
            {
                string previousNativePartId = activeNativePartId;
                VPVehicleController linkedController;
                CarLoader loader = FindActiveCarLoader(out linkedController);
                if (linkedController != null) activeController = linkedController;
                InductionMode detectedMode;
                string detectedPartId;
                activeHasNativeInduction = TryDetectMountedInduction(loader, out detectedMode, out detectedPartId);
                activeHasCustomInduction = activeHasNativeInduction && IsInductionPartId(detectedPartId);
                activeNativePartId = activeHasCustomInduction ? detectedPartId : string.Empty;
                activeHasHighBoostProcharger = activeHasCustomInduction && IsHighBoostProchargerPartId(detectedPartId);

                // Only an installed P-1X part activates boost. Stock components and saved
                // UI preferences are not evidence of fitted hardware, so they can never
                // alter another vehicle's dyno trace or factory power.
                if (activeHasCustomInduction)
                {
                    activeMode = detectedMode;
                    float storedPsi = !String.IsNullOrEmpty(activeCarKey)
                        ? PlayerPrefs.GetFloat(PrefKey(CarPsiPrefix + activeCarKey), selectedBoostPsi)
                        : selectedBoostPsi;
                    activeBoostPsi = ProchargerMath.NormalizeBoostPsi(storedPsi, GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger), 8.0f);
                    selectedMode = activeMode;
                    if (!String.Equals(previousNativePartId, detectedPartId, StringComparison.Ordinal))
                        status = "Using installed P-1X kit: " + detectedPartId;
                }
                else
                {
                    activeMode = InductionMode.Off;
                    activeBoostPsi = selectedBoostPsi;
                }
            }
        }
        private InductionMode ModeForActiveCar()
        {
            return activeMode;
        }

        private float PsiForActiveCar()
        {
            return activeBoostPsi;
        }

        internal string GetCurrentUniversalMountDisplayName()
        {
            InductionMode mode = standOccupied ? selectedMode : activeMode;
            if (mode == InductionMode.Procharger)
                return (standOccupied ? standHasHighBoostProcharger : activeHasHighBoostProcharger)
                    ? "ProCharger P-1X High-Boost" : "ProCharger P-1X Centrifugal Supercharger";
            return "Universal Induction Mount";
        }

        private InductionMode ModeForVisual()
        {
            return standOccupied ? selectedMode : activeMode;
        }

        private void RefreshStandPartDetection(GameScript game)
        {
            standHasNativeInduction = false;
            standHasHighBoostProcharger = false;
            standNativeMode = InductionMode.Off;
            if (game == null) return;

            try
            {
                List<GameObject> objects = game.GetObjectsOnEngineStand();
                if (objects == null) return;
                for (int i = 0; i < objects.Count; i++)
                {
                    InductionMode mode;
                    string partId;
                    if (!TryDetectMountedInduction(objects[i], out mode, out partId)) continue;
                    standHasNativeInduction = true;
                    standNativeMode = mode;
                    standHasHighBoostProcharger = mode == InductionMode.Procharger
                        && IsHighBoostProchargerPartId(partId);
                    return;
                }
            }
            catch (Exception exception)
            {
                Logger.LogDebug("Could not inspect engine-stand induction parts: " + exception.Message);
            }
        }

        private static bool TryDetectMountedInduction(CarLoader loader, out InductionMode mode, out string partId)
        {
            mode = InductionMode.Off;
            partId = string.Empty;
            if (loader == null) return false;
            try
            {
                GameObject engineObject = loader.GetEngine();
                if (TryDetectMountedInduction(engineObject, out mode, out partId)) return true;
                GameObject rootObject = loader.GetRoot();
                if (rootObject != engineObject && TryDetectMountedInduction(rootObject, out mode, out partId)) return true;
            }
            catch { }
            mode = InductionMode.Off;
            partId = string.Empty;
            return false;
        }

        private static bool TryDetectMountedInduction(GameObject root, out InductionMode mode, out string partId)
        {
            mode = InductionMode.Off;
            partId = string.Empty;
            if (root == null) return false;
            PartScript[] parts = root.GetComponentsInChildren<PartScript>(true);
            // Prefer a fitted CMS kit to a factory turbo/supercharger that may still
            // be mounted elsewhere on the same engine. Otherwise the stock part can
            // mask the custom kit and leave the dyno using the wrong boost mode.
            for (int pass = 0; pass < 2; pass++)
            {
                for (int i = 0; i < parts.Length; i++)
                {
                    PartScript part = parts[i];
                    if (part == null || part.IsUnmounted()) continue;
                    string candidateId = part.GetIDWithTuned();
                    InductionMode candidate = ClassifyNativePartId(candidateId);
                    if (candidate == InductionMode.Off)
                    {
                        candidateId = part.GetID();
                        candidate = ClassifyNativePartId(candidateId);
                    }
                    if (candidate == InductionMode.Off) continue;
                    bool customKit = IsInductionPartId(candidateId);
                    if ((pass == 0) != customKit) continue;
                    mode = candidate;
                    partId = candidateId;
                    return true;
                }
            }
            return false;
        }

        private static InductionMode ClassifyNativePartId(string partId)
        {
            if (String.IsNullOrEmpty(partId)) return InductionMode.Off;
            return ModeForInductionPartId(partId);
        }
        private float CalculateInductionTorqueDelta(VehiclePhysics.Engine engine, float rpm, float throttle, InductionMode mode, float spool)
        {
            if (engine == null || engine.settings == null || mode != InductionMode.Procharger) return 0.0f;
            float sampleRpm = ProchargerMath.IsFinite(rpm) ? Mathf.Max(0.0f, rpm) : 0.0f;
            float sampleThrottle = ProchargerMath.NormalizeBoostPsi(throttle, 1.0f, 0.0f);
            float boostTarget = ProchargerMath.NormalizeBoostPsi(PsiForActiveCar(),
                GetMaximumBoostPsi(mode, activeHasHighBoostProcharger), 8.0f);
            float boostPressure = CalculateP1XBoostPsi(engine.settings, sampleRpm, boostTarget);
            ChargeAirState charge = ChargeAirModel.Calculate(boostPressure, 0.70f, 0.58f, 0.55f,
                ChargeAirModel.StandardAmbientTemperatureKelvin,
                ChargeAirModel.StandardAmbientPressurePsi);
            float chargeGain = Mathf.Clamp(charge.AirDensityRatio - 1.0f, 0.0f, 1.25f);
            float baseTorque = Mathf.Max(0.0f, engine.GetMaxPowerTorque(sampleRpm));
            float throttleTorque = baseTorque * sampleThrottle;
            float pressureRatio = charge.ManifoldAbsolutePressurePsi / ChargeAirModel.StandardAmbientPressurePsi;
            float addedTorque = throttleTorque * chargeGain * 0.93f;
            float estimatedDriveLoss = throttleTorque * Mathf.Max(0.0f, pressureRatio - 1.0f) * 0.035f;
            return ClampP1XTorqueDelta(throttleTorque, addedTorque - estimatedDriveLoss, sampleRpm);
        }

        private static float ClampP1XTorqueDelta(float baseTorque, float torqueDelta, float rpm)
        {
            if (torqueDelta <= 0.0f || rpm <= 1.0f) return torqueDelta;
            const float horsepowerPerNewtonMeterAtRpm = 1.0f / 7127.0f;
            float maximumRatedTorque = P1XMaxSuperchargedHp / (rpm * horsepowerPerNewtonMeterAtRpm);
            float availableTorque = Mathf.Max(0.0f, maximumRatedTorque - Mathf.Max(0.0f, baseTorque));
            return Mathf.Min(torqueDelta, availableTorque);
        }

        private static float CalculateBoostPressurePsi(InductionMode mode, VehiclePhysics.Engine.Settings engineSettings,
            float rpm, float spool, float targetPsi)
        {
            if (mode != InductionMode.Procharger) return 0.0f;
            return CalculateP1XBoostPsi(engineSettings, rpm, targetPsi);
        }

        private static float CalculateP1XImpellerRpm(VehiclePhysics.Engine.Settings engineSettings, float rpm, float targetPsi)
        {
            if (engineSettings == null || !ProchargerMath.IsFinite(rpm) || targetPsi <= 0.0f) return 0.0f;
            float peakRpm = ProchargerMath.IsFinite(engineSettings.peakRpm)
                ? Mathf.Max(1.0f, engineSettings.peakRpm) : 1.0f;
            float peakBoost = ProchargerMath.NormalizeBoostPsi(targetPsi, P1XMaxBoostPsi, 0.0f);
            float impellerRpmAtPeak = P1XMaxImpellerRpm * Mathf.Sqrt(peakBoost / P1XMaxBoostPsi);
            float externalPulleyRatio = impellerRpmAtPeak / (peakRpm * P1XInternalStepUpRatio);
            return Mathf.Max(0.0f, rpm) * externalPulleyRatio * P1XInternalStepUpRatio;
        }

        private static float CalculateP1XBoostPsi(VehiclePhysics.Engine.Settings engineSettings, float rpm, float targetPsi)
        {
            float impellerRpm = CalculateP1XImpellerRpm(engineSettings, rpm, targetPsi);
            float speedRatio = ProchargerMath.NormalizeBoostPsi(impellerRpm / P1XMaxImpellerRpm, 1.0f, 0.0f);

            // Centrifugal compressor pressure rise is approximated from impeller speed squared.
            // The published 32 psi and 65,000 rpm ratings bound this simplified curve; the
            // manufacturer does not publish a complete operating map for this model.
            return P1XMaxBoostPsi * speedRatio * speedRatio;
        }

        private static float CalculateManifoldGaugePsi(float compressorBoostPsi, float throttle)
        {
            float throttleOpening = ProchargerMath.NormalizeBoostPsi(throttle, 1.0f, 0.0f);
            float closedThrottleVacuum = MaxManifoldVacuumPsi * Mathf.Pow(1.0f - throttleOpening, 1.8f);
            float boostAtManifold = ProchargerMath.NormalizeBoostPsi(compressorBoostPsi, P1XMaxBoostPsi, 0.0f) * Mathf.Pow(throttleOpening, 0.9f);
            return boostAtManifold - closedThrottleVacuum;
        }

        private void ApplyTorque(VehiclePhysics.Engine engine, float rpm, float throttle, ref float result)
        {
            // VehiclePhysics.Engine is a plain data object, not a scene component, so
            // the only verifiable scope available to the torque hook is the dyno chart
            // sampling window. Never alter live engines or background car previews.
            if (!dynoTorqueSampling || !activeHasCustomInduction || engine == null || engine.settings == null) return;
            float sampleRpm = ProchargerMath.IsFinite(rpm) ? Mathf.Max(0.0f, rpm) : 0.0f;
            float sampleThrottle = ProchargerMath.NormalizeBoostPsi(throttle, 1.0f, 0.0f);
            lastEngine = engine;
            lastRpm = sampleRpm;
            lastThrottle = sampleThrottle;

            InductionMode mode = ModeForActiveCar();
            if (mode != InductionMode.Procharger) return;
            if (dynoTorqueSampling && !dynoPowerDiagnosticLogged)
            {
                LogDynoDiagnostic("Dyno induction sample: car=" + activeCarKey + ", mode=" + ModeName(mode)
                    + ", target=" + PsiForActiveCar().ToString("F1") + " psi, engineType=" + engine.GetType().Name
                    + ", rpm=" + sampleRpm.ToString("F0") + ", throttle=" + sampleThrottle.ToString("F2"));
                dynoPowerDiagnosticLogged = true;
            }
            if (mode == InductionMode.Off) return;

            float spool = dynoTorqueSampling
                ? CalculateSpoolForCurrentEngine(mode, engine.settings, sampleRpm, sampleThrottle)
                : currentSpool;
            float boostPressure = CalculateBoostPressurePsi(mode, engine.settings, sampleRpm, spool, PsiForActiveCar());
            result += CalculateInductionTorqueDelta(engine, sampleRpm, sampleThrottle, mode, spool);

            liveBoostPsi = CalculateManifoldGaugePsi(boostPressure, sampleThrottle);
            lastNetTorque = result;
        }

        private void ApplyPower(VehiclePhysics.Engine engine, float rpm, ref float result)
        {
            if (!dynoTorqueSampling || !activeHasCustomInduction || engine == null || engine.settings == null) return;
            InductionMode mode = ModeForActiveCar();
            if (mode != InductionMode.Procharger) return;
            if (dynoTorqueSampling && !dynoPowerDiagnosticLogged)
            {
                LogDynoDiagnostic("Dyno power sample: car=" + activeCarKey + ", mode=" + ModeName(mode)
                    + ", target=" + PsiForActiveCar().ToString("F1") + " psi, engineType=" + engine.GetType().Name
                    + ", rpm=" + rpm.ToString("F0"));
                dynoPowerDiagnosticLogged = true;
            }
            if (mode == InductionMode.Off) return;

            float sampleRpm = ProchargerMath.IsFinite(rpm) ? Mathf.Max(0.0f, rpm) : 0.0f;
            float spool = CalculateSpoolForCurrentEngine(mode, engine.settings, sampleRpm, 1.0f);
            float torqueDelta = CalculateInductionTorqueDelta(engine, sampleRpm, 1.0f, mode, spool);
            const float radiansPerSecondPerRpm = 0.104719755f;
            result += torqueDelta * sampleRpm * radiansPerSecondPerRpm * 0.001f;
        }

        private void ApplyEngineSpecsBoost(VehiclePhysics.Engine engine, ref VehiclePhysics.Engine.EngineSpecs specs)
        {
            if (!dynoMeasuredSpecsContext || standOccupied || engine == null || engine.settings == null) return;

            InductionMode mode = ModeForActiveCar();
            if (mode != InductionMode.Procharger) return;
            if (mode == InductionMode.Off) return;

            float idleRpm = Mathf.Max(0.0f, specs.idleRpm);
            float torquePeakRpm = Mathf.Max(idleRpm, specs.peakRpm);
            float powerRpm = Mathf.Max(idleRpm, specs.maxPowerRpm);
            float torqueAtIdle = CalculateInductionTorqueDelta(engine, idleRpm, 1.0f, mode,
                CalculateSpoolForCurrentEngine(mode, engine.settings, idleRpm, 1.0f));
            float torqueAtPeak = CalculateInductionTorqueDelta(engine, torquePeakRpm, 1.0f, mode,
                CalculateSpoolForCurrentEngine(mode, engine.settings, torquePeakRpm, 1.0f));
            float torqueAtPowerPeak = CalculateInductionTorqueDelta(engine, powerRpm, 1.0f, mode,
                CalculateSpoolForCurrentEngine(mode, engine.settings, powerRpm, 1.0f));

            if (torqueAtIdle <= 0.0f && torqueAtPeak <= 0.0f && torqueAtPowerPeak <= 0.0f) return;

            specs.maxTorqueAtIdle += torqueAtIdle;
            specs.maxTorqueAtPeak += torqueAtPeak;
            float horsepowerGain = torqueAtPowerPeak * powerRpm / 7127.0f;
            specs.maxPowerInHp += horsepowerGain;
            specs.maxPowerInKw += horsepowerGain / 1.34102209f;

            if (!dynoSpecsDiagnosticLogged)
            {
                LogDynoDiagnostic("Dyno engine specs boosted: car=" + activeCarKey + ", mode=" + ModeName(mode)
                    + ", target=" + PsiForActiveCar().ToString("F1") + " psi, peak torque +"
                    + torqueAtPeak.ToString("F1") + " Nm, peak power +" + horsepowerGain.ToString("F1")
                    + " hp at " + powerRpm.ToString("F0") + " rpm; output=" + specs.maxPowerInHp.ToString("F1") + " hp");
                dynoSpecsDiagnosticLogged = true;
            }
        }

        private void LogDynoDiagnostic(string message)
        {
            try { if (Logger != null) Logger.LogInfo(message); }
            catch { }
        }

        private static float CalculateSpoolForSample(InductionMode mode, VehiclePhysics.Engine.Settings engineSettings, float rpm, float throttle)
        {
            if (mode != InductionMode.Procharger || engineSettings == null) return 0.0f;
            float idle = engineSettings.idleRpm;
            float peak = ProchargerMath.IsFinite(engineSettings.peakRpm)
                ? Mathf.Max(idle + 1.0f, engineSettings.peakRpm) : idle + 1.0f;
            float mechanicalSpeedFraction = Mathf.Clamp01(Mathf.Max(0.0f, rpm) / peak);
            float load = Mathf.Pow(Mathf.Clamp01(throttle), 0.72f);
            return mechanicalSpeedFraction * mechanicalSpeedFraction * load;
        }

        private float CalculateSpoolForCurrentEngine(InductionMode mode,
            VehiclePhysics.Engine.Settings engineSettings, float rpm, float throttle)
        {
            return CalculateSpoolForSample(mode, engineSettings, rpm, throttle);
        }







        private void AdvanceSpool(float deltaTime)
        {
            InductionMode mode = ModeForActiveCar();
            if (mode == InductionMode.Off || lastEngine == null || lastEngine.settings == null)
            {
                spoolTarget = 0.0f;
                currentSpool = Mathf.MoveTowards(currentSpool, 0.0f, Mathf.Max(0.0f, deltaTime) * 4.0f);
                liveBoostPsi = 0.0f;
                return;
            }

            spoolTarget = CalculateSpoolForCurrentEngine(mode, lastEngine.settings, lastRpm, lastThrottle);
            currentSpool = spoolTarget;

            float boostPressure = CalculateBoostPressurePsi(mode, lastEngine.settings, lastRpm, currentSpool, PsiForActiveCar());
            liveBoostPsi = CalculateManifoldGaugePsi(boostPressure, lastThrottle);
        }

        private void EnsureVisual()
        {
            InductionMode mode = ModeForVisual();
            if ((!standOccupied && activeHasNativeInduction)
                || (standOccupied && standHasNativeInduction && standNativeMode == mode))
            {
                RemoveVisual();
                return;
            }
            if (mode == InductionMode.Off)
            {
                RemoveVisual();
                return;
            }
            if (mode != InductionMode.Procharger)
            {
                // Legacy mode values remain readable for save compatibility, but no
                // non-P-1X visual or behavior is shipped in patch 0.9.0.
                RemoveVisual();
                status = "This saved induction mode is retired; select the P-1X setup to continue";
                return;
            }

            PartScript prochargerMount = null;
            Transform parent;
            if (standOccupied && mode == InductionMode.Procharger)
            {
                prochargerMount = FindStandProchargerMount();
                if (prochargerMount == null)
                {
                    // The P-1X can preview on any engine. Engines without a
                    // compatible stock attachment slot can still preview the kit on the engine body;
                    // a compatible CMS attachment point is only available on some engines.
                    parent = FindVisualParent();
                    status = "ProCharger mode preview; this engine has no factory turbo slot";
                }
                else if (IsInductionPartId(prochargerMount.GetTunedID())
                    && prochargerMount.transform.Find(InstalledInductionVisualName) != null)
                {
                    RemoveVisual();
                    status = ModeName(ModeForInductionPartId(prochargerMount.GetTunedID())) + " installed; select the existing part to interact";
                    return;
                }
                else
                {
                    parent = prochargerMount.transform;
                }
            }
            else
            {
                parent = FindVisualParent();
            }
            if (parent == null) return;
            if (visualRoot != null && visualRoot.transform.parent == parent && visualMode == mode) return;
            RemoveVisual();

            visualRoot = new GameObject("CMS18_ProCharger_P1X_Visual");
            visualRoot.transform.SetParent(parent, false);
            visualRoot.transform.localPosition = prochargerMount == null
                ? new Vector3(0.42f, 0.24f, 0.0f) : Vector3.zero;
            visualRoot.transform.localRotation = Quaternion.identity;
            visualRoot.transform.localScale = prochargerMount == null
                ? Vector3.one * 0.72f : Vector3.one;
            visualMode = mode;

            if (prochargerMount != null)
            {
                if (TryCreateStandProchargerPreview(prochargerMount))
                {
                    status = IsUniversalMountId(prochargerMount.GetID())
                        ? "P-1X preview aligned to the engine's belt-drive mount"
                        : "P-1X preview aligned to the factory induction slot";
                    return;
                }
                RemoveVisual();
                status = "Could not fit the P-1X preview to the induction mount";
                return;
            }

            if (TryCreateInductionModel(mode)) return;

            // Keep the empty, mode-tagged root so a missing mesh is not retried and
            // logged on every visual refresh. The user gets a clear status and the
            // plugin leaves the stock host geometry intact.
            status = "The P-1X model could not be loaded; check the mod log for the asset error";
            Logger.LogWarning(status);
        }

        private PartScript FindStandProchargerMount()
        {
            try
            {
                GameScript game = GameScript.Get();
                List<GameObject> objects = game == null ? null : game.GetObjectsOnEngineStand();
                if (objects == null) return null;
                PartScript nativeFallback = null;
                for (int i = 0; i < objects.Count; i++)
                {
                    if (objects[i] == null) continue;
                    PartScript[] parts = objects[i].GetComponentsInChildren<PartScript>(true);
                    for (int j = 0; j < parts.Length; j++)
                    {
                        PartScript part = parts[j];
                        if (part == null) continue;
                        if (IsUniversalMountId(part.GetID()) || IsUniversalMountId(part.GetTunedID())) return part;
                        if (nativeFallback == null && IsInductionMount(part)) nativeFallback = part;
                    }
                }
                if (nativeFallback != null) return nativeFallback;
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not locate a universal or factory induction mount on the engine stand: " + exception.Message);
            }
            return null;
        }

        private static bool IsInductionMount(PartScript part)
        {
            if (part == null) return false;
            return IsInductionMountId(part.GetID()) || IsInductionMountId(part.GetTunedID());
        }

        private static bool IsProchargerMountId(string id)
        {
            return IsInductionMountId(id);
        }

        private static bool IsInductionMountId(string id)
        {
            if (String.IsNullOrEmpty(id)) return false;
            string normalized = RemoveSlotSuffix(id);
            return IsUniversalMountId(normalized)
                || IsNativeInductionMountSlotId(normalized);
        }

        // CMS exposes these stock engine slots as usable mounting parents for the
        // universal P-1X bracket. They are mount anchors only; their native parts
        // never activate or receive forced-induction behavior from this plugin.
        private static bool IsNativeInductionMountSlotId(string id)
        {
            if (String.IsNullOrEmpty(id)) return false;
            string value = id.Trim().ToLowerInvariant();
            return value.Contains("turbo") || value.Contains("supercharger");
        }

        private static bool IsUniversalMountId(string id)
        {
            string normalized = id == null ? String.Empty : id.Trim();
            if (normalized.StartsWith("!", StringComparison.Ordinal)) normalized = normalized.Substring(1);
            normalized = RemoveSlotSuffix(normalized);
            return String.Equals(normalized, UniversalMountPartId, StringComparison.OrdinalIgnoreCase)
                || String.Equals(normalized, UniversalMountDisplayName, StringComparison.OrdinalIgnoreCase)
                || String.Equals(normalized, "Universal Induction Mount", StringComparison.OrdinalIgnoreCase)
                || String.Equals(normalized, "ProCharger Mount Bracket", StringComparison.OrdinalIgnoreCase);
        }

        private static string RemoveSlotSuffix(string id)
        {
            if (String.IsNullOrEmpty(id)) return String.Empty;
            string normalized = id.Trim();
            int slotSuffix = normalized.IndexOf('(');
            return slotSuffix >= 0 ? normalized.Substring(0, slotSuffix) : normalized;
        }

        internal static bool IsProchargerCompatibleSlot(string partId, string slotId)
        {
            if (IsUniversalMountId(partId)) return false;
            if (IsUniversalMountId(slotId) && IsInductionPartId(partId))
            {
                InductionMode requestedMode = ModeForInductionPartId(partId);
                TurboPrototypePlugin plugin = Instance;
                return requestedMode == InductionMode.Procharger
                    || plugin == null || !plugin.CurrentEngineHasCarburetor();
            }
            if (IsInductionPartId(partId) && IsCarburetorSlotId(slotId))
                return ModeForInductionPartId(partId) == InductionMode.Procharger;
            InductionMode partMode = ClassifyNativePartId(partId);
            InductionMode slotMode = ClassifyNativePartId(slotId);
            return partMode != InductionMode.Off
                && partMode != InductionMode.Procharger
                && partMode == slotMode;
        }

        private static bool IsCarburetorSlotId(string partId)
        {
            return IsCarburetorIdentifier(partId);
        }

        private static bool IsCarburetorIdentifier(string value)
        {
            if (String.IsNullOrEmpty(value)) return false;
            string id = RemoveSlotSuffix(value).Trim().ToLowerInvariant();
            return id.Contains("carb") || id.Contains("gaznik") || id.Contains("gaźnik");
        }

        private bool CurrentEngineHasCarburetor()
        {
            if (Time.unscaledTime < nextCarburetorProbe) return cachedCarburetedContext;
            nextCarburetorProbe = Time.unscaledTime + 0.5f;
            cachedCarburetedContext = DetectCarburetedEngine();
            return cachedCarburetedContext;
        }

        private bool DetectCarburetedEngine()
        {
            try
            {
                if (standOccupied)
                {
                    GameScript game = GameScript.Get();
                    List<GameObject> objects = game == null ? null : game.GetObjectsOnEngineStand();
                    if (objects != null)
                    {
                        for (int i = 0; i < objects.Count; i++)
                        {
                            GameObject item = objects[i];
                            if (item == null) continue;
                            PartScript[] parts = item.GetComponentsInChildren<PartScript>(true);
                            for (int j = 0; j < parts.Length; j++)
                            {
                                PartScript part = parts[j];
                                if (part != null && (IsCarburetorIdentifier(part.GetID())
                                    || IsCarburetorIdentifier(part.GetTunedID())
                                    || IsCarburetorIdentifier(part.gameObject.name))) return true;
                            }
                        }
                    }
                }
                else if (activeController != null)
                {
                    Transform engineRoot = FindEngineRootTransform(activeController.transform);
                    if (engineRoot != null)
                    {
                        PartScript[] parts = engineRoot.GetComponentsInChildren<PartScript>(true);
                        for (int i = 0; i < parts.Length; i++)
                        {
                            PartScript part = parts[i];
                            if (part != null && !part.IsUnmounted()
                                && (IsCarburetorIdentifier(part.GetID())
                                    || IsCarburetorIdentifier(part.GetTunedID())
                                    || IsCarburetorIdentifier(part.gameObject.name))) return true;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.LogDebug("Carburetor detection failed safely: " + exception.Message);
            }
            return false;
        }

        private bool TryCreateStandProchargerPreview(PartScript mount)
        {
            if (mount == null) return false;
            if (!inductionModelLoadAttempted.Contains(InductionMode.Procharger))
            {
                inductionModelLoadAttempted.Add(InductionMode.Procharger);
                BuildInductionModelAsset(InductionMode.Procharger, "CMS18_ProCharger_P1X_AddOn.obj", "P-1X Style ProCharger");
            }

            Mesh mesh;
            Material[] materials;
            if (!inductionModelMeshes.TryGetValue(InductionMode.Procharger, out mesh) || mesh == null
                || !inductionModelMaterials.TryGetValue(InductionMode.Procharger, out materials) || materials == null) return false;

            Renderer[] stockRenderers = mount.GetComponentsInChildren<Renderer>(true);
            Bounds localBounds;
            bool virtualMount = IsUniversalMountId(mount.GetID());
            if (virtualMount)
            {
                localBounds = new Bounds(Vector3.zero, new Vector3(0.28f, 0.24f, 0.24f));
            }
            else if (!TryGetLocalRendererBounds(stockRenderers, mount.transform, out localBounds))
            {
                return false;
            }

            Quaternion modelRotation = Quaternion.identity;
            Vector3 meshSize = mesh.bounds.size;
            Vector3 rotatedMeshSize = meshSize;
            float scaleX = localBounds.size.x / Mathf.Max(0.001f, rotatedMeshSize.x);
            float scaleY = localBounds.size.y / Mathf.Max(0.001f, rotatedMeshSize.y);
            float scaleZ = localBounds.size.z / Mathf.Max(0.001f, rotatedMeshSize.z);
            float scale = Mathf.Min(scaleX, Mathf.Min(scaleY, scaleZ)) * 0.92f;
            if (virtualMount) scale = ProchargerModelUnitScale;
            if (Single.IsNaN(scale) || Single.IsInfinity(scale) || scale <= 0.001f) return false;

            GameObject modelObject = new GameObject("CMS18 ProCharger P-1X Stand Preview");
            modelObject.transform.SetParent(visualRoot.transform, false);
            modelObject.layer = mount.gameObject.layer;
            modelObject.transform.localRotation = modelRotation;
            modelObject.transform.localScale = Vector3.one * scale;
            modelObject.transform.localPosition = localBounds.center - modelRotation * (mesh.bounds.center * scale);
            MeshFilter filter = modelObject.AddComponent<MeshFilter>();
            filter.sharedMesh = mesh;
            MeshRenderer renderer = modelObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterials = materials;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            ConfigureInductionRenderer(renderer);
            Transform engineRoot = FindEngineRootTransform(mount.transform);
            if (engineRoot != null && engineRoot.name.StartsWith("engine_", StringComparison.OrdinalIgnoreCase))
                AlignProchargerVisualToCrank(modelObject.transform, engineRoot);
            AddProchargerDriveVisuals(mount, modelObject.transform);

            Bounds selectableBounds;
            bool hasSelectableBounds = TryGetLocalRendererBounds(
                visualRoot.GetComponentsInChildren<Renderer>(true), mount.transform, out selectableBounds);
            if (!hasSelectableBounds || selectableBounds.size.sqrMagnitude < 0.000001f)
                selectableBounds = BoundsInRelativeSpace(mesh.bounds, modelObject.transform, mount.transform);
            if (selectableBounds.size.sqrMagnitude < 0.000001f) selectableBounds = localBounds;
            BoxCollider hitbox = mount.gameObject.AddComponent<BoxCollider>();
            hitbox.center = selectableBounds.center;
            hitbox.size = selectableBounds.size * 1.18f;
            hitbox.enabled = true;
            standPreviewHitboxes.Add(hitbox);

            int stateKey = mount.GetInstanceID();
            if (!standPreviewRendererStates.ContainsKey(stateKey))
            {
                List<ProchargerRendererState> states = new List<ProchargerRendererState>();
                for (int i = 0; i < stockRenderers.Length; i++)
                    if (stockRenderers[i] != null && stockRenderers[i].GetComponent<MountObject>() == null)
                        states.Add(new ProchargerRendererState(stockRenderers[i]));
                standPreviewRendererStates[stateKey] = states;
            }
            for (int i = 0; i < stockRenderers.Length; i++)
                if (stockRenderers[i] != null && stockRenderers[i].GetComponent<MountObject>() == null)
                    stockRenderers[i].enabled = false;
            return true;
        }

        private static Bounds BoundsInRelativeSpace(Bounds sourceBounds, Transform sourceTransform, Transform relativeTo)
        {
            if (sourceTransform == null || relativeTo == null) return new Bounds(Vector3.zero, Vector3.zero);
            bool initialized = false;
            Bounds result = new Bounds(Vector3.zero, Vector3.zero);
            for (int corner = 0; corner < 8; corner++)
            {
                Vector3 sourcePoint = new Vector3(
                    (corner & 1) == 0 ? sourceBounds.min.x : sourceBounds.max.x,
                    (corner & 2) == 0 ? sourceBounds.min.y : sourceBounds.max.y,
                    (corner & 4) == 0 ? sourceBounds.min.z : sourceBounds.max.z);
                Vector3 point = relativeTo.InverseTransformPoint(sourceTransform.TransformPoint(sourcePoint));
                if (!initialized)
                {
                    result = new Bounds(point, Vector3.zero);
                    initialized = true;
                }
                else result.Encapsulate(point);
            }
            return result;
        }

        private void AlignProchargerVisualToCrank(Transform modelTransform, Transform engineRoot)
        {
            if (modelTransform == null || engineRoot == null) return;
            PartScript crankPulley = FindCrankPulleyPart(engineRoot.gameObject);
            Vector3 crankCenterWorld = engineRoot.position;
            float crankRadiusWorld = 0.075f;
            Vector3 pulleyAxisWorld = engineRoot.right;
            if (crankPulley != null)
            {
                Bounds crankBounds;
                if (TryGetPartWorldBounds(crankPulley, out crankBounds)) crankCenterWorld = crankBounds.center;
                Bounds localPulleyBounds;
                if (TryGetPartLocalMeshBounds(crankPulley, out localPulleyBounds)
                    || TryGetLocalRendererBounds(crankPulley.GetComponentsInChildren<Renderer>(true), crankPulley.transform, out localPulleyBounds))
                {
                    crankCenterWorld = crankPulley.transform.TransformPoint(localPulleyBounds.center);
                    crankRadiusWorld = EstimatePulleyRadiusWorld(localPulleyBounds.size, crankPulley.transform);
                    pulleyAxisWorld = SmallestLocalBoundsAxis(localPulleyBounds.size, crankPulley.transform);
                }
                if (Vector3.Dot(pulleyAxisWorld, engineRoot.right) < 0.0f) pulleyAxisWorld = -pulleyAxisWorld;
            }
            if (pulleyAxisWorld.sqrMagnitude < 0.0001f) pulleyAxisWorld = engineRoot.right;
            pulleyAxisWorld.Normalize();

            Quaternion baseRotation = Quaternion.FromToRotation(engineRoot.right, pulleyAxisWorld) * engineRoot.rotation;
            // The 0.8.49 flip put the housing toward the block. The authored OBJ
            // orientation faces the housing outboard while preserving the pulley axis.
            modelTransform.rotation = baseRotation;
            Vector3 upWorld = engineRoot.up - pulleyAxisWorld * Vector3.Dot(engineRoot.up, pulleyAxisWorld);
            if (upWorld.sqrMagnitude < 0.0001f)
                upWorld = engineRoot.forward - pulleyAxisWorld * Vector3.Dot(engineRoot.forward, pulleyAxisWorld);
            upWorld.Normalize();
            Vector3 desiredPulleyCenter = crankCenterWorld + upWorld * Mathf.Max(0.14f, crankRadiusWorld + 0.075f);
            modelTransform.position += desiredPulleyCenter - modelTransform.TransformPoint(ProchargerDrivePulleyCenter);
            Logger.LogInfo("Aligned the installed P-1X drive pulley above "
                + (crankPulley == null ? "the estimated crank pulley" : crankPulley.GetID())
                + " on " + engineRoot.name + ".");
        }

        private void AddProchargerDriveVisuals(PartScript mount, Transform modelTransform)
        {
            if (mount == null || modelTransform == null) return;
            Transform engineRoot = FindEngineRootTransform(mount.transform);
            if (engineRoot == null) return;

            PartScript crankPulley = FindCrankPulleyPart(engineRoot.gameObject);
            Vector3 crankCenterWorld = engineRoot.position;
            float crankRadiusWorld = 0.075f;
            Bounds crankBounds = new Bounds(Vector3.zero, Vector3.zero);
            bool foundCrankPulley = crankPulley != null && TryGetPartWorldBounds(crankPulley, out crankBounds);
            bool exactCrankMeshBounds = false;
            if (foundCrankPulley)
            {
                Bounds localPulleyBounds;
                exactCrankMeshBounds = TryGetPartLocalMeshBounds(crankPulley, out localPulleyBounds);
                bool hasLocalBounds = exactCrankMeshBounds || TryGetLocalRendererBounds(
                    crankPulley.GetComponentsInChildren<Renderer>(true), crankPulley.transform, out localPulleyBounds);
                if (hasLocalBounds)
                {
                    crankCenterWorld = crankPulley.transform.TransformPoint(localPulleyBounds.center);
                    crankRadiusWorld = EstimatePulleyRadiusWorld(localPulleyBounds.size, crankPulley.transform);
                }
                else
                {
                    crankCenterWorld = crankBounds.center;
                    float[] dimensions = { crankBounds.size.x, crankBounds.size.y, crankBounds.size.z };
                    Array.Sort(dimensions);
                    crankRadiusWorld = Mathf.Clamp(dimensions[1] * 0.5f, 0.045f, 0.16f);
                }
            }
            else
            {
                Bounds engineBounds;
                if (TryGetLocalRendererBounds(engineRoot.GetComponentsInChildren<Renderer>(true), engineRoot, out engineBounds))
                {
                    Vector3 localCenter = EstimateFrontDriveCenter(engineBounds);
                    localCenter.z = engineBounds.max.z;
                    crankCenterWorld = engineRoot.TransformPoint(localCenter);
                }
                Logger.LogWarning("Could not identify the engine crank pulley for the ProCharger belt on " + engineRoot.name + "; using the engine-front bounds estimate.");
                LogEnginePartLayout(engineRoot.gameObject);
            }

            Vector3 chargerCenterWorld = modelTransform.TransformPoint(ProchargerDrivePulleyCenter);
            Vector3 axisWorld = modelTransform.TransformDirection(Vector3.right).normalized;
            Vector3 centerDelta = crankCenterWorld - chargerCenterWorld;
            crankCenterWorld = chargerCenterWorld + centerDelta - axisWorld * Vector3.Dot(centerDelta, axisWorld);

            Vector3 chargerCenter = ProchargerDrivePulleyCenter;
            Vector3 crankCenter = modelTransform.InverseTransformPoint(crankCenterWorld);
            Vector3 axis = modelTransform.InverseTransformDirection(axisWorld).normalized;
            Vector3 pulleyDirection = crankCenter - chargerCenter;
            pulleyDirection -= axis * Vector3.Dot(pulleyDirection, axis);
            if (pulleyDirection.sqrMagnitude < 0.0025f)
            {
                Logger.LogWarning("The ProCharger and crank pulley centers are too close to draw a belt on " + engineRoot.name + ".");
                return;
            }
            pulleyDirection.Normalize();
            Vector3 beltNormal = Vector3.Cross(axis, pulleyDirection).normalized;
            if (beltNormal.sqrMagnitude < 0.5f) return;

            float modelScale = Mathf.Max(0.01f, Mathf.Abs(modelTransform.lossyScale.x));
            float chargerRadius = 0.112f;
            float crankRadius = crankRadiusWorld / modelScale;
            float tensionerRadius = 0.034f / modelScale;
            Vector3 upperStart = chargerCenter + beltNormal * chargerRadius;
            Vector3 upperEnd = crankCenter + beltNormal * crankRadius;
            Vector3 tensionerCenter = Vector3.Lerp(upperStart, upperEnd, 0.53f) + beltNormal * (tensionerRadius * 0.68f);

            Mesh beltMesh = BuildProchargerBeltMesh(chargerCenter, crankCenter, tensionerCenter, axis,
                beltNormal, chargerRadius, crankRadius, tensionerRadius,
                ProchargerDriveBeltWidthMeters * 0.5f / modelScale,
                ProchargerDriveBeltThicknessMeters * 0.5f / modelScale);
            if (beltMesh == null) return;
            beltMesh.name = "CMS18 ProCharger Serpentine Drive Belt";
            GameObject beltObject = new GameObject("CMS18 ProCharger Serpentine Drive Belt");
            beltObject.transform.SetParent(modelTransform, false);
            MeshFilter beltFilter = beltObject.AddComponent<MeshFilter>();
            beltFilter.sharedMesh = beltMesh;
            MeshRenderer beltRenderer = beltObject.AddComponent<MeshRenderer>();
            beltRenderer.sharedMaterial = GetProchargerDriveMaterial(true);
            beltRenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            ConfigureInductionRenderer(beltRenderer);

            CreateProchargerDrivePulley(modelTransform, tensionerCenter, axis, tensionerRadius,
                ProchargerDriveBeltWidthMeters * 0.5f / modelScale,
                GetProchargerDriveMaterial(false), "CMS18 ProCharger Belt Tensioner");

            Vector3 engineUp = engineRoot.up;
            Vector3 supportCenter = crankCenterWorld + engineUp * (crankRadiusWorld * 0.32f);
            Vector3 earA = modelTransform.TransformPoint(new Vector3(-0.12f, -0.105f, -0.132f));
            Vector3 earB = modelTransform.TransformPoint(new Vector3(-0.12f, 0.105f, -0.132f));
            AddProchargerBracketStrut(modelTransform, earA, supportCenter + axisWorld * 0.035f, modelScale);
            AddProchargerBracketStrut(modelTransform, earB, supportCenter - axisWorld * 0.035f, modelScale);
            AddProchargerBracketStrut(modelTransform, modelTransform.TransformPoint(new Vector3(-0.12f, 0.0f, -0.132f)),
                modelTransform.TransformPoint(new Vector3(-0.23f, 0.0f, -0.145f)), modelScale);

            string intakeSearchDiagnostic;
            PartScript intakeTarget = FindIntakeConnectionTarget(engineRoot.gameObject,
                modelTransform.TransformPoint(ProchargerChargePipeOutlet), out intakeSearchDiagnostic);
            if (intakeTarget != null)
            {
                AddProchargerChargePipe(modelTransform, engineRoot, intakeTarget);
                Logger.LogInfo("Connected the P-1X charge pipe toward " + intakeTarget.GetID() + " on " + engineRoot.name + ".");
            }
            else
            {
                Logger.LogWarning("No mounted throttle-body or intake-manifold target was found for the P-1X charge pipe on "
                    + engineRoot.name + ". " + intakeSearchDiagnostic);
            }

            PartScript airFilterTarget = FindAirFilterConnectionTarget(engineRoot.gameObject,
                modelTransform.TransformPoint(ProchargerInletHoseMouth));
            if (airFilterTarget != null)
            {
                AddProchargerInletHose(modelTransform, engineRoot, airFilterTarget);
                Logger.LogInfo("Connected the 3D 3.75-inch P-1X inlet hose toward " + airFilterTarget.GetID() + " on " + engineRoot.name + ".");
            }
            else
            {
                Logger.LogDebug("No installed air-filter part was found for the P-1X inlet hose on " + engineRoot.name
                    + "; the hollow 3D inlet neck remains visible.");
            }

            Logger.LogInfo("Built the P-1X bracket, tensioner and drive belt on " + engineRoot.name
                + (foundCrankPulley ? " using " + crankPulley.GetID() + ", "
                    + (exactCrankMeshBounds ? "mesh" : "renderer") + " bounds and radius "
                    + crankRadiusWorld.ToString("F3") + " m." : " using estimated crank-pulley position."));
        }

        private static float ProjectedModelHalfExtent(Bounds bounds, Vector3 scale, Quaternion rotation, Vector3 worldAxis)
        {
            Vector3 axis = worldAxis.sqrMagnitude < 0.000001f ? Vector3.up : worldAxis.normalized;
            Vector3 extents = Vector3.Scale(bounds.extents,
                new Vector3(Mathf.Abs(scale.x), Mathf.Abs(scale.y), Mathf.Abs(scale.z)));
            return Mathf.Abs(Vector3.Dot(rotation * Vector3.right, axis)) * extents.x
                + Mathf.Abs(Vector3.Dot(rotation * Vector3.up, axis)) * extents.y
                + Mathf.Abs(Vector3.Dot(rotation * Vector3.forward, axis)) * extents.z;
        }

        private static PartScript FindIntakeConnectionTarget(GameObject engineRoot, Vector3 outletWorld,
            out string searchDiagnostic)
        {
            searchDiagnostic = "Engine root unavailable.";
            if (engineRoot == null) return null;
            PartScript best = null;
            int bestScore = Int32.MaxValue;
            float bestDistanceSquared = Single.PositiveInfinity;
            string unmatchedCandidates = String.Empty;
            int unmatchedCount = 0;
            PartScript[] parts = engineRoot.GetComponentsInChildren<PartScript>(true);
            for (int i = 0; i < parts.Length; i++)
            {
                PartScript part = parts[i];
                if (part == null || IsInductionPartId(part.GetID())
                    || IsInductionPartId(part.GetTunedID()) || IsUniversalMountId(part.GetID())
                    || IsUniversalMountId(part.GetTunedID())) continue;
                bool cmsUnmounted = part.IsUnmounted();
                if (cmsUnmounted && !HasVisiblePartGeometry(part)) continue;
                string id = ((part.GetID() ?? String.Empty) + " " + (part.GetTunedID() ?? String.Empty) + " " + part.gameObject.name).ToLowerInvariant();
                if (id.Contains("exhaust") || id.Contains("wydech")) continue;
                int score = id.Contains("throttle") || id.Contains("przepust") ? 0
                    : id.Contains("intake") || id.Contains("induction") || id.Contains("dolot")
                        || id.Contains("ssacy") || id.Contains("sacy") || id.Contains("kolektor_dolot")
                        || id.Contains("kolektor_ssacy") ? 1
                    : id.Contains("manifold") || id.Contains("kolektor") ? 2 : Int32.MaxValue;
                if (score == Int32.MaxValue)
                {
                    if (unmatchedCount < 12)
                    {
                        string partName = part.GetID();
                        if (String.IsNullOrEmpty(partName)) partName = part.gameObject.name;
                        unmatchedCandidates += (unmatchedCandidates.Length == 0 ? String.Empty : ", ") + partName;
                        unmatchedCount++;
                    }
                    continue;
                }

                float distanceSquared = Single.PositiveInfinity;
                Vector3 candidatePoint;
                Vector3 candidateNormal;
                if (TryFindClosestColliderSurface(part, outletWorld, out candidatePoint, out candidateNormal))
                    distanceSquared = (candidatePoint - outletWorld).sqrMagnitude;
                else
                {
                    Bounds partBounds;
                    if (TryGetPartWorldBounds(part, out partBounds))
                        distanceSquared = (partBounds.ClosestPoint(outletWorld) - outletWorld).sqrMagnitude;
                    else
                        distanceSquared = (part.transform.position - outletWorld).sqrMagnitude;
                }

                int effectiveScore = score * 2 + (cmsUnmounted ? 1 : 0);
                if (effectiveScore < bestScore || (effectiveScore == bestScore && distanceSquared < bestDistanceSquared))
                {
                    best = part;
                    bestScore = effectiveScore;
                    bestDistanceSquared = distanceSquared;
                }
            }

            searchDiagnostic = best == null
                ? "Scanned " + parts.Length + " engine parts; no visible intake ID matched. Candidate IDs: "
                    + (unmatchedCandidates.Length == 0 ? "none" : unmatchedCandidates)
                : "Selected " + best.GetID() + " (match priority " + bestScore + ", outlet distance "
                    + Mathf.Sqrt(bestDistanceSquared).ToString("F2") + " m, cmsUnmountedFlag=" + best.IsUnmounted()
                    + ") from " + parts.Length + " engine parts.";
            return best;
        }

        internal static int ScoreAirFilterCandidate(string partId)
        {
            if (String.IsNullOrEmpty(partId)) return Int32.MaxValue;
            string id = partId.ToLowerInvariant();
            if (id.Contains("olej") || id.Contains("oil") || id.Contains("fuel") || id.Contains("paliw")
                || id.Contains("cabin") || id.Contains("kabina")) return Int32.MaxValue;
            if (id.Contains("filtr_powietrza") || id.Contains("powietrza")
                || id.Contains("air_filter") || id.Contains("airfilter")
                || id.Contains("air_cleaner") || id.Contains("aircleaner")) return 0;
            if (id.Contains("airbox")) return 1;
            return Int32.MaxValue;
        }

        private static PartScript FindAirFilterConnectionTarget(GameObject engineRoot, Vector3 inletWorld)
        {
            if (engineRoot == null) return null;
            PartScript best = null;
            int bestScore = Int32.MaxValue;
            float bestDistance = Single.PositiveInfinity;
            PartScript[] parts = engineRoot.GetComponentsInChildren<PartScript>(true);
            for (int i = 0; i < parts.Length; i++)
            {
                PartScript part = parts[i];
                if (part == null || IsInductionPartId(part.GetID())
                    || IsInductionPartId(part.GetTunedID()) || IsUniversalMountId(part.GetID())
                    || IsUniversalMountId(part.GetTunedID())) continue;
                bool cmsUnmounted = part.IsUnmounted();
                if (cmsUnmounted && !HasVisiblePartGeometry(part)) continue;
                string id = ((part.GetID() ?? String.Empty) + " " + (part.GetTunedID() ?? String.Empty)
                    + " " + part.gameObject.name).ToLowerInvariant();
                int score = ScoreAirFilterCandidate(id);
                if (score == Int32.MaxValue || id.Contains("pokrywa") || id.Contains("cover")
                    || id.Contains("gora") || id.Contains("upper")) continue;
                Bounds bounds;
                Vector3 point = part.transform.position;
                if (TryGetPartWorldBounds(part, out bounds)) point = bounds.ClosestPoint(inletWorld);
                float distance = (point - inletWorld).sqrMagnitude;
                int effectiveScore = score * 2 + (cmsUnmounted ? 1 : 0);
                if (effectiveScore < bestScore || (effectiveScore == bestScore && distance < bestDistance))
                {
                    best = part;
                    bestScore = effectiveScore;
                    bestDistance = distance;
                }
            }
            return best;
        }

        private void AddProchargerInletHose(Transform modelTransform, Transform engineRoot, PartScript airFilterTarget)
        {
            if (modelTransform == null || engineRoot == null || airFilterTarget == null) return;
            Vector3 mouthWorld = modelTransform.TransformPoint(ProchargerInletHoseMouth);
            Bounds filterBounds;
            Vector3 targetWorld = airFilterTarget.transform.position;
            if (TryGetPartWorldBounds(airFilterTarget, out filterBounds))
            {
                Vector3 towardMouth = mouthWorld - filterBounds.center;
                if (towardMouth.sqrMagnitude > 0.0001f)
                {
                    Vector3 direction = towardMouth.normalized;
                    Vector3 extents = filterBounds.extents;
                    float faceDistance = Mathf.Min(
                        extents.x / Mathf.Max(0.0001f, Mathf.Abs(direction.x)),
                        Mathf.Min(extents.y / Mathf.Max(0.0001f, Mathf.Abs(direction.y)),
                            extents.z / Mathf.Max(0.0001f, Mathf.Abs(direction.z))));
                    targetWorld = filterBounds.center + direction * faceDistance * 0.90f;
                }
            }

            Vector3 deltaWorld = targetWorld - mouthWorld;
            float hoseLengthWorld = deltaWorld.magnitude;
            if (hoseLengthWorld < 0.08f || hoseLengthWorld > 1.25f) return;
            // The actual inlet neck axis in the P-1X OBJ points along local +X.
            Vector3 inletOutward = modelTransform.TransformDirection(Vector3.right).normalized;
            Vector3 directionToFilter = deltaWorld / hoseLengthWorld;
            Vector3 p0 = modelTransform.InverseTransformPoint(mouthWorld);
            Vector3 hoseStart = mouthWorld + inletOutward * Mathf.Min(hoseLengthWorld * 0.24f, 0.13f);
            Vector3 hoseEnd = targetWorld - directionToFilter * Mathf.Min(hoseLengthWorld * 0.16f, 0.10f);
            Vector3 hoseControl1;
            Vector3 hoseControl2;
            BuildExteriorRouteControlPoints(engineRoot, hoseStart, hoseEnd,
                ProchargerInletHoseInnerDiameterMeters * 0.5f + ProchargerInletHoseWallThicknessMeters + 0.035f,
                out hoseControl1, out hoseControl2);
            Vector3 p1 = modelTransform.InverseTransformPoint(hoseControl1);
            Vector3 p3 = modelTransform.InverseTransformPoint(targetWorld);
            Vector3 p2 = modelTransform.InverseTransformPoint(hoseControl2);
            float localScale = Mathf.Max(0.01f, Mathf.Abs(modelTransform.lossyScale.x));
            float innerRadius = ProchargerInletHoseInnerDiameterMeters * 0.5f / localScale;
            float outerRadius = (ProchargerInletHoseInnerDiameterMeters * 0.5f
                + ProchargerInletHoseWallThicknessMeters) / localScale;
            Mesh hoseMesh = BuildHollowDuctMesh(p0, p1, p2, p3, outerRadius, innerRadius, 20, 24);
            if (hoseMesh == null) return;
            hoseMesh.name = "CMS18 ProCharger Hollow 3.75-inch Air Inlet Hose";
            GameObject hoseObject = new GameObject(hoseMesh.name);
            hoseObject.transform.SetParent(modelTransform, false);
            MeshFilter filter = hoseObject.AddComponent<MeshFilter>();
            filter.sharedMesh = hoseMesh;
            MeshRenderer renderer = hoseObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = GetProchargerInletHoseMaterial();
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            ConfigureInductionRenderer(renderer);
            AddProchargerInletClamp(modelTransform, p0, p1, p2, p3, 0.045f, outerRadius, localScale, "P-1X");
            AddProchargerInletClamp(modelTransform, p0, p1, p2, p3, 0.955f, outerRadius, localScale, "Air Filter");
        }

        private void AddProchargerInletClamp(Transform parent, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3,
            float t, float hoseRadius, float localScale, string endName)
        {
            Vector3 tangent = EvaluateChargePipeTangent(p0, p1, p2, p3, t);
            if (tangent.sqrMagnitude < 0.000001f) return;
            Mesh bandMesh = BuildAnnularBandMesh(hoseRadius + 0.003f / localScale,
                hoseRadius + 0.0005f / localScale, 0.006f / localScale, 20);
            if (bandMesh == null) return;
            bandMesh.name = "CMS18 ProCharger " + endName + " Inlet Band Mesh";
            GameObject band = new GameObject("CMS18 ProCharger " + endName + " Inlet Clamp");
            band.transform.SetParent(parent, false);
            band.transform.localPosition = EvaluateChargePipePoint(p0, p1, p2, p3, t);
            band.transform.localRotation = Quaternion.FromToRotation(Vector3.up, tangent.normalized);
            MeshFilter filter = band.AddComponent<MeshFilter>();
            filter.sharedMesh = bandMesh;
            MeshRenderer renderer = band.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = GetProchargerDriveMaterial(false);
            ConfigureInductionRenderer(renderer);
        }

        private void AddProchargerChargePipe(Transform modelTransform, Transform engineRoot, PartScript intakeTarget)
        {
            if (modelTransform == null || engineRoot == null || intakeTarget == null) return;
            Vector3 outletWorld = modelTransform.TransformPoint(ProchargerChargePipeOutlet);
            Vector3 outletDirection = modelTransform.TransformDirection(ProchargerChargePipeDirection).normalized;
            Vector3 targetWorld = intakeTarget.transform.position;
            Vector3 intakeSurfaceNormal = (outletWorld - targetWorld).normalized;
            string targetSurface = "part origin fallback";
            Bounds intakeBounds = new Bounds(targetWorld, Vector3.zero);
            if (TryFindClosestMeshSurface(intakeTarget, outletWorld, out targetWorld, out intakeSurfaceNormal))
            {
                targetSurface = "nearest readable intake mesh surface";
                targetWorld -= intakeSurfaceNormal * 0.018f;
            }
            else if (TryFindClosestRendererBoundsSurface(intakeTarget, outletWorld, out targetWorld, out intakeSurfaceNormal))
            {
                targetSurface = "nearest intake renderer-mesh bounds surface";
                targetWorld -= intakeSurfaceNormal * 0.024f;
            }
            else if (TryFindClosestColliderSurface(intakeTarget, outletWorld, out targetWorld, out intakeSurfaceNormal))
            {
                targetSurface = "nearest intake collider surface";
                targetWorld -= intakeSurfaceNormal * 0.030f;
            }
            else if (TryGetPartWorldBounds(intakeTarget, out intakeBounds))
            {
                Vector3 toOutlet = outletWorld - intakeBounds.center;
                if (toOutlet.sqrMagnitude > 0.0001f)
                {
                    intakeSurfaceNormal = toOutlet.normalized;
                    Vector3 extents = intakeBounds.extents;
                    float faceDistance = Mathf.Min(
                        extents.x / Mathf.Max(0.0001f, Mathf.Abs(intakeSurfaceNormal.x)),
                        Mathf.Min(extents.y / Mathf.Max(0.0001f, Mathf.Abs(intakeSurfaceNormal.y)),
                            extents.z / Mathf.Max(0.0001f, Mathf.Abs(intakeSurfaceNormal.z))));
                    targetWorld = intakeBounds.center + intakeSurfaceNormal * Mathf.Max(0.0f, faceDistance - 0.0015f);
                    targetSurface = "intake renderer bounds fallback";
                }
            }

            Vector3 deltaWorld = targetWorld - outletWorld;
            if (deltaWorld.sqrMagnitude < 0.0025f) return;
            float outletAxisAlignment = Vector3.Dot(outletDirection, deltaWorld.normalized);
            Vector3 p0 = modelTransform.InverseTransformPoint(outletWorld);
            Vector3 p3 = modelTransform.InverseTransformPoint(targetWorld);
            float localScale = Mathf.Max(0.01f, Mathf.Abs(modelTransform.lossyScale.x));
            float pipeRadius = Mathf.Max(0.020f, ProchargerChargePipeOuterRadiusModel);
            float pipeInnerRadius = Mathf.Min(pipeRadius - 0.002f,
                Mathf.Max(0.012f, ProchargerChargePipeInnerRadiusModel));
            Vector3 pipeControl1;
            Vector3 pipeControl2;
            float outletHandleMeters;
            float routeBowMeters;
            Vector3 intakeDirection = -intakeSurfaceNormal;
            BuildCompactChargePipeControlPoints(engineRoot, modelTransform, outletWorld, outletDirection,
                targetWorld, intakeDirection, outletAxisAlignment, pipeRadius * localScale + 0.006f,
                out pipeControl1, out pipeControl2, out outletHandleMeters, out routeBowMeters);
            Vector3 p1 = modelTransform.InverseTransformPoint(pipeControl1);
            Vector3 p2 = modelTransform.InverseTransformPoint(pipeControl2);
            Mesh pipeMesh = BuildHollowDuctMesh(p0, p1, p2, p3, pipeRadius, pipeInnerRadius, 20, 24);
            if (pipeMesh == null) return;
            pipeMesh.name = "CMS18 ProCharger Hollow 3-inch Intercooler Charge Pipe";
            GameObject pipeObject = new GameObject(pipeMesh.name);
            pipeObject.transform.SetParent(modelTransform, false);
            MeshFilter filter = pipeObject.AddComponent<MeshFilter>();
            filter.sharedMesh = pipeMesh;
            MeshRenderer renderer = pipeObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = GetProchargerChargePipeMaterial();
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            ConfigureInductionRenderer(renderer);
            AddChargePipeClamp(modelTransform, p0, p1, p2, p3, 0.075f, pipeRadius, localScale, "Outlet");
            AddChargePipeClamp(modelTransform, p0, p1, p2, p3, 0.925f, pipeRadius, localScale, "Intake");
            Logger.LogInfo("Built a routed P-1X charge-pipe connection to " + intakeTarget.GetID() + " on "
                + engineRoot.name + ": port distance " + deltaWorld.magnitude.ToString("F2")
                + " m, outlet-axis alignment " + outletAxisAlignment.ToString("F2")
                + ", outlet stub " + outletHandleMeters.ToString("F2") + " m"
                + ", outboard route bow " + routeBowMeters.ToString("F2") + " m, outlet "
                + outletWorld.ToString("F3") + ", intake surface " + targetSurface + " at "
                + targetWorld.ToString("F3") + ".");
        }

        private static bool TryFindClosestColliderSurface(PartScript part, Vector3 queryWorld,
            out Vector3 surfacePoint, out Vector3 surfaceNormal)
        {
            surfacePoint = part == null ? queryWorld : part.transform.position;
            surfaceNormal = Vector3.zero;
            if (part == null) return false;

            Collider[] colliders = part.GetComponentsInChildren<Collider>(true);
            float bestDistanceSquared = Single.PositiveInfinity;
            bool found = false;
            for (int i = 0; i < colliders.Length; i++)
            {
                Collider collider = colliders[i];
                if (collider == null || !collider.enabled || collider.isTrigger) continue;
                try
                {
                    Vector3 candidate = collider.ClosestPoint(queryWorld);
                    Vector3 normal = queryWorld - candidate;
                    if (normal.sqrMagnitude < 0.000001f)
                    {
                        candidate = collider.ClosestPointOnBounds(queryWorld);
                        normal = queryWorld - candidate;
                    }
                    if (normal.sqrMagnitude < 0.000001f)
                        normal = queryWorld - collider.bounds.center;
                    if (normal.sqrMagnitude < 0.000001f) continue;

                    float distanceSquared = (candidate - queryWorld).sqrMagnitude;
                    if (distanceSquared >= bestDistanceSquared) continue;
                    normal.Normalize();
                    bestDistanceSquared = distanceSquared;
                    surfacePoint = candidate;
                    surfaceNormal = normal;
                    found = true;
                }
                catch (Exception)
                {
                    continue;
                }
            }
            return found && surfaceNormal.sqrMagnitude > 0.5f;
        }

        private static bool TryFindClosestMeshSurface(PartScript part, Vector3 queryWorld,
            out Vector3 surfacePoint, out Vector3 surfaceNormal)
        {
            surfacePoint = part == null ? queryWorld : part.transform.position;
            surfaceNormal = Vector3.zero;
            if (part == null) return false;

            MeshFilter[] filters = part.GetComponentsInChildren<MeshFilter>(true);
            float bestDistanceSquared = Single.PositiveInfinity;
            bool found = false;
            for (int filterIndex = 0; filterIndex < filters.Length; filterIndex++)
            {
                MeshFilter filter = filters[filterIndex];
                if (filter == null || filter.sharedMesh == null) continue;
                try
                {
                    Mesh mesh = filter.sharedMesh;
                    Vector3[] localVertices = mesh.vertices;
                    int[] triangles = mesh.triangles;
                    if (localVertices == null || triangles == null || triangles.Length < 3) continue;
                    Vector3[] worldVertices = new Vector3[localVertices.Length];
                    for (int i = 0; i < localVertices.Length; i++)
                        worldVertices[i] = filter.transform.TransformPoint(localVertices[i]);

                    for (int triangle = 0; triangle + 2 < triangles.Length; triangle += 3)
                    {
                        int ia = triangles[triangle];
                        int ib = triangles[triangle + 1];
                        int ic = triangles[triangle + 2];
                        if (ia < 0 || ib < 0 || ic < 0 || ia >= worldVertices.Length
                            || ib >= worldVertices.Length || ic >= worldVertices.Length) continue;
                        Vector3 a = worldVertices[ia];
                        Vector3 b = worldVertices[ib];
                        Vector3 c = worldVertices[ic];
                        Vector3 candidate = ClosestPointOnTriangle(queryWorld, a, b, c);
                        float distanceSquared = (candidate - queryWorld).sqrMagnitude;
                        if (distanceSquared >= bestDistanceSquared) continue;

                        Vector3 normal = Vector3.Cross(b - a, c - a);
                        if (normal.sqrMagnitude < 0.000001f) continue;
                        normal.Normalize();
                        if (Vector3.Dot(normal, queryWorld - candidate) < 0.0f) normal = -normal;
                        bestDistanceSquared = distanceSquared;
                        surfacePoint = candidate;
                        surfaceNormal = normal;
                        found = true;
                    }
                }
                catch (Exception)
                {
                    continue;
                }
            }
            return found && surfaceNormal.sqrMagnitude > 0.5f;
        }

        private static bool TryFindClosestRendererBoundsSurface(PartScript part, Vector3 queryWorld,
            out Vector3 surfacePoint, out Vector3 surfaceNormal)
        {
            surfacePoint = part == null ? queryWorld : part.transform.position;
            surfaceNormal = Vector3.zero;
            if (part == null) return false;

            Renderer[] renderers = part.GetComponentsInChildren<Renderer>(true);
            float bestDistanceSquared = Single.PositiveInfinity;
            bool found = false;
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null || renderer.bounds.size.sqrMagnitude < 0.0001f) continue;

                MeshFilter meshFilter = renderer.GetComponent<MeshFilter>();
                Mesh mesh = meshFilter == null ? null : meshFilter.sharedMesh;
                Vector3 candidate;
                Vector3 normal;
                if (mesh != null && mesh.bounds.size.sqrMagnitude >= 0.0001f)
                {
                    Vector3 queryLocal = meshFilter.transform.InverseTransformPoint(queryWorld);
                    Vector3 candidateLocal;
                    Vector3 normalLocal;
                    GetClosestBoundsSurface(mesh.bounds, queryLocal, out candidateLocal, out normalLocal);
                    candidate = meshFilter.transform.TransformPoint(candidateLocal);
                    normal = meshFilter.transform.TransformDirection(normalLocal).normalized;
                }
                else
                {
                    GetClosestBoundsSurface(renderer.bounds, queryWorld, out candidate, out normal);
                }

                if (normal.sqrMagnitude < 0.0001f) normal = queryWorld - candidate;
                if (normal.sqrMagnitude < 0.0001f) continue;
                float distanceSquared = (candidate - queryWorld).sqrMagnitude;
                if (distanceSquared >= bestDistanceSquared) continue;
                bestDistanceSquared = distanceSquared;
                surfacePoint = candidate;
                surfaceNormal = normal.normalized;
                found = true;
            }
            return found && surfaceNormal.sqrMagnitude > 0.5f;
        }

        private static void GetClosestBoundsSurface(Bounds bounds, Vector3 point,
            out Vector3 surfacePoint, out Vector3 surfaceNormal)
        {
            surfacePoint = bounds.ClosestPoint(point);
            surfaceNormal = point - surfacePoint;
            if (!bounds.Contains(point))
            {
                if (surfaceNormal.sqrMagnitude < 0.000001f)
                    surfaceNormal = point - bounds.center;
                return;
            }

            Vector3 min = bounds.min;
            Vector3 max = bounds.max;
            float nearestFace = point.x - min.x;
            surfacePoint.x = min.x;
            surfaceNormal = Vector3.left;
            float distance = max.x - point.x;
            if (distance < nearestFace)
            {
                nearestFace = distance;
                surfacePoint = point;
                surfacePoint.x = max.x;
                surfaceNormal = Vector3.right;
            }
            distance = point.y - min.y;
            if (distance < nearestFace)
            {
                nearestFace = distance;
                surfacePoint = point;
                surfacePoint.y = min.y;
                surfaceNormal = Vector3.down;
            }
            distance = max.y - point.y;
            if (distance < nearestFace)
            {
                nearestFace = distance;
                surfacePoint = point;
                surfacePoint.y = max.y;
                surfaceNormal = Vector3.up;
            }
            distance = point.z - min.z;
            if (distance < nearestFace)
            {
                nearestFace = distance;
                surfacePoint = point;
                surfacePoint.z = min.z;
                surfaceNormal = Vector3.back;
            }
            distance = max.z - point.z;
            if (distance < nearestFace)
            {
                surfacePoint = point;
                surfacePoint.z = max.z;
                surfaceNormal = Vector3.forward;
            }
        }

        private static Vector3 ClosestPointOnTriangle(Vector3 point, Vector3 a, Vector3 b, Vector3 c)
        {
            Vector3 ab = b - a;
            Vector3 ac = c - a;
            Vector3 ap = point - a;
            float d1 = Vector3.Dot(ab, ap);
            float d2 = Vector3.Dot(ac, ap);
            if (d1 <= 0.0f && d2 <= 0.0f) return a;

            Vector3 bp = point - b;
            float d3 = Vector3.Dot(ab, bp);
            float d4 = Vector3.Dot(ac, bp);
            if (d3 >= 0.0f && d4 <= d3) return b;

            float vc = d1 * d4 - d3 * d2;
            if (vc <= 0.0f && d1 >= 0.0f && d3 <= 0.0f)
                return a + ab * (d1 / (d1 - d3));

            Vector3 cp = point - c;
            float d5 = Vector3.Dot(ab, cp);
            float d6 = Vector3.Dot(ac, cp);
            if (d6 >= 0.0f && d5 <= d6) return c;

            float vb = d5 * d2 - d1 * d6;
            if (vb <= 0.0f && d2 >= 0.0f && d6 <= 0.0f)
                return a + ac * (d2 / (d2 - d6));

            float va = d3 * d6 - d5 * d4;
            if (va <= 0.0f && (d4 - d3) >= 0.0f && (d5 - d6) >= 0.0f)
                return b + (c - b) * ((d4 - d3) / ((d4 - d3) + (d5 - d6)));

            float denominator = 1.0f / (va + vb + vc);
            float v = vb * denominator;
            float w = vc * denominator;
            return a + ab * v + ac * w;
        }

        private static void BuildCompactChargePipeControlPoints(Transform engineRoot, Transform modelTransform,
            Vector3 startWorld, Vector3 outletDirection, Vector3 endWorld, Vector3 intakeDirection,
            float outletAxisAlignment, float clearance, out Vector3 control1World, out Vector3 control2World,
            out float outletHandleMeters, out float routeBowMeters)
        {
            Vector3 delta = endWorld - startWorld;
            float distance = delta.magnitude;
            Vector3 direction = distance > 0.0001f ? delta / distance : Vector3.forward;
            Vector3 up = engineRoot == null || engineRoot.up.sqrMagnitude < 0.0001f
                ? Vector3.up : engineRoot.up.normalized;
            Vector3 centerWorld = engineRoot == null ? (startWorld + endWorld) * 0.5f : engineRoot.position;
            Bounds engineBounds = new Bounds(Vector3.zero, Vector3.zero);
            bool hasEngineBounds = engineRoot != null
                && TryGetEngineCoreLocalBounds(engineRoot, out engineBounds);
            if (hasEngineBounds) centerWorld = engineRoot.TransformPoint(engineBounds.center);

            Vector3 side = Vector3.ProjectOnPlane(
                (modelTransform == null ? startWorld : modelTransform.position) - centerWorld, up);
            if (side.sqrMagnitude < 0.0001f)
                side = Vector3.ProjectOnPlane((startWorld + endWorld) * 0.5f - centerWorld, up);
            if (side.sqrMagnitude < 0.0001f && engineRoot != null)
                side = Vector3.ProjectOnPlane(engineRoot.right, up);
            if (side.sqrMagnitude < 0.0001f) side = Vector3.right;
            side.Normalize();

            float requiredOutboardBow = 0.0f;
            if (hasEngineBounds)
            {
                float sideExtent = ProjectedModelHalfExtent(engineBounds, engineRoot.lossyScale,
                    engineRoot.rotation, side);
                float engineSideFace = Vector3.Dot(centerWorld, side) + sideExtent
                    + Mathf.Max(0.012f, clearance);
                Vector3 midpoint = (startWorld + endWorld) * 0.5f;
                requiredOutboardBow = Mathf.Max(0.0f, engineSideFace - Vector3.Dot(midpoint, side));
            }

            // Route outside the engine envelope. The old 8% multiplier made the
            // calculated clearance almost disappear, leaving a straight-looking
            // pipe that could cross the head or block.
            float maxBow = Mathf.Min(0.16f, Mathf.Max(0.025f, distance * 0.45f));
            // Keep the charge tube just clear of the engine envelope. The former
            // 25 mm extra clearance visibly floated the I4 pipe away from the head;
            // 6 mm plus the route's 4 mm reserve leaves a realistic ~10 mm surface gap.
            routeBowMeters = Mathf.Clamp(requiredOutboardBow + 0.004f, 0.004f, maxBow);
            float handleBow = routeBowMeters / 0.75f;
            float fullOutletStub = Mathf.Clamp(distance * 0.20f, 0.018f, 0.065f);
            // Keep a short, visible run from the P-1X outlet flange. When that
            // authored outlet faces away from the chosen throttle body, turn sooner
            // instead of carrying the pipe backward for the full control handle.
            float outletAlignmentFactor = Mathf.Clamp01((outletAxisAlignment + 0.50f) / 0.75f);
            // The 0.8.58 image shows the route nearly aligned. Trim the minimum
            // handle another 5 mm when the authored outlet points away from the
            // target, without moving either endpoint or changing well-aligned
            // engine routes.
            outletHandleMeters = Mathf.Lerp(0.018f, fullOutletStub, outletAlignmentFactor);

            if (outletDirection.sqrMagnitude < 0.0001f)
                outletDirection = direction;
            else
            {
                outletDirection.Normalize();
                // The P-1X outlet axis is signed from the authored model bounds and
                // the outlet's terminal geometry. Never flip it toward the intake:
                // that reverses the hose through the compressor when the intake lies
                // behind the real outlet direction. Let the routed bend turn instead.
            }

            Vector3 intakeTangent = intakeDirection.sqrMagnitude < 0.0001f
                ? direction : intakeDirection.normalized;
            if (Vector3.Dot(intakeTangent, direction) < 0.15f)
                intakeTangent = direction;
            else intakeTangent.Normalize();

            Vector3 routeOffset = side * handleBow
                + up * Mathf.Min(0.006f, Mathf.Max(0.001f, clearance * 0.05f));
            control1World = startWorld + outletDirection * outletHandleMeters + routeOffset;
            control2World = endWorld - intakeTangent * fullOutletStub + routeOffset;
        }

        private static void BuildExteriorRouteControlPoints(Transform engineRoot, Vector3 startWorld,
            Vector3 endWorld, float clearance, out Vector3 control1World, out Vector3 control2World)
        {
            Vector3 up = engineRoot == null || engineRoot.up.sqrMagnitude < 0.0001f
                ? Vector3.up : engineRoot.up.normalized;
            Bounds engineBounds;
            if (engineRoot == null || !TryGetEngineCoreLocalBounds(engineRoot, out engineBounds))
            {
                Vector3 fallbackLift = up * Mathf.Max(0.04f, clearance + 0.025f);
                control1World = Vector3.Lerp(startWorld, endWorld, 0.30f) + fallbackLift;
                control2World = Vector3.Lerp(startWorld, endWorld, 0.70f) + fallbackLift;
                return;
            }

            Vector3 centerWorld = engineRoot.TransformPoint(engineBounds.center);
            Vector3 side = Vector3.ProjectOnPlane((startWorld + endWorld) * 0.5f - centerWorld, up);
            if (side.sqrMagnitude < 0.0001f) side = Vector3.ProjectOnPlane(startWorld - centerWorld, up);
            if (side.sqrMagnitude < 0.0001f) side = Vector3.ProjectOnPlane(engineRoot.forward, up);
            if (side.sqrMagnitude < 0.0001f) side = Vector3.right;
            side.Normalize();

            float sideExtent = ProjectedModelHalfExtent(engineBounds, engineRoot.lossyScale,
                engineRoot.rotation, side);
            float outsideCoordinate = Vector3.Dot(centerWorld, side) + sideExtent + Mathf.Max(0.025f, clearance);
            Vector3 first = Vector3.Lerp(startWorld, endWorld, 0.30f);
            Vector3 second = Vector3.Lerp(startWorld, endWorld, 0.70f);
            control1World = first + side * (outsideCoordinate - Vector3.Dot(first, side))
                + up * Mathf.Max(0.012f, clearance * 0.20f);
            control2World = second + side * (outsideCoordinate - Vector3.Dot(second, side))
                + up * Mathf.Max(0.012f, clearance * 0.20f);
        }

        private static bool TryGetEngineCoreLocalBounds(Transform engineRoot, out Bounds engineBounds)
        {
            engineBounds = new Bounds(Vector3.zero, Vector3.zero);
            if (engineRoot == null) return false;
            PartScript[] parts = engineRoot.GetComponentsInChildren<PartScript>(true);
            bool initialized = false;
            for (int i = 0; i < parts.Length; i++)
            {
                PartScript part = parts[i];
                if (part == null || part.IsUnmounted() || IsInductionPartId(part.GetID())
                    || IsInductionPartId(part.GetTunedID()) || IsUniversalMountId(part.GetID())
                    || IsUniversalMountId(part.GetTunedID())) continue;
                string id = (part.GetID() ?? String.Empty) + " " + (part.GetTunedID() ?? String.Empty)
                    + " " + part.gameObject.name;
                if (ScoreAirFilterCandidate(id) != Int32.MaxValue) continue;
                Bounds partBounds;
                if (!TryGetLocalRendererBounds(part.GetComponentsInChildren<Renderer>(true), engineRoot, out partBounds)) continue;
                if (!initialized)
                {
                    engineBounds = partBounds;
                    initialized = true;
                }
                else engineBounds.Encapsulate(partBounds);
            }
            if (initialized) return true;
            return TryGetLocalRendererBounds(engineRoot.GetComponentsInChildren<Renderer>(true), engineRoot, out engineBounds);
        }

        private void AddChargePipeClamp(Transform parent, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3,
            float t, float pipeRadius, float localScale, string endName)
        {
            Vector3 center = EvaluateChargePipePoint(p0, p1, p2, p3, t);
            Vector3 tangent = EvaluateChargePipeTangent(p0, p1, p2, p3, t);
            if (tangent.sqrMagnitude < 0.000001f) return;
            GameObject clamp = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            clamp.name = "CMS18 ProCharger " + endName + " Coupler Clamp";
            Collider collider = clamp.GetComponent<Collider>();
            if (collider != null) UnityEngine.Object.Destroy(collider);
            clamp.transform.SetParent(parent, false);
            clamp.transform.localPosition = center;
            clamp.transform.localRotation = Quaternion.FromToRotation(Vector3.up, tangent.normalized);
            float outerRadius = pipeRadius + 0.0025f / Mathf.Max(0.01f, localScale);
            float halfWidth = ProchargerChargePipeClampWidthMeters * 0.5f / Mathf.Max(0.01f, localScale);
            clamp.transform.localScale = new Vector3(outerRadius * 2.0f, halfWidth, outerRadius * 2.0f);
            Renderer renderer = clamp.GetComponent<Renderer>();
            Material material = GetProchargerDriveMaterial(false);
            if (renderer != null && material != null) renderer.sharedMaterial = material;
            ConfigureInductionRenderer(renderer);
        }

        private static Vector3 EvaluateChargePipePoint(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
        {
            float inverse = 1.0f - t;
            return p0 * (inverse * inverse * inverse)
                + p1 * (3.0f * inverse * inverse * t)
                + p2 * (3.0f * inverse * t * t)
                + p3 * (t * t * t);
        }

        private static Vector3 EvaluateChargePipeTangent(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
        {
            float inverse = 1.0f - t;
            return (p1 - p0) * (3.0f * inverse * inverse)
                + (p2 - p1) * (6.0f * inverse * t)
                + (p3 - p2) * (3.0f * t * t);
        }

        private static Vector3 GetStableTubeNormal(Vector3 tangent, Vector3 previousTangent,
            Vector3 previousNormal, bool hasPrevious)
        {
            Vector3 normal;
            if (hasPrevious)
            {
                normal = Quaternion.FromToRotation(previousTangent, tangent) * previousNormal;
                normal = Vector3.ProjectOnPlane(normal, tangent).normalized;
            }
            else
            {
                normal = Vector3.Cross(tangent, Vector3.up).normalized;
            }
            if (normal.sqrMagnitude < 0.5f)
                normal = Vector3.Cross(tangent, Vector3.right).normalized;
            if (normal.sqrMagnitude < 0.5f)
                normal = Vector3.Cross(tangent, Vector3.forward).normalized;
            return normal;
        }

        private static Mesh BuildChargePipeMesh(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float radius,
            int radialSegments, int longitudinalSegments)
        {
            if (radius <= 0.0f || radialSegments < 6 || longitudinalSegments < 4) return null;
            Vector3[] vertices = new Vector3[(longitudinalSegments + 1) * radialSegments];
            Vector2[] uv = new Vector2[vertices.Length];
            int[] triangles = new int[longitudinalSegments * radialSegments * 6];
            int vertexIndex = 0;
            int triangleIndex = 0;
            Vector3 previousTangent = Vector3.zero;
            Vector3 previousNormal = Vector3.zero;
            for (int ring = 0; ring <= longitudinalSegments; ring++)
            {
                float t = ring / (float)longitudinalSegments;
                float oneMinusT = 1.0f - t;
                Vector3 center = oneMinusT * oneMinusT * oneMinusT * p0
                    + 3.0f * oneMinusT * oneMinusT * t * p1
                    + 3.0f * oneMinusT * t * t * p2
                    + t * t * t * p3;
                Vector3 tangent = (3.0f * oneMinusT * oneMinusT * (p1 - p0)
                    + 6.0f * oneMinusT * t * (p2 - p1)
                    + 3.0f * t * t * (p3 - p2)).normalized;
                if (tangent.sqrMagnitude < 0.5f) tangent = (p3 - p0).normalized;
                Vector3 normal = GetStableTubeNormal(tangent, previousTangent, previousNormal, ring > 0);
                Vector3 binormal = Vector3.Cross(tangent, normal).normalized;
                for (int side = 0; side < radialSegments; side++)
                {
                    float angle = side * Mathf.PI * 2.0f / radialSegments;
                    Vector3 radial = normal * Mathf.Cos(angle) + binormal * Mathf.Sin(angle);
                    vertices[vertexIndex] = center + radial * radius;
                    uv[vertexIndex] = new Vector2(side / (float)radialSegments, t);
                    if (ring < longitudinalSegments)
                    {
                        int nextSide = (side + 1) % radialSegments;
                        int a = ring * radialSegments + side;
                        int b = ring * radialSegments + nextSide;
                        int c = (ring + 1) * radialSegments + nextSide;
                        int d = (ring + 1) * radialSegments + side;
                        // Keep the visible face normals pointed outward for Unity's
                        // back-face culling.
                        triangles[triangleIndex++] = a; triangles[triangleIndex++] = b; triangles[triangleIndex++] = d;
                        triangles[triangleIndex++] = b; triangles[triangleIndex++] = c; triangles[triangleIndex++] = d;
                    }
                    vertexIndex++;
                }
                previousTangent = tangent;
                previousNormal = normal;
            }
            Mesh mesh = new Mesh();
            mesh.vertices = vertices;
            mesh.uv = uv;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static Mesh BuildHollowDuctMesh(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3,
            float outerRadius, float innerRadius, int radialSegments, int longitudinalSegments)
        {
            if (innerRadius <= 0.0f || outerRadius <= innerRadius || radialSegments < 8 || longitudinalSegments < 4)
                return null;
            int rings = longitudinalSegments + 1;
            int ringVertices = rings * radialSegments;
            Vector3[] vertices = new Vector3[ringVertices * 2];
            Vector2[] uv = new Vector2[vertices.Length];
            int[] triangles = new int[(longitudinalSegments * radialSegments * 12) + (radialSegments * 12)];
            Vector3 previousTangent = Vector3.zero;
            Vector3 previousNormal = Vector3.zero;
            for (int ring = 0; ring < rings; ring++)
            {
                float t = ring / (float)longitudinalSegments;
                Vector3 center = EvaluateChargePipePoint(p0, p1, p2, p3, t);
                Vector3 tangent = EvaluateChargePipeTangent(p0, p1, p2, p3, t).normalized;
                if (tangent.sqrMagnitude < 0.5f) tangent = (p3 - p0).normalized;
                Vector3 normal = GetStableTubeNormal(tangent, previousTangent, previousNormal, ring > 0);
                Vector3 binormal = Vector3.Cross(tangent, normal).normalized;
                for (int side = 0; side < radialSegments; side++)
                {
                    float angle = side * Mathf.PI * 2.0f / radialSegments;
                    Vector3 radial = normal * Mathf.Cos(angle) + binormal * Mathf.Sin(angle);
                    int outerIndex = ring * radialSegments + side;
                    int innerIndex = ringVertices + outerIndex;
                    vertices[outerIndex] = center + radial * outerRadius;
                    vertices[innerIndex] = center + radial * innerRadius;
                    uv[outerIndex] = new Vector2(side / (float)radialSegments, t);
                    uv[innerIndex] = new Vector2(side / (float)radialSegments, t);
                }
                previousTangent = tangent;
                previousNormal = normal;
            }

            int triangleIndex = 0;
            for (int ring = 0; ring < longitudinalSegments; ring++)
            {
                for (int side = 0; side < radialSegments; side++)
                {
                    int nextSide = (side + 1) % radialSegments;
                    int a = ring * radialSegments + side;
                    int b = ring * radialSegments + nextSide;
                    int c = (ring + 1) * radialSegments + nextSide;
                    int d = (ring + 1) * radialSegments + side;
                    triangles[triangleIndex++] = a; triangles[triangleIndex++] = b; triangles[triangleIndex++] = d;
                    triangles[triangleIndex++] = b; triangles[triangleIndex++] = c; triangles[triangleIndex++] = d;

                    int ia = ringVertices + a;
                    int ib = ringVertices + b;
                    int ic = ringVertices + c;
                    int id = ringVertices + d;
                    triangles[triangleIndex++] = ia; triangles[triangleIndex++] = id; triangles[triangleIndex++] = ib;
                    triangles[triangleIndex++] = ib; triangles[triangleIndex++] = id; triangles[triangleIndex++] = ic;
                }
            }
            for (int side = 0; side < radialSegments; side++)
            {
                int nextSide = (side + 1) % radialSegments;
                int startOuter = side;
                int startOuterNext = nextSide;
                int startInner = ringVertices + side;
                int startInnerNext = ringVertices + nextSide;
                triangles[triangleIndex++] = startOuter; triangles[triangleIndex++] = startInnerNext; triangles[triangleIndex++] = startOuterNext;
                triangles[triangleIndex++] = startOuter; triangles[triangleIndex++] = startInner; triangles[triangleIndex++] = startInnerNext;

                int endOuter = longitudinalSegments * radialSegments + side;
                int endOuterNext = longitudinalSegments * radialSegments + nextSide;
                int endInner = ringVertices + endOuter;
                int endInnerNext = ringVertices + endOuterNext;
                triangles[triangleIndex++] = endOuter; triangles[triangleIndex++] = endOuterNext; triangles[triangleIndex++] = endInnerNext;
                triangles[triangleIndex++] = endOuter; triangles[triangleIndex++] = endInnerNext; triangles[triangleIndex++] = endInner;
            }
            Mesh mesh = new Mesh();
            mesh.name = "CMS18 Hollow 3D Induction Duct";
            mesh.vertices = vertices;
            mesh.uv = uv;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static Mesh BuildAnnularBandMesh(float outerRadius, float innerRadius, float halfWidth, int radialSegments)
        {
            if (innerRadius <= 0.0f || outerRadius <= innerRadius || halfWidth <= 0.0f || radialSegments < 8) return null;
            Vector3[] vertices = new Vector3[radialSegments * 4];
            int[] triangles = new int[radialSegments * 24];
            for (int side = 0; side < radialSegments; side++)
            {
                float angle = side * Mathf.PI * 2.0f / radialSegments;
                float x = Mathf.Cos(angle);
                float z = Mathf.Sin(angle);
                vertices[side] = new Vector3(x * outerRadius, -halfWidth, z * outerRadius);
                vertices[radialSegments + side] = new Vector3(x * outerRadius, halfWidth, z * outerRadius);
                vertices[radialSegments * 2 + side] = new Vector3(x * innerRadius, -halfWidth, z * innerRadius);
                vertices[radialSegments * 3 + side] = new Vector3(x * innerRadius, halfWidth, z * innerRadius);
            }
            int triangleIndex = 0;
            for (int side = 0; side < radialSegments; side++)
            {
                int next = (side + 1) % radialSegments;
                int outerBottom = side;
                int outerTop = radialSegments + side;
                int innerBottom = radialSegments * 2 + side;
                int innerTop = radialSegments * 3 + side;
                int outerBottomNext = next;
                int outerTopNext = radialSegments + next;
                int innerBottomNext = radialSegments * 2 + next;
                int innerTopNext = radialSegments * 3 + next;
                triangles[triangleIndex++] = outerBottom; triangles[triangleIndex++] = outerBottomNext; triangles[triangleIndex++] = outerTopNext;
                triangles[triangleIndex++] = outerBottom; triangles[triangleIndex++] = outerTopNext; triangles[triangleIndex++] = outerTop;
                triangles[triangleIndex++] = innerBottom; triangles[triangleIndex++] = innerTopNext; triangles[triangleIndex++] = innerBottomNext;
                triangles[triangleIndex++] = innerBottom; triangles[triangleIndex++] = innerTop; triangles[triangleIndex++] = innerTopNext;
                triangles[triangleIndex++] = outerBottom; triangles[triangleIndex++] = innerBottomNext; triangles[triangleIndex++] = outerBottomNext;
                triangles[triangleIndex++] = outerBottom; triangles[triangleIndex++] = innerBottom; triangles[triangleIndex++] = innerBottomNext;
                triangles[triangleIndex++] = outerTop; triangles[triangleIndex++] = outerTopNext; triangles[triangleIndex++] = innerTopNext;
                triangles[triangleIndex++] = outerTop; triangles[triangleIndex++] = innerTopNext; triangles[triangleIndex++] = innerTop;
            }
            Mesh mesh = new Mesh();
            mesh.name = "CMS18 Annular Inlet Hose Clamp";
            mesh.vertices = vertices;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private Material GetProchargerChargePipeMaterial()
        {
            if (prochargerChargePipeMaterial != null) return prochargerChargePipeMaterial;
            Shader shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Legacy Shaders/Diffuse");
            if (shader == null) return null;

            Material material = new Material(shader);
            material.name = "CMS18 ProCharger Opaque Aluminum Charge Pipe";
            material.color = new Color(0.72f, 0.73f, 0.73f, 1.0f);
            if (material.HasProperty("_Mode")) material.SetFloat("_Mode", 0.0f);
            if (material.HasProperty("_SrcBlend")) material.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.One);
            if (material.HasProperty("_DstBlend")) material.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.Zero);
            if (material.HasProperty("_ZWrite")) material.SetFloat("_ZWrite", 1.0f);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", 0.86f);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 0.92f);
            ConfigureOpaqueStandardMaterial(material);
            prochargerChargePipeMaterial = material;
            return material;
        }

        private Material GetProchargerInletHoseMaterial()
        {
            if (prochargerInletHoseMaterial != null) return prochargerInletHoseMaterial;
            Shader shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Legacy Shaders/Diffuse");
            if (shader == null) return null;
            Material material = new Material(shader);
            material.name = "CMS18 ProCharger Matte Black 3D Inlet Hose";
            material.color = new Color(0.065f, 0.072f, 0.076f, 1.0f);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", 0.02f);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 0.28f);
            ConfigureOpaqueStandardMaterial(material);
            prochargerInletHoseMaterial = material;
            return material;
        }

        private static Transform FindEngineRootTransform(Transform partTransform)
        {
            Transform current = partTransform;
            while (current != null)
            {
                if (current.name.StartsWith("engine_", StringComparison.OrdinalIgnoreCase)) return current;
                current = current.parent;
            }
            return partTransform == null ? null : partTransform.root;
        }

        private Material GetProchargerDriveMaterial(bool belt)
        {
            Material cached = belt ? prochargerDriveBeltMaterial : prochargerBracketMaterial;
            if (cached != null) return cached;
            Shader shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Legacy Shaders/Diffuse");
            if (shader == null) return null;
            cached = new Material(shader);
            cached.name = belt ? "CMS18 ProCharger Drive Belt Material" : "CMS18 ProCharger Bracket Material";
            cached.color = belt ? new Color(0.035f, 0.040f, 0.044f, 1.0f) : new Color(0.68f, 0.69f, 0.68f, 1.0f);
            if (cached.HasProperty("_Glossiness")) cached.SetFloat("_Glossiness", belt ? 0.18f : 0.88f);
            if (cached.HasProperty("_Metallic")) cached.SetFloat("_Metallic", belt ? 0.02f : 0.82f);
            ConfigureOpaqueStandardMaterial(cached);
            if (belt) prochargerDriveBeltMaterial = cached;
            else prochargerBracketMaterial = cached;
            return cached;
        }

        private static Mesh BuildProchargerBeltMesh(Vector3 charger, Vector3 crank, Vector3 tensioner, Vector3 axis,
            Vector3 normal, float chargerRadius, float crankRadius, float tensionerRadius, float halfWidth, float halfThickness)
        {
            List<Vector3> path = new List<Vector3>();
            Vector3 upperStart = charger + normal * chargerRadius;
            Vector3 upperEnd = crank + normal * crankRadius;
            Vector3 tensionerEntry = tensioner - (upperEnd - upperStart).normalized * tensionerRadius;
            Vector3 tensionerExit = tensioner + (upperEnd - upperStart).normalized * tensionerRadius;
            AppendBeltLine(path, upperStart, tensionerEntry, 4);
            AppendBeltArc(path, tensioner, tensionerRadius, (upperEnd - upperStart).normalized, normal, Mathf.PI, Mathf.PI * 2.0f, 10);
            AppendBeltLine(path, tensionerExit, upperEnd, 4);
            AppendBeltArc(path, crank, crankRadius, (crank - charger).normalized, normal, Mathf.PI * 0.5f, -Mathf.PI * 0.5f, 16);
            AppendBeltLine(path, crank - normal * crankRadius, charger - normal * chargerRadius, 4);
            AppendBeltArc(path, charger, chargerRadius, (crank - charger).normalized, normal, -Mathf.PI * 0.5f, -Mathf.PI * 1.5f, 16);
            if (path.Count < 12) return null;

            Vector3[] vertices = new Vector3[path.Count * 4];
            List<int> triangles = new List<int>(path.Count * 24);
            for (int i = 0; i < path.Count; i++)
            {
                Vector3 tangent = (path[(i + 1) % path.Count] - path[(i + path.Count - 1) % path.Count]).normalized;
                Vector3 thicknessAxis = Vector3.Cross(tangent, axis).normalized * halfThickness;
                Vector3 widthAxis = axis * halfWidth;
                int start = i * 4;
                vertices[start] = path[i] + widthAxis + thicknessAxis;
                vertices[start + 1] = path[i] + widthAxis - thicknessAxis;
                vertices[start + 2] = path[i] - widthAxis - thicknessAxis;
                vertices[start + 3] = path[i] - widthAxis + thicknessAxis;
                int next = ((i + 1) % path.Count) * 4;
                for (int side = 0; side < 4; side++)
                {
                    int a = start + side;
                    int b = start + ((side + 1) % 4);
                    int c = next + ((side + 1) % 4);
                    int d = next + side;
                    triangles.Add(a); triangles.Add(b); triangles.Add(c);
                    triangles.Add(a); triangles.Add(c); triangles.Add(d);
                }
            }
            Mesh mesh = new Mesh();
            mesh.vertices = vertices;
            mesh.triangles = triangles.ToArray();
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static void AppendBeltLine(List<Vector3> path, Vector3 from, Vector3 to, int steps)
        {
            for (int i = 0; i <= steps; i++)
            {
                Vector3 point = Vector3.Lerp(from, to, i / (float)steps);
                if (path.Count == 0 || (path[path.Count - 1] - point).sqrMagnitude > 0.000001f) path.Add(point);
            }
        }

        private static void AppendBeltArc(List<Vector3> path, Vector3 center, float radius, Vector3 horizontal, Vector3 vertical,
            float startAngle, float endAngle, int steps)
        {
            for (int i = 0; i <= steps; i++)
            {
                float angle = Mathf.Lerp(startAngle, endAngle, i / (float)steps);
                Vector3 point = center + (horizontal * Mathf.Cos(angle) + vertical * Mathf.Sin(angle)) * radius;
                if (path.Count == 0 || (path[path.Count - 1] - point).sqrMagnitude > 0.000001f) path.Add(point);
            }
        }

        private void CreateProchargerDrivePulley(Transform parent, Vector3 center, Vector3 axis, float radius, float width,
            Material material, string objectName)
        {
            GameObject pulley = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pulley.name = objectName;
            Collider collider = pulley.GetComponent<Collider>();
            if (collider != null) UnityEngine.Object.Destroy(collider);
            pulley.transform.SetParent(parent, false);
            pulley.transform.localPosition = center;
            pulley.transform.localRotation = Quaternion.FromToRotation(Vector3.up, axis);
            pulley.transform.localScale = new Vector3(radius * 2.0f, width, radius * 2.0f);
            Renderer renderer = pulley.GetComponent<Renderer>();
            if (renderer != null && material != null) renderer.sharedMaterial = material;
            ConfigureInductionRenderer(renderer);
        }

        private void AddProchargerBracketStrut(Transform parent, Vector3 worldStart, Vector3 worldEnd, float modelScale)
        {
            Vector3 localStart = parent.InverseTransformPoint(worldStart);
            Vector3 localEnd = parent.InverseTransformPoint(worldEnd);
            Vector3 delta = localEnd - localStart;
            if (delta.sqrMagnitude < 0.000001f) return;
            GameObject strut = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            strut.name = "CMS18 ProCharger Mount Bracket";
            Collider collider = strut.GetComponent<Collider>();
            if (collider != null) UnityEngine.Object.Destroy(collider);
            strut.transform.SetParent(parent, false);
            strut.transform.localPosition = (localStart + localEnd) * 0.5f;
            strut.transform.localRotation = Quaternion.FromToRotation(Vector3.up, delta.normalized);
            float worldToLocal = 1.0f / Mathf.Max(0.01f, modelScale);
            strut.transform.localScale = new Vector3(0.016f * worldToLocal, delta.magnitude * 0.5f, 0.016f * worldToLocal);
            Renderer renderer = strut.GetComponent<Renderer>();
            Material material = GetProchargerDriveMaterial(false);
            if (renderer != null && material != null) renderer.sharedMaterial = material;
            ConfigureInductionRenderer(renderer);
        }

        private struct ObjCorner
        {
            public int position;
            public int texCoord;
            public int normal;
        }

        private static bool TryGetObjCircularPortGeometry(List<Vector3> sourcePositions,
            HashSet<int> positionIndices, Vector3 outwardHint, out Vector3 center,
            out Vector3 outwardAxis, out float radius)
        {
            center = Vector3.zero;
            outwardAxis = Vector3.zero;
            radius = 0.0f;
            if (sourcePositions == null || positionIndices == null || positionIndices.Count < 8) return false;

            int validCount = 0;
            foreach (int index in positionIndices)
            {
                if (index < 0 || index >= sourcePositions.Count) continue;
                center += sourcePositions[index];
                validCount++;
            }
            if (validCount < 8) return false;
            center /= validCount;

            double[,] covariance = new double[3, 3];
            foreach (int index in positionIndices)
            {
                if (index < 0 || index >= sourcePositions.Count) continue;
                Vector3 delta = sourcePositions[index] - center;
                covariance[0, 0] += delta.x * delta.x;
                covariance[0, 1] += delta.x * delta.y;
                covariance[0, 2] += delta.x * delta.z;
                covariance[1, 1] += delta.y * delta.y;
                covariance[1, 2] += delta.y * delta.z;
                covariance[2, 2] += delta.z * delta.z;
            }
            double divisor = Math.Max(1, validCount);
            covariance[0, 0] /= divisor;
            covariance[0, 1] /= divisor;
            covariance[0, 2] /= divisor;
            covariance[1, 1] /= divisor;
            covariance[1, 2] /= divisor;
            covariance[2, 2] /= divisor;
            covariance[1, 0] = covariance[0, 1];
            covariance[2, 0] = covariance[0, 2];
            covariance[2, 1] = covariance[1, 2];

            double[,] eigenvectors = new double[3, 3];
            eigenvectors[0, 0] = 1.0;
            eigenvectors[1, 1] = 1.0;
            eigenvectors[2, 2] = 1.0;
            for (int iteration = 0; iteration < 24; iteration++)
            {
                int p = 0;
                int q = 1;
                double largest = Math.Abs(covariance[0, 1]);
                if (Math.Abs(covariance[0, 2]) > largest)
                {
                    p = 0;
                    q = 2;
                    largest = Math.Abs(covariance[0, 2]);
                }
                if (Math.Abs(covariance[1, 2]) > largest)
                {
                    p = 1;
                    q = 2;
                    largest = Math.Abs(covariance[1, 2]);
                }
                if (largest < 0.000000001) break;

                double tau = (covariance[q, q] - covariance[p, p]) / (2.0 * covariance[p, q]);
                double tangent = (tau >= 0.0 ? 1.0 : -1.0)
                    / (Math.Abs(tau) + Math.Sqrt(1.0 + tau * tau));
                double cosine = 1.0 / Math.Sqrt(1.0 + tangent * tangent);
                double sine = tangent * cosine;
                double app = covariance[p, p];
                double aqq = covariance[q, q];
                double apq = covariance[p, q];
                covariance[p, p] = app - tangent * apq;
                covariance[q, q] = aqq + tangent * apq;
                covariance[p, q] = 0.0;
                covariance[q, p] = 0.0;
                for (int k = 0; k < 3; k++)
                {
                    if (k == p || k == q) continue;
                    double akp = covariance[k, p];
                    double akq = covariance[k, q];
                    covariance[k, p] = cosine * akp - sine * akq;
                    covariance[p, k] = covariance[k, p];
                    covariance[k, q] = sine * akp + cosine * akq;
                    covariance[q, k] = covariance[k, q];
                }
                for (int k = 0; k < 3; k++)
                {
                    double vkp = eigenvectors[k, p];
                    double vkq = eigenvectors[k, q];
                    eigenvectors[k, p] = cosine * vkp - sine * vkq;
                    eigenvectors[k, q] = sine * vkp + cosine * vkq;
                }
            }

            int smallestEigenvalue = covariance[1, 1] < covariance[0, 0] ? 1 : 0;
            if (covariance[2, 2] < covariance[smallestEigenvalue, smallestEigenvalue]) smallestEigenvalue = 2;
            outwardAxis = new Vector3((float)eigenvectors[0, smallestEigenvalue],
                (float)eigenvectors[1, smallestEigenvalue], (float)eigenvectors[2, smallestEigenvalue]);
            if (outwardAxis.sqrMagnitude < 0.000001f) return false;
            outwardAxis.Normalize();
            if (Vector3.Dot(outwardAxis, outwardHint) < 0.0f) outwardAxis = -outwardAxis;

            float radiusSum = 0.0f;
            int radiusCount = 0;
            foreach (int index in positionIndices)
            {
                if (index < 0 || index >= sourcePositions.Count) continue;
                Vector3 delta = sourcePositions[index] - center;
                Vector3 radial = delta - outwardAxis * Vector3.Dot(delta, outwardAxis);
                radiusSum += radial.magnitude;
                radiusCount++;
            }
            if (radiusCount == 0) return false;
            radius = radiusSum / radiusCount;
            return radius > 0.01f && radius < 0.5f;
        }

        private bool TryCreateInductionModel(InductionMode mode)
        {
            if (mode != InductionMode.Procharger) return false;

            const string resourceName = "CMS18_ProCharger_P1X_AddOn.obj";
            const string modelName = "P-1X Style ProCharger";

            if (!inductionModelLoadAttempted.Contains(mode))
            {
                inductionModelLoadAttempted.Add(mode);
                BuildInductionModelAsset(mode, resourceName, modelName);
            }

            Mesh modelMesh;
            Material[] modelMaterials;
            if (!inductionModelMeshes.TryGetValue(mode, out modelMesh) || modelMesh == null
                || !inductionModelMaterials.TryGetValue(mode, out modelMaterials) || modelMaterials == null) return false;

            GameObject modelObject = new GameObject("CMS18 " + modelName + " Visual");
            modelObject.transform.SetParent(visualRoot.transform, false);
            modelObject.transform.localPosition = new Vector3(0.0f, 0.08f, 0.0f);
            modelObject.transform.localRotation = Quaternion.identity;
            modelObject.transform.localScale = Vector3.one * 0.55f;
            MeshFilter filter = modelObject.AddComponent<MeshFilter>();
            filter.sharedMesh = modelMesh;
            MeshRenderer renderer = modelObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterials = modelMaterials;
            ConfigureInductionRenderer(renderer);
            return true;
        }

        private void ConfigureProchargerPart(GameObject partRoot)
        {
            ConfigureInductionPart(partRoot, ProchargerPartId);
        }

        private void ConfigureInductionPart(GameObject partRoot, string partId)
        {
            if (partRoot == null) throw new ArgumentNullException("partRoot");
            PartScript partScript = partRoot.GetComponent<PartScript>();
            if (partScript == null) partScript = partRoot.GetComponentInChildren<PartScript>(true);
            if (partScript == null) throw new InvalidOperationException("The stock turbo_2 prefab has no PartScript to preserve the game mount lifecycle.");

            partScript.SetID(partId);
            partScript.SetTunedID(String.Empty);
            InductionMode mode = ModeForInductionPartId(partId);
            if (mode == InductionMode.Procharger
                && !TryAttachInductionVisual(partRoot, partScript.transform, false, mode))
                Logger.LogWarning("The P-1X mesh could not be attached; the shop item will keep the stock turbo_2 host visual.");
        }

        private void ConfigureMountedProchargerPart(PartScript partScript)
        {
            ConfigureMountedInductionPart(partScript, ProchargerPartId);
        }

        private void ConfigureMountedInductionPart(PartScript partScript, string partId)
        {
            if (partScript == null) return;
            InductionMode mode = ModeForInductionPartId(partId);
            partScript.gameObject.layer = PartSelectionLayer;
            SetPartField(partScript, "unmounted", false);
            SetPartField(partScript, "canBeUnmount", true);
            SetPartField(partScript, "canUnmountSingle", true);
            Collider[] colliders = partScript.GetComponents<Collider>();
            for (int i = 0; i < colliders.Length; i++)
                if (colliders[i] != null) colliders[i].enabled = true;
            int partKey = partScript.GetInstanceID();
            InductionMode previousMode;
            Transform existingVisual = partScript.transform.Find(InstalledInductionVisualName);
            if (existingVisual != null && mountedVisualModes.TryGetValue(partKey, out previousMode) && previousMode != mode)
                RestoreMountedProchargerPart(partScript);
            partScript.SetTunedID(partId);
            mountedProchargerParts.Add(partScript);
            if (mode == InductionMode.Procharger
                && !TryAttachInductionVisual(partScript.gameObject, partScript.transform, true, mode))
                Logger.LogWarning("The P-1X mount uses the stock host visual because the custom mesh could not be attached.");
            else if (mode == InductionMode.Procharger)
                mountedVisualModes[partKey] = mode;
            Transform mountedVisual = partScript.transform.Find(InstalledInductionVisualName);
            if (mode == InductionMode.Procharger && IsUniversalMountId(partScript.GetID()) && mountedVisual != null)
            {
                EnsureProchargerMountFasteners(partScript, mountedVisual);
                AddUnmountVisibilityTargets(partScript, mountedVisual);
            }
            if (mountedVisual != null) UpdateMountedInductionSelectionCollider(partScript, mountedVisual);
        }

        private void RestoreMountedProchargerPart(PartScript partScript)
        {
            if (partScript == null) return;
            mountedProchargerParts.Remove(partScript);
            int stateKey = partScript.GetInstanceID();
            mountedVisualModes.Remove(stateKey);
            Transform visual = partScript.transform.Find(InstalledInductionVisualName);
            if (visual != null)
            {
                RemoveUnmountVisibilityTargets(partScript, visual);
                visual.gameObject.SetActive(false);
                visual.gameObject.name = InstalledInductionVisualName + " Removed";
                UnityEngine.Object.Destroy(visual.gameObject);
            }

            if (IsUniversalMountId(partScript.GetID()))
            {
                RemoveProchargerMountFasteners(partScript);
                SetPartField(partScript, "oneClickUnmount", true);
                SetPartField(partScript, "MountObjects", new MountObject[0]);
            }

            List<ProchargerRendererState> states;
            if (prochargerRendererStates.TryGetValue(stateKey, out states))
            {
                for (int i = 0; i < states.Count; i++)
                    if (states[i].renderer != null) states[i].renderer.enabled = states[i].enabled;
                prochargerRendererStates.Remove(stateKey);
            }
            ResetMountedInductionSelectionCollider(partScript);
        }

        private void UpdateMountedInductionSelectionCollider(PartScript partScript, Transform visual)
        {
            if (partScript == null || visual == null) return;
            bool universalMount = IsUniversalMountId(partScript.GetID());
            BoxCollider hitbox = null;
            if (universalMount)
                hitbox = partScript.GetComponent<BoxCollider>();
            else
            {
                int partKey = partScript.GetInstanceID();
                mountedSelectionHitboxes.TryGetValue(partKey, out hitbox);
                if (hitbox == null)
                {
                    hitbox = partScript.gameObject.AddComponent<BoxCollider>();
                    mountedSelectionHitboxes[partKey] = hitbox;
                }
            }
            if (hitbox == null) hitbox = partScript.gameObject.AddComponent<BoxCollider>();
            hitbox.center = Vector3.zero;
            hitbox.size = new Vector3(0.28f, 0.18f, 0.18f);

            Bounds bounds;
            if (TryGetLocalRendererBounds(visual.GetComponentsInChildren<Renderer>(true), partScript.transform, out bounds))
            {
                Vector3 size = Vector3.Max(bounds.size * 1.14f, new Vector3(0.06f, 0.06f, 0.06f));
                hitbox.center = bounds.center;
                hitbox.size = size;
            }
            hitbox.enabled = true;
            partScript.gameObject.layer = PartSelectionLayer;
        }

        private void ResetMountedInductionSelectionCollider(PartScript partScript)
        {
            if (partScript == null) return;
            if (!IsUniversalMountId(partScript.GetID()))
            {
                int partKey = partScript.GetInstanceID();
                BoxCollider selectionCollider;
                if (mountedSelectionHitboxes.TryGetValue(partKey, out selectionCollider))
                {
                    if (selectionCollider != null) UnityEngine.Object.Destroy(selectionCollider);
                    mountedSelectionHitboxes.Remove(partKey);
                }
                return;
            }
            BoxCollider hitbox = partScript.GetComponent<BoxCollider>();
            if (hitbox == null) hitbox = partScript.gameObject.AddComponent<BoxCollider>();
            hitbox.center = Vector3.zero;
            hitbox.size = new Vector3(0.28f, 0.18f, 0.18f);
            hitbox.enabled = true;
        }

        private void RefreshMountedProchargerVisuals()
        {
            List<PartScript> stale = new List<PartScript>();
            foreach (PartScript partScript in mountedProchargerParts)
            {
                if (partScript == null)
                {
                    stale.Add(partScript);
                    continue;
                }
                Transform visual = partScript.transform.Find(InstalledInductionVisualName);
                if (visual == null) continue;
                // CMS marks a replacement as "unmounted" while it is being chosen
                // from Parts Overview. Keep its custom mesh visible during that step;
                // the parent GameObject still controls visibility when it leaves the car.
                if (!visual.gameObject.activeSelf) visual.gameObject.SetActive(true);
            }
            for (int i = 0; i < stale.Count; i++) mountedProchargerParts.Remove(stale[i]);
        }

        private static void AddUnmountVisibilityTarget(PartScript partScript, GameObject target)
        {
            FieldInfo field = typeof(PartScript).GetField("hideWhenUnmontingMounting", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (System.Object.ReferenceEquals(field, null) || partScript == null || target == null) return;
            GameObject[] current = field.GetValue(partScript) as GameObject[];
            if (current != null)
                for (int i = 0; i < current.Length; i++)
                    if (current[i] == target) return;
            int count = current == null ? 0 : current.Length;
            GameObject[] updated = new GameObject[count + 1];
            if (count > 0) Array.Copy(current, updated, count);
            updated[count] = target;
            field.SetValue(partScript, updated);
        }

        private static void AddUnmountVisibilityTargets(PartScript partScript, Transform visualRoot)
        {
            if (partScript == null || visualRoot == null) return;
            Renderer[] renderers = visualRoot.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer != null && !IsMountObjectRenderer(renderer))
                    AddUnmountVisibilityTarget(partScript, renderer.gameObject);
            }
        }

        private void RemoveProchargerMountFasteners(PartScript part)
        {
            if (part == null) return;
            Transform[] descendants = part.GetComponentsInChildren<Transform>(true);
            for (int i = descendants.Length - 1; i >= 0; i--)
            {
                Transform fastener = descendants[i];
                if (fastener == null || fastener == part.transform
                    || !fastener.name.StartsWith(ProchargerMountFastenerPrefix, StringComparison.Ordinal)) continue;
                Renderer[] renderers = fastener.GetComponentsInChildren<Renderer>(true);
                for (int rendererIndex = 0; rendererIndex < renderers.Length; rendererIndex++)
                    if (renderers[rendererIndex] != null)
                        RemoveUnmountVisibilityTarget(part, renderers[rendererIndex].gameObject);
                MountObject mountObject = fastener.GetComponent<MountObject>();
                if (mountObject != null) mountObject.SetCanBeUnmount(false);
                fastener.gameObject.SetActive(false);
                UnityEngine.Object.Destroy(fastener.gameObject);
            }
        }

        private static void RemoveUnmountVisibilityTarget(PartScript partScript, GameObject target)
        {
            FieldInfo field = typeof(PartScript).GetField("hideWhenUnmontingMounting", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (System.Object.ReferenceEquals(field, null) || partScript == null || target == null) return;
            GameObject[] current = field.GetValue(partScript) as GameObject[];
            if (current == null || current.Length == 0) return;
            List<GameObject> updated = new List<GameObject>();
            for (int i = 0; i < current.Length; i++)
                if (current[i] != null && current[i] != target) updated.Add(current[i]);
            field.SetValue(partScript, updated.ToArray());
        }

        private static void RemoveUnmountVisibilityTargets(PartScript partScript, Transform visualRoot)
        {
            if (partScript == null || visualRoot == null) return;
            Renderer[] renderers = visualRoot.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer != null) RemoveUnmountVisibilityTarget(partScript, renderer.gameObject);
            }
        }
        private bool TryAttachInductionVisual(GameObject partRoot, Transform visualAnchor, bool captureRendererState, InductionMode mode)
        {
            if (visualAnchor == null || mode != InductionMode.Procharger) return false;
            Transform existingVisual = visualAnchor.Find(InstalledInductionVisualName);
            if (existingVisual != null)
            {
                PartScript existingPartScript = visualAnchor.GetComponent<PartScript>();
                if (existingPartScript != null)
                {
                    AddUnmountVisibilityTargets(existingPartScript, existingVisual);
                    if (captureRendererState && IsUniversalMountId(existingPartScript.GetID()))
                        EnsureProchargerMountFasteners(existingPartScript, existingVisual);
                }
                return true;
            }
            if (!inductionModelLoadAttempted.Contains(mode))
            {
                inductionModelLoadAttempted.Add(mode);
                BuildInductionModelAsset(mode, "CMS18_ProCharger_P1X_AddOn.obj", "P-1X Style ProCharger");
            }

            Mesh mesh;
            Material[] materials;
            if (!inductionModelMeshes.TryGetValue(mode, out mesh) || mesh == null
                || !inductionModelMaterials.TryGetValue(mode, out materials) || materials == null) return false;

            Renderer[] stockRenderers = partRoot.GetComponentsInChildren<Renderer>(true);
            Bounds localBounds;
            bool hasBounds = TryGetLocalRendererBounds(stockRenderers, visualAnchor, out localBounds);
            Quaternion modelRotation = Quaternion.identity;
            float scale = ProchargerModelUnitScale;

            GameObject visual = new GameObject(InstalledInductionVisualName);
            visual.transform.SetParent(visualAnchor, false);
            visual.layer = partRoot.layer;
            visual.transform.localRotation = modelRotation;
            visual.transform.localScale = Vector3.one * scale;
            visual.transform.localPosition = (hasBounds ? localBounds.center : Vector3.zero)
                - modelRotation * (mesh.bounds.center * scale);
            MeshFilter filter = visual.AddComponent<MeshFilter>();
            filter.sharedMesh = mesh;
            MeshRenderer renderer = visual.AddComponent<MeshRenderer>();
            renderer.sharedMaterials = materials;
            ConfigureInductionRenderer(renderer);
            PartScript visualPartScript = visualAnchor.GetComponent<PartScript>();
            if (captureRendererState && visualPartScript != null)
            {
                int stateKey = visualPartScript.GetInstanceID();
                if (!prochargerRendererStates.ContainsKey(stateKey))
                {
                    List<ProchargerRendererState> states = new List<ProchargerRendererState>();
                    for (int i = 0; i < stockRenderers.Length; i++)
                        if (stockRenderers[i] != null && stockRenderers[i].GetComponent<MountObject>() == null)
                            states.Add(new ProchargerRendererState(stockRenderers[i]));
                    prochargerRendererStates[stateKey] = states;
                }
            }
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;

            for (int i = 0; i < stockRenderers.Length; i++)
            {
                if (stockRenderers[i] != null && stockRenderers[i].GetComponent<MountObject>() == null)
                    stockRenderers[i].enabled = false;
            }
            if (captureRendererState && mode == InductionMode.Procharger && visualPartScript != null)
            {
                Transform engineRoot = FindEngineRootTransform(visualAnchor);
                if (engineRoot != null && engineRoot.name.StartsWith("engine_", StringComparison.OrdinalIgnoreCase))
                    AlignProchargerVisualToCrank(visual.transform, engineRoot);
                AddProchargerDriveVisuals(visualPartScript, visual.transform);
            }
            if (visualPartScript != null) AddUnmountVisibilityTargets(visualPartScript, visual.transform);
            return true;
        }

        private static bool TryGetLocalRendererBounds(Renderer[] renderers, Transform relativeTo, out Bounds localBounds)
        {
            localBounds = new Bounds(Vector3.zero, Vector3.zero);
            if (renderers == null || relativeTo == null) return false;
            bool initialized = false;
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null || renderer.bounds.size.sqrMagnitude < 0.000001f) continue;
                Bounds worldBounds = renderer.bounds;
                for (int corner = 0; corner < 8; corner++)
                {
                    Vector3 point = new Vector3(
                        (corner & 1) == 0 ? worldBounds.min.x : worldBounds.max.x,
                        (corner & 2) == 0 ? worldBounds.min.y : worldBounds.max.y,
                        (corner & 4) == 0 ? worldBounds.min.z : worldBounds.max.z);
                    Vector3 localPoint = relativeTo.InverseTransformPoint(point);
                    if (!initialized)
                    {
                        localBounds = new Bounds(localPoint, Vector3.zero);
                        initialized = true;
                    }
                    else
                    {
                        localBounds.Encapsulate(localPoint);
                    }
                }
            }
            return initialized;
        }

        private void BuildInductionModelAsset(InductionMode mode, string resourceName, string modelName)
        {
            Stream stream = null;
            Mesh mesh = null;
            List<Material> materials = new List<Material>();
            try
            {
                stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName);
                if (stream == null)
                {
                    Logger.LogWarning("Embedded " + modelName + " OBJ was not found; using the procedural preview.");
                    return;
                }

                List<Vector3> sourcePositions = new List<Vector3>();
                List<Vector3> sourceNormals = new List<Vector3>();
                List<Vector2> sourceTexCoords = new List<Vector2>();
                List<Vector3> vertices = new List<Vector3>();
                List<Vector3> normals = new List<Vector3>();
                List<Vector2> texCoords = new List<Vector2>();
                List<string> materialNames = new List<string>();
                List<List<int>> submeshTriangles = new List<List<int>>();
                Dictionary<string, int> materialSlots = new Dictionary<string, int>(StringComparer.Ordinal);
                HashSet<int> outletBorePositionIndices = new HashSet<int>();
                HashSet<int> outletBeadPositionIndices = new HashSet<int>();
                string currentObjectName = String.Empty;

                int materialSlot = AddMaterialSlot("Steel", materialSlots, materialNames, submeshTriangles);
                bool completeNormals = true;
                using (StreamReader reader = new StreamReader(stream))
                {
                    stream = null;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        line = line.Trim();
                        if (line.Length == 0 || line[0] == '#') continue;
                        string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length == 0) continue;

                        if (parts[0] == "o" && parts.Length >= 2)
                        {
                            currentObjectName = String.Join(" ", parts, 1, parts.Length - 1);
                        }
                        else if (parts[0] == "v" && parts.Length >= 4)
                        {
                            sourcePositions.Add(new Vector3(ParseObjFloat(parts[1]), ParseObjFloat(parts[2]), ParseObjFloat(parts[3])));
                        }
                        else if (parts[0] == "vn" && parts.Length >= 4)
                        {
                            sourceNormals.Add(new Vector3(ParseObjFloat(parts[1]), ParseObjFloat(parts[2]), ParseObjFloat(parts[3])));
                        }
                        else if (parts[0] == "vt" && parts.Length >= 3)
                        {
                            sourceTexCoords.Add(new Vector2(ParseObjFloat(parts[1]), ParseObjFloat(parts[2])));
                        }
                        else if (parts[0] == "usemtl" && parts.Length >= 2)
                        {
                            materialSlot = AddMaterialSlot(parts[1], materialSlots, materialNames, submeshTriangles);
                        }
                        else if (parts[0] == "f" && parts.Length >= 4)
                        {
                            List<ObjCorner> face = new List<ObjCorner>();
                            bool validFace = true;
                            for (int i = 1; i < parts.Length; i++)
                            {
                                ObjCorner corner;
                                if (!TryParseObjCorner(parts[i], sourcePositions.Count, sourceTexCoords.Count, sourceNormals.Count, out corner))
                                {
                                    validFace = false;
                                    break;
                                }
                                face.Add(corner);
                            }
                            if (!validFace || face.Count < 3) continue;

                            for (int triangle = 1; triangle < face.Count - 1; triangle++)
                            {
                                if (mode == InductionMode.Procharger)
                                {
                                    if (String.Equals(currentObjectName, "P-1X_2.62_inch_outlet_bore", StringComparison.Ordinal))
                                    {
                                        outletBorePositionIndices.Add(face[0].position);
                                        outletBorePositionIndices.Add(face[triangle].position);
                                        outletBorePositionIndices.Add(face[triangle + 1].position);
                                    }
                                    else if (String.Equals(currentObjectName, "P-1X_three-inch_outlet_bead", StringComparison.Ordinal))
                                    {
                                        outletBeadPositionIndices.Add(face[0].position);
                                        outletBeadPositionIndices.Add(face[triangle].position);
                                        outletBeadPositionIndices.Add(face[triangle + 1].position);
                                    }
                                }
                                AppendObjCorner(face[0], sourcePositions, sourceTexCoords, sourceNormals, vertices, texCoords, normals, submeshTriangles[materialSlot], ref completeNormals);
                                AppendObjCorner(face[triangle], sourcePositions, sourceTexCoords, sourceNormals, vertices, texCoords, normals, submeshTriangles[materialSlot], ref completeNormals);
                                AppendObjCorner(face[triangle + 1], sourcePositions, sourceTexCoords, sourceNormals, vertices, texCoords, normals, submeshTriangles[materialSlot], ref completeNormals);
                            }
                        }
                    }
                }

                if (vertices.Count == 0)
                {
                    Logger.LogWarning("Embedded " + modelName + " OBJ had no usable faces; using the procedural preview.");
                    return;
                }

                mesh = new Mesh();
                mesh.name = "CMS18 " + modelName + " Add-On";
                mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                mesh.vertices = vertices.ToArray();
                mesh.uv = texCoords.ToArray();
                if (completeNormals) mesh.normals = normals.ToArray();
                else mesh.RecalculateNormals();
                mesh.subMeshCount = materialNames.Count;
                for (int i = 0; i < materialNames.Count; i++) mesh.SetTriangles(submeshTriangles[i].ToArray(), i);
                mesh.RecalculateBounds();

                if (mode == InductionMode.Procharger)
                {
                    Vector3 outletCenter;
                    Vector3 outletDirection;
                    float outletInnerRadius;
                    Vector3 outwardHint = ProchargerChargePipeOutlet - ProchargerModelBoundsCenter;
                    if (TryGetObjCircularPortGeometry(sourcePositions, outletBorePositionIndices, outwardHint,
                        out outletCenter, out outletDirection, out outletInnerRadius))
                    {
                        ProchargerChargePipeOutlet = outletCenter;
                        ProchargerChargePipeDirection = outletDirection;
                        ProchargerChargePipeInnerRadiusModel = outletInnerRadius;
                    }
                    else
                    {
                        Logger.LogWarning("Could not recover the P-1X outlet-bore center from the model; using the validated fallback socket.");
                    }

                    Vector3 beadCenter;
                    Vector3 beadDirection;
                    float outletOuterRadius;
                    if (TryGetObjCircularPortGeometry(sourcePositions, outletBeadPositionIndices,
                        ProchargerChargePipeDirection, out beadCenter, out beadDirection, out outletOuterRadius))
                    {
                        ProchargerChargePipeOuterRadiusModel = Mathf.Min(outletOuterRadius,
                            ProchargerOutletHoseDiameterMeters * 0.5f / ProchargerModelUnitScale);
                    }
                    else
                    {
                        ProchargerChargePipeOuterRadiusModel = ProchargerOutletHoseDiameterMeters
                            * 0.5f / ProchargerModelUnitScale;
                        Logger.LogWarning("Could not recover the P-1X outlet-bead radius from the model; using the published 3-inch outlet size.");
                    }
                    Logger.LogInfo("Derived P-1X charge-pipe socket from the embedded outlet geometry: center "
                        + ProchargerChargePipeOutlet.ToString("F3") + ", direction "
                        + ProchargerChargePipeDirection.ToString("F3") + ", bore radius "
                        + ProchargerChargePipeInnerRadiusModel.ToString("F3") + ", bead radius "
                        + ProchargerChargePipeOuterRadiusModel.ToString("F3") + " model units.");
                }

                Shader shader = Shader.Find("Standard");
                if (shader == null) shader = Shader.Find("Legacy Shaders/Diffuse");
                if (shader == null)
                {
                    Logger.LogWarning("No supported Unity shader was found for the " + modelName + " model.");
                    UnityEngine.Object.Destroy(mesh);
                    return;
                }

                for (int i = 0; i < materialNames.Count; i++)
                {
                    Material material = new Material(shader);
                    material.name = "CMS18 " + modelName + " " + materialNames[i];
                    material.color = ObjMaterialColor(materialNames[i]);
                    if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", ObjMaterialGlossiness(materialNames[i]));
                    if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", ObjMaterialMetallic(materialNames[i]));
                    ConfigureOpaqueStandardMaterial(material);
                    materials.Add(material);
                }

                inductionModelMeshes[mode] = mesh;
                inductionModelMaterials[mode] = materials.ToArray();
            }
            catch (Exception exception)
            {
                if (mesh != null) UnityEngine.Object.Destroy(mesh);
                for (int i = 0; i < materials.Count; i++) if (materials[i] != null) UnityEngine.Object.Destroy(materials[i]);
                Logger.LogWarning("Could not load the " + modelName + " preview; using the procedural model. " + exception.Message);
            }
            finally
            {
                if (stream != null) stream.Dispose();
            }
        }

        private static int AddMaterialSlot(string name, Dictionary<string, int> slots, List<string> names, List<List<int>> triangles)
        {
            int slot;
            if (slots.TryGetValue(name, out slot)) return slot;
            slot = names.Count;
            slots.Add(name, slot);
            names.Add(name);
            triangles.Add(new List<int>());
            return slot;
        }

        private static float ParseObjFloat(string value)
        {
            return Single.Parse(value, CultureInfo.InvariantCulture);
        }

        private static int ResolveObjIndex(string value, int count)
        {
            if (String.IsNullOrEmpty(value)) return -1;
            int index = Int32.Parse(value, CultureInfo.InvariantCulture);
            return index > 0 ? index - 1 : count + index;
        }

        private static bool TryParseObjCorner(string value, int positionCount, int texCoordCount, int normalCount, out ObjCorner corner)
        {
            corner = new ObjCorner();
            string[] indices = value.Split('/');
            if (indices.Length == 0) return false;
            corner.position = ResolveObjIndex(indices[0], positionCount);
            corner.texCoord = indices.Length > 1 ? ResolveObjIndex(indices[1], texCoordCount) : -1;
            corner.normal = indices.Length > 2 ? ResolveObjIndex(indices[2], normalCount) : -1;
            return corner.position >= 0 && corner.position < positionCount
                && (corner.texCoord < 0 || corner.texCoord < texCoordCount)
                && (corner.normal < 0 || corner.normal < normalCount);
        }

        private static void AppendObjCorner(ObjCorner corner, List<Vector3> sourcePositions, List<Vector2> sourceTexCoords, List<Vector3> sourceNormals, List<Vector3> vertices, List<Vector2> texCoords, List<Vector3> normals, List<int> triangles, ref bool completeNormals)
        {
            vertices.Add(sourcePositions[corner.position]);
            texCoords.Add(corner.texCoord >= 0 ? sourceTexCoords[corner.texCoord] : Vector2.zero);
            if (corner.normal >= 0) normals.Add(sourceNormals[corner.normal]);
            else
            {
                normals.Add(Vector3.zero);
                completeNormals = false;
            }
            triangles.Add(vertices.Count - 1);
        }

        private static Color ObjMaterialColor(string name)
        {
            if (name == "Charge_pipe_blue") return new Color(0.300f, 0.340f, 0.365f, 1.0f);
            if (name == "Brass_fasteners") return new Color(0.390f, 0.285f, 0.155f, 1.0f);
            if (name == "Cast_iron_hot_side") return new Color(0.190f, 0.180f, 0.160f, 1.0f);
            if (name == "Dark_inlet" || name == "Black_belt_rubber" || name == "Dark_gasket") return new Color(0.035f, 0.040f, 0.042f, 1.0f);
            if (name == "Cast_aluminum") return new Color(0.630f, 0.640f, 0.640f, 1.0f);
            if (name == "Machined_aluminum") return new Color(0.740f, 0.750f, 0.750f, 1.0f);
            if (name == "Bright_cast_compressor_aluminum") return new Color(0.800f, 0.810f, 0.810f, 1.0f);
            if (name == "Steel") return new Color(0.600f, 0.610f, 0.615f, 1.0f);
            return new Color(0.485f, 0.495f, 0.490f, 1.0f);
        }

        private static float ObjMaterialGlossiness(string name)
        {
            if (name == "Black_belt_rubber" || name == "Dark_gasket") return 0.20f;
            if (name == "Cast_iron_hot_side") return 0.34f;
            if (name == "Cast_aluminum") return 0.78f;
            if (name == "Bright_cast_compressor_aluminum") return 0.96f;
            if (name == "Dark_inlet") return 0.32f;
            if (name == "Charge_pipe_blue") return 0.66f;
            if (name == "Machined_aluminum") return 0.94f;
            if (name == "Steel") return 0.88f;
            if (name == "Brass_fasteners") return 0.64f;
            return 0.50f;
        }

        private static float ObjMaterialMetallic(string name)
        {
            if (name == "Dark_inlet" || name == "Dark_gasket" || name == "Black_belt_rubber") return 0.03f;
            if (name == "Charge_pipe_blue") return 0.52f;
            if (name == "Cast_iron_hot_side") return 0.56f;
            if (name == "Cast_aluminum") return 0.80f;
            if (name == "Bright_cast_compressor_aluminum") return 0.94f;
            if (name == "Steel") return 0.88f;
            if (name == "Brass_fasteners") return 0.78f;
            if (name == "Machined_aluminum") return 0.88f;
            return 0.60f;
        }

        private static void ConfigureInductionRenderer(Renderer renderer)
        {
            if (renderer == null) return;
            renderer.reflectionProbeUsage = UnityEngine.Rendering.ReflectionProbeUsage.BlendProbesAndSkybox;
            renderer.lightProbeUsage = UnityEngine.Rendering.LightProbeUsage.BlendProbes;
            renderer.receiveShadows = true;
        }

        private static void ConfigureOpaqueStandardMaterial(Material material)
        {
            if (material == null) return;
            if (material.HasProperty("_Mode")) material.SetFloat("_Mode", 0.0f);
            if (material.HasProperty("_SrcBlend")) material.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.One);
            if (material.HasProperty("_DstBlend")) material.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.Zero);
            if (material.HasProperty("_ZWrite")) material.SetFloat("_ZWrite", 1.0f);
            if (material.HasProperty("_GlossyReflections")) material.SetFloat("_GlossyReflections", 1.0f);
            if (material.HasProperty("_SpecularHighlights")) material.SetFloat("_SpecularHighlights", 1.0f);
            material.SetOverrideTag("RenderType", "Opaque");
            material.DisableKeyword("_ALPHATEST_ON");
            material.DisableKeyword("_ALPHABLEND_ON");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            material.renderQueue = 2000;
        }

        private void DestroyInductionModelAssets()
        {
            foreach (Mesh mesh in inductionModelMeshes.Values)
            {
                if (mesh != null) UnityEngine.Object.Destroy(mesh);
            }
            inductionModelMeshes.Clear();
            foreach (Material[] materials in inductionModelMaterials.Values)
            {
                for (int i = 0; i < materials.Length; i++)
                    if (materials[i] != null) UnityEngine.Object.Destroy(materials[i]);
            }
            inductionModelMaterials.Clear();
            inductionModelLoadAttempted.Clear();
        }

        private Transform FindVisualParent()
        {
            if (standOccupied)
            {
                try
                {
                    GameScript game = GameScript.Get();
                    List<GameObject> objects = game == null ? null : game.GetObjectsOnEngineStand();
                    if (objects != null)
                    {
                        for (int i = 0; i < objects.Count; i++)
                        {
                            if (objects[i] != null && objects[i].GetComponentInChildren<PartScript>() != null)
                            {
                                return objects[i].transform;
                            }
                        }
                        if (objects.Count > 0 && objects[0] != null) return objects[0].transform;
                    }
                }
                catch { }
            }

            VPVehicleController linkedController;
            CarLoader loader = FindActiveCarLoader(out linkedController);
            if (linkedController != null) activeController = linkedController;
            if (loader != null)
            {
                GameObject engineObject = loader.GetEngine();
                if (engineObject != null) return engineObject.transform;
            }
            return activeController == null ? null : activeController.transform;
        }

        private void RemoveVisual()
        {
            foreach (BoxCollider hitbox in standPreviewHitboxes)
            {
                if (hitbox == null) continue;
                hitbox.enabled = false;
                UnityEngine.Object.Destroy(hitbox);
            }
            standPreviewHitboxes.Clear();
            foreach (KeyValuePair<int, List<ProchargerRendererState>> entry in standPreviewRendererStates)
            {
                List<ProchargerRendererState> states = entry.Value;
                for (int i = 0; states != null && i < states.Count; i++)
                {
                    Renderer renderer = states[i].renderer;
                    if (renderer != null) renderer.enabled = states[i].enabled;
                }
            }
            standPreviewRendererStates.Clear();
            if (visualRoot != null)
            {
                UnityEngine.Object.Destroy(visualRoot);
                visualRoot = null;
            }
            visualMode = InductionMode.Off;
        }

        private float GetUiScale()
        {
            return Mathf.Clamp(Mathf.Min(Screen.width / 1600.0f, Screen.height / 900.0f), 0.75f, 1.0f);
        }

        private Texture2D CreateUiTexture(Color color)
        {
            Texture2D texture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            texture.name = "CMS18 Turbo UI";
            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.filterMode = FilterMode.Point;
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.SetPixel(0, 0, color);
            texture.Apply(false, true);
            uiTextures.Add(texture);
            return texture;
        }

        private Texture2D CreateBoostGaugeFaceTexture()
        {
            const int size = 160;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.name = "CMS18 manifold pressure gauge face";
            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.filterMode = FilterMode.Bilinear;
            texture.wrapMode = TextureWrapMode.Clamp;
            Color[] pixels = new Color[size * size];
            float center = (size - 1) * 0.5f;
            float outerRadius = size * 0.48f;
            float faceRadius = size * 0.425f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x - center;
                    float dy = y - center;
                    float radius = Mathf.Sqrt(dx * dx + dy * dy);
                    Color pixel = new Color(0.0f, 0.0f, 0.0f, 0.0f);
                    if (radius <= faceRadius)
                    {
                        float shade = 1.0f - Mathf.Clamp01(radius / faceRadius) * 0.11f;
                        pixel = new Color(0.035f * shade, 0.043f * shade, 0.051f * shade, 0.98f);
                    }
                    else if (radius <= outerRadius)
                    {
                        float rimShade = 0.38f + 0.22f * (1.0f - Mathf.Clamp01(Mathf.Abs(dy) / outerRadius));
                        pixel = new Color(rimShade, rimShade * 1.02f, rimShade * 1.04f, 0.96f);
                    }
                    pixels[y * size + x] = pixel;
                }
            }
            texture.SetPixels(pixels);
            texture.Apply(false, true);
            uiTextures.Add(texture);
            return texture;
        }

        private GUIStyle CreateUiStyle(GUIStyle source, Texture2D normal, Texture2D hover, Texture2D active, Color textColor, TextAnchor alignment, bool bold)
        {
            GUIStyle style = new GUIStyle(source);
            style.normal.background = normal;
            style.hover.background = hover == null ? normal : hover;
            style.active.background = active == null ? normal : active;
            style.focused.background = normal;
            style.normal.textColor = textColor;
            style.hover.textColor = textColor;
            style.active.textColor = textColor;
            style.focused.textColor = textColor;
            style.alignment = alignment;
            style.fontStyle = bold ? FontStyle.Bold : FontStyle.Normal;
            style.wordWrap = false;
            style.clipping = TextClipping.Clip;
            style.margin = new RectOffset(0, 0, 0, 0);
            return style;
        }

        private void EnsureUiStyles(float scale)
        {
            if (uiPanelStyle == null)
            {
                Color panelColor = new Color(0.055f, 0.064f, 0.074f, 0.94f);
                Color headerColor = new Color(0.115f, 0.132f, 0.149f, 0.98f);
                Color accentColor = new Color(0.86f, 0.39f, 0.15f, 1.0f);
                Color accentHover = new Color(0.98f, 0.50f, 0.21f, 1.0f);
                Color buttonColor = new Color(0.16f, 0.18f, 0.20f, 0.98f);
                Color buttonHover = new Color(0.23f, 0.25f, 0.27f, 1.0f);
                Color selectedColor = new Color(0.36f, 0.19f, 0.11f, 1.0f);
                Color trackColor = new Color(0.10f, 0.12f, 0.14f, 1.0f);
                Color textColor = new Color(0.91f, 0.92f, 0.91f, 1.0f);
                Color mutedColor = new Color(0.68f, 0.71f, 0.72f, 1.0f);

                Texture2D panelTexture = CreateUiTexture(panelColor);
                Texture2D headerTexture = CreateUiTexture(headerColor);
                Texture2D accentTexture = CreateUiTexture(accentColor);
                Texture2D hoverAccentTexture = CreateUiTexture(accentHover);
                Texture2D buttonTexture = CreateUiTexture(buttonColor);
                Texture2D buttonHoverTexture = CreateUiTexture(buttonHover);
                Texture2D selectedTexture = CreateUiTexture(selectedColor);
                Texture2D trackTexture = CreateUiTexture(trackColor);
                Texture2D gaugeTickTexture = CreateUiTexture(new Color(0.72f, 0.76f, 0.78f, 1.0f));
                Texture2D gaugeWarnTexture = CreateUiTexture(new Color(0.91f, 0.61f, 0.16f, 1.0f));
                Texture2D gaugeDangerTexture = CreateUiTexture(new Color(0.88f, 0.19f, 0.12f, 1.0f));

                uiPanelStyle = CreateUiStyle(GUI.skin.box, panelTexture, panelTexture, panelTexture, textColor, TextAnchor.UpperLeft, false);
                uiPanelStyle.padding = new RectOffset(0, 0, 0, 0);
                uiPanelStyle.border = new RectOffset(0, 0, 0, 0);
                uiHeaderBarStyle = CreateUiStyle(GUI.skin.box, headerTexture, headerTexture, headerTexture, textColor, TextAnchor.MiddleLeft, false);
                uiHeaderBarStyle.padding = new RectOffset(0, 0, 0, 0);
                uiHeaderBarStyle.border = new RectOffset(0, 0, 0, 0);
                uiAccentStyle = CreateUiStyle(GUI.skin.box, accentTexture, hoverAccentTexture, accentTexture, textColor, TextAnchor.MiddleLeft, false);
                uiAccentStyle.padding = new RectOffset(0, 0, 0, 0);
                uiAccentStyle.border = new RectOffset(0, 0, 0, 0);
                uiHeaderTextStyle = CreateUiStyle(GUI.skin.label, null, null, null, textColor, TextAnchor.MiddleLeft, true);
                uiBodyTextStyle = CreateUiStyle(GUI.skin.label, null, null, null, textColor, TextAnchor.MiddleLeft, false);
                uiMutedTextStyle = CreateUiStyle(GUI.skin.label, null, null, null, mutedColor, TextAnchor.MiddleLeft, false);
                uiButtonStyle = CreateUiStyle(GUI.skin.button, buttonTexture, buttonHoverTexture, selectedTexture, textColor, TextAnchor.MiddleCenter, false);
                uiSelectedButtonStyle = CreateUiStyle(GUI.skin.button, selectedTexture, accentTexture, accentTexture, textColor, TextAnchor.MiddleCenter, true);

                uiSliderStyle = new GUIStyle(GUI.skin.horizontalSlider);
                uiSliderStyle.normal.background = trackTexture;
                uiSliderStyle.hover.background = trackTexture;
                uiSliderStyle.active.background = trackTexture;
                uiSliderStyle.focused.background = trackTexture;
                uiSliderStyle.border = new RectOffset(2, 2, 2, 2);
                uiSliderThumbStyle = new GUIStyle(GUI.skin.horizontalSliderThumb);
                uiSliderThumbStyle.normal.background = accentTexture;
                uiSliderThumbStyle.hover.background = hoverAccentTexture;
                uiSliderThumbStyle.active.background = hoverAccentTexture;
                uiSliderThumbStyle.focused.background = accentTexture;

                uiGaugeTrackStyle = CreateUiStyle(GUI.skin.box, trackTexture, trackTexture, trackTexture, textColor, TextAnchor.MiddleLeft, false);
                uiGaugeTrackStyle.padding = new RectOffset(0, 0, 0, 0);
                uiGaugeTrackStyle.border = new RectOffset(0, 0, 0, 0);
                uiGaugeFillStyle = CreateUiStyle(GUI.skin.box, accentTexture, accentTexture, accentTexture, textColor, TextAnchor.MiddleLeft, false);
                uiGaugeFillStyle.padding = new RectOffset(0, 0, 0, 0);
                uiGaugeFillStyle.border = new RectOffset(0, 0, 0, 0);
                uiGaugeTickStyle = CreateUiStyle(GUI.skin.box, gaugeTickTexture, gaugeTickTexture, gaugeTickTexture, textColor, TextAnchor.MiddleCenter, false);
                uiGaugeWarnTickStyle = CreateUiStyle(GUI.skin.box, gaugeWarnTexture, gaugeWarnTexture, gaugeWarnTexture, textColor, TextAnchor.MiddleCenter, false);
                uiGaugeDangerTickStyle = CreateUiStyle(GUI.skin.box, gaugeDangerTexture, gaugeDangerTexture, gaugeDangerTexture, textColor, TextAnchor.MiddleCenter, false);
                uiGaugeNeedleStyle = CreateUiStyle(GUI.skin.box, accentTexture, accentTexture, accentTexture, textColor, TextAnchor.MiddleCenter, false);
                boostGaugeFaceTexture = CreateBoostGaugeFaceTexture();
            }

            int smallSize = Mathf.Max(10, Mathf.RoundToInt(12.0f * scale));
            int bodySize = Mathf.Max(11, Mathf.RoundToInt(13.0f * scale));
            uiHeaderTextStyle.fontSize = Mathf.Max(12, Mathf.RoundToInt(15.0f * scale));
            uiBodyTextStyle.fontSize = bodySize;
            uiMutedTextStyle.fontSize = smallSize;
            uiButtonStyle.fontSize = smallSize;
            uiSelectedButtonStyle.fontSize = smallSize;
            uiSliderStyle.fixedHeight = Mathf.Max(5.0f, 6.0f * scale);
            uiSliderThumbStyle.fixedWidth = Mathf.Max(10.0f, 12.0f * scale);
            uiSliderThumbStyle.fixedHeight = Mathf.Max(12.0f, 15.0f * scale);
        }

        private void DrawUiPanel(Rect rect, string title, float scale)
        {
            GUI.Box(rect, GUIContent.none, uiPanelStyle);
            GUI.Box(new Rect(rect.x + 3.0f * scale, rect.y + 3.0f * scale, rect.width - 6.0f * scale, 27.0f * scale), GUIContent.none, uiHeaderBarStyle);
            GUI.Box(new Rect(rect.x, rect.y + 3.0f * scale, 3.0f * scale, 27.0f * scale), GUIContent.none, uiAccentStyle);
            GUI.Label(new Rect(rect.x + 13.0f * scale, rect.y + 5.0f * scale, rect.width - 26.0f * scale, 22.0f * scale), title, uiHeaderTextStyle);
        }

        private void DrawModeButton(Rect rect, InductionMode mode)
        {
            InductionMode currentMode = !standOccupied && !String.IsNullOrEmpty(activeCarKey) ? activeMode : selectedMode;
            GUIStyle style = currentMode == mode ? uiSelectedButtonStyle : uiButtonStyle;
            if (GUI.Button(rect, ModeName(mode), style)) SetMode(mode);
        }

        private void DrawStandPanel(float scale)
        {
            float width = 500.0f * scale;
            float height = 224.0f * scale;
            float x = 20.0f * scale;
            float y = Mathf.Max(18.0f * scale, Screen.height - height - 20.0f * scale);
            Rect panel = new Rect(x, y, width, height);
            DrawUiPanel(panel, "ENGINE STAND   /   PROCHARGER P-1X", scale);
            GUI.Label(new Rect(x + 13.0f * scale, y + 38.0f * scale, width - 26.0f * scale, 20.0f * scale), cachedStandEngineText, uiBodyTextStyle);

            float buttonX = x + 12.0f * scale;
            float buttonY = y + 61.0f * scale;
            float buttonHeight = 29.0f * scale;
            float gap = 5.0f * scale;
            float currentX = buttonX;
            for (int i = 0; i < ModeButtons.Length; i++)
            {
                float buttonWidth = StandModeButtonWidths[i] * scale;
                DrawModeButton(new Rect(currentX, buttonY, buttonWidth, buttonHeight), ModeButtons[i]);
                currentX += buttonWidth + gap;
            }

            GUI.Label(new Rect(x + 13.0f * scale, y + 101.0f * scale, 145.0f * scale, 20.0f * scale), cachedStandBoostText, uiBodyTextStyle);
            Color oldColor = GUI.color;
            GUI.color = Color.white;
            float sliderX = x + 162.0f * scale;
            float sliderWidth = width - 178.0f * scale;
            float psiLimit = GetCurrentControlBoostLimit();
            bool controlsWereEnabled = GUI.enabled;
            GUI.enabled = controlsWereEnabled && selectedMode == InductionMode.Procharger;
            float psi = GUI.HorizontalSlider(new Rect(sliderX, y + 106.0f * scale, sliderWidth, 17.0f * scale), selectedBoostPsi, 0.0f, psiLimit, uiSliderStyle, uiSliderThumbStyle);
            GUI.enabled = controlsWereEnabled;
            GUI.color = oldColor;
            psi = Mathf.Round(psi * 2.0f) * 0.5f;
            if (Mathf.Abs(psi - selectedBoostPsi) > 0.1f) SetBoostPsi(psi);

            GUI.Label(new Rect(x + 13.0f * scale, y + 169.0f * scale, width - 26.0f * scale, 18.0f * scale), "Setup follows this engine when it is transferred to a car.", uiMutedTextStyle);
            GUI.Label(new Rect(x + 13.0f * scale, y + 192.0f * scale, width - 26.0f * scale, 18.0f * scale), cachedStandStatusText, uiMutedTextStyle);
        }



        private void DrawBoostGauge(float scale)
        {
            if (activeController == null || standOccupied || activeMode == InductionMode.Off) return;
            float width = 460.0f * scale;
            float height = 328.0f * scale;
            float x = Mathf.Max(18.0f * scale, Screen.width - width - 20.0f * scale);
            float y = 20.0f * scale;
            Rect panel = new Rect(x, y, width, height);
            DrawUiPanel(panel, "PROCHARGER / MANIFOLD PRESSURE  (inHg vacuum / psi boost)", scale);

            float buttonX = x + 12.0f * scale;
            float buttonY = y + 37.0f * scale;
            float gap = 4.0f * scale;
            float currentX = buttonX;
            for (int i = 0; i < ModeButtons.Length; i++)
            {
                float buttonWidth = GaugeModeButtonWidths[i] * scale;
                DrawModeButton(new Rect(currentX, buttonY, buttonWidth, 26.0f * scale), ModeButtons[i]);
                currentX += buttonWidth + gap;
            }

            Vector2 gaugeCenter = new Vector2(x + 91.0f * scale, y + 158.0f * scale);
            float gaugeMaxPsi = GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger);
            DrawBoostDial(gaugeCenter, 72.0f * scale, liveBoostPsi, gaugeMaxPsi, scale);

            float textX = x + 178.0f * scale;
            float textWidth = width - 190.0f * scale;
            GUI.Label(new Rect(textX, y + 83.0f * scale, textWidth, 23.0f * scale),
                cachedGaugeBoostText, uiHeaderTextStyle);
            GUI.Label(new Rect(textX, y + 106.0f * scale, textWidth, 19.0f * scale),
                cachedGaugeMapText, uiBodyTextStyle);
            GUI.Label(new Rect(textX, y + 128.0f * scale, textWidth, 20.0f * scale),
                cachedGaugePowerText, uiBodyTextStyle);
            GUI.Label(new Rect(textX, y + 152.0f * scale, textWidth, 19.0f * scale),
                cachedGaugeAirflowText, uiMutedTextStyle);
            GUI.Label(new Rect(textX, y + 176.0f * scale, textWidth, 19.0f * scale),
                cachedGaugeTargetText, uiBodyTextStyle);
            GUI.Label(new Rect(textX, y + 200.0f * scale, textWidth, 20.0f * scale),
                cachedGaugeRatingText, uiMutedTextStyle);
            GUI.Label(new Rect(textX, y + 224.0f * scale, textWidth, 17.0f * scale),
                "Pressure ratio uses 14.7 psia sea-level ambient.", uiMutedTextStyle);

            Color oldColor = GUI.color;
            GUI.color = Color.white;
            GUI.Label(new Rect(x + 14.0f * scale, y + 261.0f * scale, 92.0f * scale, 18.0f * scale),
                "Boost target", uiMutedTextStyle);
            float psiLimit = GetCurrentControlBoostLimit();
            float psi = GUI.HorizontalSlider(new Rect(x + 104.0f * scale, y + 261.0f * scale, width - 120.0f * scale, 17.0f * scale),
                selectedBoostPsi, 0.0f, psiLimit, uiSliderStyle, uiSliderThumbStyle);
            GUI.color = oldColor;
            psi = Mathf.Round(psi * 2.0f) * 0.5f;
            if (Mathf.Abs(psi - selectedBoostPsi) > 0.1f) SetBoostPsi(psi);
        }

        private void DrawInductionChooser(float scale)
        {
            if (!showInductionChooser) return;
            KeepChooserCursorAvailable();
            float width = Mathf.Min(540.0f * scale, Screen.width - 32.0f * scale);
            float height = 236.0f * scale;
            float x = (Screen.width - width) * 0.5f;
            float y = (Screen.height - height) * 0.5f;
            Rect panel = new Rect(x, y, width, height);
            Color oldTint = GUI.color;
            GUI.color = new Color(0.0f, 0.0f, 0.0f, 0.62f);
            GUI.DrawTexture(new Rect(0.0f, 0.0f, Screen.width, Screen.height), Texture2D.whiteTexture);
            GUI.color = oldTint;
            DrawUiPanel(panel, "ADD PROCHARGER P-1X", scale);
            GUI.Label(new Rect(x + 16.0f * scale, y + 39.0f * scale, width - 32.0f * scale,
                34.0f * scale), "Centrifugal supercharger kit. Set the target boost after selection.", uiBodyTextStyle);

            float buttonY = y + 89.0f * scale;
            float buttonH = 54.0f * scale;
            float buttonW = width - 28.0f * scale;
            Rect kitButton = new Rect(x + 14.0f * scale, buttonY, buttonW, buttonH);
            if (GUI.Button(kitButton, "ProCharger P-1X Centrifugal Supercharger", uiSelectedButtonStyle))
                pendingChooserMode = InductionMode.Procharger;

            GUI.Label(new Rect(x + 16.0f * scale, y + 155.0f * scale, width - 32.0f * scale,
                20.0f * scale), "Boost target", uiMutedTextStyle);
            float maxPsi = GetMaximumBoostPsi(pendingChooserMode,
                standOccupied ? standHasHighBoostProcharger : activeHasHighBoostProcharger);
            float psi = GUI.HorizontalSlider(new Rect(x + 112.0f * scale, y + 157.0f * scale,
                width - 222.0f * scale, 18.0f * scale), pendingChooserPsi, 0.0f, maxPsi,
                uiSliderStyle, uiSliderThumbStyle);
            psi = ProchargerMath.NormalizeBoostPsi(psi, maxPsi, selectedBoostPsi);
            psi = ProchargerMath.NormalizeBoostPsi(
                Mathf.Round(psi * 2.0f) * 0.5f, maxPsi, selectedBoostPsi);
            if (Mathf.Abs(psi - pendingChooserPsi) > 0.1f) pendingChooserPsi = psi;
            GUI.Label(new Rect(x + width - 100.0f * scale, y + 153.0f * scale,
                84.0f * scale, 22.0f * scale), pendingChooserPsi.ToString("F1", CultureInfo.InvariantCulture) + " psi", uiBodyTextStyle);
            if (GUI.Button(new Rect(x + width - 246.0f * scale, y + 190.0f * scale,
                108.0f * scale, 30.0f * scale), "Apply setup", uiSelectedButtonStyle))
            {
                selectedBoostPsi = pendingChooserPsi;
                SetMode(pendingChooserMode);
                CloseInductionChooser();
            }
            if (GUI.Button(new Rect(x + width - 126.0f * scale, y + 190.0f * scale,
                108.0f * scale, 30.0f * scale), "Cancel", uiButtonStyle))
                CloseInductionChooser();

            Event currentEvent = Event.current;
            if (currentEvent != null)
            {
                if (currentEvent.type == EventType.KeyDown && currentEvent.keyCode == KeyCode.Escape)
                {
                    CloseInductionChooser();
                    currentEvent.Use();
                }
                else if (currentEvent.type == EventType.MouseDown || currentEvent.type == EventType.MouseUp
                    || currentEvent.type == EventType.ScrollWheel)
                {
                    currentEvent.Use();
                }
            }
        }

        private void DrawBoostDial(Vector2 center, float radius, float pressurePsi, float maximumPsi, float scale)
        {
            // The dial contains only decorative drawing. Skip it during IMGUI layout and
            // input passes; buttons and sliders are drawn by the surrounding panel.
            if (Event.current == null || Event.current.type != EventType.Repaint) return;

            Rect faceRect = new Rect(center.x - radius, center.y - radius, radius * 2.0f, radius * 2.0f);
            if (boostGaugeFaceTexture != null)
                GUI.DrawTexture(faceRect, boostGaugeFaceTexture, ScaleMode.StretchToFill, true);

            float minimumPsi = BoostGaugeMinimumPsi;
            float usableMaximumPsi = Mathf.Max(10.0f, maximumPsi);
            for (int i = 0; ; i++)
            {
                float markPsi = minimumPsi + i * 2.0f;
                if (markPsi > usableMaximumPsi + 0.01f) break;
                float progress = (markPsi - minimumPsi) / (usableMaximumPsi - minimumPsi);
                float angle = 135.0f + progress * 270.0f;
                bool major = Mathf.Abs(markPsi % 10.0f) < 0.01f || Mathf.Abs(markPsi - usableMaximumPsi) < 0.01f;
                float tickWidth = (major ? 2.0f : 1.0f) * scale;
                float tickLength = (major ? 9.0f : 5.0f) * scale;
                GUIStyle tickStyle = markPsi >= usableMaximumPsi - 2.0f ? uiGaugeDangerTickStyle
                    : markPsi >= usableMaximumPsi - 8.0f ? uiGaugeWarnTickStyle
                    : uiGaugeTickStyle;
                Matrix4x4 previousMatrix = GUI.matrix;
                GUIUtility.RotateAroundPivot(angle + 90.0f, center);
                GUI.Box(new Rect(center.x - tickWidth * 0.5f, center.y - radius * 0.84f,
                    tickWidth, tickLength), GUIContent.none, tickStyle);
                GUI.matrix = previousMatrix;
            }

            for (int i = 0; i < BoostGaugeMajorPsiMarks.Length; i++)
            {
                float markPsi = BoostGaugeMajorPsiMarks[i];
                if (markPsi > usableMaximumPsi) continue;
                float progress = (markPsi - minimumPsi) / (usableMaximumPsi - minimumPsi);
                float angle = (135.0f + progress * 270.0f) * Mathf.Deg2Rad;
                float labelRadius = radius * 0.61f;
                Vector2 labelCenter = center + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * labelRadius;
                GUI.Label(new Rect(labelCenter.x - 13.0f * scale, labelCenter.y - 7.0f * scale,
                    26.0f * scale, 14.0f * scale), BoostGaugeMajorLabels[i], uiMutedTextStyle);
            }

            float needleProgress = Mathf.Clamp01((Mathf.Clamp(pressurePsi, minimumPsi, usableMaximumPsi) - minimumPsi)
                / (usableMaximumPsi - minimumPsi));
            float needleAngle = 135.0f + needleProgress * 270.0f;
            Matrix4x4 oldMatrix = GUI.matrix;
            GUIUtility.RotateAroundPivot(needleAngle + 90.0f, center);
            GUI.Box(new Rect(center.x - 1.5f * scale, center.y - radius * 0.70f,
                3.0f * scale, radius * 0.70f), GUIContent.none, uiGaugeNeedleStyle);
            GUI.matrix = oldMatrix;
            GUI.Box(new Rect(center.x - 5.0f * scale, center.y - 5.0f * scale,
                10.0f * scale, 10.0f * scale), GUIContent.none, uiGaugeNeedleStyle);
        }

        private void OnGUI()
        {
            float scale = GetUiScale();
            EnsureUiStyles(scale);
            Color oldColor = GUI.color;
            try
            {
                GUI.color = Color.white;
                DrawBoostGauge(scale);
                DrawInductionChooser(scale);
            }
            finally
            {
                GUI.color = oldColor;
            }
        }
        private void OnDestroy()
        {
            CloseInductionChooser();
            CloseMainMenuModsPanel();
            RemoveVisual();
            DestroyInductionModelAssets();
            if (prochargerDriveBeltMaterial != null) UnityEngine.Object.Destroy(prochargerDriveBeltMaterial);
            if (prochargerBracketMaterial != null) UnityEngine.Object.Destroy(prochargerBracketMaterial);
            if (prochargerChargePipeMaterial != null) UnityEngine.Object.Destroy(prochargerChargePipeMaterial);
            for (int i = 0; i < uiTextures.Count; i++)
            {
                if (uiTextures[i] != null) UnityEngine.Object.Destroy(uiTextures[i]);
            }
            uiTextures.Clear();
            uiPanelStyle = null;
            uiHeaderBarStyle = null;
            uiAccentStyle = null;
            uiHeaderTextStyle = null;
            uiBodyTextStyle = null;
            uiMutedTextStyle = null;
            uiButtonStyle = null;
            uiSelectedButtonStyle = null;
            uiSliderStyle = null;
            uiSliderThumbStyle = null;
            uiGaugeTrackStyle = null;
            uiGaugeFillStyle = null;
            if (harmony != null) harmony.UnpatchSelf();
            if (Instance == this) Instance = null;
        }

        public static bool InductionTunePartPrefix(PartScript __instance, ref string __0,
            ref bool __result, out string __state)
        {
            __state = __0;
            TurboPrototypePlugin plugin = Instance;
            // The vanilla TunePart implementation assumes every part ID has a stock
            // catalog record and prefab. Custom induction IDs do not, and loading a
            // saved custom part through that path can null-reference inside CMS.
            if (IsInductionPartId(__0))
            {
                __result = true;
                if (__instance != null) __instance.SetTunedID(__0);
                return false;
            }

            // The internal mount is only a visual/selection anchor. Clearing it must
            // not send a synthetic part through vanilla's stock inventory lookups.
            if (__instance != null && IsUniversalMountId(__instance.GetID())
                && (String.IsNullOrEmpty(__0) || IsUniversalMountId(__0)))
            {
                __instance.SetTunedID(String.Empty);
                __result = true;
                return false;
            }

            return true;
        }

        public static void InductionTunePartPostfix(PartScript __instance, string __state, bool __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null) return;
            if (IsInductionPartId(__state))
            {
                if (__result)
                {
                    plugin.ConfigureMountedInductionPart(__instance, __state);
                    plugin.RecordInstalledInductionKit(__instance, __state);
                }
            }
            else
            {
                plugin.RestoreMountedProchargerPart(__instance);
                plugin.RecordInstalledInductionKit(__instance, String.Empty);
            }
        }

        public static bool InductionIsTuningPrefix(string __0, string __1, ref bool __result)
        {
            if (!IsInductionPartId(__0) && !IsInductionPartId(__1)
                && !IsUniversalMountId(__0) && !IsUniversalMountId(__1)) return true;
            TurboPrototypePlugin plugin = Instance;
            if (IsUniversalMountId(__1) && IsInductionPartId(__0))
            {
                InductionMode requestedMode = ModeForInductionPartId(__0);
                __result = requestedMode == InductionMode.Procharger
                    || plugin == null || !plugin.CurrentEngineHasCarburetor();
            }
            else __result = IsProchargerCompatibleSlot(__0, __1);
            return false;
        }

        public static bool InductionPieOptionAvailablePrefix(string __0, ref bool __result)
        {
            if (!String.Equals(__0, AddForcedInductionPieOption, StringComparison.Ordinal)) return true;
            __result = true;
            return false;
        }

        public static void InductionPieOptionsReadPostfix(PieMenuController __instance, string __0,
            ref string[] __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null) return;
            try
            {
                bool engineStandMenu = String.Equals(__0, "!EngineStand", StringComparison.Ordinal);
                if (!engineStandMenu) return;
                GameScript game = GameScript.Get();
                if (game == null) return;
                NewGroupItem standGroup = game.GetGroupOnEngineStand();
                bool hasEngine = plugin.standOccupied || standGroup != null;
                if (!plugin.radialMenuDiagnosticLogged)
                {
                    plugin.radialMenuDiagnosticLogged = true;
                    plugin.Logger.LogInfo("Engine-stand radial options read: key=" + (__0 ?? "<null>")
                        + ", pluginOccupied=" + plugin.standOccupied.ToString()
                        + ", standGroup=" + (standGroup != null).ToString()
                        + ", options=" + (__result == null ? "<null>" : __result.Length.ToString(CultureInfo.InvariantCulture)) + ".");
                }
                if (!hasEngine) return;
                if (__result != null)
                    for (int i = 0; i < __result.Length; i++)
                        if (String.Equals(__result[i], AddForcedInductionPieOption, StringComparison.Ordinal)) return;
                List<string> expanded = __result == null
                    ? new List<string>() : new List<string>(__result);
                expanded.Add(AddForcedInductionPieOption);
                __result = expanded.ToArray();
                if (!plugin.radialMenuActionAddedLogged)
                {
                    plugin.radialMenuActionAddedLogged = true;
                    plugin.Logger.LogInfo("Added Add forced induction to the occupied engine-stand radial-menu options before stock icon creation.");
                }
            }
            catch (Exception exception)
            {
                plugin.Logger.LogWarning("Could not add the forced-induction option while CMS read the engine-stand radial menu: " + exception.Message);
            }
        }

        public static void InductionPieIconsPreparePrefix(PieMenuController __instance, ref string[] __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null || __0 == null) return;
            try
            {
                GameScript game = GameScript.Get();
                if (game == null) return;
                // PreparePieMenu stores the selected radial config immediately before
                // calling PrepareIcons. Also use the confirmed EngineStand enum value
                // because other game/mod hooks may alter the config field.
                FieldInfo previousMenuField = AccessTools.Field(typeof(PieMenuController), "PreviousValueFromIni");
                string menuKey = System.Object.ReferenceEquals(previousMenuField, null)
                    ? String.Empty : previousMenuField.GetValue(__instance) as string;
                int machineType = Convert.ToInt32(game.GetMachineOnMouseOverType(), CultureInfo.InvariantCulture);
                bool engineStandMenu = String.Equals(menuKey, "!EngineStand", StringComparison.Ordinal)
                    || menuKey.IndexOf("EngineStand", StringComparison.OrdinalIgnoreCase) >= 0
                    || machineType == 5;
                NewGroupItem standGroup = game.GetGroupOnEngineStand();
                bool hasEngine = plugin.standOccupied || standGroup != null;
                if (engineStandMenu && !plugin.radialMenuDiagnosticLogged)
                {
                    plugin.radialMenuDiagnosticLogged = true;
                    plugin.Logger.LogInfo("Engine-stand radial diagnostic: key=" + menuKey + ", machineType="
                        + machineType.ToString(CultureInfo.InvariantCulture) + ", pluginOccupied="
                        + plugin.standOccupied.ToString() + ", standGroup=" + (standGroup != null).ToString()
                        + ", options=" + __0.Length.ToString(CultureInfo.InvariantCulture) + ".");
                }
                if (!engineStandMenu || !hasEngine) return;
                for (int i = 0; i < __0.Length; i++)
                    if (String.Equals(__0[i], AddForcedInductionPieOption, StringComparison.Ordinal)) return;
                List<string> expanded = new List<string>(__0);
                expanded.Add(AddForcedInductionPieOption);
                __0 = expanded.ToArray();
                if (!plugin.radialMenuActionAddedLogged)
                {
                    plugin.radialMenuActionAddedLogged = true;
                    plugin.Logger.LogInfo("Added Add forced induction to the occupied engine-stand radial-menu options.");
                }
            }
            catch (Exception exception)
            {
                plugin.Logger.LogWarning("Could not add the forced-induction option to the engine-stand radial menu: " + exception.Message);
            }
        }

        public static void InductionPieIconsPreparedPostfix(PieMenuController __instance, string[] __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null || __0 == null) return;
            try
            {
                int optionIndex = Array.IndexOf(__0, AddForcedInductionPieOption);
                if (optionIndex < 0) return;
                FieldInfo namesField = AccessTools.Field(typeof(PieMenuController), "NameList");
                FieldInfo pathsField = AccessTools.Field(typeof(PieMenuController), "PathList");
                List<string> names = System.Object.ReferenceEquals(namesField, null) ? null : namesField.GetValue(__instance) as List<string>;
                List<Transform> paths = System.Object.ReferenceEquals(pathsField, null) ? null : pathsField.GetValue(__instance) as List<Transform>;
                if (names == null || paths == null || optionIndex >= names.Count || optionIndex >= paths.Count) return;
                ApplyRadialIcon(names, paths, optionIndex);
                if (!plugin.radialMenuActionAddedLogged)
                {
                    plugin.radialMenuActionAddedLogged = true;
                    plugin.Logger.LogInfo("Added Add forced induction to the native engine-stand radial menu before icon creation.");
                }
            }
            catch (Exception exception)
            {
                plugin.Logger.LogWarning("Could not style the forced-induction radial-menu option: " + exception.Message);
            }
        }

        private static void ApplyRadialIcon(List<string> names, List<Transform> paths, int optionIndex)
        {
            if (names == null || paths == null || optionIndex < 0 || optionIndex >= names.Count || optionIndex >= paths.Count) return;
            Image target = paths[optionIndex] == null ? null : paths[optionIndex].GetComponent<Image>();
            if (target == null) return;
            Sprite icon = null;
            for (int i = 0; i < names.Count && i < paths.Count; i++)
            {
                if (i == optionIndex || paths[i] == null) continue;
                string option = names[i] ?? String.Empty;
                if (option.StartsWith("!", StringComparison.Ordinal)) option = option.Substring(1);
                bool preferred = String.Equals(option, "GroupMount", StringComparison.OrdinalIgnoreCase)
                    || String.Equals(option, "PartSelectMountEngineStand", StringComparison.OrdinalIgnoreCase);
                if (!preferred) continue;
                Image source = paths[i].GetComponent<Image>();
                if (source != null && source.sprite != null) { icon = source.sprite; break; }
            }
            if (icon == null)
                for (int i = 0; i < paths.Count; i++)
                {
                    if (i == optionIndex || paths[i] == null) continue;
                    Image source = paths[i].GetComponent<Image>();
                    if (source != null && source.sprite != null) { icon = source.sprite; break; }
                }
            if (icon != null) target.sprite = icon;
        }

        public static bool InductionPieMenuSelectionPrefix(PieMenuController __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null) return true;
            try
            {
                FieldInfo namesField = AccessTools.Field(typeof(PieMenuController), "NameList");
                FieldInfo currentField = AccessTools.Field(typeof(PieMenuController), "CurrOption");
                List<string> names = System.Object.ReferenceEquals(namesField, null) ? null : namesField.GetValue(__instance) as List<string>;
                int selected = System.Object.ReferenceEquals(currentField, null) ? -1 : (int)currentField.GetValue(__instance);
                if (names == null || selected < 0 || selected >= names.Count) return true;
                string selectedOption = names[selected];
                if (!String.Equals(selectedOption, AddForcedInductionPieOption, StringComparison.Ordinal)) return true;
                MethodInfo close = AccessTools.Method(typeof(PieMenuController), "Close");
                if (!System.Object.ReferenceEquals(close, null)) close.Invoke(__instance, null);
                plugin.pendingChooserMode = plugin.selectedMode == InductionMode.Off
                    ? InductionMode.Procharger : plugin.selectedMode;
                plugin.pendingChooserPsi = plugin.selectedBoostPsi;
                plugin.OpenInductionChooser();
                plugin.Logger.LogInfo("Opened the forced-induction chooser from the engine-stand radial menu.");
                return false;
            }
            catch (Exception exception)
            {
                plugin.Logger.LogWarning("Could not open the forced-induction chooser from the radial menu: " + exception.Message);
                return true;
            }
        }

        public static bool Cursor3DUpdatePrefix()
        {
            TurboPrototypePlugin plugin = Instance;
            return plugin == null || !plugin.showInductionChooser;
        }

        public static void InductionPieDescriptionPostfix(PieMenuController __instance)
        {
            if (__instance == null) return;
            try
            {
                FieldInfo namesField = AccessTools.Field(typeof(PieMenuController), "NameList");
                FieldInfo currentField = AccessTools.Field(typeof(PieMenuController), "CurrOption");
                FieldInfo titleField = AccessTools.Field(typeof(PieMenuController), "TitleText");
                FieldInfo descriptionField = AccessTools.Field(typeof(PieMenuController), "DescText");
                List<string> names = System.Object.ReferenceEquals(namesField, null) ? null : namesField.GetValue(__instance) as List<string>;
                int selected = System.Object.ReferenceEquals(currentField, null) ? -1 : (int)currentField.GetValue(__instance);
                if (names == null || selected < 0 || selected >= names.Count) return;
                string selectedOption = names[selected];
                if (!String.Equals(selectedOption, AddForcedInductionPieOption, StringComparison.Ordinal)) return;
                Text title = System.Object.ReferenceEquals(titleField, null) ? null : titleField.GetValue(__instance) as Text;
                Text description = System.Object.ReferenceEquals(descriptionField, null) ? null : descriptionField.GetValue(__instance) as Text;
                if (title != null) title.text = "Add forced induction";
                if (description != null) description.text = "Choose a ProCharger P-1X kit for this engine.";
            }
            catch { }
        }

        public static bool InductionIsPartAccessiblePrefix(string __0, ref bool __result)
        {
            // Raycast.Update reads PartScript.GetID(), then gates hover and selection
            // through GameScript.IsPartAccessible(id). The virtual mount is not a native
            // engine group on every engine, so CMS's stock group test can reject it.
            if (!IsUniversalMountId(__0) && !IsInductionPartId(__0)) return true;
            __result = true;
            return false;
        }

        internal static bool ShouldHideUniversalMountFromSelector(string slotId, string itemId, string normalId)
        {
            bool isMountItem = IsUniversalMountId(itemId) || IsUniversalMountId(normalId);
            bool isTunedKit = IsInductionPartId(itemId) || IsInductionPartId(normalId);
            return IsUniversalMountId(slotId) && isMountItem && !isTunedKit;
        }

        public static void InductionInventoryGetItemsPostfix(string __0, ref List<NewInventoryItem> __result)
        {
            if (__result == null || !IsUniversalMountId(__0)) return;
            for (int i = __result.Count - 1; i >= 0; i--)
            {
                NewInventoryItem item = __result[i];
                if (item == null) continue;
                if (IsRetiredKitPartId(item.ID) || IsRetiredKitPartId(GetNormalId(item)))
                {
                    __result.RemoveAt(i);
                    continue;
                }
                if (ShouldHideUniversalMountFromSelector(__0, item.ID, GetNormalId(item)))
                {
                    __result.RemoveAt(i);
                    continue;
                }
            }
        }

        public static bool InductionGetGO2Prefix(GameInventory __instance, string __0, ref GameObject __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return true;
            if (IsUniversalMountId(__0))
            {
                __result = plugin.CreateUniversalMountPrefab(true);
                return false;
            }
            if (!IsInductionPartId(__0)) return true;

            GameObject part = null;
            try
            {
                part = __instance.GetGO2(ProchargerBasePartId);
                if (part == null)
                {
                    __result = null;
                    return false;
                }
                plugin.ConfigureInductionPart(part, __0);
                __result = part;
                return false;
            }
            catch (Exception exception)
            {
                if (part != null) UnityEngine.Object.Destroy(part);
                __result = null;
                plugin.Logger.LogError("Could not create an induction kit shop preview: " + exception);
                return false;
            }
        }
        public static bool InductionGetGOPrefix(GameInventory __instance, string __0, ref GameObject __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return true;
            if (IsUniversalMountId(__0))
            {
                __result = plugin.CreateUniversalMountPrefab(false);
                return false;
            }
            if (!IsInductionPartId(__0)) return true;

            GameObject part = null;
            try
            {
                part = __instance.GetGO(ProchargerBasePartId);
                if (part == null)
                {
                    __result = null;
                    return false;
                }
                plugin.ConfigureInductionPart(part, __0);
                __result = part;
                return false;
            }
            catch (Exception exception)
            {
                if (part != null) UnityEngine.Object.Destroy(part);
                __result = null;
                plugin.Logger.LogError("Could not create an induction kit mount prefab: " + exception);
                return false;
            }
        }

        public static void InductionShopThumbPostfix(GameInventory __instance, string __0, ref Sprite __result)
        {
            if (IsInductionPartId(__0) || IsUniversalMountId(__0)) __result = __instance.GetThumb(ProchargerBasePartId);
        }

        public static void InductionShopNamePostfix(string __0, ref string __result)
        {
            InductionMode mode = ModeForInductionPartId(__0);
            if (IsHighBoostProchargerPartId(__0)) __result = "ProCharger P-1X High-Boost (32 PSI)";
            else if (mode == InductionMode.Procharger) __result = "ProCharger P-1X Centrifugal Supercharger";
            else if (IsUniversalMountId(__0))
            {
                TurboPrototypePlugin plugin = TurboPrototypePlugin.Instance;
                __result = plugin == null ? "Universal Induction Mount" : plugin.GetCurrentUniversalMountDisplayName();
            }
        }

        public static void InductionIOLocalizedNamePostfix(InteractiveObject __0, ref string __result)
        {
            if (__0 == null) return;
            PartScript partScript = __0.GetComponent<PartScript>();
            if (partScript == null || !IsUniversalMountId(partScript.GetID())) return;
            string tunedId = partScript.GetTunedID();
            InductionMode mode = ModeForInductionPartId(tunedId);
            if (IsHighBoostProchargerPartId(tunedId)) __result = "ProCharger P-1X High-Boost";
            else if (mode == InductionMode.Procharger) __result = "ProCharger P-1X Centrifugal Supercharger";
            else
            {
                TurboPrototypePlugin plugin = TurboPrototypePlugin.Instance;
                __result = plugin == null ? "Universal Induction Mount" : plugin.GetCurrentUniversalMountDisplayName();
            }
        }

        public static void InductionShopGetItemsPostfix(GameInventory __instance, string __0,
            ref List<GameInventory.PartProperty> __result)
        {
            if (__instance == null
                || (!String.Equals(__0, "MainShop", StringComparison.Ordinal)
                    && !String.Equals(__0, "TuningShop", StringComparison.Ordinal))) return;
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return;
            try
            {
                plugin.EnsureShopCatalogReady();
                if (__result == null) __result = new List<GameInventory.PartProperty>();
                string[] productIds = String.Equals(__0, "TuningShop", StringComparison.Ordinal)
                    ? new string[] { ProchargerHighBoostPartId }
                    : new string[] { ProchargerPartId };
                for (int i = 0; i < productIds.Length; i++)
                {
                    GameInventory.PartProperty property = __instance.GetItemProperty(productIds[i]);
                    if (property == null || !String.Equals(property.ShopName, __0, StringComparison.Ordinal)) continue;
                    bool present = false;
                    for (int itemIndex = 0; itemIndex < __result.Count; itemIndex++)
                    {
                        if (__result[itemIndex] != null && String.Equals(__result[itemIndex].ID, property.ID, StringComparison.Ordinal))
                        {
                            present = true;
                            break;
                        }
                    }
                    if (!present) __result.Add(property);
                }
                string queryState = __0 + "|rows=" + __result.Count.ToString(CultureInfo.InvariantCulture)
                    + "|p1x=" + HasShopProperty(__instance, ProchargerPartId, "MainShop")
                    + "|high=" + HasShopProperty(__instance, ProchargerHighBoostPartId, "TuningShop");
                if (plugin.loggedShopQueryStates.Add(queryState))
                    plugin.Logger.LogInfo("Shop catalog query: " + queryState + ".");
            }
            catch (Exception exception)
            {
                plugin.Logger.LogWarning("Could not add the ProCharger kits to the " + __0 + " result: " + exception.Message);
            }
        }

        public static void InductionLocalizationPostfix(string __0, ref string __result)
        {
            if (String.IsNullOrEmpty(__0)) return;
            if (String.Equals(__0.Trim(), AddForcedInductionPieOption, StringComparison.Ordinal))
            {
                __result = "Add forced induction";
                return;
            }
            string key = __0.Trim();
            if (key.StartsWith("!", StringComparison.Ordinal)) key = key.Substring(1);
            key = RemoveSlotSuffix(key);
            InductionMode mode = ModeForInductionPartId(key);
            if (IsHighBoostProchargerPartId(key)) __result = "ProCharger P-1X High-Boost (32 PSI)";
            else if (mode == InductionMode.Procharger) __result = "ProCharger P-1X Centrifugal Supercharger";
            else if (IsUniversalMountId(key))
            {
                // GameScript.SetPartMouseOver sets this field immediately before requesting
                // the highlighted part's localization key. `selectedPart` is not its raycast target.
                PartScript selectedPart = ReadComponentReference<PartScript>(GameScript.Get(), "partMouseOver");
                if (selectedPart != null && IsUniversalMountId(selectedPart.GetID()))
                {
                    mode = ModeForInductionPartId(selectedPart.GetTunedID());
                    if (mode == InductionMode.Off) mode = ModeForInductionPartId(selectedPart.GetIDWithTuned());
                    if (IsHighBoostProchargerPartId(selectedPart.GetTunedID())) __result = "ProCharger P-1X High-Boost";
                    else if (mode == InductionMode.Procharger) __result = "ProCharger P-1X Centrifugal Supercharger";
                    else __result = "Universal Induction Mount";
                }
                else __result = "Universal Induction Mount";
            }
        }

        private void RecordInstalledInductionKit(PartScript part, string partId)
        {
            if (part == null) return;
            // Persist fitted-kit identity only under a specific car save key. A stand
            // group or prefab name can be reused by unrelated cars.
            string key = standOccupied ? String.Empty : activeCarKey;
            if (!String.IsNullOrEmpty(key))
            {
                string prefKey = PrefKey(InstalledKitModePrefix + key);
                if (IsInductionPartId(partId)) PlayerPrefs.SetString(prefKey, partId);
                else if (IsUniversalMountId(part.GetID())) PlayerPrefs.DeleteKey(prefKey);
            }
            if (IsHighBoostProchargerPartId(partId))
            {
                standHasHighBoostProcharger = standOccupied;
                activeHasHighBoostProcharger = !standOccupied;
                selectedMode = InductionMode.Procharger;
                if (selectedBoostPsi < P1XHighBoostDefaultPsi) selectedBoostPsi = P1XHighBoostDefaultPsi;
                if (standOccupied && standGroup != null)
                {
                    SaveGroupSettings(standGroup, InductionMode.Procharger, selectedBoostPsi);
                    AnnotateGroup(standGroup, InductionMode.Procharger, selectedBoostPsi);
                    RegisterEngineAliases(standGroup, InductionMode.Procharger, selectedBoostPsi);
                }
                else if (!String.IsNullOrEmpty(activeCarKey))
                {
                    activeMode = InductionMode.Procharger;
                    activeBoostPsi = selectedBoostPsi;
                    SaveCarSettings(activeCarKey, InductionMode.Procharger, selectedBoostPsi);
                }
                SaveGlobalSettings();
                status = "High-Boost P-1X fitted; 24 psi preset, adjustable to the 32 psi unit rating";
            }
            else if (IsProchargerPartId(partId))
            {
                standHasHighBoostProcharger = false;
                activeHasHighBoostProcharger = false;
                selectedBoostPsi = Mathf.Min(selectedBoostPsi, P1XStreetMaxBoostPsi);
                SaveGlobalSettings();
            }
            else if (IsInductionPartId(partId) || IsUniversalMountId(part.GetID()))
            {
                standHasHighBoostProcharger = standOccupied && IsHighBoostProchargerPartId(partId);
                activeHasHighBoostProcharger = !standOccupied && IsHighBoostProchargerPartId(partId);
                InductionMode installedMode = ModeForInductionPartId(partId);
                selectedBoostPsi = Mathf.Min(selectedBoostPsi, GetMaximumBoostPsi(installedMode,
                    IsHighBoostProchargerPartId(partId)));
                if (standOccupied && standGroup != null)
                {
                    SaveGroupSettings(standGroup, installedMode, selectedBoostPsi);
                    AnnotateGroup(standGroup, installedMode, selectedBoostPsi);
                }
                else if (!String.IsNullOrEmpty(activeCarKey))
                {
                    SaveCarSettings(activeCarKey, installedMode, selectedBoostPsi);
                }
                SaveGlobalSettings();
            }
            PlayerPrefs.Save();
        }

        public static void TorquePostfix(VehiclePhysics.Engine __instance, float rpm, float throttle, ref float __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (!System.Object.ReferenceEquals(plugin, null)) plugin.ApplyTorque(__instance, rpm, throttle, ref __result);
        }

        public static void PowerPostfix(VehiclePhysics.Engine __instance, float __0, ref float __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (!System.Object.ReferenceEquals(plugin, null)) plugin.ApplyPower(__instance, __0, ref __result);
        }

        public static void StandGroupPostfix(ref NewGroupItem __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __result == null) return;

            string key = BuildGroupKey(__result);
            bool isCurrentGroup = plugin.standOccupied
                && __result.UId == plugin.standGroupUid
                && String.Equals(key, plugin.standGroupKey, StringComparison.Ordinal);
            InductionMode mode;
            float psi;
            if (plugin.TryReadGroupSettings(__result, out mode, out psi))
            {
                if (isCurrentGroup)
                {
                    plugin.selectedMode = mode;
                    plugin.selectedBoostPsi = psi;
                    if (!PlayerPrefs.HasKey(plugin.PrefKey(GroupModePrefix + key)))
                    {
                        plugin.SaveGroupSettings(__result, mode, psi);
                    }
                }
                return;
            }

            if (plugin.TryReadStoredGroupSettings(__result, out mode, out psi))
            {
                if (isCurrentGroup)
                {
                    plugin.selectedMode = mode;
                    plugin.selectedBoostPsi = psi;
                }
                plugin.AnnotateGroup(__result, mode, psi);
                return;
            }
            if (!isCurrentGroup) return;

            mode = plugin.selectedMode;
            psi = plugin.selectedBoostPsi;

            plugin.SaveGroupSettings(__result, mode, psi);
            plugin.AnnotateGroup(__result, mode, psi);
        }
        public static void SetStandGroupPrefix(NewGroupItem __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __0 == null) return;
            InductionMode mode;
            float psi;
            if (!plugin.TryReadGroupSettings(__0, out mode, out psi)
                && !plugin.TryReadStoredGroupSettings(__0, out mode, out psi))
            {
                mode = InductionMode.Off;
                psi = 8.0f;
            }
            plugin.selectedMode = mode;
            plugin.selectedBoostPsi = psi;
            plugin.AnnotateGroup(__0, mode, psi);
            plugin.SaveGroupSettings(__0, mode, psi);
            plugin.SaveGlobalSettings();
            plugin.UpdateEffectiveSettings();
        }

        public static void InsertEnginePrefix(NewGroupItem __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return;
            try { plugin.RecordPendingInstall(__0); }
            catch (Exception exception) { plugin.Logger.LogError("Engine-install tracking prefix failed safely: " + exception); }
        }

        public static void InsertEnginePostfix(NewGroupItem __0, ref IEnumerator __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __result == null) return;
            try { __result = plugin.TrackActionInsertRoutine(__result, __0); }
            catch (Exception exception) { plugin.Logger.LogError("Engine-install tracking postfix failed safely: " + exception); }
        }

        public static void SwapEnginePrefix(CarLoader __instance, NewGroupItem __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return;
            try { plugin.MarkPendingEngineSwap(__0); }
            catch (Exception exception) { plugin.Logger.LogError("Engine-swap tracking prefix failed safely: " + exception); }
        }

        public static void SwapEnginePostfix(CarLoader __instance, NewGroupItem __0, ref IEnumerator __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __result == null) return;
            try { __result = plugin.TrackEngineSwapRoutine(__result, __instance, __0); }
            catch (Exception exception) { plugin.Logger.LogError("Engine-swap tracking postfix failed safely: " + exception); }
        }

        public static void SetEnginePostfix(CarLoader __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null) return;
            // Engine installation can reach SetEngine before the outer insertion
            // coroutine's completion hook. Recover only for the loader captured from
            // this specific crane transfer and only after its engine matches the group.
            if (plugin.pendingHasUniversalMount && plugin.pendingInstallGroup != null)
            {
                try { plugin.StartCoroutine(plugin.RecoverPendingEngineInstallAfterSetEngine(__instance)); }
                catch (Exception exception) { plugin.Logger.LogWarning("Pending engine-transfer recovery could not start safely: " + exception.Message); }
            }
            // CarLoader instances are also created for previews/showroom cars. Restore
            // runtime-only parts only on the currently active garage/dyno car.
            if (!plugin.IsActiveCarLoader(__instance)) return;
            try
            {
                plugin.EnsureMountForEngineSwap(__instance);
                plugin.StartCoroutine(plugin.RestoreInstalledKitAfterCarLoad(__instance));
            }
            catch (Exception exception) { plugin.Logger.LogWarning("Engine-swap mount preparation failed safely: " + exception.Message); }
        }

        public static void DynoPreparePostfix(DynoManager __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin != null)
            {
                plugin.dynoPowerDiagnosticLogged = false;
                plugin.dynoSpecsDiagnosticLogged = false;
                plugin.RefreshCarContext();
                plugin.LogDynoDiagnostic("Dyno prepared: car=" + plugin.activeCarKey + ", mode=" + ModeName(plugin.activeMode)
                    + ", target=" + plugin.PsiForActiveCar().ToString("F1") + " psi, controller="
                    + (plugin.activeController == null ? "none" : plugin.activeController.name));
            }
        }

        public static void ShopCreatePrefix()
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return;
            try { plugin.EnsureShopCatalogReady(); }
            catch (Exception exception) { plugin.Logger.LogWarning("Shop catalog registration before UI build failed safely: " + exception.Message); }
        }

        public static void DynoTorqueChartPrefix(out bool __state)
        {
            TurboPrototypePlugin plugin = Instance;
            bool hasPlugin = !System.Object.ReferenceEquals(plugin, null);
            __state = hasPlugin && plugin.dynoTorqueSampling;
            if (hasPlugin) plugin.dynoTorqueSampling = true;
        }

        public static void EngineSpecsPrefix(out bool __state)
        {
            TurboPrototypePlugin plugin = Instance;
            bool hasPlugin = !System.Object.ReferenceEquals(plugin, null);
            __state = hasPlugin && plugin.dynoTorqueSampling;
            if (hasPlugin) plugin.dynoTorqueSampling = true;
        }

        public static void MeasuredEngineHelperPrefix(out bool __state)
        {
            TurboPrototypePlugin plugin = Instance;
            bool hasPlugin = !System.Object.ReferenceEquals(plugin, null);
            __state = hasPlugin && plugin.dynoMeasuredSpecsContext;
            if (hasPlugin) plugin.dynoMeasuredSpecsContext = true;
        }

        public static Exception MeasuredEngineHelperFinalizer(Exception __exception, bool __state)
        {
            TurboPrototypePlugin plugin = Instance;
            if (!System.Object.ReferenceEquals(plugin, null)) plugin.dynoMeasuredSpecsContext = __state;
            return __exception;
        }

        public static void EngineSpecsPostfix(VehiclePhysics.Engine __instance, ref VehiclePhysics.Engine.EngineSpecs __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (System.Object.ReferenceEquals(plugin, null)) return;
            try { plugin.ApplyEngineSpecsBoost(__instance, ref __0); }
            catch (Exception exception) { plugin.Logger.LogWarning("Could not apply induction boost to engine specs: " + exception.Message); }
        }

        public static Exception EngineSpecsFinalizer(Exception __exception, bool __state)
        {
            TurboPrototypePlugin plugin = Instance;
            if (!System.Object.ReferenceEquals(plugin, null)) plugin.dynoTorqueSampling = __state;
            return __exception;
        }

        public static void DynoTorqueChartPostfix(bool __state)
        {
            TurboPrototypePlugin plugin = Instance;
            if (!System.Object.ReferenceEquals(plugin, null)) plugin.dynoTorqueSampling = __state;
        }

    }

    internal static class TurboPrototypeHooks
    {
        public static void InductionPieIconsPreparePrefix(PieMenuController __instance, ref string[] __0)
        {
            TurboPrototypePlugin.InductionPieIconsPreparePrefix(__instance, ref __0);
        }

        public static void InductionPieIconsPreparedPostfix(PieMenuController __instance, string[] __0)
        {
            TurboPrototypePlugin.InductionPieIconsPreparedPostfix(__instance, __0);
        }

        public static bool InductionPieOptionAvailablePrefix(string __0, ref bool __result)
        {
            return TurboPrototypePlugin.InductionPieOptionAvailablePrefix(__0, ref __result);
        }

        public static void InductionPieOptionsReadPostfix(PieMenuController __instance, string __0,
            ref string[] __result)
        {
            TurboPrototypePlugin.InductionPieOptionsReadPostfix(__instance, __0, ref __result);
        }

        public static bool InductionPieMenuSelectionPrefix(PieMenuController __instance)
        {
            return TurboPrototypePlugin.InductionPieMenuSelectionPrefix(__instance);
        }

        public static void InductionPieDescriptionPostfix(PieMenuController __instance)
        {
            TurboPrototypePlugin.InductionPieDescriptionPostfix(__instance);
        }

        public static void TorquePostfix(VehiclePhysics.Engine __instance, float rpm, float throttle, ref float __result)
        {
            TurboPrototypePlugin.TorquePostfix(__instance, rpm, throttle, ref __result);
        }

        public static void PowerPostfix(VehiclePhysics.Engine __instance, float __0, ref float __result)
        {
            TurboPrototypePlugin.PowerPostfix(__instance, __0, ref __result);
        }

        public static void StandGroupPostfix(ref NewGroupItem __result)
        {
            TurboPrototypePlugin.StandGroupPostfix(ref __result);
        }

        public static void SetStandGroupPrefix(NewGroupItem __0)
        {
            TurboPrototypePlugin.SetStandGroupPrefix(__0);
        }

        public static void InsertEnginePrefix(NewGroupItem __0)
        {
            TurboPrototypePlugin.InsertEnginePrefix(__0);
        }

        public static void InsertEnginePostfix(NewGroupItem __0, ref IEnumerator __result)
        {
            TurboPrototypePlugin.InsertEnginePostfix(__0, ref __result);
        }

        public static void SwapEnginePrefix(CarLoader __instance, NewGroupItem __0)
        {
            TurboPrototypePlugin.SwapEnginePrefix(__instance, __0);
        }

        public static void SwapEnginePostfix(CarLoader __instance, NewGroupItem __0, ref IEnumerator __result)
        {
            TurboPrototypePlugin.SwapEnginePostfix(__instance, __0, ref __result);
        }

        public static void SetEnginePostfix(CarLoader __instance)
        {
            TurboPrototypePlugin.SetEnginePostfix(__instance);
        }
        public static bool InductionTunePartPrefix(PartScript __instance, ref string __0,
            ref bool __result, out string __state)
        {
            return TurboPrototypePlugin.InductionTunePartPrefix(__instance, ref __0, ref __result, out __state);
        }

        public static void InductionTunePartPostfix(PartScript __instance, string __state, bool __result)
        {
            TurboPrototypePlugin.InductionTunePartPostfix(__instance, __state, __result);
        }

        public static bool InductionIsTuningPrefix(string __0, string __1, ref bool __result)
        {
            return TurboPrototypePlugin.InductionIsTuningPrefix(__0, __1, ref __result);
        }

        public static bool InductionIsPartAccessiblePrefix(string __0, ref bool __result)
        {
            return TurboPrototypePlugin.InductionIsPartAccessiblePrefix(__0, ref __result);
        }

        public static void InductionInventoryGetItemsPostfix(string __0, ref List<NewInventoryItem> __result)
        {
            TurboPrototypePlugin.InductionInventoryGetItemsPostfix(__0, ref __result);
        }

        public static bool InductionGetGO2Prefix(GameInventory __instance, string __0, ref GameObject __result)
        {
            return TurboPrototypePlugin.InductionGetGO2Prefix(__instance, __0, ref __result);
        }

        public static bool InductionGetGOPrefix(GameInventory __instance, string __0, ref GameObject __result)
        {
            return TurboPrototypePlugin.InductionGetGOPrefix(__instance, __0, ref __result);
        }

        public static void InductionShopThumbPostfix(GameInventory __instance, string __0, ref Sprite __result)
        {
            TurboPrototypePlugin.InductionShopThumbPostfix(__instance, __0, ref __result);
        }

        public static void InductionShopNamePostfix(string __0, ref string __result)
        {
            TurboPrototypePlugin.InductionShopNamePostfix(__0, ref __result);
        }

        public static void InductionShopGetItemsPostfix(GameInventory __instance, string __0,
            ref List<GameInventory.PartProperty> __result)
        {
            TurboPrototypePlugin.InductionShopGetItemsPostfix(__instance, __0, ref __result);
        }

        public static void ShopCreatePrefix()
        {
            TurboPrototypePlugin.ShopCreatePrefix();
        }

        public static void InductionLocalizationPostfix(string __0, ref string __result)
        {
            TurboPrototypePlugin.InductionLocalizationPostfix(__0, ref __result);
        }

        public static void InductionIOLocalizedNamePostfix(InteractiveObject __0, ref string __result)
        {
            TurboPrototypePlugin.InductionIOLocalizedNamePostfix(__0, ref __result);
        }

        public static void DynoPreparePostfix(DynoManager __instance)
        {
            TurboPrototypePlugin.DynoPreparePostfix(__instance);
        }

        public static void DynoTorqueChartPrefix(out bool __state)
        {
            TurboPrototypePlugin.DynoTorqueChartPrefix(out __state);
        }

        public static void DynoTorqueChartPostfix(bool __state)
        {
            TurboPrototypePlugin.DynoTorqueChartPostfix(__state);
        }

        public static void EngineSpecsPrefix(out bool __state)
        {
            TurboPrototypePlugin.EngineSpecsPrefix(out __state);
        }

        public static void EngineSpecsPostfix(VehiclePhysics.Engine __instance, ref VehiclePhysics.Engine.EngineSpecs __0)
        {
            TurboPrototypePlugin.EngineSpecsPostfix(__instance, ref __0);
        }

        public static void MeasuredEngineHelperPrefix(out bool __state)
        {
            TurboPrototypePlugin.MeasuredEngineHelperPrefix(out __state);
        }

        public static Exception MeasuredEngineHelperFinalizer(Exception __exception, bool __state)
        {
            return TurboPrototypePlugin.MeasuredEngineHelperFinalizer(__exception, __state);
        }

        public static Exception EngineSpecsFinalizer(Exception __exception, bool __state)
        {
            return TurboPrototypePlugin.EngineSpecsFinalizer(__exception, __state);
        }
    }
}




