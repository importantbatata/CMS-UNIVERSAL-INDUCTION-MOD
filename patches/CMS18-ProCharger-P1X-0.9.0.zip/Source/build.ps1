param([switch]$Install, [switch]$ReplaceInstalled)
$ErrorActionPreference = 'Stop'
$game = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018'
$managed = Join-Path $game 'cms2018_Data\Managed'
$core = Join-Path $game 'BepInEx\core'
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$source = Join-Path $PSScriptRoot 'src\CMS18TurboPrototype.cs'
$chargeModelSource = Join-Path $PSScriptRoot 'src\ChargeAirModel.cs'
$prochargerMathSource = Join-Path $PSScriptRoot 'src\ProchargerMath.cs'
$sources = @($source, $chargeModelSource, $prochargerMathSource)
$modelResources = @(
    [pscustomobject]@{ Path = (Join-Path $PSScriptRoot 'model\CMS18_ProCharger_P1X_AddOn.obj'); ResourceName = 'CMS18_ProCharger_P1X_AddOn.obj' }
)
$output = Join-Path $PSScriptRoot 'build\CMS18TurboPrototype.dll'
$references = @(
    (Join-Path $core 'BepInEx.dll'),
    (Join-Path $core '0Harmony.dll'),
    (Join-Path $managed 'Assembly-CSharp-firstpass.dll'),
    (Join-Path $managed 'UnityEngine.dll'),
    (Join-Path $managed 'UnityEngine.CoreModule.dll'),
    (Join-Path $managed 'UnityEngine.TextRenderingModule.dll'),
    (Join-Path $managed 'UnityEngine.IMGUIModule.dll'),
    (Join-Path $managed 'UnityEngine.UI.dll'),
    (Join-Path $managed 'UnityEngine.UIModule.dll'),
    (Join-Path $managed 'UnityEngine.InputModule.dll'),
    (Join-Path $managed 'UnityEngine.PhysicsModule.dll')
)
foreach ($file in @($csc) + $sources + @($modelResources | ForEach-Object { $_.Path }) + $references) {
    if (-not (Test-Path -LiteralPath $file)) { throw "Required file not found: $file" }
}
New-Item -ItemType Directory -Path (Split-Path -Parent $output) -Force | Out-Null
$compilerArgs = @('/nologo', '/target:library', "/out:$output")
foreach ($reference in $references) { $compilerArgs += "/reference:$reference" }
$compilerArgs += $sources
foreach ($model in $modelResources) {
    $compilerArgs += "/resource:$($model.Path),$($model.ResourceName)"
}
& $csc @compilerArgs
if ($LASTEXITCODE -ne 0) { throw "C# compiler failed with exit code $LASTEXITCODE" }
Write-Host "Built $output"
if ($Install) {
    if (Get-Process -Name 'cms2018' -ErrorAction SilentlyContinue) {
        throw 'Close Car Mechanic Simulator 2018 before replacing its plugin.'
    }
    $pluginFolder = Join-Path $game 'BepInEx\plugins'
    $destination = Join-Path $pluginFolder 'CMS18TurboPrototype.dll'
    if (Test-Path -LiteralPath $destination) {
        if (-not $ReplaceInstalled) { throw "Refusing to overwrite existing plugin without -ReplaceInstalled: $destination" }
        $backupFolder = Join-Path $PSScriptRoot 'build\installed-backups'
        New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null
        $backup = Join-Path $backupFolder ("CMS18TurboPrototype-" + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.dll')
        Copy-Item -LiteralPath $destination -Destination $backup
        Write-Host "Saved previous plugin to $backup"
    }
    Copy-Item -LiteralPath $output -Destination $destination -Force
    Write-Host "Installed $destination"
}

