param([string]$GameRoot = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$source = Join-Path $projectRoot 'src\CMS18TurboPrototype.cs'
$math = Join-Path $projectRoot 'src\ProchargerMath.cs'
$charge = Join-Path $projectRoot 'src\ChargeAirModel.cs'
$mesh = Join-Path $projectRoot 'model\CMS18_ProCharger_P1X_AddOn.obj'
$plugin = Join-Path $projectRoot 'build\CMS18TurboPrototype.dll'
$installed = Join-Path $GameRoot 'BepInEx\plugins\CMS18TurboPrototype.dll'
$gameAssembly = Join-Path $GameRoot 'cms2018_Data\Managed\Assembly-CSharp-firstpass.dll'
$cecil = Join-Path $GameRoot 'BepInEx\core\Mono.Cecil.dll'
foreach($path in @($source,$math,$charge,$mesh,$plugin,$gameAssembly,$cecil)){if(-not(Test-Path -LiteralPath $path)){throw "Required validation input missing: $path"}}
$tempCecil=Join-Path $env:TEMP 'CMS18Procharger09-Mono.Cecil.dll'
Copy-Item -LiteralPath $cecil -Destination $tempCecil -Force
Unblock-File -LiteralPath $tempCecil
Add-Type -Path $tempCecil
function Assert-Check([bool]$condition,[string]$message){if(-not $condition){throw "FAIL: $message"};Write-Host "PASS: $message"}
function Find-PluginVersion([Mono.Cecil.ModuleDefinition]$module){$type=$module.Types|Where-Object{$_.FullName -eq 'CMS18TurboPrototype.TurboPrototypePlugin'}|Select-Object -First 1;if($null -eq $type){return $null};$attribute=$type.CustomAttributes|Where-Object{$_.AttributeType.Name -eq 'BepInPlugin'}|Select-Object -First 1;if($null -eq $attribute -or $attribute.ConstructorArguments.Count -lt 3){return $null};return [string]$attribute.ConstructorArguments[2].Value}
function Assert-GameMethod([Mono.Cecil.ModuleDefinition]$module,[string]$typeName,[string]$methodName,[string[]]$parameters){$type=$module.Types|Where-Object{$_.FullName -eq $typeName}|Select-Object -First 1;if($null -eq $type){throw "Game type missing: $typeName"};$matches=@($type.Methods|Where-Object{if($_.Name -ne $methodName -or $_.Parameters.Count -ne $parameters.Count){return $false};for($i=0;$i -lt $parameters.Count;$i++){if($_.Parameters[$i].ParameterType.FullName -ne $parameters[$i]){return $false}};return $true});Assert-Check ($matches.Count -eq 1) "$typeName.$methodName verified signature"}
$sourceText=Get-Content -LiteralPath $source -Raw
$version=[regex]::Match($sourceText,'internal const string Version\s*=\s*"([^"]+)"')
$pluginModule=[Mono.Cecil.ModuleDefinition]::ReadModule($plugin)
$gameModule=[Mono.Cecil.ModuleDefinition]::ReadModule($gameAssembly)
Assert-Check ($version.Success -and $version.Groups[1].Value -eq '0.9.0' -and (Find-PluginVersion $pluginModule) -eq '0.9.0') 'source and compiled plugin identify as patch 0.9.0'
Assert-Check ($sourceText.Contains('[BepInPlugin("local.cms18.turboproto", "CMS 2018 ProCharger P-1X", PluginInfo.Version)]')) 'stable plugin GUID is retained while product metadata is ProCharger-branded'
Assert-Check ($sourceText.Contains('ProchargerPartId = "cms18_procharger_p1x"') -and $sourceText.Contains('ProchargerHighBoostPartId = "cms18_procharger_p1x_highboost"') -and -not $sourceText.Contains('RegisterInductionProperty(inventory, turboTemplate, RetiredTurboKitPartId') -and -not $sourceText.Contains('CMS18 Turbo Kit') -and -not $sourceText.Contains('CMS18 Supercharger Kit')) 'only standard and high-boost P-1X kits are registered as mod products'
Assert-Check ($sourceText.Contains('InductionMode.Off, InductionMode.Procharger') -and $sourceText.Contains('return value == (int)InductionMode.Procharger') -and $sourceText.Contains('mode != InductionMode.Off && mode != InductionMode.Procharger')) 'UI and saved configuration reject retired turbo and Roots modes safely'
Assert-Check ($sourceText.Contains('if (mode != InductionMode.Procharger) return 0.0f;') -and $sourceText.Contains('CalculateP1XBoostPsi') -and $sourceText.Contains('ClampP1XTorqueDelta')) 'P-1X is the only active forced-induction power path and remains rating-limited'
Assert-Check ($sourceText.Contains('private const float P1XMaxBoostPsi = 32.0f;') -and $sourceText.Contains('P1XMaxImpellerRpm = 65000.0f') -and $sourceText.Contains('P1XInternalStepUpRatio = 4.10f') -and $sourceText.Contains('P1XMaxSuperchargedHp = 950.0f')) 'P-1X model retains its configured pressure, speed, ratio, and power bounds'
Assert-Check ($sourceText.Contains('new string[] { ProchargerHighBoostPartId }') -and $sourceText.Contains('new string[] { ProchargerPartId }')) 'shop exposes only the standard and high-boost ProCharger products'
Assert-Check (-not $sourceText.Contains('TryCreateNativeInductionModel') -and -not $sourceText.Contains('TryAttachNativeInductionVisual') -and -not $sourceText.Contains('Turbo turbine housing') -and -not $sourceText.Contains('Roots supercharger case')) 'live visual pipeline contains only the authored P-1X model path'
Assert-Check (-not $sourceText.Contains('EcuLab') -and -not $sourceText.Contains('EcuCalibrationSchema') -and -not $sourceText.Contains('TurboOperatingPointModel')) 'ECU Lab and removed generic turbo-model modules are absent from live source'
Assert-Check ((Get-Content -LiteralPath $math -Raw).Contains('NormalizeBoostPsi') -and (Get-Content -LiteralPath $charge -Raw).Contains('internal static class ChargeAirModel')) 'focused numeric and charge-air model sources are present'
$resources=@($pluginModule.Resources|ForEach-Object{$_.Name})
Assert-Check ($resources -contains 'CMS18_ProCharger_P1X_AddOn.obj') 'compiled plugin embeds the ProCharger P-1X mesh'
Assert-Check (@($resources|Where-Object{$_ -match 'Turbo_AddOn|Supercharger_AddOn'}).Count -eq 0) 'compiled plugin contains no turbocharger or Roots model assets'
Assert-GameMethod $gameModule 'VehiclePhysics.Engine' 'CalculateTorque' @('System.Single','System.Single')
Assert-GameMethod $gameModule 'VehiclePhysics.Engine' 'CalculatePowerInKw' @('System.Single')
Assert-GameMethod $gameModule 'GameScript' 'GetGroupOnEngineStand' @()
Assert-GameMethod $gameModule 'PartScript' 'TunePart' @('System.String','System.Boolean')
Assert-GameMethod $gameModule 'MountObject' 'SetCanBeUnmount' @('System.Boolean')
Assert-GameMethod $gameModule 'GameScript' 'SelectToUnMount' @('PartScript','MountObject[]')
Assert-GameMethod $gameModule 'GameInventory' 'GetGO' @('System.String')
Assert-GameMethod $gameModule 'GameInventory' 'GetGO2' @('System.String')
Assert-GameMethod $gameModule 'GameInventory' 'GetItems' @('System.String')
if(Test-Path -LiteralPath $installed){Write-Warning 'A plugin DLL is currently installed. This candidate was not installed by this validation run.'}else{Write-Warning 'No mod plugin is installed; this is the expected unmodded play state.'}
Write-Host 'ProCharger 0.9 offline validation passed. No game launch or gameplay test was performed.'
