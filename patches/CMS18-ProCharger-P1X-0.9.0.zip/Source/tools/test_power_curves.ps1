param(
    [string]$GameRoot = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018',
    [string]$PluginPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'build\CMS18TurboPrototype.dll')
)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSEdition -eq 'Core') {
    $windowsPowerShell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $windowsPowerShell)) { throw 'Windows PowerShell/.NET Framework is required for CMS assembly inspection.' }
    & $windowsPowerShell -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath -GameRoot $GameRoot -PluginPath $PluginPath
    exit $LASTEXITCODE
}
$managed = Join-Path $GameRoot 'cms2018_Data\Managed'
$core = Join-Path $GameRoot 'BepInEx\core'
$cache = Join-Path $env:TEMP 'CMS18Procharger09-testassemblies'
New-Item -ItemType Directory -Path $cache -Force | Out-Null
$refs = @(
    (Join-Path $managed 'UnityEngine.dll'), (Join-Path $managed 'UnityEngine.CoreModule.dll'),
    (Join-Path $managed 'UnityEngine.TextRenderingModule.dll'), (Join-Path $managed 'UnityEngine.IMGUIModule.dll'),
    (Join-Path $core 'BepInEx.dll'), (Join-Path $core '0Harmony.dll'),
    (Join-Path $managed 'Assembly-CSharp-firstpass.dll'), $PluginPath
)
foreach ($path in $refs) {
    if (-not (Test-Path -LiteralPath $path)) { throw "Required assembly not found: $path" }
    $loadPath = $path
    if ($path.StartsWith($managed, [StringComparison]::OrdinalIgnoreCase) -or $path.StartsWith($core, [StringComparison]::OrdinalIgnoreCase)) {
        $loadPath = Join-Path $cache (Split-Path -Leaf $path)
        Copy-Item -LiteralPath $path -Destination $loadPath -Force
        Unblock-File -LiteralPath $loadPath
    }
    [Reflection.Assembly]::LoadFrom($loadPath) | Out-Null
}
$assembly = [AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.Location -eq $PluginPath } | Select-Object -First 1
if ($null -eq $assembly) { throw 'Could not load the built plugin assembly.' }
$type = $assembly.GetType('CMS18TurboPrototype.TurboPrototypePlugin', $true)
$modeType = $assembly.GetType('CMS18TurboPrototype.InductionMode', $true)
$flags = [Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$passed = 0
function Check([bool]$ok,[string]$name) { if(-not $ok){throw "FAIL: $name"}; $script:passed++; Write-Output "PASS: $name" }
function Invoke-Static([string]$name,[object[]]$parameters) { $m=$script:type.GetMethod($name,$script:flags); if($null -eq $m -or -not $m.IsStatic){throw "Missing static method $name"}; return $m.Invoke($null,$parameters) }
$settingsType = ([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'Assembly-CSharp-firstpass' } | Select-Object -First 1).GetType('VehiclePhysics.Engine+Settings',$true)
$settings = [Activator]::CreateInstance($settingsType)
$settingsType.GetField('idleRpm',$flags).SetValue($settings,[single]800)
$settingsType.GetField('peakRpm',$flags).SetValue($settings,[single]5500)
$modeValue = { param($n) [Enum]::ToObject($script:modeType,$n) }
$off = Invoke-Static 'CalculateSpoolForSample' @((&$modeValue 0),$settings,[single]5500,[single]1)
$legacyTurbo = Invoke-Static 'CalculateSpoolForSample' @((&$modeValue 1),$settings,[single]5500,[single]1)
$legacySuper = Invoke-Static 'CalculateSpoolForSample' @((&$modeValue 2),$settings,[single]5500,[single]1)
$low = Invoke-Static 'CalculateSpoolForSample' @((&$modeValue 3),$settings,[single]1800,[single]1)
$mid = Invoke-Static 'CalculateSpoolForSample' @((&$modeValue 3),$settings,[single]3500,[single]1)
$peak = Invoke-Static 'CalculateSpoolForSample' @((&$modeValue 3),$settings,[single]5500,[single]1)
Check ($off -eq 0 -and $legacyTurbo -eq 0 -and $legacySuper -eq 0) 'off and retired turbo/Roots modes cannot generate boost'
Check ($low -gt 0 -and $low -lt $mid -and $mid -lt $peak -and $peak -le 1) 'P-1X centrifugal response increases smoothly with engine speed'
$boostMethod = $type.GetMethod('CalculateP1XBoostPsi',$flags)
$impellerMethod = $type.GetMethod('CalculateP1XImpellerRpm',$flags)
$atPeak = [single]$boostMethod.Invoke($null,[object[]]@($settings,[single]5500,[single]8))
$atHalf = [single]$boostMethod.Invoke($null,[object[]]@($settings,[single]2750,[single]8))
$atMax = [single]$boostMethod.Invoke($null,[object[]]@($settings,[single]6500,[single]32))
$rpmAtPeak = [single]$impellerMethod.Invoke($null,[object[]]@($settings,[single]5500,[single]8))
Check ([Math]::Abs($atPeak-8) -lt 0.01 -and [Math]::Abs($atHalf/$atPeak-0.25) -lt 0.01 -and $atMax -le 32) 'P-1X boost curve respects selected target and the 32 PSI rating ceiling'
Check ([Math]::Abs($rpmAtPeak-32500) -lt 1) 'P-1X impeller model respects its 4.10:1 drive ratio'
$limitMethod = $type.GetMethod('GetMaximumBoostPsi',$flags)
$street = [single]$limitMethod.Invoke($null,[object[]]@((&$modeValue 3),[bool]$false))
$race = [single]$limitMethod.Invoke($null,[object[]]@((&$modeValue 3),[bool]$true))
Check ($street -eq 20 -and $race -eq 32) 'street and high-boost P-1X kits use distinct boost ceilings'
$readMode = $type.GetMethod('ReadMode',$flags)
Check (([int]$readMode.Invoke($null,@(1)) -eq 0) -and ([int]$readMode.Invoke($null,@(2)) -eq 0) -and ([int]$readMode.Invoke($null,@(3)) -eq 3)) 'saved legacy turbo/Roots settings migrate safely while P-1X identity persists'
Check (([int](Invoke-Static 'ClassifyNativePartId' @('cms18_procharger_p1x(0)')) -eq 3) -and ([int](Invoke-Static 'ClassifyNativePartId' @('turbo_2')) -eq 0) -and ([int](Invoke-Static 'ClassifyNativePartId' @('v8_supercharger')) -eq 0)) 'only custom P-1X hardware activates the mod performance system'
$source = Get-Content -LiteralPath (Join-Path (Split-Path -Parent $PSScriptRoot) 'src\CMS18TurboPrototype.cs') -Raw
Check ($source.Contains('InductionMode.Off, InductionMode.Procharger') -and $source.Contains('new string[] { ProchargerPartId }') -and -not $source.Contains('CMS18 Turbo Kit') -and -not $source.Contains('CMS18 Supercharger Kit')) 'player choices and custom shop listings are ProCharger-only'
Check (-not $source.Contains('TryCreateNativeInductionModel') -and -not $source.Contains('TryAttachNativeInductionVisual') -and -not $source.Contains('Turbo turbine housing') -and -not $source.Contains('Roots supercharger case')) 'active visual code contains no turbo/Roots renderer or model-cloning path'
Check ($source.Contains('MountObjectSelectionLayer = 15') -and $source.Contains('mountObject.SetCanBeUnmount(false)') -and $source.Contains('SetPartField(part, "oneClickUnmount", false)') -and $source.Contains('toolSpeed') -and $source.Contains('SetPartField(part, "MountObjects", fasteners.ToArray())')) 'installed P-1X uses native CMS bolt objects, the dedicated bolt raycast layer, and an active unscrew path'
$retiredTurbo = 'cms18_turbo_kit'
$retiredRoots = 'cms18_supercharger_kit'
$isCustomPart = $type.GetMethod('IsInductionPartId',$flags)
$retiredTurboRecognized = [bool]$isCustomPart.Invoke($null,@($retiredTurbo))
$retiredRootsRecognized = [bool]$isCustomPart.Invoke($null,@($retiredRoots))
$retiredTurboMode = [int](Invoke-Static 'ModeForInductionPartId' @($retiredTurbo))
$retiredRootsMode = [int](Invoke-Static 'ModeForInductionPartId' @($retiredRoots))
Check ($retiredTurboRecognized -and $retiredRootsRecognized -and $retiredTurboMode -eq 0 -and $retiredRootsMode -eq 0) 'retired kit IDs remain inert compatibility aliases for older saved parts'
Write-Output "ProCharger 0.9 model checks passed: $passed"

