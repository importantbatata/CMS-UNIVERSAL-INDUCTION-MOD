using System;

namespace CMS18TurboPrototype
{
    /// <summary>
    /// Result of the mod's steady-state charge-air estimate. This is not a
    /// transient heat-soak model and is not based on CMS-specific intercooler
    /// telemetry or a manufacturer compressor map.
    /// </summary>
    internal struct ChargeAirState
    {
        internal readonly float CompressorOutletTemperatureKelvin;
        internal readonly float ManifoldTemperatureKelvin;
        internal readonly float ManifoldAbsolutePressurePsi;
        internal readonly float ManifoldBoostPsi;
        internal readonly float AirDensityRatio;

        internal ChargeAirState(float compressorOutletTemperatureKelvin,
            float manifoldTemperatureKelvin, float manifoldAbsolutePressurePsi,
            float manifoldBoostPsi, float airDensityRatio)
        {
            CompressorOutletTemperatureKelvin = compressorOutletTemperatureKelvin;
            ManifoldTemperatureKelvin = manifoldTemperatureKelvin;
            ManifoldAbsolutePressurePsi = manifoldAbsolutePressurePsi;
            ManifoldBoostPsi = manifoldBoostPsi;
            AirDensityRatio = airDensityRatio;
        }
    }

    /// <summary>
    /// Bounded, steady-state compressor heating and intercooler estimate.
    /// Boost input is compressor-outlet gauge pressure in PSI. The model
    /// subtracts core pressure drop before calculating manifold density.
    /// </summary>
    internal static class ChargeAirModel
    {
        internal const float StandardAmbientTemperatureKelvin = 298.15f;
        internal const float StandardAmbientPressurePsi = 14.6959f;
        private const float AirHeatCapacityRatioExponent = 0.286f;

        internal static ChargeAirState Calculate(float compressorBoostPsi,
            float compressorEfficiency, float intercoolerEffectiveness,
            float intercoolerPressureDropPsi, float ambientTemperatureKelvin,
            float ambientPressurePsi)
        {
            if (!IsFinite(compressorBoostPsi) || compressorBoostPsi < 0.0f) compressorBoostPsi = 0.0f;
            if (!IsFinite(compressorEfficiency)) compressorEfficiency = 0.70f;
            compressorEfficiency = Clamp(compressorEfficiency, 0.20f, 0.95f);
            if (!IsFinite(intercoolerEffectiveness)) intercoolerEffectiveness = 0.0f;
            intercoolerEffectiveness = Clamp(intercoolerEffectiveness, 0.0f, 0.95f);
            if (!IsFinite(intercoolerPressureDropPsi) || intercoolerPressureDropPsi < 0.0f)
                intercoolerPressureDropPsi = 0.0f;
            if (!IsFinite(ambientTemperatureKelvin) || ambientTemperatureKelvin < 150.0f
                || ambientTemperatureKelvin > 400.0f)
                ambientTemperatureKelvin = StandardAmbientTemperatureKelvin;
            if (!IsFinite(ambientPressurePsi) || ambientPressurePsi < 5.0f
                || ambientPressurePsi > 25.0f)
                ambientPressurePsi = StandardAmbientPressurePsi;

            float compressorAbsolutePressure = ambientPressurePsi + compressorBoostPsi;
            float compressorPressureRatio = compressorAbsolutePressure / ambientPressurePsi;
            float compressorOutletTemperature = ambientTemperatureKelvin
                * (1.0f + ((float)Math.Pow(compressorPressureRatio, AirHeatCapacityRatioExponent) - 1.0f)
                    / compressorEfficiency);
            float manifoldTemperature = ambientTemperatureKelvin
                + (compressorOutletTemperature - ambientTemperatureKelvin)
                    * (1.0f - intercoolerEffectiveness);

            // The pressure loss cannot pull manifold pressure below ambient in
            // this simplified open-throttle, steady-state estimate.
            float manifoldAbsolutePressure = Math.Max(ambientPressurePsi,
                compressorAbsolutePressure - intercoolerPressureDropPsi);
            float manifoldBoost = Math.Max(0.0f, manifoldAbsolutePressure - ambientPressurePsi);
            float densityRatio = (manifoldAbsolutePressure / ambientPressurePsi)
                * (ambientTemperatureKelvin / Math.Max(ambientTemperatureKelvin, manifoldTemperature));

            if (!IsFinite(compressorOutletTemperature) || !IsFinite(manifoldTemperature)
                || !IsFinite(manifoldAbsolutePressure) || !IsFinite(densityRatio))
            {
                return new ChargeAirState(ambientTemperatureKelvin, ambientTemperatureKelvin,
                    ambientPressurePsi, 0.0f, 1.0f);
            }

            // Avoid a bad external/config value turning the estimate into an
            // extreme torque multiplier. This is a stability bound, not a
            // hardware capability claim.
            densityRatio = Clamp(densityRatio, 1.0f, 4.0f);
            return new ChargeAirState(compressorOutletTemperature,
                Math.Max(ambientTemperatureKelvin, manifoldTemperature),
                manifoldAbsolutePressure, manifoldBoost, densityRatio);
        }

        private static float Clamp(float value, float minimum, float maximum)
        {
            return Math.Max(minimum, Math.Min(maximum, value));
        }

        private static bool IsFinite(float value)
        {
            return !Single.IsNaN(value) && !Single.IsInfinity(value);
        }
    }
}
