using System;

namespace CMS18TurboPrototype
{
    /// <summary>Numeric guards shared by the P-1X boost and dyno model.</summary>
    internal static class ProchargerMath
    {
        internal static float NormalizeBoostPsi(float value, float maximum, float fallback)
        {
            if (!IsFinite(maximum) || maximum < 0.0f) maximum = 0.0f;
            if (!IsFinite(fallback)) fallback = 0.0f;
            if (!IsFinite(value)) value = fallback;
            fallback = Math.Max(0.0f, Math.Min(maximum, fallback));
            if (!IsFinite(value)) value = fallback;
            return Math.Max(0.0f, Math.Min(maximum, value));
        }

        internal static bool IsFinite(float value)
        {
            return !Single.IsNaN(value) && !Single.IsInfinity(value);
        }
    }
}
