# CMS 2018 Custom Induction Mod — Patch 0.8.59

**Date:** 2026-10-31  
**Build:** C# compilation succeeded; patch installed while CMS was closed.  
**Installed DLL SHA-256:** `D9A4835622926FF61CA7D9B4311586C0AF0F58516E6FA3F4BB86488C7693A348`  
**Rollback DLL:** `build/installed-backups/CMS18TurboPrototype-20261031-200601.dll` (patch 0.8.58)  
**Status:** Ready for the user's next visual check. CMS has not been launched with 0.8.59. No dyno test has been run.

## Evidence from the 0.8.58 visual check

- The user said the R4 fitment is “almost there.” The latest image shows the pipe sweep close to the ProCharger outlet and throttle route, with a small remaining alignment issue.
- BepInEx loaded 0.8.58 on profile 2 with zero patch errors.
- Runtime selected `r4_przepustnica`; outlet-axis alignment was `-0.46`. The 0.8.58 log reported a `0.03 m` stub, rounded to two decimals; the computed handle at this alignment is about 25 mm.
- The logged outlet and intake endpoints are unchanged from the prior R4 test. The route keeps the same engine-clearance bow.

## Change in 0.8.59

- Shorten the minimum initial outlet handle from 23 mm to 18 mm when the outlet points away from the intake. At the logged R4 alignment of -0.46, the handle is about 20 mm.
- Preserve both measured endpoints, the outboard engine-clearance route, blower placement, I6 fitment, shop/menu behavior, and power behavior.
- This is a small fitment refinement based on “almost there,” not a claim that routing or dyno behavior is fully validated.

## Build and installation

- Compiled from `src/CMS18TurboPrototype.cs` against the local CMS and BepInEx references.
- Installed in `BepInEx/plugins` with the previous 0.8.58 DLL backed up at the path listed above.
- The installed file hash matches the compiled DLL.
- No game launch, in-game test, save edit, dyno run, or test script was performed for this patch.

## Next visual check

Use the same sandbox profile and view the R4 setup from the same angle. Confirm the short outlet turn looks aligned and remains joined at both ends without clipping. Check the I6 placement still looks good. Hold dyno testing until the user accepts the pipe routing.
