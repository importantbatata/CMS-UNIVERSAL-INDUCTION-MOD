using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace CMS18TurboPrototype
{
    public enum InductionMode
    {
        Off = 0,
        // Values 1 and 2 are retained because 0.8.x persisted these integers.
        // ReadMode now migrates both retired configurations to Off.
        Turbo = 1,
        Supercharger = 2,
        Procharger = 3
    }

    internal static class PluginInfo
    {
        internal const string Version = "0.9.18";
    }

    [BepInPlugin("local.cms18.turboproto", "CMS 2018 ProCharger P-1X", PluginInfo.Version)]
    public sealed class TurboPrototypePlugin : BaseUnityPlugin
    {
        private static readonly FieldInfo GameScriptHoveredPartField = AccessTools.Field(typeof(GameScript), "partMouseOver");
        private const string InstallProchargerPieOption = "cms18_install_procharger";
        private const string FindProchargerPieOption = "cms18_find_procharger";
        private const string BoostTargetPieOption = "cms18_procharger_boost";
        private const string BoostOffPieOption = "cms18_boost_off";
        private const string BoostStreetPieOption = "cms18_boost_street";
        private const string BoostTwentyPieOption = "cms18_boost_twenty";
        private const string BoostMaximumPieOption = "cms18_boost_maximum";
        private const string BoostIncreasePieOption = "cms18_boost_increase";
        private const string BoostDecreasePieOption = "cms18_boost_decrease";
        private const string BoostBackPieOption = "cms18_boost_back";
        private const string RemoveProchargerPieOption = "cms18_remove_procharger";
        // Keep the click callback type local to this plugin, then adapt it to
        // Button.onClick's UnityAction in the listener.

        private const string GlobalModeKey = "Mode";
        private const string GlobalPsiKey = "BoostPsi";
        private const string GroupModePrefix = "GroupMode.";
        private const string GroupPsiPrefix = "GroupPsi.";
        private const string EngineModePrefix = "EngineMode.";
        private const string EnginePsiPrefix = "EnginePsi.";
        private const string CarModePrefix = "CarMode.";
        private const string CarPsiPrefix = "CarPsi.";
        private const string MetaModeKey = "cms18_induction_mode";
        private const string MetaPsiKey = "cms18_boost_psi";
        private const string ProchargerPartId = "cms18_procharger_p1x";
        private const string ProchargerHighBoostPartId = "cms18_procharger_p1x_highboost";
        // Keep aliases only to load/remove parts saved by pre-0.9 builds. They are
        // excluded from shops, selectors, and the performance activation path.
        private const string RetiredTurboKitPartId = "cms18_turbo_kit";
        private const string RetiredRootsKitPartId = "cms18_supercharger_kit";
        private const string UniversalMountPartId = "cms18_universal_induction_mount";
        private const string UniversalMountDisplayName = "CMS18 Universal Induction Mount";
        private const int PartSelectionLayer = 16;
        // CMS Raycast.Init assigns 32768 (1 << 15) to mountObjectsRaycastMask.
        // Bolt colliders must use this layer; the parent part itself uses layer 16.
        private const string VirtualMountAnchorName = "CMS18 Induction Mount Fasteners";
        private const string ProchargerMountFastenerPrefix = "CMS18 Induction Mount Bolt ";
        private const int MountObjectSelectionLayer = 15;
        private static readonly float[] ProchargerMountBoltSeats = { 0.098f, 0.087f, 0.075f, 0.064f };
        private const string ProchargerBasePartId = "turbo_2";
        // Published P-1X limits: ProCharger Supercharger Specs (02/2026).
        // At peak engine RPM, the boost target sets a pulley ratio that stays
        // inside this impeller speed limit; centrifugal pressure rise follows N^2.
        private const float P1XMaxBoostPsi = 32.0f;
        private const float P1XStreetMaxBoostPsi = 20.0f;
        private const float P1XHighBoostDefaultPsi = 24.0f;
        private const float P1XChargeToTorqueFactor = 0.65f;
        private const float P1XMaxFlowCfm = 1275.0f;
        private const float P1XMaxSuperchargedHp = 950.0f;
        private const float P1XMaxImpellerRpm = 65000.0f;
        private const float P1XInternalStepUpRatio = 4.10f;
        private const float ProchargerOilCapacityMultiplier = 1.15f;
        // The P-1X OBJ is authored at 0.4 game-world meters per model unit.
        // This is checked against the 9-inch volute and 3.75-inch inlet geometry.
        private const float ProchargerModelUnitScale = 0.40f;
        private const string ProchargerModelResource = "CMS18_ProCharger_P1X.obj";
        // A common ProCharger street-system drive uses the factory six-rib belt.
        private const float ProchargerDriveBeltWidthMeters = 0.019f;
        private const float ProchargerDriveBeltThicknessMeters = 0.0034f;
        private const float SeaLevelAirDensityLbPerCubicFoot = 0.076f;
        private const float EstimatedHorsepowerPerLbPerMinute = 10.0f;
        private const float PsiPerAtmosphere = 14.7f;
        private const float PsiPerInchOfMercury = 2.03602f;
        private const float MaxManifoldVacuumPsi = 20.0f / PsiPerInchOfMercury;
        private const float BoostGaugeMinimumPsi = -10.0f;
        private const float BoostGaugeMaximumPsi = 32.0f;
        private static readonly Vector3 ProchargerDrivePulleyCenter = new Vector3(-0.315f, 0.0f, -0.095f);
        private const float ProchargerDrivePulleyRadiusModel = 0.1008f;
        private static readonly Vector3 ProchargerModelBoundsCenter = new Vector3(-0.0886f, -0.0167f, -0.0249f);
        // Charge-pipe socket data is recovered from the named outlet bore and bead
        // geometry in the embedded OBJ when it is loaded. These values are safe
        // fallbacks only; runtime ports are measured from the asset mesh.
        private const string InstalledInductionVisualName = "CMS18 Universal Induction Installed Model";
        private const string InstalledKitModePrefix = "InstalledKit.";
        private const float ContextRefreshSeconds = 3.0f;
        private const float VisualRefreshSeconds = 4.0f;
        private const float UiTextRefreshSeconds = 0.15f;
        private static readonly InductionMode[] ModeButtons =
        {
            InductionMode.Off, InductionMode.Procharger
        };
        private static readonly float[] StandModeButtonWidths = { 64.0f, 176.0f };
        private static readonly float[] GaugeModeButtonWidths = { 46.0f, 122.0f };
        private static readonly float[] BoostGaugeMajorPsiMarks = { -10.0f, 0.0f, 10.0f, 20.0f, 30.0f };
        private static readonly string[] BoostGaugeMajorLabels = { "20", "0", "10", "20", "30" };

        public static TurboPrototypePlugin Instance;

        private Harmony harmony;
        private InductionMode selectedMode = InductionMode.Off;
        private float selectedBoostPsi = 8.0f;
        private string standGroupKey = string.Empty;
        private string standGroupName = string.Empty;
        private int standGroupUid;
        private NewGroupItem standGroup;
        private bool standOccupied;
        private string activeCarKey = string.Empty;
        private VPVehicleController activeController;
        private InductionMode activeMode = InductionMode.Off;
        private float activeBoostPsi = 8.0f;
        private VehiclePhysics.Engine lastEngine;
        private CarLoader dynoResultsLoader;
        private CarLoader expandedOilFillCar;
        private PartScript unscrewingProcharger;
        private Sprite prochargerSetupIcon;
        private bool prochargerRemovalAnimating;
        private Mesh prochargerMountBoltMesh;
        private float? dynoSampleBoostPsi;
        private GUIStyle uiPanelStyle;
        private GUIStyle uiHeaderBarStyle;
        private GUIStyle uiAccentStyle;
        private GUIStyle uiHeaderTextStyle;
        private GUIStyle uiBodyTextStyle;
        private GUIStyle uiMutedTextStyle;
        private GUIStyle uiButtonStyle;
        private GUIStyle uiSelectedButtonStyle;
        private GUIStyle uiSliderStyle;
        private GUIStyle uiSliderThumbStyle;
        private GUIStyle uiGaugeTrackStyle;
        private GUIStyle uiGaugeFillStyle;
        private GUIStyle uiGaugeTickStyle;
        private GUIStyle uiGaugeWarnTickStyle;
        private GUIStyle uiGaugeDangerTickStyle;
        private GUIStyle uiGaugeNeedleStyle;
        private Texture2D boostGaugeFaceTexture;
        private readonly List<Texture2D> uiTextures = new List<Texture2D>();
        private float lastRpm;
        private float lastThrottle;
        private float lastNetTorque;
        private float currentSpool;
        private float spoolTarget;
        private float liveBoostPsi;
        private float nextContextRefresh;
        private float nextVisualRefresh;
        private GameObject visualRoot;
        private InductionMode visualMode;
        private InductionMode standNativeMode;
        private bool standHasNativeInduction;
        private bool standHasHighBoostProcharger;
        private bool cachedCarburetedContext;
        private float nextCarburetorProbe;
        private bool activeHasNativeInduction;
        private bool activeHasCustomInduction;
        private bool activeHasHighBoostProcharger;
        private string activeNativePartId = string.Empty;
        private readonly Dictionary<InductionMode, Mesh> inductionModelMeshes = new Dictionary<InductionMode, Mesh>();
        private readonly Dictionary<InductionMode, Material[]> inductionModelMaterials = new Dictionary<InductionMode, Material[]>();
        private readonly HashSet<InductionMode> inductionModelLoadAttempted = new HashSet<InductionMode>();
        private bool nativeTurboMaterialAppliedToProcharger;
        private Material prochargerDriveBeltMaterial;
        private Material prochargerBracketMaterial;
        private string status = "Waiting for an engine stand or driving test scene";
        private int settingsProfile;
        private GameInventory registeredShopInventory;
        private bool inductionShopItemsRegistered;
        private bool prochargerShopCardRecolorPending;
        private bool shopRegistrationWarningLogged;
        private string lastShopReadinessDiagnostic = String.Empty;
        private readonly HashSet<string> loggedShopQueryStates = new HashSet<string>();
        private NewGroupItem pendingInstallGroup;
        private string pendingInstallGroupName;
        private CarLoader pendingInstallLoader;
        private InductionMode pendingInstallMode;
        private float pendingInstallPsi;
        private bool pendingSwapObserved;
        private string pendingInstallKitId = String.Empty;
        private float nextUiTextRefresh;
        private string cachedGaugeBoostText = "MAP  0.0 psi";
        private string cachedGaugeMapText = "MAP 14.7 psia  |  PR 1.00";
        private string cachedGaugePowerText = "0 rpm    |    0 estimated hp";
        private string cachedGaugeAirflowText = "Estimated airflow  0.0 lb/min";
        private string cachedGaugeTargetText = "Target boost  8.0 psi";
        private string cachedGaugeRatingText = "Manifold pressure estimate";
        private readonly Dictionary<int, List<ProchargerRendererState>> prochargerRendererStates = new Dictionary<int, List<ProchargerRendererState>>();
        private int harmonyPatchFailures;
        private readonly Dictionary<int, List<ProchargerRendererState>> standPreviewRendererStates = new Dictionary<int, List<ProchargerRendererState>>();
        private readonly HashSet<BoxCollider> standPreviewHitboxes = new HashSet<BoxCollider>();
        private readonly HashSet<PartScript> mountedProchargerParts = new HashSet<PartScript>();
        private readonly HashSet<int> armedUniversalMounts = new HashSet<int>();
        private PartScript cachedPartMouseOver;
        private readonly Dictionary<int, InductionMode> mountedVisualModes = new Dictionary<int, InductionMode>();
        private bool loggedDisabledOutline;
        private readonly Dictionary<int, BoxCollider> mountedSelectionHitboxes = new Dictionary<int, BoxCollider>();
        private readonly Dictionary<int, MeshCollider> mountedSelectionMeshColliders = new Dictionary<int, MeshCollider>();
        private readonly Dictionary<int, Mesh> mountedSelectionCollisionMeshes = new Dictionary<int, Mesh>();
        private readonly Dictionary<int, List<PartColliderState>> mountedOriginalColliderStates = new Dictionary<int, List<PartColliderState>>();
        private readonly HashSet<int> checkedStandMountRoots = new HashSet<int>();

        private struct ProchargerRendererState
        {
            public Renderer renderer;
            public bool enabled;

            public ProchargerRendererState(Renderer target)
            {
                renderer = target;
                enabled = target != null && target.enabled;
            }
        }

        private struct PartColliderState
        {
            public Collider collider;
            public bool enabled;

            public PartColliderState(Collider target)
            {
                collider = target;
                enabled = target != null && target.enabled;
            }
        }

        private sealed class InstallTrackingEnumerator : IEnumerator
        {
            private readonly IEnumerator inner;
            private readonly TurboPrototypePlugin owner;
            private readonly NewGroupItem group;
            private readonly CarLoader loader;
            private readonly bool engineSwap;
            private bool finalized;

            internal InstallTrackingEnumerator(IEnumerator routine, TurboPrototypePlugin plugin, NewGroupItem installGroup, CarLoader targetLoader, bool isEngineSwap)
            {
                inner = routine;
                owner = plugin;
                group = installGroup;
                loader = targetLoader;
                engineSwap = isEngineSwap;
            }

            public object Current
            {
                get { return inner.Current; }
            }

            public bool MoveNext()
            {
                try
                {
                    if (inner.MoveNext()) return true;
                }
                catch
                {
                    FinalizeRoutine(false);
                    throw;
                }
                FinalizeRoutine(true);
                return false;
            }

            public void Reset()
            {
                inner.Reset();
                finalized = false;
            }

            private void FinalizeRoutine(bool succeeded)
            {
                if (finalized) return;
                finalized = true;
                if (owner == null || group == null) return;
                try
                {
                    if (succeeded)
                    {
                        if (engineSwap) owner.CompleteEngineInstall(loader, group);
                        else owner.CompleteActionInsert(group);
                    }
                    else
                    {
                        string reason = engineSwap
                            ? "Engine swap routine failed before completion"
                            : "Engine install action failed before completion";
                        owner.AbortPendingInstall(group, reason);
                    }
                }
                catch (Exception exception)
                {
                    // Bookkeeping must never turn a successful vanilla coroutine
                    // into a failed engine installation.
                    try { Debug.LogError("CMS 2018 ProCharger P-1X install bookkeeping failed: " + exception); }
                    catch { }
                }
            }
        }

        private void Awake()
        {
            try
            {
                // Log before touching profile/preferences so an early bootstrap
                // failure cannot leave only BepInEx's generic "Loading" line.
                Logger.LogInfo("CMS 2018 ProCharger P-1X " + PluginInfo.Version + " bootstrap entered.");
                Instance = this;
                settingsProfile = ReadSelectedProfile(0);
                selectedMode = ReadMode(PlayerPrefs.GetInt(PrefKey(GlobalModeKey), 0));
                selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(
                    PlayerPrefs.GetFloat(PrefKey(GlobalPsiKey), 8.0f), P1XMaxBoostPsi, 8.0f);

                harmony = new Harmony("local.cms18.turboproto");
                Patch(typeof(VehiclePhysics.Engine), "GetMaxPowerTorque", new Type[] { typeof(float) }, null, "MaxPowerTorquePostfix");
                // EngineSpecs is intentionally not patched. CMS reuses it for factory,
                // showroom and dyno values; changing it here contaminated every car's
                // factory baseline. Dyno torque charts remain sampled on the active car.
                Patch(typeof(GameScript), "GetGroupOnEngineStand", Type.EmptyTypes, null, "StandGroupPostfix");
                Patch(typeof(GameScript), "SetGroupOnEngineStand", new Type[] { typeof(NewGroupItem) }, "SetStandGroupPrefix", null);
                // Add the option to the result from CMS's menu-config reader. This is
                // the earliest stable point: PreparePieMenu immediately passes this
                // array to PrepareIcons, so the stock menu builds the new action itself.
                Patch(typeof(PieMenuController), "ReadOptionsFromIni", new Type[] { typeof(string) }, null, "InductionPieOptionsReadPostfix");
                Patch(typeof(PieMenuController), "PrepareIcons", new Type[] { typeof(string[]) }, "InductionPieIconsPreparePrefix", "InductionPieIconsPreparedPostfix");
                Patch(typeof(PieMenuController), "CheckSelectedOption", Type.EmptyTypes, "InductionPieMenuSelectionPrefix", null);
                Patch(typeof(PieMenuController), "SetPieMenuDescription", new Type[] { typeof(int) }, null, "InductionPieDescriptionPostfix");
                Patch(typeof(GameManager), "CheckOptionIsAvaiable", new Type[] { typeof(string) }, "InductionPieOptionAvailablePrefix", null);
                Patch(typeof(GameManager), "ActionInsertEngineToCar", new Type[] { typeof(NewGroupItem) }, "InsertEnginePrefix", "InsertEnginePostfix");
                Patch(typeof(CarLoader), "SwapEngine", new Type[] { typeof(NewGroupItem) }, "SwapEnginePrefix", "SwapEnginePostfix");
                Patch(typeof(CarLoader), "SetEngine", Type.EmptyTypes, null, "SetEnginePostfix");
                Patch(typeof(GameInventory), "GetGO", new Type[] { typeof(string) }, "InductionGetGOPrefix", null);
                Patch(typeof(GameInventory), "GetGO2", new Type[] { typeof(string) }, "InductionGetGO2Prefix", null);
                Patch(typeof(GameInventory), "IsTuning", new Type[] { typeof(string), typeof(string) }, "InductionIsTuningPrefix", null);
                // The synthetic mount sets ForcePartGroup=-1, which verified Raycast IL
                // routes directly to the string-ID check. CMS may restore the group on
                // a runtime instance, so the integer fallback below is scoped only to
                // an installed/armed mount that is currently hovered.
                Patch(typeof(GameScript), "IsPartAccessible", new Type[] { typeof(int) }, "InductionIsPartGroupAccessiblePrefix", null);
                Patch(typeof(GameScript), "IsPartAccessible", new Type[] { typeof(string) }, "InductionIsPartAccessiblePrefix", null);
                Patch(typeof(GameScript), "SetPartMouseOver", new Type[] { typeof(PartScript) }, null, "InductionPartMouseOverPostfix");
                Patch(typeof(PartScript), "MouseOver", Type.EmptyTypes, null, "ProchargerHitHighlightPostfix");
                Patch(typeof(Inventory), "GetItems", new Type[] { typeof(string) }, null, "InductionInventoryGetItemsPostfix");
                Patch(typeof(PartScript), "TunePart", new Type[] { typeof(string), typeof(bool) }, "InductionTunePartPrefix", "InductionTunePartPostfix");
                Patch(typeof(PartScript), "ActionUnMount", Type.EmptyTypes, "ProchargerUnmountPrefix", null);
                Patch(typeof(PartScript), "Update", Type.EmptyTypes, "ProchargerBoltUpdatePrefix", null);
                Patch(typeof(GameInventory), "GetThumb", new Type[] { typeof(string) }, null, "InductionShopThumbPostfix");
                Patch(typeof(GameInventory), "GetItemLocalizeName", new Type[] { typeof(string) }, null, "InductionShopNamePostfix");
                Patch(typeof(GameInventory), "GetIOLocalizedName", new Type[] { typeof(InteractiveObject) }, null, "InductionIOLocalizedNamePostfix");
                Patch(typeof(GameInventory), "GetItems", new Type[] { typeof(string) }, null, "InductionShopGetItemsPostfix");
                Patch(typeof(Localization), "Get", new Type[] { typeof(string) }, null, "InductionLocalizationPostfix");
                Patch(typeof(UIManager), "CreateShop", Type.EmptyTypes, "ShopCreatePrefix", null);
                Type shopCreatorType = typeof(UIManager).Assembly.GetType("UIManager/<CreateShop>c__IteratorD", false);
                if (!System.Object.ReferenceEquals(shopCreatorType, null))
                    Patch(shopCreatorType, "MoveNext", Type.EmptyTypes, null, "ShopCardMoveNextPostfix");
                Patch(typeof(DynoManager), "PrepareDyno", Type.EmptyTypes, null, "DynoPreparePostfix");
                Patch(typeof(PuszkaWlewOleju), "OnEnable", Type.EmptyTypes, null, "OilCanEnabledPostfix");
                Patch(typeof(PuszkaWlewOleju), "OnDisable", Type.EmptyTypes, null, "OilCanDisabledPostfix");
                Patch(typeof(CarLoader), "AddOil", new Type[] { typeof(float), typeof(float) }, "ProchargerOilFillPrefix", null);
                Patch(typeof(MenuDyno), "StartShowData", Type.EmptyTypes, "DynoResultsPrefix", null, "DynoResultsFinalizer");
                Patch(typeof(MenuDyno), "SetNewData", Type.EmptyTypes, "DynoResultsPrefix", null, "DynoResultsFinalizer");
                Patch(typeof(CarEngineHelper), ".ctor", new Type[] { typeof(CarLoader) }, "DynoMeasuredEnginePrefix", null, "DynoSamplingFinalizer");
                Patch(typeof(CarEngineHelper), "DrawPowerTorqueChart", null, "DynoTorqueChartPrefix", null, "DynoSamplingFinalizer");
                Logger.LogInfo("CMS 2018 ProCharger P-1X " + PluginInfo.Version + " loaded for save profile " + settingsProfile + ". P-1X shop, installation, visual, boost, and dyno hooks are active. Factory engine specifications are left untouched. Patch errors=" + harmonyPatchFailures + ".");
                if (harmonyPatchFailures > 0)
                    status = harmonyPatchFailures + " Harmony patch(es) failed; see BepInEx LogOutput.log";
            }
            catch (Exception exception)
            {
                status = "Plugin startup failed; see BepInEx LogOutput.log";
                Logger.LogError(status + ": " + exception);
            }
        }

        private void Patch(Type targetType, string targetName, Type[] argumentTypes, string prefixName, string postfixName, string finalizerName = null)
        {
            MethodBase original = null;
            try
            {
                if (targetName == ".ctor")
                {
                    original = targetType.GetConstructor(
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                        null, argumentTypes ?? Type.EmptyTypes, null);
                }
                else
                {
                    original = argumentTypes == null
                        ? AccessTools.Method(targetType, targetName)
                        : AccessTools.Method(targetType, targetName, argumentTypes);
                }
                if (System.Object.ReferenceEquals(original, null))
                    throw new MissingMethodException(targetType.FullName, targetName);

                HarmonyMethod prefix = prefixName == null ? null : CreateHarmonyMethod(prefixName);
                HarmonyMethod postfix = postfixName == null ? null : CreateHarmonyMethod(postfixName);
                HarmonyMethod finalizer = finalizerName == null ? null : CreateHarmonyMethod(finalizerName);
                harmony.Patch(original, prefix, postfix, null, finalizer, null);
                Logger.LogInfo("Patched " + original.DeclaringType.FullName + "." + original.Name);
            }
            catch (Exception exception)
            {
                harmonyPatchFailures++;
                string target = System.Object.ReferenceEquals(original, null)
                    ? targetType.FullName + "." + targetName
                    : original.DeclaringType.FullName + "." + original.Name;
                Logger.LogError("Could not patch " + target + "; remaining patches will still be attempted: " + exception);
            }
        }

        private static HarmonyMethod CreateHarmonyMethod(string methodName)
        {
            const BindingFlags hookFlags = BindingFlags.Public | BindingFlags.NonPublic
                | BindingFlags.Static | BindingFlags.Instance;
            // AccessTools.Method logs a Harmony warning for a missing name. Some
            // hooks intentionally live on the plugin class rather than the hooks
            // adapter, so use reflection here and only report a real miss below.
            MethodInfo method = typeof(TurboPrototypeHooks).GetMethod(methodName, hookFlags);
            if (System.Object.ReferenceEquals(method, null))
                method = typeof(TurboPrototypePlugin).GetMethod(methodName, hookFlags);
            if (System.Object.ReferenceEquals(method, null)) throw new MissingMethodException("CMS18TurboPrototype hook", methodName);
            return new HarmonyMethod(method);
        }

        private void Update()
        {
            if (Time.unscaledTime >= nextContextRefresh)
            {
                nextContextRefresh = Time.unscaledTime + ContextRefreshSeconds;
                RefreshProfileContext();
                RefreshStandContext();
                RefreshCarContext();
                EnsureProchargerShopRegistration();
                RefreshProchargerNativeTurboMaterial();
                RefreshMountedProchargerVisuals();
            }

            if (Input.GetKeyDown(KeyCode.F8))
            {
                CycleMode();
            }

            AdvanceSpool(Time.deltaTime);

            if (Time.unscaledTime >= nextUiTextRefresh)
            {
                nextUiTextRefresh = Time.unscaledTime + UiTextRefreshSeconds;
                RefreshUiTextCache();
            }

            if (Time.unscaledTime >= nextVisualRefresh)
            {
                nextVisualRefresh = Time.unscaledTime + VisualRefreshSeconds;
                EnsureVisual();
            }

        }

        private void LateUpdate()
        {
            if (unscrewingProcharger == null || prochargerRemovalAnimating) return;
            GameMode mode = GameMode.Get();
            if (mode == null || mode.GetCurrentMode() != gameMode.PartUnMount)
            {
                ResetProchargerBoltRemoval();
                return;
            }
            MountObject[] bolts = unscrewingProcharger.MountObjects;
            if (bolts == null || bolts.Length != ProchargerMountBoltSeats.Length || Array.Exists(bolts, bolt => bolt == null))
            {
                ResetProchargerBoltRemoval();
                mode.SetCurrentMode(gameMode.PartSelect);
                ShowProchargerPopup("The ProCharger mounting bolts are unavailable.");
                return;
            }
            foreach (MountObject bolt in bolts)
                if (bolt.GetMountState() > 0.0001f) return;
            prochargerRemovalAnimating = true;
            StartCoroutine(FinishProchargerBoltRemoval(unscrewingProcharger));
        }

        private void RefreshUiTextCache()
        {
            cachedGaugeBoostText = liveBoostPsi >= 0.0f
                ? "MANIFOLD  +" + liveBoostPsi.ToString("F1") + " psi"
                : "VACUUM  " + (Mathf.Abs(liveBoostPsi) * PsiPerInchOfMercury).ToString("F1") + " inHg";
            float manifoldAbsolutePsi = Mathf.Max(0.1f, PsiPerAtmosphere + liveBoostPsi);
            float pressureRatio = manifoldAbsolutePsi / PsiPerAtmosphere;
            cachedGaugeMapText = "MAP " + manifoldAbsolutePsi.ToString("F1") + " psia  |  PR " + pressureRatio.ToString("F2");
            float horsepower = lastNetTorque * lastRpm / 7127.0f;
            float estimatedAirflow = Mathf.Max(0.0f, horsepower) / EstimatedHorsepowerPerLbPerMinute;
            cachedGaugePowerText = lastRpm.ToString("F0") + " rpm  |  " + horsepower.ToString("F0") + " est. hp  |  " + lastNetTorque.ToString("F0") + " Nm";
            cachedGaugeAirflowText = activeMode == InductionMode.Procharger
                ? "Flow est. " + estimatedAirflow.ToString("F1") + " lb/min  ("
                    + (estimatedAirflow / SeaLevelAirDensityLbPerCubicFoot).ToString("F0") + "/"
                    + P1XMaxFlowCfm.ToString("F0") + " CFM)"
                : "Flow estimate  " + estimatedAirflow.ToString("F1") + " lb/min";
            if (activeMode == InductionMode.Procharger && lastEngine != null && lastEngine.settings != null)
            {
                float activeTarget = ProchargerMath.NormalizeBoostPsi(PsiForActiveCar(), GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger), 8.0f);
                float impellerRpm = CalculateP1XImpellerRpm(lastEngine.settings, lastRpm, activeTarget);
                cachedGaugeTargetText = "Target " + activeTarget.ToString("F1") + " psi  |  P-1X "
                    + (impellerRpm / 1000.0f).ToString("F1") + "/" + (P1XMaxImpellerRpm / 1000.0f).ToString("F0") + "k rpm";
            }
            else
            {
                cachedGaugeTargetText = "Boost target  " + PsiForActiveCar().ToString("F1") + " psi";
            }
            cachedGaugeRatingText = activeMode == InductionMode.Procharger
                ? (activeHasHighBoostProcharger ? "High-Boost target ceiling " : "Street-kit target ceiling ")
                    + GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger).ToString("F0") + " psi; P-1X unit: "
                    + P1XMaxSuperchargedHp.ToString("F0") + " hp / " + P1XMaxFlowCfm.ToString("F0") + " CFM / 65k rpm"
                : "Generic compressor estimate; no exact map loaded";
        }

        private void EnsureProchargerShopRegistration()
        {
            GameInventory[] candidates = UnityEngine.Object.FindObjectsOfType<GameInventory>();
            GameInventory inventory = null;
            for (int i = 0; i < candidates.Length; i++)
            {
                GameInventory candidate = candidates[i];
                if (candidate != null && candidate.IsReady && HasPartPropertyList(candidate))
                {
                    try
                    {
                        GameInventory.PartProperty template = candidate.GetItemProperty(ProchargerBasePartId);
                        if (IsValidProchargerShopTemplate(template))
                        {
                            inventory = candidate;
                            break;
                        }
                    }
                    catch (Exception) { }
                }
            }
            if (inventory == null)
            {
                GameInventory candidate = candidates.Length > 0 ? candidates[0] : null;
                string readiness = candidate == null ? "no active GameInventory" : "GameInventory ready="
                    + candidate.IsReady + ", partsFlag=" + candidate.IsReadyFillPartPropertyList
                    + ", catalog=" + HasPartPropertyList(candidate) + ", turbo_2=" + HasValidTurboTemplate(candidate);
                if (!String.Equals(lastShopReadinessDiagnostic, readiness, StringComparison.Ordinal))
                {
                    lastShopReadinessDiagnostic = readiness;
                    Logger.LogInfo("Shop catalog waiting for the active inventory: " + readiness + ".");
                }
                return;
            }
            lastShopReadinessDiagnostic = String.Empty;
            if (registeredShopInventory != inventory)
            {
                registeredShopInventory = inventory;
                inductionShopItemsRegistered = false;
                shopRegistrationWarningLogged = false;
            }
            if (inductionShopItemsRegistered && HasRegisteredShopProducts(inventory)) return;

            try
            {
                GameInventory.PartProperty turboTemplate = inventory.GetItemProperty(ProchargerBasePartId);
                if (!IsValidProchargerShopTemplate(turboTemplate))
                {
                    if (!shopRegistrationWarningLogged)
                    {
                        shopRegistrationWarningLogged = true;
                        Logger.LogWarning("Could not register the ProCharger shop item because the stock turbo_2 Engine shop definition was not ready.");
                    }
                    return;
                }

                RegisterInductionProperty(inventory, turboTemplate, UniversalMountPartId,
                    "Universal Induction Mount", "CMS18", "CMS18Internal", 0);
                RegisterInductionProperty(inventory, turboTemplate, ProchargerPartId,
                    "ProCharger P-1X", "ProCharger", "MainShop", 12500);
                RegisterInductionProperty(inventory, turboTemplate, ProchargerHighBoostPartId,
                    "ProCharger P-1X High-Boost (32 PSI)", "ProCharger", "TuningShop", 24900);
                inductionShopItemsRegistered = HasShopProperty(inventory, ProchargerPartId, "MainShop")
                    && HasShopProperty(inventory, ProchargerHighBoostPartId, "TuningShop");
                if (inductionShopItemsRegistered)
                {
                    status = "Standard P-1X registered in Main Shop; high-boost P-1X registered in Tuning Shop";
                    Logger.LogInfo(status + "; high-boost P-1X is $24,900 and the internal mount is hidden from shops.");
                }
            }
            catch (Exception exception)
            {
                if (!shopRegistrationWarningLogged)
                {
                    shopRegistrationWarningLogged = true;
                    Logger.LogWarning("Could not register the ProCharger shop item: " + exception);
                }
            }
        }

        private static bool HasRegisteredShopProducts(GameInventory inventory)
        {
            return HasShopProperty(inventory, ProchargerPartId, "MainShop")
                && HasShopProperty(inventory, ProchargerHighBoostPartId, "TuningShop");
        }

        private static bool HasPartPropertyList(GameInventory inventory)
        {
            if (inventory == null) return false;
            FieldInfo field = AccessTools.Field(typeof(GameInventory), "partPropertyList");
            // Avoid FieldInfo.op_Inequality: the CMS 2018 Mono runtime is missing it.
            return !System.Object.ReferenceEquals(field, null) && field.GetValue(inventory) is IList;
        }

        private static bool HasValidTurboTemplate(GameInventory inventory)
        {
            if (inventory == null || !HasPartPropertyList(inventory)) return false;
            try { return IsValidProchargerShopTemplate(inventory.GetItemProperty(ProchargerBasePartId)); }
            catch { return false; }
        }

        private static bool HasShopProperty(GameInventory inventory, string id, string shopName)
        {
            if (inventory == null) return false;
            GameInventory.PartProperty property = inventory.GetItemProperty(id);
            // GetItemProperty returns an unregistered placeholder, rather than null,
            // for unknown IDs. Require the actual catalog fields before accepting it.
            return property != null
                && String.Equals(property.ID, id, StringComparison.Ordinal)
                && String.Equals(property.ShopName, shopName, StringComparison.Ordinal)
                && String.Equals(property.ShopGroup, "Engine", StringComparison.Ordinal);
        }

        public void EnsureShopCatalogReady()
        {
            EnsureProchargerShopRegistration();
        }

        private static void RegisterInductionProperty(GameInventory inventory, GameInventory.PartProperty template,
            string id, string localizedName, string brand, string shopName, int price)
        {
            // GetItemProperty constructs a non-null placeholder for unknown IDs and
            // copies the ID into ShopName/ShopGroup. Only an actual catalog row should
            // suppress registration.
            if (HasShopProperty(inventory, id, shopName)) return;
            // CMS shop-card creation calls SteamScript.GetDLC and hides rows
            // whose list is empty. DLC id 0 is the game's base-game sentinel
            // (GetDLC(0) checks id -1), so mod-added products remain visible.
            int[] dlc = new int[] { 0 };
            GameInventory.PartProperty property = new GameInventory.PartProperty(id, price, template.PartGroup,
                template.ShopGroup, template.ExamineGroup, template.RepairGroup, template.SpecialGroup,
                dlc, template.TuningValue, false, localizedName, brand, shopName);
            inventory.AddToPartPropertyList(property.ID, property.Price, property.PartGroup, property.ShopGroup,
                property.ExamineGroup, property.RepairGroup, property.SpecialGroup, property.DLC,
                property.TuningValue, property.IsBody, property.LocalizedName, property.Brand, property.ShopName);
        }

        internal static bool IsValidProchargerShopTemplate(GameInventory.PartProperty template)
        {
            return template != null
                && String.Equals(template.ID, ProchargerBasePartId, StringComparison.Ordinal)
                && String.Equals(template.ShopName, "MainShop", StringComparison.Ordinal)
                && String.Equals(template.ShopGroup, "Engine", StringComparison.Ordinal);
        }

        internal static GameInventory.PartProperty CreateProchargerShopProperty(GameInventory.PartProperty turboTemplate)
        {
            if (turboTemplate == null) throw new ArgumentNullException("turboTemplate");
            int[] dlc = new int[] { 0 };
            long scaledPrice = (long)Math.Max(0, turboTemplate.Price) * 2L;
            int price = (int)Math.Min(Int32.MaxValue, Math.Max(12500L, scaledPrice));
            return new GameInventory.PartProperty(ProchargerPartId, price, turboTemplate.PartGroup,
                turboTemplate.ShopGroup, turboTemplate.ExamineGroup, turboTemplate.RepairGroup,
                turboTemplate.SpecialGroup, dlc, turboTemplate.TuningValue, false,
                "ProCharger P-1X", "ProCharger", turboTemplate.ShopName);
        }

        internal static GameInventory.PartProperty CreateProchargerHighBoostShopProperty(GameInventory.PartProperty turboTemplate)
        {
            if (turboTemplate == null) throw new ArgumentNullException("turboTemplate");
            int[] dlc = new int[] { 0 };
            return new GameInventory.PartProperty(ProchargerHighBoostPartId, 24900, turboTemplate.PartGroup,
                turboTemplate.ShopGroup, turboTemplate.ExamineGroup, turboTemplate.RepairGroup,
                turboTemplate.SpecialGroup, dlc, turboTemplate.TuningValue, false,
                "ProCharger P-1X High-Boost (32 PSI)", "ProCharger", "TuningShop");
        }

        internal static bool IsProchargerPartId(string partId)
        {
            return IsCustomPartId(partId, ProchargerPartId)
                || IsCustomPartId(partId, ProchargerHighBoostPartId);
        }

        internal static bool IsHighBoostProchargerPartId(string partId)
        {
            return IsCustomPartId(partId, ProchargerHighBoostPartId);
        }

        internal static string NormalizeProchargerTuneId(string partId)
        {
            return NormalizeInductionTuneId(partId);
        }

        internal static bool IsInductionPartId(string partId)
        {
            return IsProchargerPartId(partId) || IsRetiredKitPartId(partId);
        }

        internal static bool IsRetiredKitPartId(string partId)
        {
            return IsCustomPartId(partId, RetiredTurboKitPartId)
                || IsCustomPartId(partId, RetiredRootsKitPartId);
        }

        internal static InductionMode ModeForInductionPartId(string partId)
        {
            if (IsProchargerPartId(partId)) return InductionMode.Procharger;
            return InductionMode.Off;
        }

        internal static string NormalizeInductionTuneId(string partId)
        {
            return IsInductionPartId(partId) ? ProchargerBasePartId : partId;
        }

        private static bool IsCustomPartId(string partId, string baseId)
        {
            if (String.IsNullOrEmpty(partId) || String.IsNullOrEmpty(baseId)) return false;
            string id = partId.Trim();
            if (String.Equals(id, baseId, StringComparison.OrdinalIgnoreCase)) return true;
            string prefix = baseId + "(";
            if (!id.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || !id.EndsWith(")", StringComparison.Ordinal)) return false;
            int digitCount = id.Length - prefix.Length - 1;
            if (digitCount <= 0) return false;
            for (int i = 0; i < digitCount; i++)
            {
                char digit = id[prefix.Length + i];
                if (digit < '0' || digit > '9') return false;
            }
            return true;
        }
        private void RefreshStandContext()
        {
            try
            {
                GameScript game = GameScript.Get();
                if (game == null || game.EngineStandIsEmpty())
                {
                    standOccupied = false;
                    standHasNativeInduction = false;
                    standHasHighBoostProcharger = false;
                    standNativeMode = InductionMode.Off;
                    standGroup = null;
                    standGroupKey = string.Empty;
                    standGroupName = string.Empty;
                    standGroupUid = 0;
                    return;
                }

                // The belt-drive mount is a gameplay part and must exist even before the
                // shop catalog has been initialized; otherwise P-1X falls back to the
                // factory turbo slot and routes its pipe through the engine.
                EnsureUniversalMountOnStand(game);
                NewGroupItem group = game.GetGroupOnEngineStand();
                if (group == null || group.ItemList == null || group.ItemList.Count == 0)
                {
                    standOccupied = false;
                    standHasNativeInduction = false;
                    standHasHighBoostProcharger = false;
                    standNativeMode = InductionMode.Off;
                    standGroup = null;
                    standGroupKey = string.Empty;
                    standGroupName = string.Empty;
                    standGroupUid = 0;
                    return;
                }

                string key = BuildGroupKey(group);
                bool changed = !String.Equals(key, standGroupKey, StringComparison.Ordinal) || group.UId != standGroupUid;
                standOccupied = true;
                standGroup = group;
                standGroupKey = key;
                standGroupName = String.IsNullOrEmpty(group.GroupName) ? "engine group" : group.GroupName;
                standGroupUid = group.UId;
                RefreshStandPartDetection(game);

                if (changed)
                {
                    checkedStandMountRoots.Clear();
                    InductionMode mode;
                    float psi;
                    if (TryReadGroupSettings(group, out mode, out psi))
                    {
                        selectedMode = mode;
                        selectedBoostPsi = psi;
                    }
                    else if (TryReadStoredGroupSettings(group, out mode, out psi))
                    {
                        selectedMode = mode;
                        selectedBoostPsi = psi;
                    }
                    else
                    {
                        selectedMode = InductionMode.Off;
                        selectedBoostPsi = 8.0f;
                    }
                    selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(selectedBoostPsi,
                        GetMaximumBoostPsi(selectedMode, standHasHighBoostProcharger), 8.0f);

                    SaveGlobalSettings();
                    status = "Engine stand ready: " + standGroupName;
                }
            }
            catch (Exception exception)
            {
                standOccupied = false;
                standGroup = null;
                standGroupKey = string.Empty;
                standGroupName = string.Empty;
                standGroupUid = 0;
                Logger.LogWarning("Could not inspect the engine stand: " + exception.Message);
            }
        }

        private void RefreshCarContext()
        {
            try
            {
                VPVehicleController linkedController;
                CarLoader loader = FindActiveCarLoader(out linkedController);
                activeController = linkedController;
                string key = string.Empty;
                if (loader != null)
                {
                    key = BuildCarIdentityKey(loader);
                }

                if (!String.Equals(key, activeCarKey, StringComparison.Ordinal))
                {
                    activeCarKey = key;
                    if (!standOccupied && !String.IsNullOrEmpty(activeCarKey))
                    {
                        if (PlayerPrefs.HasKey(PrefKey(CarModePrefix + activeCarKey)))
                        {
                            selectedMode = ReadMode(PlayerPrefs.GetInt(PrefKey(CarModePrefix + activeCarKey), 0));
                            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(PlayerPrefs.GetFloat(PrefKey(CarPsiPrefix + activeCarKey), 8.0f), P1XMaxBoostPsi, 8.0f);
                            SaveGlobalSettings();
                            status = "Loaded induction settings for " + activeCarKey;
                        }
                        else if (TryLoadEngineAlias(loader, out selectedMode, out selectedBoostPsi))
                        {
                            SaveCarSettings(activeCarKey, selectedMode, selectedBoostPsi);
                            status = "Restored P-1X setup from the installed engine";
                        }
                        else
                        {
                            selectedMode = InductionMode.Off;
                            selectedBoostPsi = 8.0f;
                            SaveGlobalSettings();
                        }
                    }
                    UpdateEffectiveSettings();
                }
                else if (!String.IsNullOrEmpty(activeCarKey))
                {
                    // Parts can be mounted or removed without changing the car scene.
                    // Recheck at the existing context-refresh interval so native shop parts
                    // can switch the automatic induction mode immediately.
                    UpdateEffectiveSettings();
                }
            }
            catch (Exception exception)
            {
                activeController = null;
                Logger.LogWarning("Could not inspect the active car: " + exception.Message);
            }
        }
        private void CycleMode()
        {
            SetMode(selectedMode == InductionMode.Procharger ? InductionMode.Off : InductionMode.Procharger);
        }

        private void SetMode(InductionMode mode)
        {
            if (mode != InductionMode.Off && mode != InductionMode.Procharger)
            {
                status = "This build supports the ProCharger P-1X only.";
                Logger.LogInfo(status);
                return;
            }
            bool installedProcharger = standOccupied
                ? standHasNativeInduction && standNativeMode == InductionMode.Procharger
                : activeHasCustomInduction && activeMode == InductionMode.Procharger;
            if (mode == InductionMode.Procharger && !installedProcharger)
            {
                selectedMode = InductionMode.Off;
                status = "No ProCharger is installed. Buy a kit from the Main Shop or Tuning Shop, then install it from inventory.";
                SaveGlobalSettings();
                RemoveVisual();
                Logger.LogInfo(status);
                return;
            }
            if (mode == InductionMode.Off && installedProcharger)
            {
                status = "A ProCharger is installed. Remove it through the engine assembly to return to naturally aspirated operation.";
                Logger.LogInfo(status);
                return;
            }
            if (selectedMode != mode)
            {
                currentSpool = 0.0f;
                liveBoostPsi = 0.0f;
            }
            selectedMode = mode;
            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(selectedBoostPsi, GetMaximumBoostPsi(mode, standOccupied ? standHasHighBoostProcharger : activeHasHighBoostProcharger), 8.0f);
            SaveGlobalSettings();
            UpdateEffectiveSettings();
            if (standOccupied && standGroup != null)
            {
                SaveGroupSettings(standGroup, mode, selectedBoostPsi);
                SaveGroupKitSelection(standGroup, mode);
                AnnotateGroup(standGroup, mode, selectedBoostPsi);
                RegisterEngineAliases(standGroup, mode, selectedBoostPsi);
                status = ModeName(mode) + " selected for " + standGroupName;
            }
            else if (!String.IsNullOrEmpty(activeCarKey))
            {
                SaveCarSettings(activeCarKey, mode, selectedBoostPsi);
                status = ModeName(mode) + " selected for " + activeCarKey;
            }
            else
            {
                status = ModeName(mode) + " selected; choose an engine on the stand to attach it to that engine";
            }

            RemoveVisual();
            EnsureVisual();
            Logger.LogInfo(status);
        }

        private void SaveGroupKitSelection(NewGroupItem group, InductionMode mode)
        {
            // Installed-kit state belongs to a specific car key. Group keys are
            // shared by engine builds and must never persist a fitted kit.
        }

        private void SetBoostPsi(float psi)
        {
            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(psi, GetCurrentControlBoostLimit(), selectedBoostPsi);
            SaveGlobalSettings();
            UpdateEffectiveSettings();
            if (standOccupied && standGroup != null)
            {
                SaveGroupSettings(standGroup, selectedMode, selectedBoostPsi);
                AnnotateGroup(standGroup, selectedMode, selectedBoostPsi);
                RegisterEngineAliases(standGroup, selectedMode, selectedBoostPsi);
            }
            else if (!String.IsNullOrEmpty(activeCarKey))
            {
                SaveCarSettings(activeCarKey, selectedMode, selectedBoostPsi);
            }
        }

        private void SaveGlobalSettings()
        {
            PlayerPrefs.SetInt(PrefKey(GlobalModeKey), (int)selectedMode);
            PlayerPrefs.SetFloat(PrefKey(GlobalPsiKey), selectedBoostPsi);
        }

        private static float GetMaximumBoostPsi(InductionMode mode, bool highBoostProcharger)
        {
            if (mode == InductionMode.Procharger && highBoostProcharger) return P1XMaxBoostPsi;
            return P1XStreetMaxBoostPsi;
        }

        private float GetCurrentControlBoostLimit()
        {
            return standOccupied
                ? GetMaximumBoostPsi(selectedMode, standHasHighBoostProcharger)
                : GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger);
        }

        private void SaveGroupSettings(NewGroupItem group, InductionMode mode, float psi)
        {
            string key = BuildGroupKey(group);
            PlayerPrefs.SetInt(PrefKey(GroupModePrefix + key), (int)mode);
            PlayerPrefs.SetFloat(PrefKey(GroupPsiPrefix + key), psi);
            SaveGlobalSettings();
            PlayerPrefs.Save();
        }

        private bool TryReadStoredGroupSettings(NewGroupItem group, out InductionMode mode, out float psi)
        {
            mode = InductionMode.Off;
            psi = 8.0f;
            if (group == null) return false;

            string currentKey = BuildGroupKey(group);
            string storedKey = currentKey;
            if (!PlayerPrefs.HasKey(PrefKey(GroupModePrefix + storedKey)))
            {
                string legacyKey = BuildLegacyGroupKey(group);
                if (String.IsNullOrEmpty(legacyKey) || String.Equals(legacyKey, currentKey, StringComparison.Ordinal)
                    || !PlayerPrefs.HasKey(PrefKey(GroupModePrefix + legacyKey))) return false;
                storedKey = legacyKey;
            }

            mode = ReadMode(PlayerPrefs.GetInt(PrefKey(GroupModePrefix + storedKey), 0));
            psi = ProchargerMath.NormalizeBoostPsi(PlayerPrefs.GetFloat(PrefKey(GroupPsiPrefix + storedKey), 8.0f), P1XMaxBoostPsi, 8.0f);
            if (!String.Equals(storedKey, currentKey, StringComparison.Ordinal))
            {
                PlayerPrefs.SetInt(PrefKey(GroupModePrefix + currentKey), (int)mode);
                PlayerPrefs.SetFloat(PrefKey(GroupPsiPrefix + currentKey), psi);
                PlayerPrefs.Save();
            }
            return true;
        }

        private void SaveCarSettings(string carKey, InductionMode mode, float psi)
        {
            if (String.IsNullOrEmpty(carKey)) return;
            PlayerPrefs.SetInt(PrefKey(CarModePrefix + carKey), (int)mode);
            PlayerPrefs.SetFloat(PrefKey(CarPsiPrefix + carKey), psi);
            SaveGlobalSettings();
            PlayerPrefs.Save();
            UpdateEffectiveSettings();
        }
        private static string BuildGroupKey(NewGroupItem group)
        {
            if (group == null) return string.Empty;
            string groupName = NormalizeKey(group.GroupName);
            if (!String.IsNullOrEmpty(groupName)) return groupName;
            string itemKey = string.Empty;
            if (group.ItemList != null && group.ItemList.Count > 0)
            {
                NewInventoryItem item = group.ItemList[0];
                if (item != null)
                {
                    itemKey = NormalizeKey(GetNormalId(item));
                }
            }
            return itemKey;
        }

        private static string BuildLegacyGroupKey(NewGroupItem group)
        {
            if (group == null) return string.Empty;
            string itemKey = string.Empty;
            if (group.ItemList != null && group.ItemList.Count > 0)
            {
                NewInventoryItem item = group.ItemList[0];
                if (item != null) itemKey = NormalizeKey(GetNormalId(item));
            }
            return NormalizeKey(group.GroupName) + "_" + itemKey;
        }

        private static T ReadComponentReference<T>(object instance, string fieldName) where T : class
        {
            if (instance == null) return null;
            FieldInfo field = AccessTools.Field(instance.GetType(), fieldName);
            return System.Object.ReferenceEquals(field, null) ? null : field.GetValue(instance) as T;
        }

        private CarLoader FindActiveCarLoader(out VPVehicleController controller)
        {
            controller = null;
            PrepareCarPhysics setup = PrepareCarPhysics.Get();
            CarLoader setupLoader = null;
            if (setup != null)
            {
                controller = ReadComponentReference<VPVehicleController>(setup, "vpVehicleController");
                setupLoader = ReadComponentReference<CarLoader>(setup, "carLoader");
                if (controller != null && setupLoader != null) return setupLoader;
            }

            DynoManager dyno = DynoManager.Get();
            CarLoader dynoLoader = ReadComponentReference<CarLoader>(dyno, "carLoader");
            if (dynoLoader != null)
            {
                controller = null;
                return dynoLoader;
            }
            return setupLoader;
        }

        private string PrefKey(string key)
        {
            return "CMS18Turbo.Profile" + settingsProfile.ToString() + "." + key;
        }

        private void EnsureUniversalMountOnStand(GameScript game)
        {
            if (game == null) return;
            try
            {
                List<GameObject> objects = game.GetObjectsOnEngineStand();
                if (objects == null || objects.Count == 0) return;
                GameObject target = null;
                for (int i = 0; i < objects.Count; i++)
                {
                    GameObject candidate = objects[i];
                    if (candidate == null || candidate.GetComponentInChildren<PartScript>(true) == null) continue;
                    target = FindEngineContainer(candidate);
                    if (target == null) target = candidate;
                    break;
                }
                if (target == null) return;
                int rootId = target.GetInstanceID();
                if (checkedStandMountRoots.Contains(rootId)) return;
                string key = !String.IsNullOrEmpty(standGroupKey) ? standGroupKey : standGroupName;
                PartScript mount = EnsureUniversalMount(target, key);
                if (mount != null)
                {
                    bool installed = IsInductionPartId(mount.GetTunedID()) || IsInductionPartId(mount.GetIDWithTuned());
                    SetUniversalMountSelectable(mount, installed || armedUniversalMounts.Contains(mount.GetInstanceID()));
                }
                checkedStandMountRoots.Add(rootId);
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not add the universal induction mount to the engine stand: " + exception.Message);
            }
        }

        private static GameObject FindEngineContainer(GameObject part)
        {
            Transform current = part == null ? null : part.transform;
            while (current != null)
            {
                if (current.name.StartsWith("engine_", StringComparison.OrdinalIgnoreCase)) return current.gameObject;
                current = current.parent;
            }
            return null;
        }

        private PartScript EnsureUniversalMount(GameObject engineRoot, string engineKey)
        {
            if (engineRoot == null) return null;
            PartScript[] existingParts = engineRoot.GetComponentsInChildren<PartScript>(true);
            for (int i = 0; i < existingParts.Length; i++)
            {
                PartScript existing = existingParts[i];
                if (existing != null && IsUniversalMountId(existing.GetID()))
                {
                    InitializeVirtualMountPart(existing);
                    existing.gameObject.layer = PartSelectionLayer;
                    bool installed = IsInductionPartId(existing.GetTunedID()) || IsInductionPartId(existing.GetIDWithTuned());
                    SetUniversalMountSelectable(existing, installed || armedUniversalMounts.Contains(existing.GetInstanceID()));
                    PositionUniversalMountNearDrivePulley(engineRoot, existing.transform);
                    return existing;
                }
            }

            GameObject mountObject = new GameObject(UniversalMountDisplayName + "(0)");
            string selectableLayerSource;
            mountObject.layer = FindSelectablePartLayer(engineRoot, out selectableLayerSource);
            mountObject.transform.SetParent(engineRoot.transform, false);
            mountObject.transform.localRotation = Quaternion.identity;
            mountObject.transform.localScale = Vector3.one;
            BoxCollider collider = mountObject.AddComponent<BoxCollider>();
            collider.enabled = false;
            collider.size = new Vector3(0.28f, 0.18f, 0.18f);
            PositionUniversalMountNearDrivePulley(engineRoot, mountObject.transform);

            PartScript mount = mountObject.AddComponent<PartScript>();
            mount.SetID(UniversalMountPartId);
            mount.SetTunedID(String.Empty);
            InitializeVirtualMountPart(mount);
            SetUniversalMountSelectable(mount, false);
            Logger.LogInfo("Universal induction mount uses selectable part layer " + mountObject.layer
                + " copied from " + selectableLayerSource + ".");
            Logger.LogInfo("Added a universal induction mount to " + engineRoot.name + ".");
            return mount;
        }

        private static void SetUniversalMountSelectable(PartScript mount, bool selectable)
        {
            if (mount == null) return;
            Collider[] colliders = mount.GetComponents<Collider>();
            if (colliders.Length == 0)
            {
                BoxCollider targetCollider = mount.gameObject.AddComponent<BoxCollider>();
                targetCollider.size = new Vector3(0.28f, 0.18f, 0.18f);
                colliders = mount.GetComponents<Collider>();
            }
            for (int i = 0; i < colliders.Length; i++)
                if (colliders[i] != null) colliders[i].enabled = selectable;
            bool hasInstalledKit = IsInductionPartId(mount.GetTunedID()) || IsInductionPartId(mount.GetIDWithTuned());
            SetPartField(mount, "canBeUnmount", hasInstalledKit);
            SetPartField(mount, "canUnmountSingle", hasInstalledKit);
        }

        private bool HasKitInPlayerInventory(string kitId)
        {
            if (!IsInductionPartId(kitId)) return false;
            try
            {
                Inventory inventory = Inventory.Get();
                if (inventory == null) return false;
                return inventory.GetItem(kitId) != null;
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not check ProCharger inventory before arming the mount: " + exception.Message);
                return false;
            }
        }

        private static string InstalledUniversalProchargerId(PartScript mount)
        {
            if (mount == null || !IsUniversalMountId(mount.GetID())) return String.Empty;
            string kitId = mount.GetTunedID();
            if (IsProchargerPartId(kitId)) return kitId;
            kitId = mount.GetIDWithTuned();
            return IsProchargerPartId(kitId) ? kitId : String.Empty;
        }

        private bool RemoveUniversalProcharger(PartScript mount)
        {
            string kitId = InstalledUniversalProchargerId(mount);
            if (String.IsNullOrEmpty(kitId)) return false;
            bool onStand = IsPartOnEngineStand(mount);
            string carKey = onStand ? String.Empty : FindOwningCarKey(mount);
            if (!onStand && String.IsNullOrEmpty(carKey))
            {
                status = "The owning car is unavailable. The ProCharger is still installed.";
                return false;
            }
            Inventory inventory = Inventory.Get();
            if (inventory == null || registeredShopInventory == null
                || registeredShopInventory.GetItemProperty(kitId) == null)
            {
                status = "Inventory is unavailable. The ProCharger is still installed.";
                return false;
            }

            NewInventoryItem item = new NewInventoryItem(kitId, mount.GetCondition(),
                Inventory.SetColor(mount.GetColor()), true);
            item.extraParameters.Add("Quality", mount.GetQuality());
            try
            {
                inventory.AddWithNotification(item);
            }
            catch (Exception exception)
            {
                // CMS adds the item before refreshing its inventory UI. A late UI
                // error must not leave both an inventory item and an installed kit.
                List<NewInventoryItem> items = inventory.GetItems("All");
                if (item.UId == 0 || items == null || !items.Exists(entry => entry != null && entry.UId == item.UId))
                {
                    status = "Could not return the ProCharger to inventory. It is still installed.";
                    Logger.LogWarning(status + " " + exception.Message);
                    return false;
                }
                Logger.LogWarning("ProCharger was returned to inventory, but its inventory UI refresh failed: " + exception.Message);
            }

            mount.SetTunedID(String.Empty);
            RestoreMountedProchargerPart(mount);
            if (onStand)
            {
                if (standGroup != null && standGroup.ItemList != null)
                    standGroup.ItemList.RemoveAll(entry => entry != null
                        && (IsProchargerPartId(entry.ID) || IsProchargerPartId(GetNormalId(entry))));
                RefreshStandPartDetection(GameScript.Get());
            }
            RecordInstalledInductionKit(mount, String.Empty, onStand, carKey);
            UpdateEffectiveSettings();
            RemoveVisual();
            status = (IsHighBoostProchargerPartId(kitId) ? "High-Boost P-1X" : "ProCharger P-1X") + " returned to inventory.";
            Logger.LogInfo(status + " Item UID=" + item.UId + ", condition=" + item.Condition.ToString("F3", CultureInfo.InvariantCulture) + ".");
            return true;
        }

        private PartScript FindCurrentUniversalMount(bool createIfMissing)
        {
            if (standOccupied)
            {
                PartScript standMount = FindStandProchargerMount();
                return standMount != null && IsUniversalMountId(standMount.GetID()) ? standMount : null;
            }

            VPVehicleController ignoredController;
            CarLoader loader = FindActiveCarLoader(out ignoredController);
            GameObject engine = null;
            try { if (loader != null) engine = loader.GetEngine(); }
            catch (Exception exception) { Logger.LogWarning("Could not locate the active engine for ProCharger mounting: " + exception.Message); }
            if (engine == null) return null;
            PartScript[] parts = engine.GetComponentsInChildren<PartScript>(true);
            for (int i = 0; i < parts.Length; i++)
                if (parts[i] != null && IsUniversalMountId(parts[i].GetID())) return parts[i];
            return createIfMissing ? EnsureUniversalMount(engine, activeCarKey) : null;
        }

        private bool OpenProchargerInventoryPicker()
        {
            if (!HasKitInPlayerInventory(ProchargerPartId) && !HasKitInPlayerInventory(ProchargerHighBoostPartId))
            {
                status = "Find the P-1X in Main Shop or the High-Boost kit in Tuning Shop.";
                return false;
            }
            PartScript mount = FindCurrentUniversalMount(true);
            if (mount == null || !String.IsNullOrEmpty(InstalledUniversalProchargerId(mount)))
            {
                status = "The ProCharger mount is unavailable.";
                return false;
            }
            int mountKey = mount.GetInstanceID();
            armedUniversalMounts.Add(mountKey);
            SetUniversalMountSelectable(mount, true);
            try
            {
                GameScript game = GameScript.Get();
                if (game == null) throw new InvalidOperationException("CMS GameScript is unavailable.");
                game.SetPartMouseOver(mount);
                game.ShowSelectPartMount(UniversalMountPartId);
                Logger.LogInfo("Opened the native ProCharger inventory picker from the radial menu.");
                return true;
            }
            catch (Exception exception)
            {
                armedUniversalMounts.Remove(mountKey);
                SetUniversalMountSelectable(mount, false);
                status = "Could not open the ProCharger inventory picker.";
                Logger.LogWarning(status + " " + exception.Message);
                return false;
            }
        }

        private bool IsCurrentUniversalMountSelectable()
        {
            // Raycast access is queried by part ID during engine-bay interaction.
            // During an engine swap or bay transition CarLoader.GetEngine() may
            // briefly return null even though the active vehicle's installed kit
            // has already been detected. Trust that installed-hardware state first;
            // the raycast still has to hit the ProCharger mount's own collider.
            if (!standOccupied && activeHasCustomInduction) return true;
            PartScript mount = FindCurrentUniversalMount(false);
            if (mount == null) return false;
            return IsInductionPartId(mount.GetTunedID()) || IsInductionPartId(mount.GetIDWithTuned())
                || armedUniversalMounts.Contains(mount.GetInstanceID());
        }

        private static int FindSelectablePartLayer(GameObject engineRoot, out string sourceName)
        {
            sourceName = "CMS part-selection raycast layer 16";
            return PartSelectionLayer;
        }

        private void PositionUniversalMountNearDrivePulley(GameObject engineRoot, Transform mount)
        {
            if (engineRoot == null || mount == null) return;
            Transform engineTransform = engineRoot.transform;
            PartScript crankPulley = FindCrankPulleyPart(engineRoot);
            Vector3 crankCenterWorld;
            Vector3 pulleyAxisWorld = engineTransform.right;
            float crankRadius = 0.075f;
            Bounds pulleyBounds = new Bounds(Vector3.zero, Vector3.zero);
            Bounds localPulleyBounds = new Bounds(Vector3.zero, Vector3.zero);
            bool hasExactMeshBounds = false;
            bool hasLocalBounds = false;
            bool hasPulley = crankPulley != null && TryGetPartWorldBounds(crankPulley, out pulleyBounds);
            if (hasPulley)
            {
                hasExactMeshBounds = TryGetPartLocalMeshBounds(crankPulley, out localPulleyBounds);
                hasLocalBounds = hasExactMeshBounds || TryGetLocalRendererBounds(
                    crankPulley.GetComponentsInChildren<Renderer>(true), crankPulley.transform, out localPulleyBounds);
                if (hasLocalBounds)
                {
                    crankCenterWorld = crankPulley.transform.TransformPoint(localPulleyBounds.center);
                    crankRadius = EstimatePulleyRadiusWorld(localPulleyBounds.size, crankPulley.transform);
                }
                else
                {
                    crankCenterWorld = pulleyBounds.center;
                    float[] worldDimensions = { pulleyBounds.size.x, pulleyBounds.size.y, pulleyBounds.size.z };
                    Array.Sort(worldDimensions);
                    crankRadius = Mathf.Clamp(worldDimensions[1] * 0.5f, 0.045f, 0.16f);
                }
                Vector3 localAxisSize = hasLocalBounds ? localPulleyBounds.size : pulleyBounds.size;
                pulleyAxisWorld = SmallestLocalBoundsAxis(localAxisSize, crankPulley.transform);
                if (Vector3.Dot(pulleyAxisWorld, engineTransform.right) < 0.0f) pulleyAxisWorld = -pulleyAxisWorld;
            }
            else
            {
                Bounds engineBounds;
                if (TryGetLocalRendererBounds(engineRoot.GetComponentsInChildren<Renderer>(true), engineTransform, out engineBounds))
                {
                    Vector3 localCenter = EstimateFrontDriveCenter(engineBounds);
                    localCenter.z = engineBounds.max.z;
                    crankCenterWorld = engineTransform.TransformPoint(localCenter);
                }
                else
                {
                    crankCenterWorld = engineTransform.position;
                }
                Logger.LogWarning("Could not identify a crank-pulley part on " + engineRoot.name + "; placing the induction mount from engine bounds.");
            }

            if (pulleyAxisWorld.sqrMagnitude < 0.0001f) pulleyAxisWorld = engineTransform.right;
            pulleyAxisWorld.Normalize();
            Quaternion alignedRotation = Quaternion.FromToRotation(engineTransform.right, pulleyAxisWorld) * engineTransform.rotation;
            mount.rotation = alignedRotation;

            Vector3 upWorld = engineTransform.up - pulleyAxisWorld * Vector3.Dot(engineTransform.up, pulleyAxisWorld);
            if (upWorld.sqrMagnitude < 0.0001f) upWorld = engineTransform.forward - pulleyAxisWorld * Vector3.Dot(engineTransform.forward, pulleyAxisWorld);
            upWorld.Normalize();
            float centerSpacing = Mathf.Max(0.14f, crankRadius + 0.075f);
            Vector3 desiredChargerPulleyWorld = crankCenterWorld + upWorld * centerSpacing;
            // Keep mount placement in lockstep with the measured 0.4 m/model-unit
            // scale used by the P-1X visual and its belt/bracket geometry.
            const float approximateModelScale = ProchargerModelUnitScale;
            // Keep the model in its authored orientation. The old 180-degree flip
            // put the compressor body on the block side of its drive pulley.
            Quaternion modelRotation = Quaternion.identity;
            Vector3 pulleyOffset = modelRotation * ((ProchargerDrivePulleyCenter - ProchargerModelBoundsCenter) * approximateModelScale);
            Vector3 mountWorld = desiredChargerPulleyWorld - mount.rotation * pulleyOffset;
            mount.position = mountWorld;

            if (hasPulley)
                Logger.LogInfo("Placed the universal induction mount beside " + crankPulley.GetID() + " on " + engineRoot.name
                    + "; crank=" + engineTransform.InverseTransformPoint(crankCenterWorld).ToString("F3")
                    + ", axis=" + engineTransform.InverseTransformDirection(pulleyAxisWorld).ToString("F3")
                    + ", mount=" + engineTransform.InverseTransformPoint(mount.position).ToString("F3")
                    + ", radius=" + crankRadius.ToString("F3")
                    + ", cmsUnmountedFlag=" + crankPulley.IsUnmounted()
                    + ", pulleyBounds=" + (hasExactMeshBounds ? "mesh" : "renderer")
                    + (hasLocalBounds ? localPulleyBounds.size.ToString("F3") : "unavailable") + ".");
        }

        private static PartScript FindCrankPulleyPart(GameObject engineRoot)
        {
            if (engineRoot == null) return null;
            PartScript[] parts = engineRoot.GetComponentsInChildren<PartScript>(true);
            PartScript best = null;
            int bestScore = Int32.MaxValue;
            float lowestY = Single.MaxValue;
            for (int i = 0; i < parts.Length; i++)
            {
                PartScript part = parts[i];
                if (part == null || IsUniversalMountId(part.GetID())) continue;
                string id = (part.GetID() ?? String.Empty) + " " + (part.GetTunedID() ?? String.Empty) + " " + part.gameObject.name;
                int score = ScoreCrankPulleyCandidate(id);
                if (score == Int32.MaxValue || !HasVisiblePartGeometry(part)) continue;
                // During transfer CMS can mark a part unmounted while its mesh remains visible.
                bool cmsUnmounted = part.IsUnmounted();
                int effectiveScore = score * 2 + (cmsUnmounted ? 1 : 0);
                Vector3 localCenter = engineRoot.transform.InverseTransformPoint(part.transform.position);
                if (effectiveScore < bestScore || (effectiveScore == bestScore && localCenter.y < lowestY))
                {
                    best = part;
                    bestScore = effectiveScore;
                    lowestY = localCenter.y;
                }
            }
            return best;
        }

        private static bool HasVisiblePartGeometry(PartScript part)
        {
            if (part == null || part.gameObject == null || !part.gameObject.activeInHierarchy) return false;
            Renderer[] renderers = part.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null || !renderer.enabled || !renderer.gameObject.activeInHierarchy) continue;
                Bounds bounds = renderer.bounds;
                if (bounds.size.sqrMagnitude > 0.000001f) return true;
            }
            return false;
        }

        internal static int ScoreCrankPulleyCandidate(string partId)
        {
            if (String.IsNullOrEmpty(partId)) return Int32.MaxValue;
            string id = partId.ToLowerInvariant();
            bool pulley = id.Contains("pulley") || id.Contains("kolo_pasowe") || id.Contains("kolo pasowe");
            bool crankshaftPulley = pulley && (id.Contains("crank") || id.Contains("walu") || id.Contains("wału"));
            bool balancer = id.Contains("balancer") || id.Contains("harmonic");
            if (crankshaftPulley) return 0;
            if (balancer) return 1;
            if (IsTimingDrivePart(id) || id.Contains("alternat") || id.Contains("idler")
                || id.Contains("tension") || id.Contains("napinacz") || id.Contains("rolka")
                || id.Contains("water_pump") || id.Contains("pompa")) return Int32.MaxValue;
            if (pulley) return 2;
            return Int32.MaxValue;
        }

        private static bool IsTimingDrivePart(string id)
        {
            return id.Contains("rozrz") || id.Contains("timing") || id.Contains("camshaft")
                || id.Contains("cam_gear") || id.Contains("cam_pulley") || id.Contains("walka");
        }

        private static Vector3 EstimateFrontDriveCenter(Bounds engineBounds)
        {
            Vector3 center = engineBounds.center;
            // Keep the visual hardware above the radiator/crossmember area. This is a
            // fallback only; a detected crank pulley always takes precedence.
            center.y = engineBounds.min.y + Mathf.Clamp(engineBounds.size.y * 0.32f, 0.18f, 0.26f);
            return center;
        }

        private static bool TryGetPartWorldBounds(PartScript part, out Bounds bounds)
        {
            bounds = new Bounds(Vector3.zero, Vector3.zero);
            if (part == null) return false;
            Renderer[] renderers = part.GetComponentsInChildren<Renderer>(true);
            bool initialized = false;
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null || renderer.bounds.size.sqrMagnitude < 0.000001f) continue;
                if (!initialized)
                {
                    bounds = renderer.bounds;
                    initialized = true;
                }
                else
                {
                    bounds.Encapsulate(renderer.bounds);
                }
            }
            return initialized;
        }

        private static bool TryGetPartLocalMeshBounds(PartScript part, out Bounds bounds)
        {
            bounds = new Bounds(Vector3.zero, Vector3.zero);
            if (part == null) return false;
            Renderer[] renderers = part.GetComponentsInChildren<Renderer>(true);
            bool initialized = false;
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null || !renderer.enabled || !renderer.gameObject.activeInHierarchy
                    || renderer.GetComponentInParent<PartScript>() != part || renderer.GetComponent<MountObject>() != null)
                    continue;
                Mesh mesh = null;
                MeshFilter filter = renderer.GetComponent<MeshFilter>();
                if (filter != null) mesh = filter.sharedMesh;
                if (mesh == null)
                {
                    SkinnedMeshRenderer skinned = renderer as SkinnedMeshRenderer;
                    if (skinned != null) mesh = skinned.sharedMesh;
                }
                if (mesh == null || mesh.bounds.size.sqrMagnitude < 0.000001f) continue;

                Bounds meshBounds = mesh.bounds;
                for (int corner = 0; corner < 8; corner++)
                {
                    Vector3 meshPoint = new Vector3(
                        (corner & 1) == 0 ? meshBounds.min.x : meshBounds.max.x,
                        (corner & 2) == 0 ? meshBounds.min.y : meshBounds.max.y,
                        (corner & 4) == 0 ? meshBounds.min.z : meshBounds.max.z);
                    Vector3 localPoint = part.transform.InverseTransformPoint(renderer.transform.TransformPoint(meshPoint));
                    if (!initialized)
                    {
                        bounds = new Bounds(localPoint, Vector3.zero);
                        initialized = true;
                    }
                    else bounds.Encapsulate(localPoint);
                }
            }
            return initialized;
        }

        private static float EstimatePulleyRadiusWorld(Vector3 localBoundsSize, Transform pulleyTransform,
            float minimumRadius = 0.045f, float maximumRadius = 0.16f)
        {
            int shaftAxis = localBoundsSize.x <= localBoundsSize.y && localBoundsSize.x <= localBoundsSize.z ? 0
                : localBoundsSize.y <= localBoundsSize.x && localBoundsSize.y <= localBoundsSize.z ? 1 : 2;
            Vector3 firstRadialAxis = shaftAxis == 0 ? Vector3.up : Vector3.right;
            Vector3 secondRadialAxis = shaftAxis == 2 ? Vector3.up : Vector3.forward;
            if (shaftAxis == 1) secondRadialAxis = Vector3.forward;
            float firstDiameter = shaftAxis == 0 ? localBoundsSize.y : localBoundsSize.x;
            float secondDiameter = shaftAxis == 2 ? localBoundsSize.y : localBoundsSize.z;
            float firstScale = pulleyTransform == null ? 1.0f : pulleyTransform.TransformVector(firstRadialAxis).magnitude;
            float secondScale = pulleyTransform == null ? 1.0f : pulleyTransform.TransformVector(secondRadialAxis).magnitude;
            return Mathf.Clamp((firstDiameter * firstScale + secondDiameter * secondScale) * 0.25f, minimumRadius, maximumRadius);
        }

        private static Vector3 SmallestLocalBoundsAxis(Vector3 size, Transform localToWorld)
        {
            Vector3 localAxis = size.x <= size.y && size.x <= size.z ? Vector3.right
                : size.y <= size.x && size.y <= size.z ? Vector3.up : Vector3.forward;
            Vector3 worldAxis = localToWorld == null ? Vector3.right : localToWorld.TransformDirection(localAxis);
            return worldAxis.sqrMagnitude < 0.0001f ? Vector3.right : worldAxis.normalized;
        }

        private void InitializeVirtualMountPart(PartScript part)
        {
            if (part == null) return;
            Transform installedVisual = part.transform.Find(InstalledInductionVisualName);
            bool prochargerInstalled = IsProchargerPartId(part.GetTunedID()) && installedVisual != null;
            SetPartField(part, "canBeUnmount", prochargerInstalled);
            SetPartField(part, "canUnmountSingle", prochargerInstalled);
            SetPartField(part, "canMountUnmountOnlyOnCarLoader", false);
            // Raycast.Update uses -1 as the documented internal sentinel to skip its
            // ForcePartGroup gate and check this synthetic part by its ID instead.
            SetPartField(part, "ForcePartGroup", -1);
            SetPartField(part, "unmounted", false);
            SetPartField(part, "forInventory", false);
            // The inventory picker still uses CMS's direct fitting path. The
            // dedicated removal handler routes an installed kit through bolt mode.
            SetPartField(part, "oneClickUnmount", true);
            // The universal mount is an internal visual anchor, not a physical
            // four-bolt part. Keep selection on its PartScript root only.
            Transform anchor = part.transform.Find(VirtualMountAnchorName);
            if (anchor == null)
            {
                GameObject anchorObject = new GameObject(VirtualMountAnchorName);
                anchorObject.layer = part.gameObject.layer;
                anchorObject.transform.SetParent(part.transform, false);
                anchorObject.transform.localPosition = new Vector3(0.0f, -0.045f, 0.0f);
                anchorObject.transform.localRotation = Quaternion.identity;
                anchorObject.transform.localScale = Vector3.one;
                anchor = anchorObject.transform;
            }
            anchor.gameObject.layer = part.gameObject.layer;

            // Older builds put a large invisible MountObject and synthetic
            // bolt heads here. Neither should become a game unscrew task.
            MountObject legacyMountObject = anchor.GetComponent<MountObject>();
            if (legacyMountObject != null)
            {
                legacyMountObject.SetCanBeUnmount(false);
                UnityEngine.Object.Destroy(legacyMountObject);
            }
            Collider[] legacyColliders = anchor.GetComponents<Collider>();
            for (int i = 0; i < legacyColliders.Length; i++)
            {
                if (legacyColliders[i] == null) continue;
                legacyColliders[i].enabled = false;
                UnityEngine.Object.Destroy(legacyColliders[i]);
            }

            if (prochargerInstalled)
            {
                EnsureProchargerMountBolts(part, installedVisual);
                SetEmptyArrayPartField(part, "unblockOnUnmount");
                SetEmptyArrayPartField(part, "unblockOnUnmountName");
                SetEmptyArrayPartField(part, "enableOnUnmount");
                SetEmptyArrayPartField(part, "disableOnUnmount");
                SetEmptyListPartField(part, "blockedBy");
                SetEmptyListPartField(part, "unmountWith");
                AddUnmountVisibilityTargets(part, installedVisual);
                return;
            }

            Transform[] oldFasteners = part.GetComponentsInChildren<Transform>(true);
            for (int i = oldFasteners.Length - 1; i >= 0; i--)
            {
                Transform oldFastener = oldFasteners[i];
                if (oldFastener == null || oldFastener == part.transform
                    || !oldFastener.name.StartsWith(ProchargerMountFastenerPrefix, StringComparison.Ordinal)) continue;
                oldFastener.gameObject.SetActive(false);
                UnityEngine.Object.Destroy(oldFastener.gameObject);
            }
            SetPartField(part, "MountObjects", new MountObject[0]);
            SetEmptyArrayPartField(part, "unblockOnUnmount");
            SetEmptyArrayPartField(part, "unblockOnUnmountName");
            SetEmptyArrayPartField(part, "enableOnUnmount");
            SetEmptyArrayPartField(part, "disableOnUnmount");
            SetEmptyArrayPartField(part, "hideWhenUnmontingMounting");
            SetEmptyListPartField(part, "blockedBy");
            SetEmptyListPartField(part, "unmountWith");
        }

        private static void SetPartField(PartScript part, string fieldName, object value)
        {
            FieldInfo field = AccessTools.Field(typeof(PartScript), fieldName);
            if (!System.Object.ReferenceEquals(field, null) && (value == null || field.FieldType.IsInstanceOfType(value)))
                field.SetValue(part, value);
        }

        private static bool IsMountObjectRenderer(Renderer renderer)
        {
            Transform current = renderer == null ? null : renderer.transform;
            while (current != null)
            {
                if (current.GetComponent<MountObject>() != null) return true;
                current = current.parent;
            }
            return false;
        }

        private static bool IsMountObjectCollider(Collider collider)
        {
            Transform current = collider == null ? null : collider.transform;
            while (current != null)
            {
                if (current.GetComponent<MountObject>() != null) return true;
                current = current.parent;
            }
            return false;
        }

        private static void SetEmptyArrayPartField(PartScript part, string fieldName)
        {
            FieldInfo field = AccessTools.Field(typeof(PartScript), fieldName);
            if (System.Object.ReferenceEquals(field, null) || !field.FieldType.IsArray) return;
            field.SetValue(part, Array.CreateInstance(field.FieldType.GetElementType(), 0));
        }

        private static void SetEmptyListPartField(PartScript part, string fieldName)
        {
            FieldInfo field = AccessTools.Field(typeof(PartScript), fieldName);
            if (System.Object.ReferenceEquals(field, null)) return;
            if (field.FieldType.IsAssignableFrom(typeof(List<PartScript>))) field.SetValue(part, new List<PartScript>());
        }

        private GameObject CreateUniversalMountPrefab(bool inventoryPreview)
        {
            GameObject mountObject = new GameObject(UniversalMountDisplayName + "(0)");
            mountObject.transform.localScale = Vector3.one;
            BoxCollider collider = mountObject.AddComponent<BoxCollider>();
            collider.size = new Vector3(0.28f, 0.18f, 0.18f);
            collider.enabled = !inventoryPreview;
            PartScript mount = mountObject.AddComponent<PartScript>();
            mount.SetID(UniversalMountPartId);
            mount.SetTunedID(String.Empty);
            InitializeVirtualMountPart(mount);
            SetPartField(mount, "forInventory", inventoryPreview);
            return mountObject;
        }

        private static int ReadSelectedProfile(int fallback)
        {
            try
            {
                ProfileManager manager = ProfileManager.Get();
                return manager == null ? fallback : manager.GetSelectedProfile();
            }
            catch
            {
                return fallback;
            }
        }

        private void RefreshProfileContext()
        {
            int profile = ReadSelectedProfile(settingsProfile);
            if (profile == settingsProfile) return;

            settingsProfile = profile;
            checkedStandMountRoots.Clear();
            activeCarKey = string.Empty;
            standGroupKey = string.Empty;
            standGroupName = string.Empty;
            standGroupUid = 0;
            selectedMode = ReadMode(PlayerPrefs.GetInt(PrefKey(GlobalModeKey), 0));
            selectedBoostPsi = ProchargerMath.NormalizeBoostPsi(PlayerPrefs.GetFloat(PrefKey(GlobalPsiKey), 8.0f), P1XMaxBoostPsi, 8.0f);
            status = "Loaded induction settings for save profile " + settingsProfile;
            Logger.LogInfo(status);
            UpdateEffectiveSettings();
        }

        private static string GetNormalId(NewInventoryItem item)
        {
            if (item == null) return string.Empty;
            try
            {
                if (item.extraParameters != null && item.extraParameters.ContainsKey("NormalID"))
                {
                    object value = item.extraParameters.GetFromKey("NormalID");
                    if (value != null && !String.IsNullOrEmpty(value.ToString())) return value.ToString();
                }
            }
            catch { }
            return item.ID;
        }

        private static string NormalizeKey(string value)
        {
            if (String.IsNullOrEmpty(value)) return string.Empty;
            string normalized = value.Replace("(Clone)", string.Empty).Trim().ToLowerInvariant();
            normalized = normalized.Replace(' ', '_').Replace('/', '_').Replace('\\', '_');
            return normalized;
        }

        private static string BuildCarIdentityKey(CarLoader loader)
        {
            if (loader == null) return string.Empty;
            try
            {
                // GetSaveName() returns the Unity object name (for example
                // "#carloader5"), which CMS reuses for unrelated cars. Prefer the
                // saved factory plate: custom front/rear plates can be changed by
                // the player and would otherwise change the settings key mid-save.
                // If no factory plate exists, use the visible plates as a fallback.
                string plate = ReadCarLoaderString(loader, "factoryLicensePlateNumber");
                if (String.IsNullOrEmpty(plate)) plate = ReadCarLoaderString(loader, "licensePlateNumberRear");
                if (String.IsNullOrEmpty(plate)) plate = ReadCarLoaderString(loader, "licensePlateNumberFront");
                if (String.IsNullOrEmpty(plate)) return string.Empty;

                string model = string.Empty;
                try { model = NormalizeKey(loader.GetNameWithSufix()); }
                catch { }
                if (String.IsNullOrEmpty(model))
                {
                    try { model = NormalizeKey(loader.GetName()); }
                    catch { }
                }
                string normalizedPlate = NormalizeKey(plate);
                if (String.IsNullOrEmpty(normalizedPlate)) return string.Empty;
                return String.IsNullOrEmpty(model) ? "plate_" + normalizedPlate : model + "_plate_" + normalizedPlate;
            }
            catch { return string.Empty; }
        }

        private static string ReadCarLoaderString(CarLoader loader, string fieldName)
        {
            if (loader == null || String.IsNullOrEmpty(fieldName)) return string.Empty;
            try
            {
                FieldInfo field = typeof(CarLoader).GetField(fieldName,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                object value = System.Object.ReferenceEquals(field, null) ? null : field.GetValue(loader);
                return value == null ? string.Empty : value.ToString().Trim();
            }
            catch { return string.Empty; }
        }

        private static InductionMode ReadMode(int value)
        {
            // Value 3 is the original P-1X mode and remains save-compatible.
            // Old turbo and Roots selections are deliberately migrated to Off.
            return value == (int)InductionMode.Procharger
                ? InductionMode.Procharger : InductionMode.Off;
        }

        private static string ModeName(InductionMode mode)
        {
            if (mode == InductionMode.Procharger) return "ProCharger P-1X";
            return "Off";
        }

        private bool TryReadGroupSettings(NewGroupItem group, out InductionMode mode, out float psi)
        {
            mode = InductionMode.Off;
            psi = 8.0f;
            if (group == null || group.ItemList == null) return false;

            for (int i = 0; i < group.ItemList.Count; i++)
            {
                NewInventoryItem item = group.ItemList[i];
                if (item == null || item.extraParameters == null) continue;
                try
                {
                    if (!item.extraParameters.ContainsKey(MetaModeKey)) continue;
                    object modeValue = item.extraParameters.GetFromKey(MetaModeKey);
                    object psiValue = item.extraParameters.GetFromKey(MetaPsiKey);
                    mode = ReadMode(Convert.ToInt32(modeValue));
                    if (psiValue != null) psi = ProchargerMath.NormalizeBoostPsi(Convert.ToSingle(psiValue), P1XMaxBoostPsi, 8.0f);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            return false;
        }

        private void AnnotateGroup(NewGroupItem group, InductionMode mode, float psi)
        {
            if (group == null || group.ItemList == null || group.ItemList.Count == 0) return;
            try
            {
                NewInventoryItem item = group.ItemList[0];
                if (item == null) return;
                if (item.extraParameters == null) item.extraParameters = new NewHash();
                System.Collections.Hashtable table = item.extraParameters.GetHashTable();
                table[MetaModeKey] = (int)mode;
                table[MetaPsiKey] = psi;
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not attach induction settings to the engine group: " + exception.Message);
            }
        }

        private void RegisterEngineAliases(NewGroupItem group, InductionMode mode, float psi)
        {
            // Never persist induction by engine prefab/group name: that key is shared
            // by every car using the same engine and caused cross-car installation.
        }

        private void SaveEngineAlias(string key, InductionMode mode, float psi)
        {
            if (String.IsNullOrEmpty(key)) return;
            PlayerPrefs.SetInt(PrefKey(EngineModePrefix + key), (int)mode);
            PlayerPrefs.SetFloat(PrefKey(EnginePsiPrefix + key), psi);
        }

        private bool TryLoadEngineAlias(CarLoader loader, out InductionMode mode, out float psi)
        {
            mode = InductionMode.Off;
            psi = 8.0f;
            // Engine aliases are shared by every car using a given engine prefab.
            // Reading them caused a kit selected for one car to leak into others.
            return false;
        }

        private bool IsActiveCarLoader(CarLoader loader)
        {
            if (loader == null) return false;
            VPVehicleController ignored;
            return System.Object.ReferenceEquals(loader, FindActiveCarLoader(out ignored));
        }

        private void RecordPendingInstall(NewGroupItem group)
        {
            if (group == null) return;
            InductionMode mode;
            float psi;
            if (!TryReadGroupSettings(group, out mode, out psi)
                && !TryReadStoredGroupSettings(group, out mode, out psi))
            {
                psi = 8.0f;
            }
            string kitId = FindInductionKitId(group);
            mode = IsProchargerPartId(kitId) ? InductionMode.Procharger : InductionMode.Off;
            pendingInstallGroup = group;
            pendingInstallGroupName = group.GroupName;
            pendingInstallLoader = null;
            pendingInstallMode = mode;
            pendingInstallPsi = psi;
            pendingSwapObserved = false;
            pendingInstallKitId = kitId;
            PlayerPrefs.Save();
            try
            {
                ToolsMoveManager manager = ToolsMoveManager.Get();
                if (manager != null) pendingInstallLoader = manager.GetConnectedCarLoader(IOSpecialType.EngineCrane);
            }
            catch { }
            EnsureMountForSameEngineTransfer(group);
            AnnotateGroup(group, mode, psi);
            RegisterEngineAliases(group, mode, psi);
            status = "Installing " + ModeName(mode) + " engine setup";
            Logger.LogInfo(status + " for group " + group.GroupName);
        }

        private static string FindInductionKitId(NewGroupItem group)
        {
            if (group == null || group.ItemList == null) return String.Empty;
            for (int i = 0; i < group.ItemList.Count; i++)
            {
                NewInventoryItem item = group.ItemList[i];
                if (item == null) continue;
                if (IsProchargerPartId(item.ID)) return item.ID;
                string normalId = GetNormalId(item);
                if (IsProchargerPartId(normalId)) return normalId;
            }
            return String.Empty;
        }

        private void EnsureMountForSameEngineTransfer(NewGroupItem group)
        {
            if (!IsProchargerPartId(pendingInstallKitId) || pendingSwapObserved || pendingInstallLoader == null || group == null) return;
            try
            {
                GameObject engine = pendingInstallLoader.GetEngine();
                if (engine == null || !String.Equals(engine.name, group.GroupName, StringComparison.Ordinal)) return;
                PartScript mount = EnsureUniversalMount(engine, group.GroupName);
                string kitId = pendingInstallKitId;
                if (mount != null && IsInductionPartId(kitId))
                {
                    ConfigureMountedInductionPart(mount, kitId);
                    PrepareUniversalMountForInstalledKit(engine, mount);
                }
                Logger.LogInfo("Prepared the " + (IsInductionPartId(kitId) ? kitId : "universal mount")
                    + " before inserting the existing " + engine.name + " engine.");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not prepare the universal mount for the existing engine; vanilla installation will continue: " + exception.Message);
            }
        }

        private void EnsureMountForEngineSwap(CarLoader loader)
        {
            if (!pendingSwapObserved || !IsProchargerPartId(pendingInstallKitId) || pendingInstallGroup == null
                || loader == null || loader != pendingInstallLoader) return;
            try
            {
                GameObject engine = loader.GetEngine();
                if (engine == null || !String.Equals(engine.name, pendingInstallGroupName, StringComparison.Ordinal)) return;
                PartScript mount = EnsureUniversalMount(engine, pendingInstallGroupName);
                string kitId = pendingInstallKitId;
                if (mount != null && IsInductionPartId(kitId))
                {
                    ConfigureMountedInductionPart(mount, kitId);
                    PrepareUniversalMountForInstalledKit(engine, mount);
                    Logger.LogInfo("Restored " + kitId + " on the transferred " + engine.name + " engine.");
                }
                Logger.LogInfo("Prepared the universal mount before transferring the replacement " + engine.name + " engine.");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not prepare the universal mount for the replacement engine; vanilla installation will continue: " + exception.Message);
            }
        }

        private bool PendingInstallMatches(NewGroupItem group)
        {
            return SameEngineGroup(group, pendingInstallGroup);
        }

        private static bool SameEngineGroup(NewGroupItem first, NewGroupItem second)
        {
            return first != null && second != null
                && (System.Object.ReferenceEquals(first, second)
                    || (first.UId > 0 && first.UId == second.UId
                        && String.Equals(first.GroupName, second.GroupName, StringComparison.Ordinal)));
        }

        private void MarkPendingEngineSwap(CarLoader loader, NewGroupItem group)
        {
            if (!PendingInstallMatches(group) || loader == null) return;
            if (pendingInstallLoader != null && !System.Object.ReferenceEquals(loader, pendingInstallLoader)) return;
            pendingInstallLoader = loader;
            pendingSwapObserved = true;
        }

        private IEnumerator TrackActionInsertRoutine(IEnumerator routine, NewGroupItem group)
        {
            if (routine == null) return null;
            return new InstallTrackingEnumerator(routine, this, group, null, false);
        }

        private IEnumerator TrackEngineSwapRoutine(IEnumerator routine, CarLoader loader, NewGroupItem group)
        {
            if (routine == null) return null;
            return new InstallTrackingEnumerator(routine, this, group, loader, true);
        }

        private void CompleteActionInsert(NewGroupItem group)
        {
            if (!PendingInstallMatches(group) || pendingSwapObserved) return;
            CompleteEngineInstall(pendingInstallLoader, group);
        }

        private void CompleteEngineInstall(CarLoader loader, NewGroupItem group)
        {
            if (!PendingInstallMatches(group)) return;
            if (loader == null) loader = pendingInstallLoader;
            if (loader == null)
            {
                AbortPendingInstall(group, "Engine install target could not be resolved; settings remain with the engine group");
                return;
            }

            GameObject installedEngine = null;
            try
            {
                if (loader != null) installedEngine = loader.GetEngine();
            }
            catch { }
            if (installedEngine == null || !String.Equals(installedEngine.name, group.GroupName, StringComparison.Ordinal))
            {
                AbortPendingInstall(group, "Engine setup transfer did not complete; settings remain with the engine group");
                return;
            }
            RecordInstalledCar(loader, group);
        }

        private IEnumerator RecoverPendingEngineInstallAfterSetEngine(CarLoader loader)
        {
            NewGroupItem group = pendingInstallGroup;
            if (loader == null || group == null) yield break;

            // The engine crane can begin its transfer before the connected loader is
            // exposed by ToolsMoveManager. Resolve it again from the exact crane, then
            // wait for CMS to finish assigning the transferred engine. This closes the
            // gap where the stand contains the kit but the in-car engine does not.
            if (pendingInstallLoader == null)
            {
                try
                {
                    ToolsMoveManager manager = ToolsMoveManager.Get();
                    if (manager != null)
                        pendingInstallLoader = manager.GetConnectedCarLoader(IOSpecialType.EngineCrane);
                }
                catch { }
            }
            if (!System.Object.ReferenceEquals(loader, pendingInstallLoader)) yield break;

            for (int frame = 0; frame < 120; frame++)
            {
                if (!PendingInstallMatches(group) || !System.Object.ReferenceEquals(loader, pendingInstallLoader))
                    yield break;

                GameObject engine = null;
                try { engine = loader.GetEngine(); }
                catch { }
                if (engine != null && String.Equals(engine.name, group.GroupName, StringComparison.Ordinal))
                {
                    Logger.LogInfo("Confirmed transferred engine " + engine.name
                        + " on its recorded car loader; completing induction-kit restoration.");
                    CompleteEngineInstall(loader, group);
                    yield break;
                }
                yield return null;
            }

            if (PendingInstallMatches(group))
                AbortPendingInstall(group, "Engine transfer did not expose the expected engine on its recorded car loader; induction setup was not attached");
        }

        private void AbortPendingInstall(NewGroupItem group, string reason)
        {
            if (!PendingInstallMatches(group)) return;
            pendingInstallGroup = null;
            pendingInstallGroupName = string.Empty;
            pendingInstallLoader = null;
            pendingSwapObserved = false;
            pendingInstallKitId = String.Empty;
            status = reason;
            Logger.LogWarning(status);
        }

        private void RecordInstalledCar(CarLoader loader, NewGroupItem group)
        {
            if (loader == null || group == null) return;
            if (!PendingInstallMatches(group)) return;

            string carKey = BuildCarIdentityKey(loader);
            string kitId = pendingInstallKitId;
            if (!String.IsNullOrEmpty(carKey))
            {
                string prefKey = PrefKey(InstalledKitModePrefix + carKey);
                if (IsProchargerPartId(kitId)) PlayerPrefs.SetString(prefKey, kitId);
                else PlayerPrefs.DeleteKey(prefKey);
                SaveCarSettings(carKey, pendingInstallMode, pendingInstallPsi);
                RegisterEngineAliases(group, pendingInstallMode, pendingInstallPsi);
                selectedMode = pendingInstallMode;
                selectedBoostPsi = pendingInstallPsi;
                activeCarKey = carKey;
                PlayerPrefs.Save();
            }
            // Visual reattachment is safe after the verified transfer even if the
            // car's persistent plate fields are not populated yet. Only persistence
            // above is conditional on having a durable per-car identity.
            if (IsProchargerPartId(kitId)) RestoreTransferredInductionKit(loader, group, carKey, kitId);
            if (IsProchargerPartId(kitId) && !String.IsNullOrEmpty(carKey))
            {
                try { StartCoroutine(ReconcileTransferredInductionKit(loader, group, carKey, kitId)); }
                catch (Exception exception)
                {
                    Logger.LogWarning("Could not schedule the brief post-transfer induction check: " + exception.Message);
                }
            }
            UpdateEffectiveSettings();
            status = String.IsNullOrEmpty(carKey)
                ? ModeName(pendingInstallMode) + " setup restored on transferred engine; car identity unavailable"
                : ModeName(pendingInstallMode) + " setup linked to car " + carKey;
            Logger.LogInfo(status);
            pendingInstallGroup = null;
            pendingInstallGroupName = string.Empty;
            pendingInstallLoader = null;
            pendingSwapObserved = false;
            pendingInstallKitId = String.Empty;
        }

        private void RestoreTransferredInductionKit(CarLoader loader, NewGroupItem group, string carKey, string kitId)
        {
            if (loader == null || group == null || !IsProchargerPartId(kitId)) return;
            try
            {
                GameObject engine = loader.GetEngine();
                if (engine == null || !String.Equals(engine.name, group.GroupName, StringComparison.Ordinal)) return;

                PartScript mount = FindMountedInductionPart(engine, kitId);
                if (mount == null)
                {
                    mount = EnsureUniversalMount(engine, carKey);
                    if (mount == null)
                    {
                        Logger.LogWarning("The transferred engine " + engine.name + " could not create its universal induction mount.");
                        return;
                    }
                }

                ConfigureMountedInductionPart(mount, kitId);
                PrepareUniversalMountForInstalledKit(engine, mount);
                Logger.LogInfo("Restored the " + kitId + " visual and mount on car " + carKey + " after engine transfer.");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("The engine transfer completed, but its induction kit visual could not be restored: " + exception.Message);
            }
        }

        private IEnumerator ReconcileTransferredInductionKit(CarLoader loader, NewGroupItem group, string expectedCarKey, string kitId)
        {
            // CMS can replace the engine GameObject again after the crane coroutine
            // reports completion. The first mount restore may then belong to a
            // temporary engine instance. Recheck briefly on this exact loader and
            // reattach only while its durable car identity still matches.
            for (int frame = 0; frame < 120; frame += 6)
            {
                for (int waitFrame = 0; waitFrame < 6; waitFrame++) yield return null;
                if (loader == null || group == null) yield break;

                string currentCarKey = BuildCarIdentityKey(loader);
                if (String.IsNullOrEmpty(currentCarKey)
                    || !String.Equals(currentCarKey, expectedCarKey, StringComparison.Ordinal))
                    yield break;
                if (!String.Equals(PlayerPrefs.GetString(PrefKey(InstalledKitModePrefix + expectedCarKey), String.Empty),
                    kitId, StringComparison.Ordinal)) yield break;

                GameObject engine = null;
                try { engine = loader.GetEngine(); }
                catch { }
                if (engine == null || !String.Equals(engine.name, group.GroupName, StringComparison.Ordinal))
                    continue;

                PartScript mount = FindMountedInductionPart(engine, kitId);
                Transform visual = mount == null ? null : mount.transform.Find(InstalledInductionVisualName);
                bool attachedToCurrentEngine = mount != null
                    && mount.transform.IsChildOf(engine.transform)
                    && mount.gameObject.activeInHierarchy
                    && visual != null
                    && visual.gameObject.activeInHierarchy;
                if (!attachedToCurrentEngine)
                {
                    RestoreTransferredInductionKit(loader, group, expectedCarKey, kitId);
                    Logger.LogInfo("Reconciled the induction mount against the final engine instance on car "
                        + expectedCarKey + ".");
                }

                // Continue for a short stabilization window in case another CMS
                // engine-object replacement occurs immediately after this frame.
            }
            Logger.LogInfo("Post-transfer induction check finished for car " + expectedCarKey + ".");
        }

        private IEnumerator RestoreInstalledKitAfterCarLoad(CarLoader loader)
        {
            yield return new WaitForEndOfFrame();
            if (loader == null) yield break;
            if (pendingInstallGroup != null && System.Object.ReferenceEquals(loader, pendingInstallLoader)) yield break;
            try
            {
                GameObject engine = loader.GetEngine();
                if (engine == null) yield break;
                string carKey = BuildCarIdentityKey(loader);
                // A transferred induction kit is represented by a runtime mount and
                // can be absent from the vanilla part list after CMS reloads the car.
                // Restore from the durable model/plate key, never from Unity's reused
                // CarLoader object name. If no stable identity exists, only a kit
                // already present on the actual engine is eligible for restoration.
                InductionMode fittedMode;
                string fittedKitId;
                bool hasMountedCustomKit = TryDetectMountedInduction(loader, out fittedMode, out fittedKitId)
                    && IsProchargerPartId(fittedKitId);
                string kitId = hasMountedCustomKit ? fittedKitId : !String.IsNullOrEmpty(carKey)
                    ? PlayerPrefs.GetString(PrefKey(InstalledKitModePrefix + carKey), String.Empty)
                    : String.Empty;
                if (!IsProchargerPartId(kitId)) yield break;
                PartScript mount = FindMountedInductionPart(engine, kitId);

                // A synthetic mount is not part of a vanilla car save. Recreate it
                // from the profile-scoped kit record when the engine is loaded again.
                if (mount == null) mount = EnsureUniversalMount(engine, carKey);
                if (mount == null) yield break;

                ConfigureMountedInductionPart(mount, kitId);
                PrepareUniversalMountForInstalledKit(engine, mount);
                if (!String.IsNullOrEmpty(carKey))
                    PlayerPrefs.SetString(PrefKey(InstalledKitModePrefix + carKey), kitId);
                PlayerPrefs.Save();
                Logger.LogInfo("Restored the saved " + kitId + " visual on loaded car " + carKey + ".");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not restore a saved induction kit after loading a car: " + exception.Message);
            }
        }

        private static PartScript FindMountedInductionPart(GameObject engine, string kitId)
        {
            if (engine == null) return null;
            PartScript fallbackMount = null;
            PartScript[] parts = engine.GetComponentsInChildren<PartScript>(true);
            for (int i = 0; i < parts.Length; i++)
            {
                PartScript candidate = parts[i];
                if (candidate == null || candidate.IsUnmounted()) continue;
                bool universalMount = IsUniversalMountId(candidate.GetID()) || IsUniversalMountId(candidate.GetTunedID());
                string tunedId = candidate.GetTunedID();
                string combinedId = candidate.GetIDWithTuned();
                if (IsInductionPartId(tunedId) && (!IsInductionPartId(kitId)
                    || String.Equals(tunedId, kitId, StringComparison.OrdinalIgnoreCase))) return candidate;
                if (IsInductionPartId(combinedId) && (!IsInductionPartId(kitId)
                    || String.Equals(combinedId, kitId, StringComparison.OrdinalIgnoreCase))) return candidate;
                if (universalMount && fallbackMount == null) fallbackMount = candidate;
            }
            return fallbackMount;
        }

        private void PrepareUniversalMountForInstalledKit(GameObject engine, PartScript mount)
        {
            if (engine == null || mount == null || !IsUniversalMountId(mount.GetID())) return;

            // CMS disables a part's collider and marks it unmounted while it is being
            // previewed for removal. A saved kit means this runtime-only anchor should
            // be mounted again when the engine is transferred or loaded.
            if (!mount.gameObject.activeSelf) mount.gameObject.SetActive(true);
            SetPartField(mount, "unmounted", false);
            SetPartField(mount, "canBeUnmount", true);
            SetPartField(mount, "canUnmountSingle", true);
            SetPartField(mount, "canMountUnmountOnlyOnCarLoader", false);
            SetPartField(mount, "ForcePartGroup", -1);
            SetPartField(mount, "forInventory", false);

            // Re-evaluate after transfer/load, when the engine carries its full
            // pulley and intake assembly. Pre-transfer bounds can be incomplete.
            PositionUniversalMountNearDrivePulley(engine, mount.transform);

            string sourceName;
            mount.gameObject.layer = FindSelectablePartLayer(engine, out sourceName);
            Collider[] colliders = mount.GetComponents<Collider>();
            for (int i = 0; i < colliders.Length; i++)
                if (colliders[i] != null) colliders[i].enabled = true;

            Transform visual = mount.transform.Find(InstalledInductionVisualName);
            if (visual != null)
            {
                if (!visual.gameObject.activeSelf) visual.gameObject.SetActive(true);
                AlignProchargerVisualToCrank(visual, engine.transform);
                AddProchargerDriveVisuals(mount, visual);
                Renderer[] renderers = visual.GetComponentsInChildren<Renderer>(true);
                int enabledRenderers = 0;
                for (int i = 0; i < renderers.Length; i++)
                {
                    if (renderers[i] == null) continue;
                    if (!renderers[i].gameObject.activeSelf) renderers[i].gameObject.SetActive(true);
                    renderers[i].enabled = true;
                    if (renderers[i].enabled && renderers[i].gameObject.activeInHierarchy) enabledRenderers++;
                }
                AddUnmountVisibilityTargets(mount, visual);
                ResetMountedInductionSelectionCollider(mount);
                UpdateMountedInductionSelectionCollider(mount, visual);
                RefreshPartHighlight(mount);
                HighlightingSystem.Highlighter visualHighlighter = visual.GetComponent<HighlightingSystem.Highlighter>();
                if (visualHighlighter != null) visualHighlighter.ReinitMaterials();
                Logger.LogInfo("Verified induction visual visibility after transfer: mountActive="
                    + mount.gameObject.activeInHierarchy + ", visualActive=" + visual.gameObject.activeInHierarchy
                    + ", renderers=" + enabledRenderers + "/" + renderers.Length + ", engine=" + engine.name + ".");
            }
            else
            {
                Logger.LogWarning("The transferred universal mount has no " + InstalledInductionVisualName
                    + " child visual on " + engine.name + ".");
            }
            Logger.LogInfo("Reactivated the saved induction mount on " + engine.name + " at selectable layer "
                + mount.gameObject.layer + " (source part " + sourceName + ").");
        }
        private void UpdateEffectiveSettings()
        {
            if (standOccupied)
            {
                activeHasNativeInduction = false;
                activeHasCustomInduction = false;
                activeHasHighBoostProcharger = false;
                activeNativePartId = string.Empty;
                activeMode = InductionMode.Off;
                activeBoostPsi = selectedBoostPsi;
            }
            else
            {
                string previousNativePartId = activeNativePartId;
                VPVehicleController linkedController;
                CarLoader loader = FindActiveCarLoader(out linkedController);
                if (linkedController != null) activeController = linkedController;
                InductionMode detectedMode;
                string detectedPartId;
                activeHasNativeInduction = TryDetectMountedInduction(loader, out detectedMode, out detectedPartId);
                activeHasCustomInduction = activeHasNativeInduction && IsInductionPartId(detectedPartId);
                activeNativePartId = activeHasCustomInduction ? detectedPartId : string.Empty;
                activeHasHighBoostProcharger = activeHasCustomInduction && IsHighBoostProchargerPartId(detectedPartId);

                // Only an installed P-1X part activates boost. Stock components and saved
                // UI preferences are not evidence of fitted hardware, so they can never
                // alter another vehicle's dyno trace or factory power.
                if (activeHasCustomInduction)
                {
                    activeMode = detectedMode;
                    float storedPsi = !String.IsNullOrEmpty(activeCarKey)
                        ? PlayerPrefs.GetFloat(PrefKey(CarPsiPrefix + activeCarKey), selectedBoostPsi)
                        : selectedBoostPsi;
                    activeBoostPsi = ProchargerMath.NormalizeBoostPsi(storedPsi, GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger), 8.0f);
                    selectedMode = activeMode;
                    if (!String.Equals(previousNativePartId, detectedPartId, StringComparison.Ordinal))
                        status = "Using installed P-1X kit: " + detectedPartId;
                }
                else
                {
                    activeMode = InductionMode.Off;
                    activeBoostPsi = selectedBoostPsi;
                }
            }
        }
        private InductionMode ModeForActiveCar()
        {
            return activeMode;
        }

        private float PsiForActiveCar()
        {
            return activeBoostPsi;
        }

        internal string GetCurrentUniversalMountDisplayName()
        {
            bool installed = standOccupied
                ? standHasNativeInduction && standNativeMode == InductionMode.Procharger
                : activeHasCustomInduction && activeMode == InductionMode.Procharger;
            if (installed)
                return (standOccupied ? standHasHighBoostProcharger : activeHasHighBoostProcharger)
                    ? "ProCharger P-1X High-Boost" : "ProCharger P-1X";
            return "ProCharger Mount Point (kit not installed)";
        }

        private bool CurrentContextHasProcharger()
        {
            return standOccupied
                ? standHasNativeInduction && standNativeMode == InductionMode.Procharger
                : activeHasCustomInduction && activeMode == InductionMode.Procharger;
        }

        private string CurrentContextProchargerName()
        {
            if (!CurrentContextHasProcharger()) return "No ProCharger installed";
            return (standOccupied ? standHasHighBoostProcharger : activeHasHighBoostProcharger)
                ? "ProCharger P-1X High-Boost" : "ProCharger P-1X";
        }

        private InductionMode ModeForVisual()
        {
            return standOccupied ? selectedMode : activeMode;
        }

        private void RefreshStandPartDetection(GameScript game)
        {
            standHasNativeInduction = false;
            standHasHighBoostProcharger = false;
            standNativeMode = InductionMode.Off;
            if (game == null) return;

            try
            {
                List<GameObject> objects = game.GetObjectsOnEngineStand();
                if (objects == null) return;
                for (int i = 0; i < objects.Count; i++)
                {
                    InductionMode mode;
                    string partId;
                    if (!TryDetectMountedInduction(objects[i], out mode, out partId)) continue;
                    standHasNativeInduction = true;
                    standNativeMode = mode;
                    standHasHighBoostProcharger = mode == InductionMode.Procharger
                        && IsHighBoostProchargerPartId(partId);
                    return;
                }
            }
            catch (Exception exception)
            {
                Logger.LogDebug("Could not inspect engine-stand induction parts: " + exception.Message);
            }
        }

        private static bool TryDetectMountedInduction(CarLoader loader, out InductionMode mode, out string partId)
        {
            mode = InductionMode.Off;
            partId = string.Empty;
            if (loader == null) return false;
            try
            {
                GameObject engineObject = loader.GetEngine();
                if (TryDetectMountedInduction(engineObject, out mode, out partId)) return true;
                GameObject rootObject = loader.GetRoot();
                if (rootObject != engineObject && TryDetectMountedInduction(rootObject, out mode, out partId)) return true;
            }
            catch { }
            mode = InductionMode.Off;
            partId = string.Empty;
            return false;
        }

        private static bool TryDetectMountedInduction(GameObject root, out InductionMode mode, out string partId)
        {
            mode = InductionMode.Off;
            partId = string.Empty;
            if (root == null) return false;
            PartScript[] parts = root.GetComponentsInChildren<PartScript>(true);
            // Prefer a fitted CMS kit to a factory turbo/supercharger that may still
            // be mounted elsewhere on the same engine. Otherwise the stock part can
            // mask the custom kit and leave the dyno using the wrong boost mode.
            for (int pass = 0; pass < 2; pass++)
            {
                for (int i = 0; i < parts.Length; i++)
                {
                    PartScript part = parts[i];
                    if (part == null || part.IsUnmounted()) continue;
                    string candidateId = part.GetIDWithTuned();
                    InductionMode candidate = ClassifyNativePartId(candidateId);
                    if (candidate == InductionMode.Off)
                    {
                        candidateId = part.GetID();
                        candidate = ClassifyNativePartId(candidateId);
                    }
                    if (candidate == InductionMode.Off) continue;
                    bool customKit = IsInductionPartId(candidateId);
                    if ((pass == 0) != customKit) continue;
                    mode = candidate;
                    partId = candidateId;
                    return true;
                }
            }
            return false;
        }

        private static InductionMode ClassifyNativePartId(string partId)
        {
            if (String.IsNullOrEmpty(partId)) return InductionMode.Off;
            return ModeForInductionPartId(partId);
        }
        private static float CalculateInductionTorqueDelta(VehiclePhysics.Engine engine, float rpm, float baseTorque, float boostTarget)
        {
            if (engine == null || engine.settings == null) return 0.0f;
            float sampleRpm = ProchargerMath.IsFinite(rpm) ? Mathf.Max(0.0f, rpm) : 0.0f;
            float boostPressure = CalculateP1XBoostPsi(engine.settings, sampleRpm, boostTarget);
            ChargeAirState charge = ChargeAirModel.Calculate(boostPressure, 0.70f, 0.58f, 0.55f,
                ChargeAirModel.StandardAmbientTemperatureKelvin,
                ChargeAirModel.StandardAmbientPressurePsi);
            float chargeGain = Mathf.Clamp(charge.AirDensityRatio - 1.0f, 0.0f, 1.25f);
            // CMS passes gross torque here and deducts friction in both dyno
            // series. Scale the kit's gain from the engine's usable torque.
            float availableTorque = Mathf.Max(0.0f, baseTorque - engine.GetFrictionTorque(sampleRpm));
            float pressureRatio = charge.ManifoldAbsolutePressurePsi / ChargeAirModel.StandardAmbientPressurePsi;
            float addedTorque = availableTorque * chargeGain * P1XChargeToTorqueFactor;
            float estimatedDriveLoss = availableTorque * Mathf.Max(0.0f, pressureRatio - 1.0f) * 0.035f;
            return ClampP1XTorqueDelta(availableTorque, addedTorque - estimatedDriveLoss, sampleRpm);
        }

        private static float ClampP1XTorqueDelta(float baseTorque, float torqueDelta, float rpm)
        {
            if (torqueDelta <= 0.0f || rpm <= 1.0f) return torqueDelta;
            const float horsepowerPerNewtonMeterAtRpm = 1.0f / 7127.0f;
            float maximumRatedTorque = P1XMaxSuperchargedHp / (rpm * horsepowerPerNewtonMeterAtRpm);
            float availableTorque = Mathf.Max(0.0f, maximumRatedTorque - Mathf.Max(0.0f, baseTorque));
            return Mathf.Min(torqueDelta, availableTorque);
        }

        private static float CalculateBoostPressurePsi(InductionMode mode, VehiclePhysics.Engine.Settings engineSettings,
            float rpm, float spool, float targetPsi)
        {
            if (mode != InductionMode.Procharger) return 0.0f;
            return CalculateP1XBoostPsi(engineSettings, rpm, targetPsi);
        }

        private static float CalculateP1XImpellerRpm(VehiclePhysics.Engine.Settings engineSettings, float rpm, float targetPsi)
        {
            if (engineSettings == null || !ProchargerMath.IsFinite(rpm) || targetPsi <= 0.0f) return 0.0f;
            float peakRpm = ProchargerMath.IsFinite(engineSettings.peakRpm)
                ? Mathf.Max(1.0f, engineSettings.peakRpm) : 1.0f;
            float peakBoost = ProchargerMath.NormalizeBoostPsi(targetPsi, P1XMaxBoostPsi, 0.0f);
            float impellerRpmAtPeak = P1XMaxImpellerRpm * Mathf.Sqrt(peakBoost / P1XMaxBoostPsi);
            float externalPulleyRatio = impellerRpmAtPeak / (peakRpm * P1XInternalStepUpRatio);
            return Mathf.Max(0.0f, rpm) * externalPulleyRatio * P1XInternalStepUpRatio;
        }

        private static float CalculateP1XBoostPsi(VehiclePhysics.Engine.Settings engineSettings, float rpm, float targetPsi)
        {
            float impellerRpm = CalculateP1XImpellerRpm(engineSettings, rpm, targetPsi);
            float speedRatio = ProchargerMath.NormalizeBoostPsi(impellerRpm / P1XMaxImpellerRpm, 1.0f, 0.0f);

            // Centrifugal compressor pressure rise is approximated from impeller speed squared.
            // The published 32 psi and 65,000 rpm ratings bound this simplified curve; the
            // manufacturer does not publish a complete operating map for this model.
            float boostLimit = ProchargerMath.NormalizeBoostPsi(targetPsi, P1XMaxBoostPsi, 0.0f);
            return Mathf.Min(boostLimit, P1XMaxBoostPsi * speedRatio * speedRatio);
        }

        private static float CalculateManifoldGaugePsi(float compressorBoostPsi, float throttle)
        {
            float throttleOpening = ProchargerMath.NormalizeBoostPsi(throttle, 1.0f, 0.0f);
            float closedThrottleVacuum = MaxManifoldVacuumPsi * Mathf.Pow(1.0f - throttleOpening, 1.8f);
            float boostAtManifold = ProchargerMath.NormalizeBoostPsi(compressorBoostPsi, P1XMaxBoostPsi, 0.0f) * Mathf.Pow(throttleOpening, 0.9f);
            return boostAtManifold - closedThrottleVacuum;
        }

        private bool IsEngineInActiveApplicationScope(VehiclePhysics.Engine engine)
        {
            if (engine == null) return false;
            // CarEngineHelper uses a separate plain Engine object for the dyno curve.
            // Its calls are safe to augment only while CMS is drawing the active car's
            // dyno chart. The runtime engine is matched by reference to CMS's verified
            // VPVehicleController.m_engine field to avoid affecting previews/other cars.
            if (dynoSampleBoostPsi.HasValue) return true;
            if (!activeHasCustomInduction) return false;
            VPVehicleController controller = activeController;
            VehiclePhysics.Engine liveEngine = ReadComponentReference<VehiclePhysics.Engine>(controller, "m_engine");
            return System.Object.ReferenceEquals(engine, liveEngine);
        }

        private void ApplyMaxPowerTorque(VehiclePhysics.Engine engine, float rpm, ref float result)
        {
            if (!IsEngineInActiveApplicationScope(engine) || engine.settings == null) return;
            float sampleRpm = ProchargerMath.IsFinite(rpm) ? Mathf.Max(0.0f, rpm) : 0.0f;
            lastEngine = engine;
            lastRpm = sampleRpm;
            lastThrottle = 1.0f;

            InductionMode mode = dynoSampleBoostPsi.HasValue ? InductionMode.Procharger : ModeForActiveCar();
            if (mode != InductionMode.Procharger) return;
            float targetPsi = dynoSampleBoostPsi ?? PsiForActiveCar();
            float boostPressure = CalculateBoostPressurePsi(mode, engine.settings, sampleRpm, currentSpool, targetPsi);
            float torqueDelta = CalculateInductionTorqueDelta(engine, sampleRpm, result, targetPsi);
            if (!ProchargerMath.IsFinite(torqueDelta) || torqueDelta <= 0.0f) return;
            result += torqueDelta;
            liveBoostPsi = CalculateManifoldGaugePsi(boostPressure, 1.0f);
            lastNetTorque = result;
        }

        private static float CalculateSpoolForSample(InductionMode mode, VehiclePhysics.Engine.Settings engineSettings, float rpm, float throttle)
        {
            if (mode != InductionMode.Procharger || engineSettings == null) return 0.0f;
            float idle = engineSettings.idleRpm;
            float peak = ProchargerMath.IsFinite(engineSettings.peakRpm)
                ? Mathf.Max(idle + 1.0f, engineSettings.peakRpm) : idle + 1.0f;
            float mechanicalSpeedFraction = Mathf.Clamp01(Mathf.Max(0.0f, rpm) / peak);
            float load = Mathf.Pow(Mathf.Clamp01(throttle), 0.72f);
            return mechanicalSpeedFraction * mechanicalSpeedFraction * load;
        }

        private float CalculateSpoolForCurrentEngine(InductionMode mode,
            VehiclePhysics.Engine.Settings engineSettings, float rpm, float throttle)
        {
            return CalculateSpoolForSample(mode, engineSettings, rpm, throttle);
        }







        private void AdvanceSpool(float deltaTime)
        {
            InductionMode mode = ModeForActiveCar();
            if (mode == InductionMode.Off || lastEngine == null || lastEngine.settings == null)
            {
                spoolTarget = 0.0f;
                currentSpool = Mathf.MoveTowards(currentSpool, 0.0f, Mathf.Max(0.0f, deltaTime) * 4.0f);
                liveBoostPsi = 0.0f;
                return;
            }

            spoolTarget = CalculateSpoolForCurrentEngine(mode, lastEngine.settings, lastRpm, lastThrottle);
            currentSpool = spoolTarget;

            float boostPressure = CalculateBoostPressurePsi(mode, lastEngine.settings, lastRpm, currentSpool, PsiForActiveCar());
            liveBoostPsi = CalculateManifoldGaugePsi(boostPressure, lastThrottle);
        }

        private void EnsureVisual()
        {
            InductionMode mode = ModeForVisual();
            if (mode == InductionMode.Procharger && !CurrentContextHasProcharger())
            {
                RemoveVisual();
                return;
            }
            if ((!standOccupied && activeHasNativeInduction)
                || (standOccupied && standHasNativeInduction && standNativeMode == mode))
            {
                RemoveVisual();
                return;
            }
            if (mode == InductionMode.Off)
            {
                RemoveVisual();
                return;
            }
            if (mode != InductionMode.Procharger)
            {
                // Legacy mode values remain readable for save compatibility, but no
                // non-P-1X visual or behavior is shipped in patch 0.9.1.
                RemoveVisual();
                status = "This saved induction mode is retired; select the P-1X setup to continue";
                return;
            }

            PartScript prochargerMount = null;
            Transform parent;
            if (standOccupied && mode == InductionMode.Procharger)
            {
                prochargerMount = FindStandProchargerMount();
                if (prochargerMount == null)
                {
                    // The P-1X can preview on any engine. Engines without a
                    // compatible stock attachment slot can still preview the kit on the engine body;
                    // a compatible CMS attachment point is only available on some engines.
                    parent = FindVisualParent();
                    status = "ProCharger mode preview; this engine has no factory turbo slot";
                }
                else if (IsInductionPartId(prochargerMount.GetTunedID())
                    && prochargerMount.transform.Find(InstalledInductionVisualName) != null)
                {
                    RemoveVisual();
                    status = ModeName(ModeForInductionPartId(prochargerMount.GetTunedID())) + " installed; select the existing part to interact";
                    return;
                }
                else
                {
                    parent = prochargerMount.transform;
                }
            }
            else
            {
                parent = FindVisualParent();
            }
            if (parent == null) return;
            if (visualRoot != null && visualRoot.transform.parent == parent && visualMode == mode) return;
            RemoveVisual();

            visualRoot = new GameObject("CMS18_ProCharger_P1X_Visual");
            visualRoot.transform.SetParent(parent, false);
            visualRoot.transform.localPosition = prochargerMount == null
                ? new Vector3(0.42f, 0.24f, 0.0f) : Vector3.zero;
            visualRoot.transform.localRotation = Quaternion.identity;
            visualRoot.transform.localScale = prochargerMount == null
                ? Vector3.one * 0.72f : Vector3.one;
            visualMode = mode;

            if (prochargerMount != null)
            {
                if (TryCreateStandProchargerPreview(prochargerMount))
                {
                    status = IsUniversalMountId(prochargerMount.GetID())
                        ? "P-1X preview aligned to the engine's belt-drive mount"
                        : "P-1X preview aligned to the factory induction slot";
                    return;
                }
                RemoveVisual();
                status = "Could not fit the P-1X preview to the induction mount";
                return;
            }

            if (TryCreateInductionModel(mode)) return;

            // Keep the empty, mode-tagged root so a missing mesh is not retried and
            // logged on every visual refresh. The user gets a clear status and the
            // plugin leaves the stock host geometry intact.
            status = "The P-1X model could not be loaded; check the mod log for the asset error";
            Logger.LogWarning(status);
        }

        private PartScript FindStandProchargerMount()
        {
            try
            {
                GameScript game = GameScript.Get();
                List<GameObject> objects = game == null ? null : game.GetObjectsOnEngineStand();
                if (objects == null) return null;
                PartScript nativeFallback = null;
                for (int i = 0; i < objects.Count; i++)
                {
                    if (objects[i] == null) continue;
                    PartScript[] parts = objects[i].GetComponentsInChildren<PartScript>(true);
                    for (int j = 0; j < parts.Length; j++)
                    {
                        PartScript part = parts[j];
                        if (part == null) continue;
                        if (IsUniversalMountId(part.GetID()) || IsUniversalMountId(part.GetTunedID())) return part;
                        if (nativeFallback == null && IsInductionMount(part)) nativeFallback = part;
                    }
                }
                if (nativeFallback != null) return nativeFallback;
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not locate a universal or factory induction mount on the engine stand: " + exception.Message);
            }
            return null;
        }

        private static bool IsInductionMount(PartScript part)
        {
            if (part == null) return false;
            return IsInductionMountId(part.GetID()) || IsInductionMountId(part.GetTunedID());
        }

        private static bool IsProchargerMountId(string id)
        {
            return IsInductionMountId(id);
        }

        private static bool IsInductionMountId(string id)
        {
            if (String.IsNullOrEmpty(id)) return false;
            string normalized = RemoveSlotSuffix(id);
            return IsUniversalMountId(normalized)
                || IsNativeInductionMountSlotId(normalized);
        }

        // CMS exposes these stock engine slots as usable mounting parents for the
        // universal P-1X bracket. They are mount anchors only; their native parts
        // never activate or receive forced-induction behavior from this plugin.
        private static bool IsNativeInductionMountSlotId(string id)
        {
            if (String.IsNullOrEmpty(id)) return false;
            string value = id.Trim().ToLowerInvariant();
            return value.Contains("turbo") || value.Contains("supercharger");
        }

        private static bool IsUniversalMountId(string id)
        {
            string normalized = id == null ? String.Empty : id.Trim();
            if (normalized.StartsWith("!", StringComparison.Ordinal)) normalized = normalized.Substring(1);
            normalized = RemoveSlotSuffix(normalized);
            return String.Equals(normalized, UniversalMountPartId, StringComparison.OrdinalIgnoreCase)
                || String.Equals(normalized, UniversalMountDisplayName, StringComparison.OrdinalIgnoreCase)
                || String.Equals(normalized, "Universal Induction Mount", StringComparison.OrdinalIgnoreCase)
                || String.Equals(normalized, "ProCharger Mount Bracket", StringComparison.OrdinalIgnoreCase);
        }

        private static string RemoveSlotSuffix(string id)
        {
            if (String.IsNullOrEmpty(id)) return String.Empty;
            string normalized = id.Trim();
            int slotSuffix = normalized.IndexOf('(');
            return slotSuffix >= 0 ? normalized.Substring(0, slotSuffix) : normalized;
        }

        internal static bool IsProchargerCompatibleSlot(string partId, string slotId)
        {
            if (IsUniversalMountId(partId)) return false;
            if (IsUniversalMountId(slotId) && IsInductionPartId(partId))
            {
                InductionMode requestedMode = ModeForInductionPartId(partId);
                TurboPrototypePlugin plugin = Instance;
                return requestedMode == InductionMode.Procharger
                    || plugin == null || !plugin.CurrentEngineHasCarburetor();
            }
            if (IsInductionPartId(partId) && IsCarburetorSlotId(slotId))
                return ModeForInductionPartId(partId) == InductionMode.Procharger;
            InductionMode partMode = ClassifyNativePartId(partId);
            InductionMode slotMode = ClassifyNativePartId(slotId);
            return partMode != InductionMode.Off
                && partMode != InductionMode.Procharger
                && partMode == slotMode;
        }

        private static bool IsCarburetorSlotId(string partId)
        {
            return IsCarburetorIdentifier(partId);
        }

        private static bool IsCarburetorIdentifier(string value)
        {
            if (String.IsNullOrEmpty(value)) return false;
            string id = RemoveSlotSuffix(value).Trim().ToLowerInvariant();
            return id.Contains("carb") || id.Contains("gaznik") || id.Contains("gaźnik");
        }

        private bool CurrentEngineHasCarburetor()
        {
            if (Time.unscaledTime < nextCarburetorProbe) return cachedCarburetedContext;
            nextCarburetorProbe = Time.unscaledTime + 0.5f;
            cachedCarburetedContext = DetectCarburetedEngine();
            return cachedCarburetedContext;
        }

        private bool DetectCarburetedEngine()
        {
            try
            {
                if (standOccupied)
                {
                    GameScript game = GameScript.Get();
                    List<GameObject> objects = game == null ? null : game.GetObjectsOnEngineStand();
                    if (objects != null)
                    {
                        for (int i = 0; i < objects.Count; i++)
                        {
                            GameObject item = objects[i];
                            if (item == null) continue;
                            PartScript[] parts = item.GetComponentsInChildren<PartScript>(true);
                            for (int j = 0; j < parts.Length; j++)
                            {
                                PartScript part = parts[j];
                                if (part != null && (IsCarburetorIdentifier(part.GetID())
                                    || IsCarburetorIdentifier(part.GetTunedID())
                                    || IsCarburetorIdentifier(part.gameObject.name))) return true;
                            }
                        }
                    }
                }
                else if (activeController != null)
                {
                    Transform engineRoot = FindEngineRootTransform(activeController.transform);
                    if (engineRoot != null)
                    {
                        PartScript[] parts = engineRoot.GetComponentsInChildren<PartScript>(true);
                        for (int i = 0; i < parts.Length; i++)
                        {
                            PartScript part = parts[i];
                            if (part != null && !part.IsUnmounted()
                                && (IsCarburetorIdentifier(part.GetID())
                                    || IsCarburetorIdentifier(part.GetTunedID())
                                    || IsCarburetorIdentifier(part.gameObject.name))) return true;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.LogDebug("Carburetor detection failed safely: " + exception.Message);
            }
            return false;
        }

        private bool TryCreateStandProchargerPreview(PartScript mount)
        {
            if (mount == null) return false;
            if (!inductionModelLoadAttempted.Contains(InductionMode.Procharger))
            {
                inductionModelLoadAttempted.Add(InductionMode.Procharger);
                BuildInductionModelAsset(InductionMode.Procharger, ProchargerModelResource, "P-1X Style ProCharger");
            }

            Mesh mesh;
            Material[] materials;
            if (!inductionModelMeshes.TryGetValue(InductionMode.Procharger, out mesh) || mesh == null
                || !inductionModelMaterials.TryGetValue(InductionMode.Procharger, out materials) || materials == null) return false;

            Renderer[] stockRenderers = mount.GetComponentsInChildren<Renderer>(true);
            Bounds localBounds;
            bool virtualMount = IsUniversalMountId(mount.GetID());
            if (virtualMount)
            {
                localBounds = new Bounds(Vector3.zero, new Vector3(0.28f, 0.24f, 0.24f));
            }
            else if (!TryGetLocalRendererBounds(stockRenderers, mount.transform, out localBounds))
            {
                return false;
            }

            Quaternion modelRotation = Quaternion.identity;
            Vector3 meshSize = mesh.bounds.size;
            Vector3 rotatedMeshSize = meshSize;
            float scaleX = localBounds.size.x / Mathf.Max(0.001f, rotatedMeshSize.x);
            float scaleY = localBounds.size.y / Mathf.Max(0.001f, rotatedMeshSize.y);
            float scaleZ = localBounds.size.z / Mathf.Max(0.001f, rotatedMeshSize.z);
            float scale = Mathf.Min(scaleX, Mathf.Min(scaleY, scaleZ)) * 0.92f;
            if (virtualMount) scale = ProchargerModelUnitScale;
            if (Single.IsNaN(scale) || Single.IsInfinity(scale) || scale <= 0.001f) return false;

            GameObject modelObject = new GameObject("CMS18 ProCharger P-1X Stand Preview");
            modelObject.transform.SetParent(visualRoot.transform, false);
            modelObject.layer = mount.gameObject.layer;
            modelObject.transform.localRotation = modelRotation;
            modelObject.transform.localScale = Vector3.one * scale;
            modelObject.transform.localPosition = localBounds.center - modelRotation * (mesh.bounds.center * scale);
            MeshFilter filter = modelObject.AddComponent<MeshFilter>();
            filter.sharedMesh = mesh;
            MeshRenderer renderer = modelObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterials = materials;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            ConfigureInductionRenderer(renderer);
            Transform engineRoot = FindEngineRootTransform(mount.transform);
            if (engineRoot != null && engineRoot.name.StartsWith("engine_", StringComparison.OrdinalIgnoreCase))
                AlignProchargerVisualToCrank(modelObject.transform, engineRoot);
            AddProchargerDriveVisuals(mount, modelObject.transform);

            Bounds selectableBounds;
            bool hasSelectableBounds = TryGetLocalRendererBounds(
                visualRoot.GetComponentsInChildren<Renderer>(true), mount.transform, out selectableBounds);
            if (!hasSelectableBounds || selectableBounds.size.sqrMagnitude < 0.000001f)
                selectableBounds = BoundsInRelativeSpace(mesh.bounds, modelObject.transform, mount.transform);
            if (selectableBounds.size.sqrMagnitude < 0.000001f) selectableBounds = localBounds;
            BoxCollider hitbox = mount.gameObject.AddComponent<BoxCollider>();
            hitbox.center = selectableBounds.center;
            hitbox.size = selectableBounds.size * 1.18f;
            hitbox.enabled = true;
            standPreviewHitboxes.Add(hitbox);

            int stateKey = mount.GetInstanceID();
            if (!standPreviewRendererStates.ContainsKey(stateKey))
            {
                List<ProchargerRendererState> states = new List<ProchargerRendererState>();
                for (int i = 0; i < stockRenderers.Length; i++)
                    if (stockRenderers[i] != null && stockRenderers[i].GetComponent<MountObject>() == null)
                        states.Add(new ProchargerRendererState(stockRenderers[i]));
                standPreviewRendererStates[stateKey] = states;
            }
            for (int i = 0; i < stockRenderers.Length; i++)
                if (stockRenderers[i] != null && stockRenderers[i].GetComponent<MountObject>() == null)
                    stockRenderers[i].enabled = false;
            RefreshPartHighlight(mount);
            return true;
        }

        private static Bounds BoundsInRelativeSpace(Bounds sourceBounds, Transform sourceTransform, Transform relativeTo)
        {
            if (sourceTransform == null || relativeTo == null) return new Bounds(Vector3.zero, Vector3.zero);
            bool initialized = false;
            Bounds result = new Bounds(Vector3.zero, Vector3.zero);
            for (int corner = 0; corner < 8; corner++)
            {
                Vector3 sourcePoint = new Vector3(
                    (corner & 1) == 0 ? sourceBounds.min.x : sourceBounds.max.x,
                    (corner & 2) == 0 ? sourceBounds.min.y : sourceBounds.max.y,
                    (corner & 4) == 0 ? sourceBounds.min.z : sourceBounds.max.z);
                Vector3 point = relativeTo.InverseTransformPoint(sourceTransform.TransformPoint(sourcePoint));
                if (!initialized)
                {
                    result = new Bounds(point, Vector3.zero);
                    initialized = true;
                }
                else result.Encapsulate(point);
            }
            return result;
        }

        private void AlignProchargerVisualToCrank(Transform modelTransform, Transform engineRoot)
        {
            if (modelTransform == null || engineRoot == null) return;
            PartScript crankPulley = FindCrankPulleyPart(engineRoot.gameObject);
            Vector3 crankCenterWorld = engineRoot.position;
            float crankRadiusWorld = 0.075f;
            Vector3 pulleyAxisWorld = engineRoot.right;
            if (crankPulley != null)
            {
                Bounds crankBounds;
                if (TryGetPartWorldBounds(crankPulley, out crankBounds)) crankCenterWorld = crankBounds.center;
                Bounds localPulleyBounds;
                if (TryGetPartLocalMeshBounds(crankPulley, out localPulleyBounds)
                    || TryGetLocalRendererBounds(crankPulley.GetComponentsInChildren<Renderer>(true), crankPulley.transform, out localPulleyBounds))
                {
                    crankCenterWorld = crankPulley.transform.TransformPoint(localPulleyBounds.center);
                    crankRadiusWorld = EstimatePulleyRadiusWorld(localPulleyBounds.size, crankPulley.transform);
                    pulleyAxisWorld = SmallestLocalBoundsAxis(localPulleyBounds.size, crankPulley.transform);
                }
                if (Vector3.Dot(pulleyAxisWorld, engineRoot.right) < 0.0f) pulleyAxisWorld = -pulleyAxisWorld;
            }
            if (pulleyAxisWorld.sqrMagnitude < 0.0001f) pulleyAxisWorld = engineRoot.right;
            pulleyAxisWorld.Normalize();

            Quaternion baseRotation = Quaternion.FromToRotation(engineRoot.right, pulleyAxisWorld) * engineRoot.rotation;
            // The 0.8.49 flip put the housing toward the block. The authored OBJ
            // orientation faces the housing outboard while preserving the pulley axis.
            modelTransform.rotation = baseRotation;
            Vector3 upWorld = engineRoot.up - pulleyAxisWorld * Vector3.Dot(engineRoot.up, pulleyAxisWorld);
            if (upWorld.sqrMagnitude < 0.0001f)
                upWorld = engineRoot.forward - pulleyAxisWorld * Vector3.Dot(engineRoot.forward, pulleyAxisWorld);
            upWorld.Normalize();
            Vector3 desiredPulleyCenter = crankCenterWorld + upWorld * Mathf.Max(0.14f, crankRadiusWorld + 0.075f);
            modelTransform.position += desiredPulleyCenter - modelTransform.TransformPoint(ProchargerDrivePulleyCenter);
            Logger.LogInfo("Aligned the installed P-1X drive pulley above "
                + (crankPulley == null ? "the estimated crank pulley" : crankPulley.GetID())
                + " on " + engineRoot.name + ".");
        }

        private const string ProchargerBeltObjectName = "CMS18 ProCharger Drive Belt";

        private static bool TryGetDrivePulleyBounds(PartScript part, out Bounds bounds)
        {
            return TryGetPartLocalMeshBounds(part, out bounds);
        }

        private static int ScoreBeltTensioner(string partId)
        {
            if (String.IsNullOrEmpty(partId)) return Int32.MaxValue;
            string id = partId.ToLowerInvariant();
            if (IsTimingDrivePart(id)) return Int32.MaxValue;
            if (id.Contains("tensioner") || id.Contains("napinacz")) return 0;
            if (id.Contains("rolka_gladka") || id.Contains("smooth_idler")) return 1;
            if (id.Contains("rolka_prowadzaca") || id.Contains("idler")) return 2;
            return Int32.MaxValue;
        }

        private void AddProchargerDriveVisuals(PartScript mount, Transform modelTransform)
        {
            if (mount == null || modelTransform == null) return;
            Transform engineRoot = FindEngineRootTransform(mount.transform);
            if (engineRoot == null) return;

            Transform previousBelt = modelTransform.Find(ProchargerBeltObjectName);
            if (previousBelt != null)
            {
                RemoveUnmountVisibilityTargets(mount, previousBelt);
                previousBelt.gameObject.SetActive(false);
                previousBelt.SetParent(null, false);
                UnityEngine.Object.Destroy(previousBelt.gameObject);
            }

            PartScript crank = FindCrankPulleyPart(engineRoot.gameObject);
            Bounds crankBounds;
            if (!TryGetDrivePulleyBounds(crank, out crankBounds)) return;
            Vector3 axisWorld = modelTransform.right;
            float modelScale = Mathf.Max(0.01f, Mathf.Abs(modelTransform.lossyScale.x));
            Vector3 chargerCenter = ProchargerDrivePulleyCenter;
            Vector3 crankCenter = modelTransform.InverseTransformPoint(crank.transform.TransformPoint(crankBounds.center));
            float crankRadius = EstimatePulleyRadiusWorld(crankBounds.size, crank.transform) / modelScale;
            float maxHalfWidth = ProchargerDriveBeltWidthMeters * 0.5f / modelScale;
            float crankHalfWidth = ProjectedModelHalfExtent(crankBounds, crank.transform.lossyScale, crank.transform.rotation, axisWorld) / modelScale;
            crankCenter.x = chargerCenter.x;
            float halfThickness = ProchargerDriveBeltThicknessMeters * 0.5f / modelScale;
            float halfWidth = maxHalfWidth;
            float planeOffset = 0.0f;
            PartScript tensioner = null;
            Vector3 extensionCenter = Vector3.zero;
            float extensionRadius = 0.0f;
            float extensionFace = 0.0f;
            List<Vector3> path = null;
            int bestScore = Int32.MaxValue;
            float bestLength = Single.PositiveInfinity;

            foreach (PartScript part in engineRoot.GetComponentsInChildren<PartScript>(true))
            {
                if (part == null || part == crank) continue;
                string partId = part.GetID();
                int score = ScoreBeltTensioner(partId);
                bool dedicatedLane = engineRoot.name.StartsWith("engine_r4_turbo", StringComparison.OrdinalIgnoreCase)
                    && (String.Equals(partId, "rolka_gladka", StringComparison.OrdinalIgnoreCase)
                        || (partId != null && partId.StartsWith("rolka_gladka(", StringComparison.OrdinalIgnoreCase)));
                if (dedicatedLane) score = -1;
                if (score > bestScore || score == Int32.MaxValue) continue;
                Bounds bounds;
                if (!TryGetDrivePulleyBounds(part, out bounds)) continue;
                Vector3 pulleyAxis = SmallestLocalBoundsAxis(bounds.size, part.transform);
                if (Mathf.Abs(Vector3.Dot(axisWorld, pulleyAxis)) < 0.96f) continue;
                float rollerHalfWidth = ProjectedModelHalfExtent(bounds, part.transform.lossyScale, part.transform.rotation, axisWorld) / modelScale;
                Vector3 rollerCenter = modelTransform.InverseTransformPoint(part.transform.TransformPoint(bounds.center));
                float rollerOuterFace = rollerCenter.x + rollerHalfWidth;
                float usableHalfWidth;
                float offset;
                if (dedicatedLane)
                {
                    // The smooth stock roller already runs a factory belt. Give the
                    // ProCharger its own coaxial, grooved roller and crank track.
                    usableHalfWidth = maxHalfWidth;
                    offset = GetDedicatedBeltOffset(crankHalfWidth, rollerOuterFace - chargerCenter.x,
                        maxHalfWidth, 0.002f / modelScale);
                }
                else if (!TryGetSharedBeltPlane(crankHalfWidth, rollerHalfWidth, rollerCenter.x - chargerCenter.x,
                    maxHalfWidth, 0.004f / modelScale, out usableHalfWidth, out offset)) continue;
                rollerCenter.x = chargerCenter.x;
                float rollerRadiusWorld = EstimatePulleyRadiusWorld(bounds.size, part.transform, 0.0f, Single.PositiveInfinity);
                if (rollerRadiusWorld < 0.012f || rollerRadiusWorld > 0.078f) continue;
                float rollerRadius = rollerRadiusWorld / modelScale;
                List<Vector3> candidate;
                float length;
                if (!TryBuildTensionerPath(chargerCenter, crankCenter, rollerCenter,
                    ProchargerDrivePulleyRadiusModel, crankRadius, rollerRadius, dedicatedLane || score == 2,
                    out candidate, out length)) continue;
                if (score == bestScore && length >= bestLength) continue;
                tensioner = part;
                bestScore = score;
                bestLength = length;
                path = candidate;
                halfWidth = usableHalfWidth;
                planeOffset = offset;
                extensionCenter = rollerCenter;
                extensionRadius = dedicatedLane ? rollerRadius : 0.0f;
                extensionFace = rollerOuterFace;
            }

            if (path == null)
            {
                float ignored;
                if (!TryBuildBeltPath(new Vector3[] { chargerCenter, crankCenter },
                    new float[] { ProchargerDrivePulleyRadiusModel, crankRadius }, out path, out ignored)) return;
            }

            Mesh mesh = BuildProchargerBeltMesh(path, halfWidth, halfThickness);
            modelTransform.position += modelTransform.TransformVector(Vector3.right * planeOffset);
            Transform belt = AddDriveMesh(modelTransform, ProchargerBeltObjectName, mesh, GetProchargerDriveMaterial(true));
            if (extensionRadius > 0.0f)
            {
                Material pulleyMaterial = FindProchargerModelMaterial("P1X_Pulley") ?? GetProchargerDriveMaterial(false);
                AddDriveExtension(belt, "P-1X crank drive extension", crankCenter, crankRadius,
                    crankCenter.x + crankHalfWidth - planeOffset, halfWidth, halfThickness, pulleyMaterial);
                AddDriveExtension(belt, "P-1X tensioner extension", extensionCenter, extensionRadius,
                    extensionFace - planeOffset, halfWidth, halfThickness, pulleyMaterial);
            }
            Logger.LogInfo("Fitted the P-1X belt to " + crank.GetID()
                + (tensioner != null ? " and stock " + tensioner.GetID() : " on a two-pulley route")
                + (extensionRadius > 0.0f ? " with separate drive extensions" : String.Empty)
                + " on " + engineRoot.name + "; belt width=" + (halfWidth * 2.0f * modelScale * 1000.0f).ToString("F1")
                + " mm, pulley-plane shift=" + (planeOffset * modelScale * 1000.0f).ToString("F1") + " mm.");
        }

        private static Transform AddDriveMesh(Transform parent, string name, Mesh mesh, Material material)
        {
            mesh.name = name;
            GameObject item = new GameObject(name);
            item.transform.SetParent(parent, false);
            item.AddComponent<MeshFilter>().sharedMesh = mesh;
            item.AddComponent<ProchargerBeltMeshOwner>().Mesh = mesh;
            MeshRenderer renderer = item.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = material;
            ConfigureInductionRenderer(renderer);
            return item.transform;
        }

        private static float GetDedicatedBeltOffset(float crankOuterFace, float rollerOuterFace,
            float beltHalfWidth, float clearance)
        {
            return Mathf.Max(crankOuterFace, rollerOuterFace) + beltHalfWidth + clearance;
        }

        private static void AddDriveExtension(Transform parent, string name, Vector3 center,
            float pitchRadius, float stockFace, float beltHalfWidth, float beltHalfThickness, Material material)
        {
            float contactRadius = pitchRadius - beltHalfThickness;
            float hubRadius = contactRadius * 0.65f;
            float rimDepth = contactRadius - hubRadius * 0.90f;
            AddDriveRing(parent, name, center, contactRadius, rimDepth, beltHalfWidth * 1.10f, material);

            float rimInnerFace = center.x - beltHalfWidth;
            Vector3 hubCenter = center;
            hubCenter.x = (stockFace + rimInnerFace) * 0.5f;
            AddDriveRing(parent, name + " hub", hubCenter, hubRadius, hubRadius * 0.92f,
                (rimInnerFace - stockFace) * 0.5f + beltHalfWidth * 0.15f, material);
        }

        private static void AddDriveRing(Transform parent, string name, Vector3 center,
            float radius, float radialDepth, float halfWidth, Material material)
        {
            List<Vector3> profile = new List<Vector3>();
            float halfDepth = radialDepth * 0.5f;
            AppendBeltArc(profile, center, radius - halfDepth, Vector3.up, Vector3.forward, 0.0f, -2.0f * Mathf.PI, 48);
            profile.RemoveAt(profile.Count - 1);
            AddDriveMesh(parent, name, BuildProchargerBeltMesh(profile, halfWidth, halfDepth), material);
        }

        private static bool TryGetSharedBeltPlane(float crankHalfWidth, float rollerHalfWidth, float rollerOffset,
            float nominalHalfWidth, float minimumHalfWidth, out float halfWidth, out float offset)
        {
            float low = Mathf.Max(-crankHalfWidth * 0.9f, rollerOffset - rollerHalfWidth * 0.9f);
            float high = Mathf.Min(crankHalfWidth * 0.9f, rollerOffset + rollerHalfWidth * 0.9f);
            halfWidth = Mathf.Min(nominalHalfWidth, (high - low) * 0.5f);
            offset = 0.0f;
            if (halfWidth < minimumHalfWidth) return false;
            offset = Mathf.Clamp(rollerOffset, low + halfWidth, high - halfWidth);
            return true;
        }
        private static float ProjectedModelHalfExtent(Bounds bounds, Vector3 scale, Quaternion rotation, Vector3 worldAxis)
        {
            Vector3 axis = worldAxis.sqrMagnitude < 0.000001f ? Vector3.up : worldAxis.normalized;
            Vector3 extents = Vector3.Scale(bounds.extents,
                new Vector3(Mathf.Abs(scale.x), Mathf.Abs(scale.y), Mathf.Abs(scale.z)));
            return Mathf.Abs(Vector3.Dot(rotation * Vector3.right, axis)) * extents.x
                + Mathf.Abs(Vector3.Dot(rotation * Vector3.up, axis)) * extents.y
                + Mathf.Abs(Vector3.Dot(rotation * Vector3.forward, axis)) * extents.z;
        }

        private Material FindProchargerModelMaterial(string materialSuffix)
        {
            if (String.IsNullOrEmpty(materialSuffix)) return null;
            Material[] materials;
            if (!inductionModelMaterials.TryGetValue(InductionMode.Procharger, out materials) || materials == null)
                return null;
            string suffix = " " + materialSuffix;
            for (int i = 0; i < materials.Length; i++)
                if (materials[i] != null && materials[i].name.EndsWith(suffix, StringComparison.Ordinal))
                    return materials[i];
            return null;
        }

        private static Transform FindEngineRootTransform(Transform partTransform)
        {
            Transform current = partTransform;
            while (current != null)
            {
                if (current.name.StartsWith("engine_", StringComparison.OrdinalIgnoreCase)) return current;
                current = current.parent;
            }
            return partTransform == null ? null : partTransform.root;
        }

        private Material GetProchargerDriveMaterial(bool belt)
        {
            Material cached = belt ? prochargerDriveBeltMaterial : prochargerBracketMaterial;
            if (cached != null) return cached;
            if (!belt)
            {
                cached = CreateNativeTurboMetalFinishClone();
                if (cached != null)
                {
                    cached.name = "CMS18 Native Turbocharger_2 P-1X Bracket Finish";
                    prochargerBracketMaterial = cached;
                    return cached;
                }
            }
            Shader shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Legacy Shaders/Diffuse");
            if (shader == null) return null;
            cached = new Material(shader);
            cached.name = belt ? "CMS18 ProCharger Drive Belt Material" : "CMS18 ProCharger Bracket Material";
            cached.color = belt ? new Color(0.035f, 0.040f, 0.044f, 1.0f) : new Color(0.68f, 0.69f, 0.68f, 1.0f);
            if (cached.HasProperty("_Glossiness")) cached.SetFloat("_Glossiness", belt ? 0.18f : 0.88f);
            if (cached.HasProperty("_Metallic")) cached.SetFloat("_Metallic", belt ? 0.02f : 0.82f);
            ConfigureOpaqueStandardMaterial(cached);
            if (belt) prochargerDriveBeltMaterial = cached;
            else prochargerBracketMaterial = cached;
            return cached;
        }

        private static bool TryBuildTensionerPath(Vector3 charger, Vector3 crank, Vector3 roller,
            float chargerRadius, float crankRadius, float rollerRadius, bool allowGroovedRoute,
            out List<Vector3> path, out float length)
        {
            path = null;
            length = Single.PositiveInfinity;
            for (int side = 0; side < 2; side++)
            {
                Vector3[] centers = side == 0 ? new Vector3[] { charger, crank, roller } : new Vector3[] { charger, roller, crank };
                for (int face = 0; face < (allowGroovedRoute ? 2 : 1); face++)
                {
                    // A smooth roller contacts the back of the belt. A guide
                    // pulley can also accept the ribbed face when the layout requires it.
                    float signedRadius = face == 0 ? -rollerRadius : rollerRadius;
                    float[] radii = side == 0 ? new float[] { chargerRadius, crankRadius, signedRadius }
                        : new float[] { chargerRadius, signedRadius, crankRadius };
                    List<Vector3> candidate;
                    float candidateLength;
                    if (!TryBuildBeltPath(centers, radii, out candidate, out candidateLength)
                        || candidateLength >= length) continue;
                    path = candidate;
                    length = candidateLength;
                }
            }
            return path != null;
        }

        private static bool TryBuildBeltPath(Vector3[] centers, float[] signedRadii, out List<Vector3> path, out float length)
        {
            path = new List<Vector3>();
            length = 0.0f;
            int count = centers.Length;
            Vector3[] incoming = new Vector3[count];
            Vector3[] outgoing = new Vector3[count];
            for (int i = 0; i < count; i++)
            {
                int next = (i + 1) % count;
                Vector3 offset = centers[next] - centers[i];
                float distance = offset.magnitude;
                float radiusDifference = signedRadii[i] - signedRadii[next];
                if (distance <= Mathf.Abs(signedRadii[i]) + Mathf.Abs(signedRadii[next]) + 0.003f) return false;
                Vector3 along = offset / distance;
                float ratio = radiusDifference / distance;
                Vector3 normal = along * ratio + Vector3.Cross(Vector3.right, along) * Mathf.Sqrt(1.0f - ratio * ratio);
                outgoing[i] = normal * Mathf.Sign(signedRadii[i]);
                incoming[next] = normal * Mathf.Sign(signedRadii[next]);
            }

            for (int i = 0; i < count; i++)
            {
                int next = (i + 1) % count;
                float radius = Mathf.Abs(signedRadii[i]);
                float angle = Mathf.Atan2(Vector3.Cross(incoming[i], outgoing[i]).x, Vector3.Dot(incoming[i], outgoing[i]));
                if (signedRadii[i] > 0.0f && angle > 0.0f) angle -= 2.0f * Mathf.PI;
                if (signedRadii[i] < 0.0f && angle < 0.0f) angle += 2.0f * Mathf.PI;
                if (Mathf.Abs(angle) < 0.07f || Mathf.Abs(angle) > (signedRadii[i] < 0.0f ? 2.85f : 4.85f)) return false;
                AppendBeltArc(path, centers[i], radius, incoming[i], Vector3.Cross(Vector3.right, incoming[i]),
                    0.0f, angle, Mathf.CeilToInt(Mathf.Abs(angle) * 18.0f));
                Vector3 end = centers[i] + outgoing[i] * radius;
                Vector3 start = centers[next] + incoming[next] * Mathf.Abs(signedRadii[next]);
                AppendBeltLine(path, end, start, 3);
                length += Mathf.Abs(angle) * radius + (start - end).magnitude;
            }
            if (path.Count < 4) return false;
            path.RemoveAt(path.Count - 1);

            // Reject a folded route or a belt that cuts through another pulley.
            for (int edge = 0; edge < path.Count; edge++)
            {
                Vector3 a = path[edge];
                Vector3 b = path[(edge + 1) % path.Count];
                Vector3 ab = b - a;
                for (int i = 0; i < count; i++)
                {
                    float t = Mathf.Clamp01(Vector3.Dot(centers[i] - a, ab) / ab.sqrMagnitude);
                    float clearance = Mathf.Max(0.0f, Mathf.Abs(signedRadii[i]) - 0.0025f);
                    if ((centers[i] - (a + ab * t)).sqrMagnitude < clearance * clearance) return false;
                }
                for (int other = edge + 2; other < path.Count; other++)
                {
                    if (edge == 0 && other == path.Count - 1) continue;
                    Vector3 c = path[other];
                    Vector3 d = path[(other + 1) % path.Count];
                    Vector3 cd = d - c;
                    if (Vector3.Cross(ab, c - a).x * Vector3.Cross(ab, d - a).x < -1.0e-12f
                        && Vector3.Cross(cd, a - c).x * Vector3.Cross(cd, b - c).x < -1.0e-12f) return false;
                }
            }
            return true;
        }

        private static Mesh BuildProchargerBeltMesh(List<Vector3> path, float halfWidth, float halfThickness)
        {
            Vector3 axis = Vector3.right;
            Vector3[] vertices = new Vector3[path.Count * 4];
            List<int> triangles = new List<int>(path.Count * 24);
            for (int i = 0; i < path.Count; i++)
            {
                Vector3 tangent = (path[(i + 1) % path.Count] - path[(i + path.Count - 1) % path.Count]).normalized;
                Vector3 thicknessAxis = Vector3.Cross(tangent, axis).normalized * halfThickness;
                Vector3 widthAxis = axis * halfWidth;
                int start = i * 4;
                vertices[start] = path[i] + widthAxis + thicknessAxis;
                vertices[start + 1] = path[i] + widthAxis - thicknessAxis;
                vertices[start + 2] = path[i] - widthAxis - thicknessAxis;
                vertices[start + 3] = path[i] - widthAxis + thicknessAxis;
                int next = ((i + 1) % path.Count) * 4;
                for (int side = 0; side < 4; side++)
                {
                    int a = start + side;
                    int b = start + ((side + 1) % 4);
                    int c = next + ((side + 1) % 4);
                    int d = next + side;
                    triangles.Add(a); triangles.Add(c); triangles.Add(b);
                    triangles.Add(a); triangles.Add(d); triangles.Add(c);
                }
            }
            Mesh mesh = new Mesh();
            mesh.vertices = vertices;
            mesh.triangles = triangles.ToArray();
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static void AppendBeltLine(List<Vector3> path, Vector3 from, Vector3 to, int steps)
        {
            for (int i = 0; i <= steps; i++)
            {
                Vector3 point = Vector3.Lerp(from, to, i / (float)steps);
                if (path.Count == 0 || (path[path.Count - 1] - point).sqrMagnitude > 0.000001f) path.Add(point);
            }
        }

        private static void AppendBeltArc(List<Vector3> path, Vector3 center, float radius, Vector3 horizontal, Vector3 vertical,
            float startAngle, float endAngle, int steps)
        {
            for (int i = 0; i <= steps; i++)
            {
                float angle = Mathf.Lerp(startAngle, endAngle, i / (float)steps);
                Vector3 point = center + (horizontal * Mathf.Cos(angle) + vertical * Mathf.Sin(angle)) * radius;
                if (path.Count == 0 || (path[path.Count - 1] - point).sqrMagnitude > 0.000001f) path.Add(point);
            }
        }

        private struct ObjCorner
        {
            public int position;
            public int texCoord;
            public int normal;
        }

        private bool TryCreateInductionModel(InductionMode mode)
        {
            if (mode != InductionMode.Procharger) return false;

            const string modelName = "P-1X Style ProCharger";

            if (!inductionModelLoadAttempted.Contains(mode))
            {
                inductionModelLoadAttempted.Add(mode);
                BuildInductionModelAsset(mode, ProchargerModelResource, modelName);
            }

            Mesh modelMesh;
            Material[] modelMaterials;
            if (!inductionModelMeshes.TryGetValue(mode, out modelMesh) || modelMesh == null
                || !inductionModelMaterials.TryGetValue(mode, out modelMaterials) || modelMaterials == null) return false;

            GameObject modelObject = new GameObject("CMS18 " + modelName + " Visual");
            modelObject.transform.SetParent(visualRoot.transform, false);
            modelObject.transform.localPosition = new Vector3(0.0f, 0.08f, 0.0f);
            modelObject.transform.localRotation = Quaternion.identity;
            modelObject.transform.localScale = Vector3.one * 0.55f;
            MeshFilter filter = modelObject.AddComponent<MeshFilter>();
            filter.sharedMesh = modelMesh;
            MeshRenderer renderer = modelObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterials = modelMaterials;
            ConfigureInductionRenderer(renderer);
            return true;
        }

        private void ConfigureProchargerPart(GameObject partRoot)
        {
            ConfigureInductionPart(partRoot, ProchargerPartId);
        }

        private void ConfigureInductionPart(GameObject partRoot, string partId)
        {
            if (partRoot == null) throw new ArgumentNullException("partRoot");
            PartScript partScript = partRoot.GetComponent<PartScript>();
            if (partScript == null) partScript = partRoot.GetComponentInChildren<PartScript>(true);
            if (partScript == null) throw new InvalidOperationException("The stock turbo_2 prefab has no PartScript to preserve the game mount lifecycle.");

            partScript.SetID(partId);
            partScript.SetTunedID(String.Empty);
            InductionMode mode = ModeForInductionPartId(partId);
            if (mode == InductionMode.Procharger
                && !TryAttachInductionVisual(partRoot, partScript.transform, false, mode))
                Logger.LogWarning("The P-1X mesh could not be attached; the shop item will keep the stock turbo_2 host visual.");
        }

        private void ConfigureMountedProchargerPart(PartScript partScript)
        {
            ConfigureMountedInductionPart(partScript, ProchargerPartId);
        }

        private void ConfigureMountedInductionPart(PartScript partScript, string partId)
        {
            if (partScript == null) return;
            InductionMode mode = ModeForInductionPartId(partId);
            partScript.gameObject.layer = PartSelectionLayer;
            SetPartField(partScript, "unmounted", false);
            SetPartField(partScript, "canBeUnmount", true);
            SetPartField(partScript, "canUnmountSingle", true);
            SetPartField(partScript, "canMountUnmountOnlyOnCarLoader", false);
            SetPartField(partScript, "ForcePartGroup", -1);
            CaptureOriginalPartColliders(partScript);
            Collider[] colliders = partScript.GetComponents<Collider>();
            for (int i = 0; i < colliders.Length; i++)
                if (colliders[i] != null) colliders[i].enabled = true;
            int partKey = partScript.GetInstanceID();
            InductionMode previousMode;
            Transform existingVisual = partScript.transform.Find(InstalledInductionVisualName);
            if (existingVisual != null && mountedVisualModes.TryGetValue(partKey, out previousMode) && previousMode != mode)
                RestoreMountedProchargerPart(partScript);
            partScript.SetTunedID(partId);
            mountedProchargerParts.Add(partScript);
            if (mode == InductionMode.Procharger
                && !TryAttachInductionVisual(partScript.gameObject, partScript.transform, true, mode))
                Logger.LogWarning("The P-1X mount uses the stock host visual because the custom mesh could not be attached.");
            else if (mode == InductionMode.Procharger)
                mountedVisualModes[partKey] = mode;
            Transform mountedVisual = partScript.transform.Find(InstalledInductionVisualName);
            if (mode == InductionMode.Procharger && IsUniversalMountId(partScript.GetID()) && mountedVisual != null)
            {
                EnsureProchargerMountBolts(partScript, mountedVisual);
                SetPartField(partScript, "canBeUnmount", true);
                SetPartField(partScript, "canUnmountSingle", true);
                SetPartField(partScript, "canMountUnmountOnlyOnCarLoader", false);
                AddUnmountVisibilityTargets(partScript, mountedVisual);
            }
            if (mountedVisual != null) UpdateMountedInductionSelectionCollider(partScript, mountedVisual);
        }

        private void RestoreMountedProchargerPart(PartScript partScript)
        {
            if (partScript == null) return;
            mountedProchargerParts.Remove(partScript);
            int stateKey = partScript.GetInstanceID();
            mountedVisualModes.Remove(stateKey);
            Transform visual = partScript.transform.Find(InstalledInductionVisualName);
            if (visual != null)
            {
                RemoveUnmountVisibilityTargets(partScript, visual);
                visual.gameObject.SetActive(false);
                visual.SetParent(null, false);
                visual.gameObject.name = InstalledInductionVisualName + " Removed";
                UnityEngine.Object.Destroy(visual.gameObject);
            }

            if (IsUniversalMountId(partScript.GetID()))
            {
                RemoveProchargerMountFasteners(partScript);
                SetPartField(partScript, "oneClickUnmount", true);
                SetPartField(partScript, "MountObjects", new MountObject[0]);
            }

            List<ProchargerRendererState> states;
            if (prochargerRendererStates.TryGetValue(stateKey, out states))
            {
                for (int i = 0; i < states.Count; i++)
                    if (states[i].renderer != null) states[i].renderer.enabled = states[i].enabled;
                prochargerRendererStates.Remove(stateKey);
            }
            ResetMountedInductionSelectionCollider(partScript);
            if (IsUniversalMountId(partScript.GetID()))
            {
                armedUniversalMounts.Remove(stateKey);
                SetUniversalMountSelectable(partScript, false);
            }
            RefreshPartHighlight(partScript);
        }

        private static void RefreshPartHighlight(PartScript part)
        {
            // CMS may have cached the empty anchor when it highlighted it for
            // installation. Rescan the renderer hierarchy on the next native hover.
            HighlightingSystem.Highlighter highlighter = ReadComponentReference<HighlightingSystem.Highlighter>(part, "ho");
            if (highlighter != null) highlighter.ReinitMaterials();
        }

        private void UpdateMountedInductionSelectionCollider(PartScript partScript, Transform visual)
        {
            if (partScript == null || visual == null) return;
            int partKey = partScript.GetInstanceID();
            CaptureOriginalPartColliders(partScript);

            MeshCollider meshCollider;
            Mesh collisionMesh;
            if (!mountedSelectionMeshColliders.TryGetValue(partKey, out meshCollider) || meshCollider == null)
            {
                meshCollider = partScript.gameObject.AddComponent<MeshCollider>();
                meshCollider.convex = false;
                mountedSelectionMeshColliders[partKey] = meshCollider;
            }
            if (!mountedSelectionCollisionMeshes.TryGetValue(partKey, out collisionMesh) || collisionMesh == null)
            {
                collisionMesh = CreateSelectionCollisionMesh(visual, partScript.transform);
                if (collisionMesh != null) mountedSelectionCollisionMeshes[partKey] = collisionMesh;
            }

            // The native turbo prefab can carry colliders on child objects too.
            // Disable every inherited collider while the P-1X triangle mesh is
            // active, or the stock shapes leave a hover halo around the kit.
            Collider[] partColliders = partScript.GetComponentsInChildren<Collider>(true);
            if (collisionMesh != null)
            {
                meshCollider.sharedMesh = null;
                meshCollider.sharedMesh = collisionMesh;
                meshCollider.enabled = true;
                for (int i = 0; i < partColliders.Length; i++)
                    if (partColliders[i] != null && partColliders[i] != meshCollider
                        && !IsMountObjectCollider(partColliders[i])) partColliders[i].enabled = false;
            }
            else
            {
                Logger.LogWarning("Exact P-1X selection mesh could not be built; using a tight renderer-bounds fallback.");
                BoxCollider fallback;
                if (!mountedSelectionHitboxes.TryGetValue(partKey, out fallback) || fallback == null)
                {
                    fallback = partScript.gameObject.AddComponent<BoxCollider>();
                    mountedSelectionHitboxes[partKey] = fallback;
                }
                Bounds bounds;
                if (TryGetLocalRendererBounds(visual.GetComponentsInChildren<Renderer>(true), partScript.transform, out bounds))
                {
                    fallback.center = bounds.center;
                    fallback.size = Vector3.Max(bounds.size * 1.02f, new Vector3(0.02f, 0.02f, 0.02f));
                }
                fallback.enabled = true;
                for (int i = 0; i < partColliders.Length; i++)
                    if (partColliders[i] != null && partColliders[i] != fallback
                        && !IsMountObjectCollider(partColliders[i])) partColliders[i].enabled = false;
            }
            partScript.gameObject.layer = PartSelectionLayer;
        }

        private void CaptureOriginalPartColliders(PartScript partScript)
        {
            if (partScript == null) return;
            int partKey = partScript.GetInstanceID();
            if (mountedOriginalColliderStates.ContainsKey(partKey)) return;
            Collider[] colliders = partScript.GetComponentsInChildren<Collider>(true);
            List<PartColliderState> states = new List<PartColliderState>(colliders.Length);
            for (int i = 0; i < colliders.Length; i++)
                if (colliders[i] != null) states.Add(new PartColliderState(colliders[i]));
            mountedOriginalColliderStates[partKey] = states;
        }

        private static Mesh CreateSelectionCollisionMesh(Transform visual, Transform partRoot)
        {
            if (visual == null || partRoot == null) return null;
            MeshFilter filter = visual.GetComponent<MeshFilter>();
            Mesh source = filter == null ? null : filter.sharedMesh;
            if (source == null) return null;
            Vector3[] vertices = source.vertices;
            Matrix4x4 modelToPart = partRoot.worldToLocalMatrix * visual.localToWorldMatrix;
            for (int i = 0; i < vertices.Length; i++) vertices[i] = modelToPart.MultiplyPoint3x4(vertices[i]);
            Mesh result = new Mesh();
            result.name = "CMS18 ProCharger Selection Mesh";
            result.hideFlags = HideFlags.DontSave;
            result.vertices = vertices;
            result.triangles = source.triangles;
            result.RecalculateBounds();
            return result;
        }

        private void ResetMountedInductionSelectionCollider(PartScript partScript)
        {
            if (partScript == null) return;
            int partKey = partScript.GetInstanceID();
            MeshCollider meshCollider;
            if (mountedSelectionMeshColliders.TryGetValue(partKey, out meshCollider))
            {
                if (meshCollider != null)
                {
                    meshCollider.sharedMesh = null;
                    UnityEngine.Object.Destroy(meshCollider);
                }
                mountedSelectionMeshColliders.Remove(partKey);
            }
            Mesh collisionMesh;
            if (mountedSelectionCollisionMeshes.TryGetValue(partKey, out collisionMesh))
            {
                if (collisionMesh != null) UnityEngine.Object.Destroy(collisionMesh);
                mountedSelectionCollisionMeshes.Remove(partKey);
            }
            BoxCollider selectionCollider;
            if (mountedSelectionHitboxes.TryGetValue(partKey, out selectionCollider))
            {
                if (selectionCollider != null) UnityEngine.Object.Destroy(selectionCollider);
                mountedSelectionHitboxes.Remove(partKey);
            }
            List<PartColliderState> states;
            if (mountedOriginalColliderStates.TryGetValue(partKey, out states))
            {
                for (int i = 0; i < states.Count; i++)
                    if (states[i].collider != null) states[i].collider.enabled = states[i].enabled;
                mountedOriginalColliderStates.Remove(partKey);
            }
            if (IsUniversalMountId(partScript.GetID()) && partScript.GetComponent<Collider>() == null)
            {
                BoxCollider hitbox = partScript.gameObject.AddComponent<BoxCollider>();
                hitbox.center = Vector3.zero;
                hitbox.size = new Vector3(0.28f, 0.18f, 0.18f);
                hitbox.enabled = true;
            }
        }

        private void RefreshMountedProchargerVisuals()
        {
            List<PartScript> stale = new List<PartScript>();
            foreach (PartScript partScript in mountedProchargerParts)
            {
                if (partScript == null)
                {
                    stale.Add(partScript);
                    continue;
                }
                Transform visual = partScript.transform.Find(InstalledInductionVisualName);
                if (visual == null) continue;
                // CMS marks a replacement as "unmounted" while it is being chosen
                // from Parts Overview. Keep its custom mesh visible during that step;
                // the parent GameObject still controls visibility when it leaves the car.
                if (!visual.gameObject.activeSelf) visual.gameObject.SetActive(true);
            }
            for (int i = 0; i < stale.Count; i++) mountedProchargerParts.Remove(stale[i]);
        }

        private static void AddUnmountVisibilityTarget(PartScript partScript, GameObject target)
        {
            FieldInfo field = typeof(PartScript).GetField("hideWhenUnmontingMounting", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (System.Object.ReferenceEquals(field, null) || partScript == null || target == null) return;
            GameObject[] current = field.GetValue(partScript) as GameObject[];
            if (current != null)
                for (int i = 0; i < current.Length; i++)
                    if (current[i] == target) return;
            int count = current == null ? 0 : current.Length;
            GameObject[] updated = new GameObject[count + 1];
            if (count > 0) Array.Copy(current, updated, count);
            updated[count] = target;
            field.SetValue(partScript, updated);
        }

        private static void AddUnmountVisibilityTargets(PartScript partScript, Transform visualRoot)
        {
            if (partScript == null || visualRoot == null) return;
            Renderer[] renderers = visualRoot.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer != null && !IsMountObjectRenderer(renderer))
                    AddUnmountVisibilityTarget(partScript, renderer.gameObject);
            }
        }

        private MountObject[] EnsureProchargerMountBolts(PartScript part, Transform visual)
        {
            MountObject[] bolts = new MountObject[ProchargerMountBoltSeats.Length];
            for (int i = 0; i < bolts.Length; i++)
            {
                string name = ProchargerMountFastenerPrefix + i;
                Transform existing = visual.Find(name);
                if (existing != null)
                {
                    bolts[i] = existing.GetComponent<MountObject>();
                    continue;
                }

                float angle = (30.0f + 90.0f * i) * Mathf.Deg2Rad;
                GameObject bolt = new GameObject(name);
                bolt.layer = MountObjectSelectionLayer;
                bolt.transform.SetParent(visual, false);
                bolt.transform.localPosition = new Vector3(ProchargerMountBoltSeats[i] + 0.002f,
                    -0.038f + Mathf.Cos(angle) * 0.108f, -0.017f + Mathf.Sin(angle) * 0.108f);
                // Stock MountObject backs out along its negative local X axis.
                bolt.transform.localRotation = Quaternion.Euler(0.0f, 180.0f, 0.0f);
                BoxCollider hitbox = bolt.AddComponent<BoxCollider>();
                hitbox.center = new Vector3(-0.004f, 0.0f, 0.0f);
                // Awake caches the collider's X size as the world-space travel.
                // Set that from the physical head size, then widen only the hitbox.
                float travel = visual.TransformVector(Vector3.right * 0.016f).magnitude;
                hitbox.size = new Vector3(travel, 0.032f, 0.032f);
                if (prochargerMountBoltMesh == null) prochargerMountBoltMesh = CreateProchargerMountBoltMesh();
                bolt.AddComponent<MeshFilter>().sharedMesh = prochargerMountBoltMesh;
                MeshRenderer renderer = bolt.AddComponent<MeshRenderer>();
                renderer.sharedMaterial = FindProchargerModelMaterial("P1X_Fastener") ?? GetProchargerDriveMaterial(false);
                ConfigureInductionRenderer(renderer);
                MountObject fastener = bolt.AddComponent<MountObject>();
                hitbox.size = new Vector3(0.016f, 0.032f, 0.032f);
                fastener.SetFullMountPosition();
                bolts[i] = fastener;
            }
            SetPartField(part, "MountObjects", bolts);
            return bolts;
        }

        private static Mesh CreateProchargerMountBoltMesh()
        {
            const int sides = 6;
            Vector3[] rings = new Vector3[sides * 3];
            for (int ring = 0; ring < 3; ring++)
            {
                float x = ring == 0 ? 0.002f : ring == 1 ? -0.005f : -0.008f;
                float radius = ring == 2 ? 0.0085f : 0.011f;
                for (int i = 0; i < sides; i++)
                {
                    float angle = i * Mathf.PI * 2.0f / sides;
                    rings[ring * sides + i] = new Vector3(x, Mathf.Cos(angle) * radius, Mathf.Sin(angle) * radius);
                }
            }

            List<Vector3> vertices = new List<Vector3>();
            for (int i = 0; i < sides; i++)
            {
                int next = (i + 1) % sides;
                for (int ring = 0; ring < 2; ring++)
                {
                    int a = ring * sides + i;
                    int b = ring * sides + next;
                    int c = (ring + 1) * sides + next;
                    int d = (ring + 1) * sides + i;
                    vertices.Add(rings[a]); vertices.Add(rings[d]); vertices.Add(rings[c]);
                    vertices.Add(rings[a]); vertices.Add(rings[c]); vertices.Add(rings[b]);
                }
                vertices.Add(new Vector3(-0.008f, 0.0f, 0.0f));
                vertices.Add(rings[2 * sides + next]);
                vertices.Add(rings[2 * sides + i]);
            }
            int[] triangles = new int[vertices.Count];
            for (int i = 0; i < triangles.Length; i++) triangles[i] = i;
            Mesh mesh = new Mesh();
            mesh.name = "P-1X chamfered mounting bolt";
            mesh.vertices = vertices.ToArray();
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            return mesh;
        }

        private bool BeginProchargerBoltRemoval(PartScript part)
        {
            if (part == null || unscrewingProcharger != null)
            {
                status = "A ProCharger removal is already in progress.";
                return false;
            }
            Transform visual = part.transform.Find(InstalledInductionVisualName);
            GameScript game = GameScript.Get();
            if (visual == null || game == null)
            {
                status = "The ProCharger mounting bolts are unavailable.";
                return false;
            }
            MountObject[] bolts = EnsureProchargerMountBolts(part, visual);
            if (Array.Exists(bolts, bolt => bolt == null))
            {
                status = "The ProCharger mounting bolts are unavailable.";
                return false;
            }

            SetPartField(part, "mountMode", false);
            CameraManager camera = CameraManager.Get();
            if (camera != null) camera.SaveZoom();
            unscrewingProcharger = part;
            game.SelectToUnMount(part, bolts);
            foreach (MountObject bolt in bolts)
            {
                bolt.gameObject.layer = MountObjectSelectionLayer;
                bolt.SetCanBeUnmount(true);
            }
            part.EnableGamepadMountObject(true);
            Logger.LogInfo("Opened CMS bolt removal for the four P-1X flange bolts.");
            return true;
        }

        private void ResetProchargerBoltRemoval()
        {
            PartScript part = unscrewingProcharger;
            unscrewingProcharger = null;
            if (part == null) return;
            part.EnableGamepadMountObject(false);
            MountObject[] bolts = part.MountObjects;
            if (bolts == null) return;
            foreach (MountObject bolt in bolts)
                if (bolt != null) bolt.SetFullMountPosition();
        }

        private IEnumerator FinishProchargerBoltRemoval(PartScript part)
        {
            GameScript game = GameScript.Get();
            bool canExit = game != null && game.CanExit;
            Transform visual = part.transform.Find(InstalledInductionVisualName);
            Vector3 start = visual == null ? Vector3.zero : visual.position;
            int moveTween = -1;
            MeshRenderer[] renderers = visual == null ? new MeshRenderer[0] : visual.GetComponentsInChildren<MeshRenderer>();
            MaterialPropertyBlock[] original = new MaterialPropertyBlock[renderers.Length];
            MaterialPropertyBlock[] dissolving = new MaterialPropertyBlock[renderers.Length];
            const string dissolveProperty = "_AlphaDissolve";
            bool removed = false;
            if (game != null) game.CanExit = false;
            try
            {
                part.EnableGamepadMountObject(false);
                foreach (MountObject bolt in part.MountObjects)
                    if (bolt != null) bolt.SetFullUnmountPosition();
                Logger.LogInfo("All four P-1X bolts are loose; playing the removal animation.");
                if (visual != null)
                {
                    const float duration = 1.0f;
                    const float dissolveDuration = 0.5f;
                    moveTween = LeanTween.move(visual.gameObject, start + visual.right * 0.15f, duration)
                        .setEase(LeanTweenType.easeSpring).setIgnoreTimeScale(true).id;
                    for (int i = 0; i < renderers.Length; i++)
                    {
                        MeshRenderer renderer = renderers[i];
                        if (!Array.Exists(renderer.sharedMaterials, material => material != null && material.HasProperty(dissolveProperty)))
                            continue;
                        original[i] = new MaterialPropertyBlock();
                        dissolving[i] = new MaterialPropertyBlock();
                        renderer.GetPropertyBlock(original[i]);
                        renderer.GetPropertyBlock(dissolving[i]);
                    }
                    float startedAt = Time.unscaledTime;
                    bool playedTakeoff = false;
                    while (visual != null)
                    {
                        float elapsed = Time.unscaledTime - startedAt;
                        float dissolve = 1.0f - Mathf.Clamp01(elapsed / dissolveDuration);
                        for (int i = 0; i < renderers.Length; i++)
                        {
                            if (renderers[i] == null || dissolving[i] == null) continue;
                            dissolving[i].SetFloat(dissolveProperty, dissolve);
                            renderers[i].SetPropertyBlock(dissolving[i]);
                        }
                        if (!playedTakeoff && elapsed >= dissolveDuration)
                        {
                            SoundManager sound = SoundManager.Get();
                            if (sound != null) sound.PlaySFX("PartTakeOff");
                            playedTakeoff = true;
                        }
                        if (elapsed >= duration) break;
                        yield return null;
                    }
                }

                if (part != null)
                {
                    try { removed = RemoveUniversalProcharger(part); }
                    catch (Exception exception)
                    {
                        status = "The ProCharger removal could not be completed.";
                        Logger.LogWarning(status + " " + exception);
                    }
                }
                if (!removed && part != null) ShowProchargerPopup(status);
            }
            finally
            {
                if (moveTween != -1) LeanTween.cancel(moveTween);
                if (!removed && InstalledUniversalProchargerId(part).Length != 0)
                {
                    if (visual != null) visual.position = start;
                    for (int i = 0; i < renderers.Length; i++)
                        if (renderers[i] != null && original[i] != null) renderers[i].SetPropertyBlock(original[i]);
                    ResetProchargerBoltRemoval();
                }
                else unscrewingProcharger = null;
                prochargerRemovalAnimating = false;
                if (game != null) game.CanExit = canExit;
                GameMode mode = GameMode.Get();
                if (mode != null && mode.GetCurrentMode() == gameMode.PartUnMount)
                    mode.SetCurrentMode(gameMode.PartSelect);
                Cursor3D cursor = Cursor3D.Get();
                if (cursor != null) cursor.ResetButton();
            }
        }

        private static bool ProchargerBoltUpdatePrefix(PartScript __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            // Keep the stock PartScript.Hide coroutine from racing the mod's
            // inventory return. Each bolt still runs its own stock update.
            return plugin == null || __instance == null || plugin.unscrewingProcharger != __instance;
        }

        private void RemoveProchargerMountFasteners(PartScript part)
        {
            if (part == null) return;
            Transform[] descendants = part.GetComponentsInChildren<Transform>(true);
            for (int i = descendants.Length - 1; i >= 0; i--)
            {
                Transform fastener = descendants[i];
                if (fastener == null || fastener == part.transform
                    || !fastener.name.StartsWith(ProchargerMountFastenerPrefix, StringComparison.Ordinal)) continue;
                Renderer[] renderers = fastener.GetComponentsInChildren<Renderer>(true);
                for (int rendererIndex = 0; rendererIndex < renderers.Length; rendererIndex++)
                    if (renderers[rendererIndex] != null)
                        RemoveUnmountVisibilityTarget(part, renderers[rendererIndex].gameObject);
                MountObject mountObject = fastener.GetComponent<MountObject>();
                if (mountObject != null) mountObject.SetCanBeUnmount(false);
                fastener.gameObject.SetActive(false);
                UnityEngine.Object.Destroy(fastener.gameObject);
            }
        }

        private static void RemoveUnmountVisibilityTarget(PartScript partScript, GameObject target)
        {
            FieldInfo field = typeof(PartScript).GetField("hideWhenUnmontingMounting", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (System.Object.ReferenceEquals(field, null) || partScript == null || target == null) return;
            GameObject[] current = field.GetValue(partScript) as GameObject[];
            if (current == null || current.Length == 0) return;
            List<GameObject> updated = new List<GameObject>();
            for (int i = 0; i < current.Length; i++)
                if (current[i] != null && current[i] != target) updated.Add(current[i]);
            field.SetValue(partScript, updated.ToArray());
        }

        private static void RemoveUnmountVisibilityTargets(PartScript partScript, Transform visualRoot)
        {
            if (partScript == null || visualRoot == null) return;
            Renderer[] renderers = visualRoot.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer != null) RemoveUnmountVisibilityTarget(partScript, renderer.gameObject);
            }
        }
        private bool TryAttachInductionVisual(GameObject partRoot, Transform visualAnchor, bool captureRendererState, InductionMode mode)
        {
            if (visualAnchor == null || mode != InductionMode.Procharger) return false;
            Renderer[] stockRenderers = partRoot != null ? partRoot.GetComponentsInChildren<Renderer>(true) : null;
            Transform existingVisual = visualAnchor.Find(InstalledInductionVisualName);
            if (existingVisual != null)
            {
                PartScript existingPartScript = visualAnchor.GetComponent<PartScript>();
                if (existingPartScript != null) AddUnmountVisibilityTargets(existingPartScript, existingVisual);
                return true;
            }
            if (!inductionModelLoadAttempted.Contains(mode))
            {
                inductionModelLoadAttempted.Add(mode);
                BuildInductionModelAsset(mode, ProchargerModelResource, "P-1X Style ProCharger");
            }

            Mesh mesh;
            Material[] materials;
            if (!inductionModelMeshes.TryGetValue(mode, out mesh) || mesh == null
                || !inductionModelMaterials.TryGetValue(mode, out materials) || materials == null) return false;

            Bounds localBounds;
            bool hasBounds = TryGetLocalRendererBounds(stockRenderers, visualAnchor, out localBounds);
            Quaternion modelRotation = Quaternion.identity;
            float scale = ProchargerModelUnitScale;

            GameObject visual = new GameObject(InstalledInductionVisualName);
            visual.transform.SetParent(visualAnchor, false);
            visual.layer = partRoot.layer;
            visual.transform.localRotation = modelRotation;
            visual.transform.localScale = Vector3.one * scale;
            visual.transform.localPosition = (hasBounds ? localBounds.center : Vector3.zero)
                - modelRotation * (mesh.bounds.center * scale);
            MeshFilter filter = visual.AddComponent<MeshFilter>();
            filter.sharedMesh = mesh;
            MeshRenderer renderer = visual.AddComponent<MeshRenderer>();
            renderer.sharedMaterials = materials;
            ConfigureInductionRenderer(renderer);
            PartScript visualPartScript = visualAnchor.GetComponent<PartScript>();
            if (captureRendererState && visualPartScript != null)
            {
                int stateKey = visualPartScript.GetInstanceID();
                if (!prochargerRendererStates.ContainsKey(stateKey))
                {
                    List<ProchargerRendererState> states = new List<ProchargerRendererState>();
                    for (int i = 0; i < stockRenderers.Length; i++)
                        if (stockRenderers[i] != null && stockRenderers[i].GetComponent<MountObject>() == null)
                            states.Add(new ProchargerRendererState(stockRenderers[i]));
                    prochargerRendererStates[stateKey] = states;
                }
            }
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;

            for (int i = 0; i < stockRenderers.Length; i++)
            {
                if (stockRenderers[i] != null && stockRenderers[i].GetComponent<MountObject>() == null)
                    stockRenderers[i].enabled = false;
            }
            if (captureRendererState && mode == InductionMode.Procharger && visualPartScript != null)
            {
                Transform engineRoot = FindEngineRootTransform(visualAnchor);
                if (engineRoot != null && engineRoot.name.StartsWith("engine_", StringComparison.OrdinalIgnoreCase))
                    AlignProchargerVisualToCrank(visual.transform, engineRoot);
                AddProchargerDriveVisuals(visualPartScript, visual.transform);
            }
            if (visualPartScript != null)
            {
                AddUnmountVisibilityTargets(visualPartScript, visual.transform);
                if (captureRendererState) RefreshPartHighlight(visualPartScript);
            }
            return true;
        }

        private static bool TryGetLocalRendererBounds(Renderer[] renderers, Transform relativeTo, out Bounds localBounds)
        {
            localBounds = new Bounds(Vector3.zero, Vector3.zero);
            if (renderers == null || relativeTo == null) return false;
            bool initialized = false;
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer == null || renderer.bounds.size.sqrMagnitude < 0.000001f) continue;
                Bounds worldBounds = renderer.bounds;
                for (int corner = 0; corner < 8; corner++)
                {
                    Vector3 point = new Vector3(
                        (corner & 1) == 0 ? worldBounds.min.x : worldBounds.max.x,
                        (corner & 2) == 0 ? worldBounds.min.y : worldBounds.max.y,
                        (corner & 4) == 0 ? worldBounds.min.z : worldBounds.max.z);
                    Vector3 localPoint = relativeTo.InverseTransformPoint(point);
                    if (!initialized)
                    {
                        localBounds = new Bounds(localPoint, Vector3.zero);
                        initialized = true;
                    }
                    else
                    {
                        localBounds.Encapsulate(localPoint);
                    }
                }
            }
            return initialized;
        }

        private Material CreateNativeTurboMaterialClone()
        {
            if (registeredShopInventory == null) return null;
            GameObject nativePart = null;
            try
            {
                nativePart = registeredShopInventory.GetGO2(ProchargerBasePartId);
                if (nativePart == null) return null;
                Renderer[] renderers = nativePart.GetComponentsInChildren<Renderer>(true);
                for (int i = 0; i < renderers.Length; i++)
                {
                    if (renderers[i] == null) continue;
                    Material[] sourceMaterials = renderers[i].sharedMaterials;
                    for (int materialIndex = 0; materialIndex < sourceMaterials.Length; materialIndex++)
                    {
                        Material sourceMaterial = sourceMaterials[materialIndex];
                        if (sourceMaterial == null || sourceMaterial.name.IndexOf("Turbocharger_2", StringComparison.OrdinalIgnoreCase) < 0) continue;
                        Material clone = new Material(sourceMaterial);
                        clone.name = "CMS18 Native Turbocharger_2 Compressor Material";
                        return clone;
                    }
                }
                Logger.LogWarning("Could not find the native Turbocharger_2 material; using the P-1X fallback finish.");
            }
            catch (Exception exception)
            {
                Logger.LogWarning("Could not clone the native Turbocharger_2 material; using the P-1X fallback finish. " + exception.Message);
            }
            finally
            {
                if (nativePart != null) UnityEngine.Object.Destroy(nativePart);
            }
            return null;
        }

        private Material CreateNativeTurboMetalFinishClone()
        {
            Material material = CreateNativeTurboMaterialClone();
            if (material == null) return null;
            material.name = "CMS18 Native Turbocharger_2 P-1X Metal Finish";
            // P-1X timing parts have their own UV layout. Keep the native shader,
            // color, metallic and smoothness response, but remove atlas textures
            // whose coordinates are specific to the stock turbo mesh.
            string[] textureProperties = {
                "_MainTex", "_BaseMap", "_BumpMap", "_MetallicGlossMap", "_SpecGlossMap",
                "_OcclusionMap", "_EmissionMap", "_DetailAlbedoMap", "_DetailNormalMap", "_ParallaxMap"
            };
            for (int i = 0; i < textureProperties.Length; i++)
                if (material.HasProperty(textureProperties[i])) material.SetTexture(textureProperties[i], null);
            material.mainTexture = null;
            ConfigureOpaqueStandardMaterial(material);
            return material;
        }

        private void RefreshProchargerNativeTurboMaterial()
        {
            if (registeredShopInventory == null) return;
            if (prochargerBracketMaterial == null
                || !String.Equals(prochargerBracketMaterial.name, "CMS18 Native Turbocharger_2 P-1X Bracket Finish", StringComparison.Ordinal))
            {
                Material nativeBracketFinish = CreateNativeTurboMetalFinishClone();
                if (nativeBracketFinish != null)
                {
                    nativeBracketFinish.name = "CMS18 Native Turbocharger_2 P-1X Bracket Finish";
                    Material previousBracketMaterial = prochargerBracketMaterial;
                    prochargerBracketMaterial = nativeBracketFinish;
                    if (previousBracketMaterial != null)
                    {
                        if (visualRoot != null)
                            ReplaceModelRendererMaterial(visualRoot.GetComponentsInChildren<Renderer>(true), previousBracketMaterial, nativeBracketFinish);
                        foreach (PartScript part in mountedProchargerParts)
                            if (part != null)
                                ReplaceModelRendererMaterial(part.GetComponentsInChildren<Renderer>(true), previousBracketMaterial, nativeBracketFinish);
                        UnityEngine.Object.Destroy(previousBracketMaterial);
                    }
                    Logger.LogInfo("Updated generated P-1X brackets and tensioner to the native Turbocharger_2 metal finish.");
                }
            }
            if (nativeTurboMaterialAppliedToProcharger) return;
            Material[] modelMaterials;
            if (!inductionModelMaterials.TryGetValue(InductionMode.Procharger, out modelMaterials)
                || modelMaterials == null) return;

            int materialIndex = -1;
            for (int i = 0; i < modelMaterials.Length; i++)
            {
                if (modelMaterials[i] == null) continue;
                if (String.Equals(modelMaterials[i].name, "CMS18 Native Turbocharger_2 Compressor Material", StringComparison.Ordinal))
                {
                    nativeTurboMaterialAppliedToProcharger = true;
                    return;
                }
                if (modelMaterials[i].name.EndsWith(" Turbocharger_2", StringComparison.Ordinal))
                    materialIndex = i;
            }
            if (materialIndex < 0) return;

            Material nativeMaterial = CreateNativeTurboMaterialClone();
            if (nativeMaterial == null) return;
            Material previousMaterial = modelMaterials[materialIndex];
            modelMaterials[materialIndex] = nativeMaterial;
            inductionModelMaterials[InductionMode.Procharger] = modelMaterials;

            if (visualRoot != null)
                ReplaceModelRendererMaterial(visualRoot.GetComponentsInChildren<Renderer>(true), previousMaterial, nativeMaterial);
            foreach (PartScript part in mountedProchargerParts)
                if (part != null)
                    ReplaceModelRendererMaterial(part.GetComponentsInChildren<Renderer>(true), previousMaterial, nativeMaterial);

            nativeTurboMaterialAppliedToProcharger = true;
            if (previousMaterial != null) UnityEngine.Object.Destroy(previousMaterial);
            Logger.LogInfo("Replaced the early P-1X fallback finish with the native CMS Turbocharger_2 material after shop inventory became available.");
        }

        private static void ReplaceModelRendererMaterial(Renderer[] renderers, Material previousMaterial, Material replacement)
        {
            if (renderers == null || previousMaterial == null || replacement == null) return;
            for (int rendererIndex = 0; rendererIndex < renderers.Length; rendererIndex++)
            {
                Renderer renderer = renderers[rendererIndex];
                if (renderer == null) continue;
                Material[] shared = renderer.sharedMaterials;
                bool changed = false;
                for (int materialIndex = 0; materialIndex < shared.Length; materialIndex++)
                {
                    if (!System.Object.ReferenceEquals(shared[materialIndex], previousMaterial)) continue;
                    shared[materialIndex] = replacement;
                    changed = true;
                }
                if (changed) renderer.sharedMaterials = shared;
            }
        }

        private void BuildInductionModelAsset(InductionMode mode, string resourceName, string modelName)
        {
            Stream stream = null;
            Mesh mesh = null;
            List<Material> materials = new List<Material>();
            try
            {
                stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName);
                if (stream == null)
                {
                    Logger.LogWarning("Embedded " + modelName + " OBJ was not found; using the procedural preview.");
                    return;
                }

                List<Vector3> sourcePositions = new List<Vector3>();
                List<Vector3> sourceNormals = new List<Vector3>();
                List<Vector2> sourceTexCoords = new List<Vector2>();
                List<Vector3> vertices = new List<Vector3>();
                List<Vector3> normals = new List<Vector3>();
                List<Vector2> texCoords = new List<Vector2>();
                List<string> materialNames = new List<string>();
                List<List<int>> submeshTriangles = new List<List<int>>();
                Dictionary<string, int> materialSlots = new Dictionary<string, int>(StringComparer.Ordinal);

                int materialSlot = AddMaterialSlot("Steel", materialSlots, materialNames, submeshTriangles);
                bool completeNormals = true;
                using (StreamReader reader = new StreamReader(stream))
                {
                    stream = null;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        line = line.Trim();
                        if (line.Length == 0 || line[0] == '#') continue;
                        string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length == 0) continue;

                        if (parts[0] == "v" && parts.Length >= 4)
                        {
                            sourcePositions.Add(new Vector3(ParseObjFloat(parts[1]), ParseObjFloat(parts[2]), ParseObjFloat(parts[3])));
                        }
                        else if (parts[0] == "vn" && parts.Length >= 4)
                        {
                            sourceNormals.Add(new Vector3(ParseObjFloat(parts[1]), ParseObjFloat(parts[2]), ParseObjFloat(parts[3])));
                        }
                        else if (parts[0] == "vt" && parts.Length >= 3)
                        {
                            sourceTexCoords.Add(new Vector2(ParseObjFloat(parts[1]), ParseObjFloat(parts[2])));
                        }
                        else if (parts[0] == "usemtl" && parts.Length >= 2)
                        {
                            materialSlot = AddMaterialSlot(parts[1], materialSlots, materialNames, submeshTriangles);
                        }
                        else if (parts[0] == "f" && parts.Length >= 4)
                        {
                            List<ObjCorner> face = new List<ObjCorner>();
                            bool validFace = true;
                            for (int i = 1; i < parts.Length; i++)
                            {
                                ObjCorner corner;
                                if (!TryParseObjCorner(parts[i], sourcePositions.Count, sourceTexCoords.Count, sourceNormals.Count, out corner))
                                {
                                    validFace = false;
                                    break;
                                }
                                face.Add(corner);
                            }
                            if (!validFace || face.Count < 3) continue;

                            for (int triangle = 1; triangle < face.Count - 1; triangle++)
                            {
                                AppendObjCorner(face[0], sourcePositions, sourceTexCoords, sourceNormals, vertices, texCoords, normals, submeshTriangles[materialSlot], ref completeNormals);
                                AppendObjCorner(face[triangle], sourcePositions, sourceTexCoords, sourceNormals, vertices, texCoords, normals, submeshTriangles[materialSlot], ref completeNormals);
                                AppendObjCorner(face[triangle + 1], sourcePositions, sourceTexCoords, sourceNormals, vertices, texCoords, normals, submeshTriangles[materialSlot], ref completeNormals);
                            }
                        }
                    }
                }

                if (vertices.Count == 0)
                {
                    Logger.LogWarning("Embedded " + modelName + " OBJ had no usable faces; using the procedural preview.");
                    return;
                }

                mesh = new Mesh();
                mesh.name = "CMS18 " + modelName + " Add-On";
                mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                mesh.vertices = vertices.ToArray();
                mesh.uv = texCoords.ToArray();
                if (completeNormals) mesh.normals = normals.ToArray();
                else mesh.RecalculateNormals();
                mesh.subMeshCount = materialNames.Count;
                for (int i = 0; i < materialNames.Count; i++) mesh.SetTriangles(submeshTriangles[i].ToArray(), i);
                mesh.RecalculateBounds();

                Shader shader = Shader.Find("Standard");
                if (shader == null) shader = Shader.Find("Legacy Shaders/Diffuse");
                if (shader == null)
                {
                    Logger.LogWarning("No supported Unity shader was found for the " + modelName + " model.");
                    UnityEngine.Object.Destroy(mesh);
                    return;
                }

                for (int i = 0; i < materialNames.Count; i++)
                {
                    if (String.Equals(materialNames[i], "Turbocharger_2", StringComparison.Ordinal))
                    {
                        Material nativeMaterial = CreateNativeTurboMaterialClone();
                        if (nativeMaterial != null)
                        {
                            materials.Add(nativeMaterial);
                            if (mode == InductionMode.Procharger)
                                nativeTurboMaterialAppliedToProcharger = true;
                            Logger.LogInfo("Applied the native CMS Turbocharger_2 material to the ProCharger compressor geometry.");
                            continue;
                        }
                    }
                    Material material = new Material(shader);
                    material.name = "CMS18 " + modelName + " " + materialNames[i];
                    material.color = ObjMaterialColor(materialNames[i]);
                    if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", ObjMaterialGlossiness(materialNames[i]));
                    if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", ObjMaterialMetallic(materialNames[i]));
                    ConfigureOpaqueStandardMaterial(material);
                    materials.Add(material);
                }

                inductionModelMeshes[mode] = mesh;
                inductionModelMaterials[mode] = materials.ToArray();
            }
            catch (Exception exception)
            {
                if (mesh != null) UnityEngine.Object.Destroy(mesh);
                for (int i = 0; i < materials.Count; i++) if (materials[i] != null) UnityEngine.Object.Destroy(materials[i]);
                Logger.LogWarning("Could not load the " + modelName + " preview; using the procedural model. " + exception.Message);
            }
            finally
            {
                if (stream != null) stream.Dispose();
            }
        }

        private static int AddMaterialSlot(string name, Dictionary<string, int> slots, List<string> names, List<List<int>> triangles)
        {
            int slot;
            if (slots.TryGetValue(name, out slot)) return slot;
            slot = names.Count;
            slots.Add(name, slot);
            names.Add(name);
            triangles.Add(new List<int>());
            return slot;
        }

        private static float ParseObjFloat(string value)
        {
            return Single.Parse(value, CultureInfo.InvariantCulture);
        }

        private static int ResolveObjIndex(string value, int count)
        {
            if (String.IsNullOrEmpty(value)) return -1;
            int index = Int32.Parse(value, CultureInfo.InvariantCulture);
            return index > 0 ? index - 1 : count + index;
        }

        private static bool TryParseObjCorner(string value, int positionCount, int texCoordCount, int normalCount, out ObjCorner corner)
        {
            corner = new ObjCorner();
            string[] indices = value.Split('/');
            if (indices.Length == 0) return false;
            corner.position = ResolveObjIndex(indices[0], positionCount);
            corner.texCoord = indices.Length > 1 ? ResolveObjIndex(indices[1], texCoordCount) : -1;
            corner.normal = indices.Length > 2 ? ResolveObjIndex(indices[2], normalCount) : -1;
            return corner.position >= 0 && corner.position < positionCount
                && (corner.texCoord < 0 || corner.texCoord < texCoordCount)
                && (corner.normal < 0 || corner.normal < normalCount);
        }

        private static void AppendObjCorner(ObjCorner corner, List<Vector3> sourcePositions, List<Vector2> sourceTexCoords, List<Vector3> sourceNormals, List<Vector3> vertices, List<Vector2> texCoords, List<Vector3> normals, List<int> triangles, ref bool completeNormals)
        {
            vertices.Add(sourcePositions[corner.position]);
            texCoords.Add(corner.texCoord >= 0 ? sourceTexCoords[corner.texCoord] : Vector2.zero);
            if (corner.normal >= 0) normals.Add(sourceNormals[corner.normal]);
            else
            {
                normals.Add(Vector3.zero);
                completeNormals = false;
            }
            triangles.Add(vertices.Count - 1);
        }

        private static Color ObjMaterialColor(string name)
        {
            if (name == "Turbocharger_2") return new Color(0.68f, 0.68f, 0.66f, 1.0f);
            if (name == "P1X_Pulley") return new Color(0.17f, 0.18f, 0.19f, 1.0f);
            if (name == "P1X_Fastener") return new Color(0.46f, 0.48f, 0.49f, 1.0f);
            if (name == "Charge_pipe_blue") return new Color(0.300f, 0.340f, 0.365f, 1.0f);
            if (name == "Brass_fasteners") return new Color(0.390f, 0.285f, 0.155f, 1.0f);
            if (name == "Cast_iron_hot_side") return new Color(0.190f, 0.180f, 0.160f, 1.0f);
            if (name == "Dark_inlet" || name == "Black_belt_rubber" || name == "Dark_gasket") return new Color(0.035f, 0.040f, 0.042f, 1.0f);
            if (name == "Cast_aluminum") return new Color(0.630f, 0.640f, 0.640f, 1.0f);
            if (name == "Machined_aluminum") return new Color(0.740f, 0.750f, 0.750f, 1.0f);
            if (name == "Bright_cast_compressor_aluminum") return new Color(0.800f, 0.810f, 0.810f, 1.0f);
            if (name == "Steel") return new Color(0.600f, 0.610f, 0.615f, 1.0f);
            return new Color(0.485f, 0.495f, 0.490f, 1.0f);
        }

        private static float ObjMaterialGlossiness(string name)
        {
            if (name == "Turbocharger_2") return 0.73f;
            if (name == "P1X_Pulley") return 0.61f;
            if (name == "P1X_Fastener") return 0.66f;
            if (name == "Black_belt_rubber" || name == "Dark_gasket") return 0.20f;
            if (name == "Cast_iron_hot_side") return 0.34f;
            if (name == "Cast_aluminum") return 0.53f;
            if (name == "Bright_cast_compressor_aluminum") return 0.96f;
            if (name == "Dark_inlet") return 0.32f;
            if (name == "Charge_pipe_blue") return 0.66f;
            if (name == "Machined_aluminum") return 0.77f;
            if (name == "Steel") return 0.64f;
            if (name == "Brass_fasteners") return 0.64f;
            return 0.50f;
        }

        private static float ObjMaterialMetallic(string name)
        {
            if (name == "Turbocharger_2") return 0.65f;
            if (name == "P1X_Pulley") return 0.62f;
            if (name == "P1X_Fastener") return 0.72f;
            if (name == "Dark_inlet" || name == "Dark_gasket" || name == "Black_belt_rubber") return 0.03f;
            if (name == "Charge_pipe_blue") return 0.52f;
            if (name == "Cast_iron_hot_side") return 0.56f;
            if (name == "Cast_aluminum") return 0.65f;
            if (name == "Bright_cast_compressor_aluminum") return 0.94f;
            if (name == "Steel") return 0.88f;
            if (name == "Brass_fasteners") return 0.78f;
            if (name == "Machined_aluminum") return 0.88f;
            return 0.60f;
        }

        private static void ConfigureInductionRenderer(Renderer renderer)
        {
            if (renderer == null) return;
            renderer.reflectionProbeUsage = UnityEngine.Rendering.ReflectionProbeUsage.BlendProbesAndSkybox;
            renderer.lightProbeUsage = UnityEngine.Rendering.LightProbeUsage.BlendProbes;
            renderer.receiveShadows = true;
        }

        private static void ConfigureOpaqueStandardMaterial(Material material)
        {
            if (material == null) return;
            if (material.HasProperty("_Mode")) material.SetFloat("_Mode", 0.0f);
            if (material.HasProperty("_SrcBlend")) material.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.One);
            if (material.HasProperty("_DstBlend")) material.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.Zero);
            if (material.HasProperty("_ZWrite")) material.SetFloat("_ZWrite", 1.0f);
            if (material.HasProperty("_GlossyReflections")) material.SetFloat("_GlossyReflections", 1.0f);
            if (material.HasProperty("_SpecularHighlights")) material.SetFloat("_SpecularHighlights", 1.0f);
            material.SetOverrideTag("RenderType", "Opaque");
            material.DisableKeyword("_ALPHATEST_ON");
            material.DisableKeyword("_ALPHABLEND_ON");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            material.renderQueue = 2000;
        }

        private void DestroyInductionModelAssets()
        {
            foreach (Mesh mesh in inductionModelMeshes.Values)
            {
                if (mesh != null) UnityEngine.Object.Destroy(mesh);
            }
            inductionModelMeshes.Clear();
            foreach (Material[] materials in inductionModelMaterials.Values)
            {
                for (int i = 0; i < materials.Length; i++)
                    if (materials[i] != null) UnityEngine.Object.Destroy(materials[i]);
            }
            inductionModelMaterials.Clear();
            inductionModelLoadAttempted.Clear();
        }

        private Transform FindVisualParent()
        {
            if (standOccupied)
            {
                try
                {
                    GameScript game = GameScript.Get();
                    List<GameObject> objects = game == null ? null : game.GetObjectsOnEngineStand();
                    if (objects != null)
                    {
                        for (int i = 0; i < objects.Count; i++)
                        {
                            if (objects[i] != null && objects[i].GetComponentInChildren<PartScript>() != null)
                            {
                                return objects[i].transform;
                            }
                        }
                        if (objects.Count > 0 && objects[0] != null) return objects[0].transform;
                    }
                }
                catch { }
            }

            VPVehicleController linkedController;
            CarLoader loader = FindActiveCarLoader(out linkedController);
            if (linkedController != null) activeController = linkedController;
            if (loader != null)
            {
                GameObject engineObject = loader.GetEngine();
                if (engineObject != null) return engineObject.transform;
            }
            return activeController == null ? null : activeController.transform;
        }

        private void RemoveVisual()
        {
            PartScript previewMount = null;
            foreach (BoxCollider hitbox in standPreviewHitboxes)
            {
                if (hitbox == null) continue;
                if (previewMount == null) previewMount = hitbox.GetComponent<PartScript>();
                hitbox.enabled = false;
                UnityEngine.Object.Destroy(hitbox);
            }
            standPreviewHitboxes.Clear();
            foreach (KeyValuePair<int, List<ProchargerRendererState>> entry in standPreviewRendererStates)
            {
                List<ProchargerRendererState> states = entry.Value;
                for (int i = 0; states != null && i < states.Count; i++)
                {
                    Renderer renderer = states[i].renderer;
                    if (renderer != null) renderer.enabled = states[i].enabled;
                }
            }
            standPreviewRendererStates.Clear();
            if (visualRoot != null)
            {
                visualRoot.SetActive(false);
                visualRoot.transform.SetParent(null, false);
                UnityEngine.Object.Destroy(visualRoot);
                visualRoot = null;
            }
            if (previewMount != null) RefreshPartHighlight(previewMount);
            visualMode = InductionMode.Off;
        }

        private float GetUiScale()
        {
            return Mathf.Clamp(Mathf.Min(Screen.width / 1600.0f, Screen.height / 900.0f), 0.75f, 1.0f);
        }

        private Texture2D CreateUiTexture(Color color)
        {
            Texture2D texture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            texture.name = "CMS18 Turbo UI";
            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.filterMode = FilterMode.Point;
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.SetPixel(0, 0, color);
            texture.Apply(false, true);
            uiTextures.Add(texture);
            return texture;
        }

        private Texture2D CreateBoostGaugeFaceTexture()
        {
            const int size = 160;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.name = "CMS18 manifold pressure gauge face";
            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.filterMode = FilterMode.Bilinear;
            texture.wrapMode = TextureWrapMode.Clamp;
            Color[] pixels = new Color[size * size];
            float center = (size - 1) * 0.5f;
            float outerRadius = size * 0.48f;
            float faceRadius = size * 0.425f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x - center;
                    float dy = y - center;
                    float radius = Mathf.Sqrt(dx * dx + dy * dy);
                    Color pixel = new Color(0.0f, 0.0f, 0.0f, 0.0f);
                    if (radius <= faceRadius)
                    {
                        float shade = 1.0f - Mathf.Clamp01(radius / faceRadius) * 0.11f;
                        pixel = new Color(0.035f * shade, 0.043f * shade, 0.051f * shade, 0.98f);
                    }
                    else if (radius <= outerRadius)
                    {
                        float rimShade = 0.38f + 0.22f * (1.0f - Mathf.Clamp01(Mathf.Abs(dy) / outerRadius));
                        pixel = new Color(rimShade, rimShade * 1.02f, rimShade * 1.04f, 0.96f);
                    }
                    pixels[y * size + x] = pixel;
                }
            }
            texture.SetPixels(pixels);
            texture.Apply(false, true);
            uiTextures.Add(texture);
            return texture;
        }

        private GUIStyle CreateUiStyle(GUIStyle source, Texture2D normal, Texture2D hover, Texture2D active, Color textColor, TextAnchor alignment, bool bold)
        {
            GUIStyle style = new GUIStyle(source);
            style.normal.background = normal;
            style.hover.background = hover == null ? normal : hover;
            style.active.background = active == null ? normal : active;
            style.focused.background = normal;
            style.normal.textColor = textColor;
            style.hover.textColor = textColor;
            style.active.textColor = textColor;
            style.focused.textColor = textColor;
            style.alignment = alignment;
            style.fontStyle = bold ? FontStyle.Bold : FontStyle.Normal;
            style.wordWrap = false;
            style.clipping = TextClipping.Clip;
            style.margin = new RectOffset(0, 0, 0, 0);
            return style;
        }

        private void EnsureUiStyles(float scale)
        {
            if (uiPanelStyle == null)
            {
                Color panelColor = new Color(0.055f, 0.064f, 0.074f, 0.94f);
                Color headerColor = new Color(0.115f, 0.132f, 0.149f, 0.98f);
                Color accentColor = new Color(0.86f, 0.39f, 0.15f, 1.0f);
                Color accentHover = new Color(0.98f, 0.50f, 0.21f, 1.0f);
                Color buttonColor = new Color(0.16f, 0.18f, 0.20f, 0.98f);
                Color buttonHover = new Color(0.23f, 0.25f, 0.27f, 1.0f);
                Color selectedColor = new Color(0.36f, 0.19f, 0.11f, 1.0f);
                Color trackColor = new Color(0.10f, 0.12f, 0.14f, 1.0f);
                Color textColor = new Color(0.91f, 0.92f, 0.91f, 1.0f);
                Color mutedColor = new Color(0.68f, 0.71f, 0.72f, 1.0f);

                Texture2D panelTexture = CreateUiTexture(panelColor);
                Texture2D headerTexture = CreateUiTexture(headerColor);
                Texture2D accentTexture = CreateUiTexture(accentColor);
                Texture2D hoverAccentTexture = CreateUiTexture(accentHover);
                Texture2D buttonTexture = CreateUiTexture(buttonColor);
                Texture2D buttonHoverTexture = CreateUiTexture(buttonHover);
                Texture2D selectedTexture = CreateUiTexture(selectedColor);
                Texture2D trackTexture = CreateUiTexture(trackColor);
                Texture2D gaugeTickTexture = CreateUiTexture(new Color(0.72f, 0.76f, 0.78f, 1.0f));
                Texture2D gaugeWarnTexture = CreateUiTexture(new Color(0.91f, 0.61f, 0.16f, 1.0f));
                Texture2D gaugeDangerTexture = CreateUiTexture(new Color(0.88f, 0.19f, 0.12f, 1.0f));

                uiPanelStyle = CreateUiStyle(GUI.skin.box, panelTexture, panelTexture, panelTexture, textColor, TextAnchor.UpperLeft, false);
                uiPanelStyle.padding = new RectOffset(0, 0, 0, 0);
                uiPanelStyle.border = new RectOffset(0, 0, 0, 0);
                uiHeaderBarStyle = CreateUiStyle(GUI.skin.box, headerTexture, headerTexture, headerTexture, textColor, TextAnchor.MiddleLeft, false);
                uiHeaderBarStyle.padding = new RectOffset(0, 0, 0, 0);
                uiHeaderBarStyle.border = new RectOffset(0, 0, 0, 0);
                uiAccentStyle = CreateUiStyle(GUI.skin.box, accentTexture, hoverAccentTexture, accentTexture, textColor, TextAnchor.MiddleLeft, false);
                uiAccentStyle.padding = new RectOffset(0, 0, 0, 0);
                uiAccentStyle.border = new RectOffset(0, 0, 0, 0);
                uiHeaderTextStyle = CreateUiStyle(GUI.skin.label, null, null, null, textColor, TextAnchor.MiddleLeft, true);
                uiBodyTextStyle = CreateUiStyle(GUI.skin.label, null, null, null, textColor, TextAnchor.MiddleLeft, false);
                uiMutedTextStyle = CreateUiStyle(GUI.skin.label, null, null, null, mutedColor, TextAnchor.MiddleLeft, false);
                uiButtonStyle = CreateUiStyle(GUI.skin.button, buttonTexture, buttonHoverTexture, selectedTexture, textColor, TextAnchor.MiddleCenter, false);
                uiSelectedButtonStyle = CreateUiStyle(GUI.skin.button, selectedTexture, accentTexture, accentTexture, textColor, TextAnchor.MiddleCenter, true);

                uiSliderStyle = new GUIStyle(GUI.skin.horizontalSlider);
                uiSliderStyle.normal.background = trackTexture;
                uiSliderStyle.hover.background = trackTexture;
                uiSliderStyle.active.background = trackTexture;
                uiSliderStyle.focused.background = trackTexture;
                uiSliderStyle.border = new RectOffset(2, 2, 2, 2);
                uiSliderThumbStyle = new GUIStyle(GUI.skin.horizontalSliderThumb);
                uiSliderThumbStyle.normal.background = accentTexture;
                uiSliderThumbStyle.hover.background = hoverAccentTexture;
                uiSliderThumbStyle.active.background = hoverAccentTexture;
                uiSliderThumbStyle.focused.background = accentTexture;

                uiGaugeTrackStyle = CreateUiStyle(GUI.skin.box, trackTexture, trackTexture, trackTexture, textColor, TextAnchor.MiddleLeft, false);
                uiGaugeTrackStyle.padding = new RectOffset(0, 0, 0, 0);
                uiGaugeTrackStyle.border = new RectOffset(0, 0, 0, 0);
                uiGaugeFillStyle = CreateUiStyle(GUI.skin.box, accentTexture, accentTexture, accentTexture, textColor, TextAnchor.MiddleLeft, false);
                uiGaugeFillStyle.padding = new RectOffset(0, 0, 0, 0);
                uiGaugeFillStyle.border = new RectOffset(0, 0, 0, 0);
                uiGaugeTickStyle = CreateUiStyle(GUI.skin.box, gaugeTickTexture, gaugeTickTexture, gaugeTickTexture, textColor, TextAnchor.MiddleCenter, false);
                uiGaugeWarnTickStyle = CreateUiStyle(GUI.skin.box, gaugeWarnTexture, gaugeWarnTexture, gaugeWarnTexture, textColor, TextAnchor.MiddleCenter, false);
                uiGaugeDangerTickStyle = CreateUiStyle(GUI.skin.box, gaugeDangerTexture, gaugeDangerTexture, gaugeDangerTexture, textColor, TextAnchor.MiddleCenter, false);
                uiGaugeNeedleStyle = CreateUiStyle(GUI.skin.box, accentTexture, accentTexture, accentTexture, textColor, TextAnchor.MiddleCenter, false);
                boostGaugeFaceTexture = CreateBoostGaugeFaceTexture();
            }

            int smallSize = Mathf.Max(10, Mathf.RoundToInt(12.0f * scale));
            int bodySize = Mathf.Max(11, Mathf.RoundToInt(13.0f * scale));
            uiHeaderTextStyle.fontSize = Mathf.Max(12, Mathf.RoundToInt(15.0f * scale));
            uiBodyTextStyle.fontSize = bodySize;
            uiMutedTextStyle.fontSize = smallSize;
            uiButtonStyle.fontSize = smallSize;
            uiSelectedButtonStyle.fontSize = smallSize;
            uiSliderStyle.fixedHeight = Mathf.Max(5.0f, 6.0f * scale);
            uiSliderThumbStyle.fixedWidth = Mathf.Max(10.0f, 12.0f * scale);
            uiSliderThumbStyle.fixedHeight = Mathf.Max(12.0f, 15.0f * scale);
        }

        private void DrawUiPanel(Rect rect, string title, float scale)
        {
            GUI.Box(rect, GUIContent.none, uiPanelStyle);
            GUI.Box(new Rect(rect.x + 3.0f * scale, rect.y + 3.0f * scale, rect.width - 6.0f * scale, 27.0f * scale), GUIContent.none, uiHeaderBarStyle);
            GUI.Box(new Rect(rect.x, rect.y + 3.0f * scale, 3.0f * scale, 27.0f * scale), GUIContent.none, uiAccentStyle);
            GUI.Label(new Rect(rect.x + 13.0f * scale, rect.y + 5.0f * scale, rect.width - 26.0f * scale, 22.0f * scale), title, uiHeaderTextStyle);
        }

        private void DrawModeButton(Rect rect, InductionMode mode)
        {
            InductionMode currentMode = !standOccupied && !String.IsNullOrEmpty(activeCarKey) ? activeMode : selectedMode;
            GUIStyle style = currentMode == mode ? uiSelectedButtonStyle : uiButtonStyle;
            if (GUI.Button(rect, ModeName(mode), style)) SetMode(mode);
        }

        private void DrawBoostGauge(float scale)
        {
            if (activeController == null || standOccupied || activeMode == InductionMode.Off) return;
            float width = 460.0f * scale;
            float height = 328.0f * scale;
            float x = Mathf.Max(18.0f * scale, Screen.width - width - 20.0f * scale);
            float y = 20.0f * scale;
            Rect panel = new Rect(x, y, width, height);
            DrawUiPanel(panel, "PROCHARGER / MANIFOLD PRESSURE  (inHg vacuum / psi boost)", scale);

            float buttonX = x + 12.0f * scale;
            float buttonY = y + 37.0f * scale;
            float gap = 4.0f * scale;
            float currentX = buttonX;
            for (int i = 0; i < ModeButtons.Length; i++)
            {
                float buttonWidth = GaugeModeButtonWidths[i] * scale;
                DrawModeButton(new Rect(currentX, buttonY, buttonWidth, 26.0f * scale), ModeButtons[i]);
                currentX += buttonWidth + gap;
            }

            Vector2 gaugeCenter = new Vector2(x + 91.0f * scale, y + 158.0f * scale);
            float gaugeMaxPsi = GetMaximumBoostPsi(activeMode, activeHasHighBoostProcharger);
            DrawBoostDial(gaugeCenter, 72.0f * scale, liveBoostPsi, gaugeMaxPsi, scale);

            float textX = x + 178.0f * scale;
            float textWidth = width - 190.0f * scale;
            GUI.Label(new Rect(textX, y + 83.0f * scale, textWidth, 23.0f * scale),
                cachedGaugeBoostText, uiHeaderTextStyle);
            GUI.Label(new Rect(textX, y + 106.0f * scale, textWidth, 19.0f * scale),
                cachedGaugeMapText, uiBodyTextStyle);
            GUI.Label(new Rect(textX, y + 128.0f * scale, textWidth, 20.0f * scale),
                cachedGaugePowerText, uiBodyTextStyle);
            GUI.Label(new Rect(textX, y + 152.0f * scale, textWidth, 19.0f * scale),
                cachedGaugeAirflowText, uiMutedTextStyle);
            GUI.Label(new Rect(textX, y + 176.0f * scale, textWidth, 19.0f * scale),
                cachedGaugeTargetText, uiBodyTextStyle);
            GUI.Label(new Rect(textX, y + 200.0f * scale, textWidth, 20.0f * scale),
                cachedGaugeRatingText, uiMutedTextStyle);
            GUI.Label(new Rect(textX, y + 224.0f * scale, textWidth, 17.0f * scale),
                "Pressure ratio uses 14.7 psia sea-level ambient.", uiMutedTextStyle);

            Color oldColor = GUI.color;
            GUI.color = Color.white;
            GUI.Label(new Rect(x + 14.0f * scale, y + 261.0f * scale, 92.0f * scale, 18.0f * scale),
                "Boost target", uiMutedTextStyle);
            float psiLimit = GetCurrentControlBoostLimit();
            float psi = GUI.HorizontalSlider(new Rect(x + 104.0f * scale, y + 261.0f * scale, width - 120.0f * scale, 17.0f * scale),
                selectedBoostPsi, 0.0f, psiLimit, uiSliderStyle, uiSliderThumbStyle);
            GUI.color = oldColor;
            psi = Mathf.Round(psi * 2.0f) * 0.5f;
            if (Mathf.Abs(psi - selectedBoostPsi) > 0.1f) SetBoostPsi(psi);
        }

        private void DrawBoostDial(Vector2 center, float radius, float pressurePsi, float maximumPsi, float scale)
        {
            // The dial contains only decorative drawing. Skip it during IMGUI layout and
            // input passes; buttons and sliders are drawn by the surrounding panel.
            if (Event.current == null || Event.current.type != EventType.Repaint) return;

            Rect faceRect = new Rect(center.x - radius, center.y - radius, radius * 2.0f, radius * 2.0f);
            if (boostGaugeFaceTexture != null)
                GUI.DrawTexture(faceRect, boostGaugeFaceTexture, ScaleMode.StretchToFill, true);

            float minimumPsi = BoostGaugeMinimumPsi;
            float usableMaximumPsi = Mathf.Max(10.0f, maximumPsi);
            for (int i = 0; ; i++)
            {
                float markPsi = minimumPsi + i * 2.0f;
                if (markPsi > usableMaximumPsi + 0.01f) break;
                float progress = (markPsi - minimumPsi) / (usableMaximumPsi - minimumPsi);
                float angle = 135.0f + progress * 270.0f;
                bool major = Mathf.Abs(markPsi % 10.0f) < 0.01f || Mathf.Abs(markPsi - usableMaximumPsi) < 0.01f;
                float tickWidth = (major ? 2.0f : 1.0f) * scale;
                float tickLength = (major ? 9.0f : 5.0f) * scale;
                GUIStyle tickStyle = markPsi >= usableMaximumPsi - 2.0f ? uiGaugeDangerTickStyle
                    : markPsi >= usableMaximumPsi - 8.0f ? uiGaugeWarnTickStyle
                    : uiGaugeTickStyle;
                Matrix4x4 previousMatrix = GUI.matrix;
                GUIUtility.RotateAroundPivot(angle + 90.0f, center);
                GUI.Box(new Rect(center.x - tickWidth * 0.5f, center.y - radius * 0.84f,
                    tickWidth, tickLength), GUIContent.none, tickStyle);
                GUI.matrix = previousMatrix;
            }

            for (int i = 0; i < BoostGaugeMajorPsiMarks.Length; i++)
            {
                float markPsi = BoostGaugeMajorPsiMarks[i];
                if (markPsi > usableMaximumPsi) continue;
                float progress = (markPsi - minimumPsi) / (usableMaximumPsi - minimumPsi);
                float angle = (135.0f + progress * 270.0f) * Mathf.Deg2Rad;
                float labelRadius = radius * 0.61f;
                Vector2 labelCenter = center + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * labelRadius;
                GUI.Label(new Rect(labelCenter.x - 13.0f * scale, labelCenter.y - 7.0f * scale,
                    26.0f * scale, 14.0f * scale), BoostGaugeMajorLabels[i], uiMutedTextStyle);
            }

            float needleProgress = Mathf.Clamp01((Mathf.Clamp(pressurePsi, minimumPsi, usableMaximumPsi) - minimumPsi)
                / (usableMaximumPsi - minimumPsi));
            float needleAngle = 135.0f + needleProgress * 270.0f;
            Matrix4x4 oldMatrix = GUI.matrix;
            GUIUtility.RotateAroundPivot(needleAngle + 90.0f, center);
            GUI.Box(new Rect(center.x - 1.5f * scale, center.y - radius * 0.70f,
                3.0f * scale, radius * 0.70f), GUIContent.none, uiGaugeNeedleStyle);
            GUI.matrix = oldMatrix;
            GUI.Box(new Rect(center.x - 5.0f * scale, center.y - 5.0f * scale,
                10.0f * scale, 10.0f * scale), GUIContent.none, uiGaugeNeedleStyle);
        }

        private void OnGUI()
        {
            float scale = GetUiScale();
            EnsureUiStyles(scale);
            Color oldColor = GUI.color;
            try
            {
                GUI.color = Color.white;
                DrawBoostGauge(scale);
            }
            finally
            {
                GUI.color = oldColor;
            }
        }
        private void OnDestroy()
        {
            RemoveVisual();
            DestroyInductionModelAssets();
            if (prochargerMountBoltMesh != null) UnityEngine.Object.Destroy(prochargerMountBoltMesh);
            if (prochargerDriveBeltMaterial != null) UnityEngine.Object.Destroy(prochargerDriveBeltMaterial);
            if (prochargerBracketMaterial != null) UnityEngine.Object.Destroy(prochargerBracketMaterial);
            for (int i = 0; i < uiTextures.Count; i++)
            {
                if (uiTextures[i] != null) UnityEngine.Object.Destroy(uiTextures[i]);
            }
            uiTextures.Clear();
            uiPanelStyle = null;
            uiHeaderBarStyle = null;
            uiAccentStyle = null;
            uiHeaderTextStyle = null;
            uiBodyTextStyle = null;
            uiMutedTextStyle = null;
            uiButtonStyle = null;
            uiSelectedButtonStyle = null;
            uiSliderStyle = null;
            uiSliderThumbStyle = null;
            uiGaugeTrackStyle = null;
            uiGaugeFillStyle = null;
            if (harmony != null) harmony.UnpatchSelf();
            if (Instance == this) Instance = null;
        }

        public static bool InductionTunePartPrefix(PartScript __instance, ref string __0,
            ref bool __result, out string __state)
        {
            __state = __0;
            TurboPrototypePlugin plugin = Instance;
            // The vanilla TunePart implementation assumes every part ID has a stock
            // catalog record and prefab. Custom induction IDs do not, and loading a
            // saved custom part through that path can null-reference inside CMS.
            if (IsInductionPartId(__0))
            {
                __result = true;
                if (__instance != null) __instance.SetTunedID(__0);
                if (plugin != null) plugin.Logger.LogInfo("CMS selected " + __0 + " for mount "
                    + (__instance == null ? "<missing>" : __instance.GetID()) + "; preparing installed hardware.");
                return false;
            }

            // The internal mount is only a visual/selection anchor. Clearing it must
            // not send a synthetic part through vanilla's stock inventory lookups.
            if (__instance != null && IsUniversalMountId(__instance.GetID())
                && (String.IsNullOrEmpty(__0) || IsUniversalMountId(__0)))
            {
                __instance.SetTunedID(String.Empty);
                if (plugin != null) plugin.Logger.LogInfo("CMS selected removal for the installed ProCharger mount.");
                __result = true;
                return false;
            }

            return true;
        }

        public static void InductionTunePartPostfix(PartScript __instance, string __state, bool __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null) return;
            if (IsInductionPartId(__state))
            {
                if (__result)
                {
                    plugin.ConfigureMountedInductionPart(__instance, __state);
                    plugin.RecordInstalledInductionKit(__instance, __state);
                    plugin.Logger.LogInfo("Installed " + __state + " on CMS mount " + __instance.GetID()
                        + "; CMS fasteners=" + (__instance.MountObjects == null ? 0 : __instance.MountObjects.Length) + ".");
                }
                return;
            }

            // TunePart is also called by CMS for ordinary engine-bay selections.
            // Running ProCharger teardown for every non-ProCharger part caused
            // repeated collider/renderer cleanup and log spam during normal part
            // selection. Only a cleared universal mount that actually had our
            // installed visual should enter the removal path.
            if (!IsUniversalMountId(__instance.GetID())) return;
            int partKey = __instance.GetInstanceID();
            bool hadInstalledVisual = plugin.mountedVisualModes.ContainsKey(partKey)
                || __instance.transform.Find(InstalledInductionVisualName) != null;
            bool stillHasProcharger = IsProchargerPartId(__instance.GetTunedID())
                || IsProchargerPartId(__instance.GetIDWithTuned());
            if (hadInstalledVisual && !stillHasProcharger
                && (__result || String.IsNullOrEmpty(__state) || IsUniversalMountId(__state)))
            {
                plugin.RestoreMountedProchargerPart(__instance);
                plugin.RecordInstalledInductionKit(__instance, String.Empty);
                plugin.Logger.LogInfo("Removed the ProCharger visual and restored the empty, inventory-installable CMS mount.");
            }
        }

        public static bool ProchargerUnmountPrefix(PartScript __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || String.IsNullOrEmpty(InstalledUniversalProchargerId(__instance))) return true;
            try
            {
                if (!plugin.BeginProchargerBoltRemoval(__instance)) plugin.ShowProchargerPopup(plugin.status);
            }
            finally
            {
                Cursor3D cursor = Cursor3D.Get();
                if (cursor != null) cursor.ResetButton();
            }
            return false;
        }

        public static bool InductionIsTuningPrefix(string __0, string __1, ref bool __result)
        {
            if (!IsInductionPartId(__0) && !IsInductionPartId(__1)
                && !IsUniversalMountId(__0) && !IsUniversalMountId(__1)) return true;
            TurboPrototypePlugin plugin = Instance;
            if (IsUniversalMountId(__1) && IsInductionPartId(__0))
            {
                InductionMode requestedMode = ModeForInductionPartId(__0);
                __result = requestedMode == InductionMode.Procharger
                    || plugin == null || !plugin.CurrentEngineHasCarburetor();
            }
            else __result = IsProchargerCompatibleSlot(__0, __1);
            return false;
        }

        private static string ProchargerWheelLabel(string option)
        {
            switch (option)
            {
                case InstallProchargerPieOption: return "Install ProCharger";
                case FindProchargerPieOption: return "Find ProCharger";
                case BoostTargetPieOption: return "ProCharger Setup";
                case BoostOffPieOption: return "0 psi";
                case BoostStreetPieOption: return "8 psi";
                case BoostTwentyPieOption: return "20 psi";
                case BoostMaximumPieOption: return "32 psi";
                case BoostIncreasePieOption: return "+0.5 psi";
                case BoostDecreasePieOption: return "-0.5 psi";
                case BoostBackPieOption: return "Back";
                case RemoveProchargerPieOption: return "Remove ProCharger";
                default: return null;
            }
        }

        private void AddProchargerWheelActions(ref string[] options)
        {
            RefreshStandContext();
            if (!standOccupied) return;
            List<string> wheel = new List<string>();
            if (options != null)
                for (int i = 0; i < options.Length; i++)
                    if (ProchargerWheelLabel(options[i]) == null) wheel.Add(options[i]);
            if (IsProchargerPartId(InstalledUniversalProchargerId(FindCurrentUniversalMount(false))))
            {
                wheel.Add(BoostTargetPieOption);
            }
            else
            {
                bool ownsKit = HasKitInPlayerInventory(ProchargerPartId)
                    || HasKitInPlayerInventory(ProchargerHighBoostPartId);
                wheel.Add(ownsKit ? InstallProchargerPieOption : FindProchargerPieOption);
            }
            options = wheel.ToArray();
        }

        public static bool InductionPieOptionAvailablePrefix(string __0, ref bool __result)
        {
            if (ProchargerWheelLabel(__0) == null) return true;
            __result = true;
            return false;
        }

        public static void InductionPieOptionsReadPostfix(PieMenuController __instance, string __0, ref string[] __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null || String.IsNullOrEmpty(__0)
                || __0.IndexOf("EngineStand", StringComparison.OrdinalIgnoreCase) < 0) return;
            plugin.AddProchargerWheelActions(ref __result);
        }

        public static void InductionPieIconsPreparePrefix(PieMenuController __instance, ref string[] __0)
        {
            TurboPrototypePlugin plugin = Instance;
            GameScript game = GameScript.Get();
            if (plugin == null || __instance == null || __0 == null || game == null) return;
            if (Array.Exists(__0, option => ProchargerWheelLabel(option) != null)) return;
            FieldInfo field = AccessTools.Field(typeof(PieMenuController), "PreviousValueFromIni");
            string key = System.Object.ReferenceEquals(field, null) ? String.Empty : field.GetValue(__instance) as string;
            if ((!String.IsNullOrEmpty(key) && key.IndexOf("EngineStand", StringComparison.OrdinalIgnoreCase) >= 0)
                || Convert.ToInt32(game.GetMachineOnMouseOverType(), CultureInfo.InvariantCulture) == 5)
                plugin.AddProchargerWheelActions(ref __0);
        }

        public static void InductionPieIconsPreparedPostfix(PieMenuController __instance, string[] __0)
        {
            if (Instance == null || __instance == null || __0 == null) return;
            List<string> names = ReadComponentReference<List<string>>(__instance, "NameList");
            List<Transform> paths = ReadComponentReference<List<Transform>>(__instance, "PathList");
            if (names == null || paths == null) return;
            for (int i = 0; i < names.Count && i < paths.Count; i++)
                if (ProchargerWheelLabel(names[i]) != null) ApplyRadialIcon(names, paths, i);
        }
        private static void ApplyRadialIcon(List<string> names, List<Transform> paths, int optionIndex)
        {
            if (names == null || paths == null || optionIndex < 0 || optionIndex >= names.Count || optionIndex >= paths.Count) return;
            Image target = paths[optionIndex] == null ? null : paths[optionIndex].GetComponent<Image>();
            if (target == null) return;
            string action = names[optionIndex];
            string preferred = action == RemoveProchargerPieOption || action == BoostDecreasePieOption ? "PartSelectEngineStand"
                : action == BoostBackPieOption ? "Back"
                : action == BoostTargetPieOption ? "Dyno"
                : action == FindProchargerPieOption ? "Shop"
                : action == InstallProchargerPieOption || action == BoostIncreasePieOption ? "PartSelectMountEngineStand" : "Dyno";
            Sprite icon = Resources.Load<Sprite>("Sprites/PieMenu/" + preferred);
            for (int i = 0; i < names.Count && i < paths.Count; i++)
            {
                if (icon != null) break;
                if (i == optionIndex || paths[i] == null || ProchargerWheelLabel(names[i]) != null) continue;
                string option = names[i] ?? String.Empty;
                if (option.StartsWith("!", StringComparison.Ordinal)) option = option.Substring(1);
                if (!String.Equals(option, preferred, StringComparison.OrdinalIgnoreCase)
                    && !String.Equals(option, "GroupMount", StringComparison.OrdinalIgnoreCase)) continue;
                Image source = paths[i].GetComponent<Image>();
                if (source != null && source.sprite != null) { icon = source.sprite; break; }
            }
            if (icon == null)
                for (int i = 0; i < paths.Count; i++)
                {
                    if (i == optionIndex || paths[i] == null) continue;
                    Image source = paths[i].GetComponent<Image>();
                    if (source != null && source.sprite != null) { icon = source.sprite; break; }
                }
            TurboPrototypePlugin plugin = Instance;
            if (plugin != null)
            {
                if (action == BoostTargetPieOption && icon != null) plugin.prochargerSetupIcon = icon;
                if (icon == null) icon = plugin.prochargerSetupIcon;
            }
            if (icon != null) target.sprite = icon;
        }

        private static string SelectedProchargerWheelAction(PieMenuController pie)
        {
            if (pie == null) return null;
            FieldInfo field = AccessTools.Field(typeof(PieMenuController), "CurrOption");
            return System.Object.ReferenceEquals(field, null) ? null
                : ProchargerWheelActionAt(ReadComponentReference<List<string>>(pie, "NameList"), (int)field.GetValue(pie));
        }

        private static string ProchargerWheelActionAt(List<string> names, int selected)
        {
            if (names == null || selected < 0 || selected >= names.Count) return null;
            string action = names[selected];
            return ProchargerWheelLabel(action) == null ? null : action;
        }

        private void ShowProchargerPopup(string text)
        {
            UIManager ui = UIManager.Get();
            if (ui != null) ui.ShowPopup("ProCharger", text, PopupType.Normal);
        }

        private static string[] BuildProchargerSetupOptions(bool highBoost)
        {
            List<string> options = new List<string>
            {
                BoostOffPieOption, BoostStreetPieOption, BoostTwentyPieOption
            };
            if (highBoost) options.Add(BoostMaximumPieOption);
            options.Add(BoostIncreasePieOption);
            options.Add(BoostDecreasePieOption);
            options.Add(RemoveProchargerPieOption);
            options.Add(BoostBackPieOption);
            return options.ToArray();
        }

        private static bool TryGetWheelBoostTarget(string action, float current, bool highBoost, out float target)
        {
            switch (action)
            {
                case BoostOffPieOption: target = 0.0f; break;
                case BoostStreetPieOption: target = 8.0f; break;
                case BoostTwentyPieOption: target = 20.0f; break;
                case BoostMaximumPieOption: target = 32.0f; break;
                case BoostIncreasePieOption: target = current + 0.5f; break;
                case BoostDecreasePieOption: target = current - 0.5f; break;
                default: target = current; return false;
            }
            target = ProchargerMath.NormalizeBoostPsi(target, GetMaximumBoostPsi(InductionMode.Procharger, highBoost), current);
            return true;
        }

        private static void OpenProchargerSetupWheel(PieMenuController pie, bool highBoost)
        {
            FieldInfo returnFlag = AccessTools.Field(typeof(PieMenuController), "RunPrevMenuWhenClose");
            MethodInfo transition = AccessTools.Method(typeof(PieMenuController), "PreparePieMenuWithFader");
            if (System.Object.ReferenceEquals(returnFlag, null) || System.Object.ReferenceEquals(transition, null))
                throw new MissingMethodException("CMS radial submenu controls are unavailable.");
            returnFlag.SetValue(pie, true);
            SoundManager sound = SoundManager.Get();
            if (sound != null) sound.PlaySFXOneShot("ButtonClick");
            transition.Invoke(pie, new object[] { BuildProchargerSetupOptions(highBoost) });
        }

        public static bool InductionPieMenuSelectionPrefix(PieMenuController __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return true;
            string action = SelectedProchargerWheelAction(__instance);
            if (action == null) return true;
            try
            {
                PartScript setupMount = plugin.FindCurrentUniversalMount(false);
                string fittedKit = InstalledUniversalProchargerId(setupMount);
                bool hasKit = IsProchargerPartId(fittedKit);
                bool highBoost = IsHighBoostProchargerPartId(fittedKit);
                if (action == BoostTargetPieOption && hasKit)
                {
                    OpenProchargerSetupWheel(__instance, highBoost);
                    return false;
                }
                if (action == BoostBackPieOption)
                {
                    MethodInfo hide = AccessTools.Method(typeof(PieMenuController), "Hide");
                    if (!System.Object.ReferenceEquals(hide, null)) hide.Invoke(__instance, null);
                    return false;
                }
                float target;
                if (hasKit && TryGetWheelBoostTarget(action, plugin.selectedBoostPsi, highBoost, out target))
                {
                    plugin.selectedMode = InductionMode.Procharger;
                    plugin.standHasHighBoostProcharger = highBoost;
                    plugin.SetBoostPsi(target);
                    Text description = ReadComponentReference<Text>(__instance, "DescText");
                    if (description != null) description.text = plugin.FormatWheelBoostTarget();
                    SoundManager sound = SoundManager.Get();
                    if (sound != null) sound.PlaySFXOneShot("ButtonClick");
                    return false;
                }

                MethodInfo close = AccessTools.Method(typeof(PieMenuController), "Close");
                if (!System.Object.ReferenceEquals(close, null)) close.Invoke(__instance, null);
                GameMode mode = GameMode.Get();
                if (mode != null) mode.SetCurrentMode(mode.GetPreviousMode());

                if (action == InstallProchargerPieOption)
                {
                    if (!plugin.OpenProchargerInventoryPicker()) plugin.ShowProchargerPopup(plugin.status);
                }
                else if (action == FindProchargerPieOption)
                {
                    plugin.ShowProchargerPopup("P-1X: Main Shop. High-Boost: Tuning Shop.");
                }
                else if (action == RemoveProchargerPieOption && hasKit)
                {
                    if (!plugin.BeginProchargerBoltRemoval(setupMount))
                        plugin.ShowProchargerPopup(plugin.status);
                }
            }
            catch (Exception exception)
            {
                plugin.Logger.LogWarning("Could not complete the ProCharger wheel action: " + exception.Message);
            }
            return false;
        }

        private string FormatWheelBoostTarget()
        {
            return "Target: " + selectedBoostPsi.ToString("F1", CultureInfo.InvariantCulture) + " psi";
        }

        public static void InductionPieDescriptionPostfix(PieMenuController __instance, int __0)
        {
            string action = ProchargerWheelActionAt(ReadComponentReference<List<string>>(__instance, "NameList"), __0);
            if (action == null) return;
            Text title = ReadComponentReference<Text>(__instance, "TitleText");
            Text description = ReadComponentReference<Text>(__instance, "DescText");
            if (title != null) title.text = ProchargerWheelLabel(action);
            if (description == null) return;
            switch (action)
            {
                case InstallProchargerPieOption: description.text = "Choose a kit from your inventory."; break;
                case FindProchargerPieOption: description.text = "P-1X in Main Shop. High-Boost in Tuning Shop."; break;
                case BoostTargetPieOption:
                case BoostOffPieOption:
                case BoostStreetPieOption:
                case BoostTwentyPieOption:
                case BoostMaximumPieOption:
                case BoostIncreasePieOption:
                case BoostDecreasePieOption:
                    description.text = Instance == null ? String.Empty : Instance.FormatWheelBoostTarget();
                    break;
                case BoostBackPieOption: description.text = "Return to the engine stand menu."; break;
                case RemoveProchargerPieOption: description.text = "Undo the four mounting bolts to remove the kit."; break;
            }
        }
        public static bool InductionIsPartAccessiblePrefix(string __0, ref bool __result)
        {
            // Raycast.Update asks this once per hovered frame. Resolve the active mount
            // from GameScript's already-updated hover reference; never search the car's
            // full engine hierarchy here. A hierarchy scan on each raycast caused stalls
            // and could miss the mount while CMS was refreshing its active loader.
            if (IsUniversalMountId(__0))
            {
                TurboPrototypePlugin plugin = Instance;
                __result = IsHoveredUniversalMountSelectable(plugin);
                return false;
            }
            if (!IsInductionPartId(__0)) return true;
            __result = true;
            return false;
        }

        private static bool IsHoveredUniversalMountSelectable(TurboPrototypePlugin plugin)
        {
            if (plugin == null) return false;
            PartScript mount = plugin.cachedPartMouseOver;
            if (mount == null) return false;
            bool isP1xTarget = IsUniversalMountId(mount.GetID())
                || IsProchargerPartId(mount.GetID())
                || IsProchargerPartId(mount.GetTunedID())
                || IsProchargerPartId(mount.GetIDWithTuned());
            if (!isP1xTarget) return false;
            int mountKey = mount.GetInstanceID();
            bool directInstalledState = IsInductionPartId(mount.GetTunedID())
                || IsInductionPartId(mount.GetIDWithTuned())
                || plugin.armedUniversalMounts.Contains(mountKey)
                || plugin.mountedVisualModes.ContainsKey(mountKey);
            bool detectedInstalledState = plugin.standOccupied
                ? plugin.standHasNativeInduction && plugin.standNativeMode == InductionMode.Procharger
                : plugin.activeHasCustomInduction && IsProchargerPartId(plugin.activeNativePartId);
            bool selectable = directInstalledState || detectedInstalledState;
            return selectable;
        }

        private static void ProchargerHitHighlightPostfix(PartScript __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null || __instance.IsUnmounted()
                || String.IsNullOrEmpty(InstalledUniversalProchargerId(__instance))) return;
            GameMode game = GameMode.Get();
            if (game == null) return;
            gameMode mode = game.GetCurrentMode();
            if (mode != gameMode.PartSelect && mode != gameMode.PartSelectMount && mode != gameMode.ExamineCondition) return;
            if (!GameSettings.CanHighlight)
            {
                if (!plugin.loggedDisabledOutline)
                {
                    plugin.loggedDisabledOutline = true;
                    plugin.Logger.LogInfo("CMS part highlighting is disabled for the current profile.");
                }
                return;
            }

            Transform visual = __instance.transform.Find(InstalledInductionVisualName);
            if (visual == null || !visual.gameObject.activeInHierarchy) return;
            HighlightingSystem.Highlighter highlighter = visual.GetComponent<HighlightingSystem.Highlighter>();
            if (highlighter == null)
            {
                // Use the rendered part as the root so the outline is driven by the
                // actual raycast hit, even when the synthetic PartScript's Update
                // does not drive its own highlighter for this frame.
                highlighter = visual.gameObject.AddComponent<HighlightingSystem.Highlighter>();
                RefreshPartHighlight(__instance);
            }
            highlighter.On(mode == gameMode.PartSelectMount ? Color.gray : Color.green);
        }

        public static void InductionPartMouseOverPostfix(PartScript __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || plugin.cachedPartMouseOver == __0) return;
            plugin.cachedPartMouseOver = __0;
        }

        public static bool InductionIsPartGroupAccessiblePrefix(int __0, ref bool __result)
        {
            // The stock group gate is allowed to reject every normal part. Override
            // it only when the current PartScript is the installed/armed ProCharger.
            TurboPrototypePlugin plugin = Instance;
            if (!IsHoveredUniversalMountSelectable(plugin)) return true;
            __result = true;
            return false;
        }

        public static void InductionInventoryGetItemsPostfix(string __0, ref List<NewInventoryItem> __result)
        {
            if (!IsUniversalMountId(__0)) return;
            Inventory inventory = Inventory.Get();
            if (inventory == null) return;
            List<NewInventoryItem> items = inventory.GetItems("All");
            if (items == null) return;
            __result = items.FindAll(item => item != null
                && (IsProchargerPartId(item.ID) || IsProchargerPartId(GetNormalId(item))));
        }
        public static bool InductionGetGO2Prefix(GameInventory __instance, string __0, ref GameObject __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return true;
            if (IsUniversalMountId(__0))
            {
                __result = plugin.CreateUniversalMountPrefab(true);
                return false;
            }
            if (!IsInductionPartId(__0)) return true;

            GameObject part = null;
            try
            {
                part = __instance.GetGO2(ProchargerBasePartId);
                if (part == null)
                {
                    __result = null;
                    return false;
                }
                plugin.ConfigureInductionPart(part, __0);
                __result = part;
                return false;
            }
            catch (Exception exception)
            {
                if (part != null) UnityEngine.Object.Destroy(part);
                __result = null;
                plugin.Logger.LogError("Could not create an induction kit shop preview: " + exception);
                return false;
            }
        }
        public static bool InductionGetGOPrefix(GameInventory __instance, string __0, ref GameObject __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return true;
            if (IsUniversalMountId(__0))
            {
                __result = plugin.CreateUniversalMountPrefab(false);
                return false;
            }
            if (!IsInductionPartId(__0)) return true;

            GameObject part = null;
            try
            {
                part = __instance.GetGO(ProchargerBasePartId);
                if (part == null)
                {
                    __result = null;
                    return false;
                }
                plugin.ConfigureInductionPart(part, __0);
                __result = part;
                return false;
            }
            catch (Exception exception)
            {
                if (part != null) UnityEngine.Object.Destroy(part);
                __result = null;
                plugin.Logger.LogError("Could not create an induction kit mount prefab: " + exception);
                return false;
            }
        }

        public static void InductionShopThumbPostfix(GameInventory __instance, string __0, ref Sprite __result)
        {
            if (IsInductionPartId(__0) || IsUniversalMountId(__0)) __result = __instance.GetThumb(ProchargerBasePartId);
        }

        public static void InductionShopNamePostfix(string __0, ref string __result)
        {
            InductionMode mode = ModeForInductionPartId(__0);
            if (IsHighBoostProchargerPartId(__0)) __result = "ProCharger P-1X High-Boost";
            else if (mode == InductionMode.Procharger) __result = "ProCharger P-1X";
            else if (IsUniversalMountId(__0))
            {
                TurboPrototypePlugin plugin = TurboPrototypePlugin.Instance;
                __result = plugin == null ? "ProCharger Mount Point (kit not installed)" : plugin.GetCurrentUniversalMountDisplayName();
            }
        }

        public static void InductionIOLocalizedNamePostfix(InteractiveObject __0, ref string __result)
        {
            if (__0 == null) return;
            PartScript partScript = __0.GetComponent<PartScript>();
            if (partScript == null) return;
            string tunedId = partScript.GetTunedID();
            InductionMode mode = ModeForInductionPartId(tunedId);
            if (IsHighBoostProchargerPartId(tunedId)) __result = "ProCharger P-1X High-Boost";
            else if (mode == InductionMode.Procharger) __result = "ProCharger P-1X";
            else if (!IsUniversalMountId(partScript.GetID())) return;
            else
            {
                TurboPrototypePlugin plugin = TurboPrototypePlugin.Instance;
                __result = plugin == null ? "ProCharger Mount Point (kit not installed)" : plugin.GetCurrentUniversalMountDisplayName();
            }
        }

        public static void InductionShopGetItemsPostfix(GameInventory __instance, string __0,
            ref List<GameInventory.PartProperty> __result)
        {
            if (__instance == null
                || (!String.Equals(__0, "MainShop", StringComparison.Ordinal)
                    && !String.Equals(__0, "TuningShop", StringComparison.Ordinal))) return;
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return;
            try
            {
                plugin.EnsureShopCatalogReady();
                if (__result == null) __result = new List<GameInventory.PartProperty>();
                string[] productIds = String.Equals(__0, "TuningShop", StringComparison.Ordinal)
                    ? new string[] { ProchargerHighBoostPartId }
                    : new string[] { ProchargerPartId };
                for (int i = 0; i < productIds.Length; i++)
                {
                    GameInventory.PartProperty property = __instance.GetItemProperty(productIds[i]);
                    if (property == null || !String.Equals(property.ShopName, __0, StringComparison.Ordinal)) continue;
                    bool present = false;
                    for (int itemIndex = 0; itemIndex < __result.Count; itemIndex++)
                    {
                        if (__result[itemIndex] != null && String.Equals(__result[itemIndex].ID, property.ID, StringComparison.Ordinal))
                        {
                            present = true;
                            break;
                        }
                    }
                    if (!present) __result.Add(property);
                }
                string queryState = __0 + "|rows=" + __result.Count.ToString(CultureInfo.InvariantCulture)
                    + "|p1x=" + HasShopProperty(__instance, ProchargerPartId, "MainShop")
                    + "|high=" + HasShopProperty(__instance, ProchargerHighBoostPartId, "TuningShop");
                if (plugin.loggedShopQueryStates.Add(queryState))
                    plugin.Logger.LogInfo("Shop catalog query: " + queryState + ".");
            }
            catch (Exception exception)
            {
                plugin.Logger.LogWarning("Could not add the ProCharger kits to the " + __0 + " result: " + exception.Message);
            }
        }

        public static void InductionLocalizationPostfix(string __0, ref string __result)
        {
            if (String.IsNullOrEmpty(__0)) return;
            string wheelLabel = ProchargerWheelLabel(__0.Trim());
            if (wheelLabel != null)
            {
                __result = wheelLabel;
                return;
            }            string key = __0.Trim();
            if (key.StartsWith("!", StringComparison.Ordinal)) key = key.Substring(1);
            key = RemoveSlotSuffix(key);
            PartScript selectedPart = ReadComponentReference<PartScript>(GameScript.Get(), "partMouseOver");
            if (selectedPart != null)
            {
                string tunedId = selectedPart.GetTunedID();
                string installedId = selectedPart.GetID();
                bool samePart = String.Equals(key, installedId, StringComparison.Ordinal)
                    || String.Equals(key, tunedId, StringComparison.Ordinal)
                    || (IsUniversalMountId(key) && IsUniversalMountId(installedId));
                if (samePart && IsHighBoostProchargerPartId(tunedId))
                {
                    __result = "ProCharger P-1X High-Boost";
                    return;
                }
                if (samePart && IsProchargerPartId(tunedId))
                {
                    __result = "ProCharger P-1X";
                    return;
                }
            }
            InductionMode mode = ModeForInductionPartId(key);
            if (IsHighBoostProchargerPartId(key)) __result = "ProCharger P-1X High-Boost";
            else if (mode == InductionMode.Procharger) __result = "ProCharger P-1X";
            else if (IsUniversalMountId(key))
            {
                // GameScript.SetPartMouseOver sets this field immediately before requesting
                // the highlighted part's localization key. `selectedPart` is not its raycast target.
                if (selectedPart != null && IsUniversalMountId(selectedPart.GetID()))
                {
                    mode = ModeForInductionPartId(selectedPart.GetTunedID());
                    if (mode == InductionMode.Off) mode = ModeForInductionPartId(selectedPart.GetIDWithTuned());
                    if (IsHighBoostProchargerPartId(selectedPart.GetTunedID())) __result = "ProCharger P-1X High-Boost";
                    else if (mode == InductionMode.Procharger) __result = "ProCharger P-1X";
                    else __result = "ProCharger Mount Point (kit not installed)";
                }
                else __result = "ProCharger Mount Point (kit not installed)";
            }
        }

        private static bool IsPartOnEngineStand(PartScript part)
        {
            GameScript game = GameScript.Get();
            if (part == null || game == null || game.EngineStandIsEmpty()) return false;
            List<GameObject> standObjects = game.GetObjectsOnEngineStand();
            if (standObjects == null) return false;
            GameObject engine = FindEngineContainer(part.gameObject);
            if (engine == null) return false;
            for (int i = 0; i < standObjects.Count; i++)
                if (standObjects[i] == engine || FindEngineContainer(standObjects[i]) == engine) return true;
            return false;
        }

        private static bool CarOwnsPart(CarLoader loader, PartScript part)
        {
            if (loader == null || part == null) return false;
            GameObject engine = loader.GetEngine();
            return engine != null && part.transform.IsChildOf(engine.transform);
        }

        private string FindOwningCarKey(PartScript part)
        {
            if (part == null) return String.Empty;
            GameScript game = GameScript.Get();
            CarLoader hovered = game == null ? null : game.GetIOMouseOverCarLoader2();
            if (CarOwnsPart(hovered, part)) return BuildCarIdentityKey(hovered);
            CarLoader parent = part.GetComponentInParent<CarLoader>();
            if (CarOwnsPart(parent, part)) return BuildCarIdentityKey(parent);
            VPVehicleController ignored;
            CarLoader active = FindActiveCarLoader(out ignored);
            return CarOwnsPart(active, part) ? BuildCarIdentityKey(active) : String.Empty;
        }

        private void RecordInstalledInductionKit(PartScript part, string partId)
        {
            if (part == null) return;
            bool onStand = IsPartOnEngineStand(part);
            RecordInstalledInductionKit(part, partId, onStand, onStand ? String.Empty : FindOwningCarKey(part));
        }

        private void RecordInstalledInductionKit(PartScript part, string partId, bool onStand, string carKey)
        {
            bool fitted = IsProchargerPartId(partId);
            if (!fitted && !IsUniversalMountId(part.GetID())) return;
            if (fitted) armedUniversalMounts.Remove(part.GetInstanceID());

            bool highBoost = IsHighBoostProchargerPartId(partId);
            InductionMode mode = fitted ? InductionMode.Procharger : InductionMode.Off;
            float psi = selectedBoostPsi;
            if (!onStand && !String.IsNullOrEmpty(carKey))
                psi = PlayerPrefs.GetFloat(PrefKey(CarPsiPrefix + carKey), psi);
            if (highBoost) psi = Mathf.Max(psi, P1XHighBoostDefaultPsi);
            if (fitted) psi = ProchargerMath.NormalizeBoostPsi(psi, GetMaximumBoostPsi(mode, highBoost), 8.0f);

            if (onStand)
            {
                standHasHighBoostProcharger = highBoost;
                selectedMode = mode;
                selectedBoostPsi = psi;
                if (standGroup != null)
                {
                    SaveGroupSettings(standGroup, mode, psi);
                    AnnotateGroup(standGroup, mode, psi);
                }
            }
            else if (!String.IsNullOrEmpty(carKey))
            {
                string prefKey = PrefKey(InstalledKitModePrefix + carKey);
                if (fitted) PlayerPrefs.SetString(prefKey, partId);
                else PlayerPrefs.DeleteKey(prefKey);
                PlayerPrefs.SetInt(PrefKey(CarModePrefix + carKey), (int)mode);
                PlayerPrefs.SetFloat(PrefKey(CarPsiPrefix + carKey), psi);
                if (!standOccupied && String.Equals(carKey, activeCarKey, StringComparison.Ordinal))
                {
                    selectedMode = mode;
                    selectedBoostPsi = psi;
                    activeHasHighBoostProcharger = highBoost;
                    UpdateEffectiveSettings();
                }
            }
            if (highBoost) status = "High-Boost P-1X fitted.";
            SaveGlobalSettings();
            PlayerPrefs.Save();
        }
        public static void MaxPowerTorquePostfix(VehiclePhysics.Engine __instance, float __0, ref float __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (!System.Object.ReferenceEquals(plugin, null)) plugin.ApplyMaxPowerTorque(__instance, __0, ref __result);
        }

        public static void StandGroupPostfix(ref NewGroupItem __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __result == null) return;

            string key = BuildGroupKey(__result);
            bool isCurrentGroup = plugin.standOccupied
                && __result.UId == plugin.standGroupUid
                && String.Equals(key, plugin.standGroupKey, StringComparison.Ordinal);
            InductionMode mode;
            float psi;
            if (plugin.TryReadGroupSettings(__result, out mode, out psi))
            {
                if (isCurrentGroup)
                {
                    plugin.selectedMode = mode;
                    plugin.selectedBoostPsi = psi;
                    if (!PlayerPrefs.HasKey(plugin.PrefKey(GroupModePrefix + key)))
                    {
                        plugin.SaveGroupSettings(__result, mode, psi);
                    }
                }
                return;
            }

            if (plugin.TryReadStoredGroupSettings(__result, out mode, out psi))
            {
                if (isCurrentGroup)
                {
                    plugin.selectedMode = mode;
                    plugin.selectedBoostPsi = psi;
                }
                plugin.AnnotateGroup(__result, mode, psi);
                return;
            }
            if (!isCurrentGroup) return;

            mode = plugin.selectedMode;
            psi = plugin.selectedBoostPsi;

            plugin.SaveGroupSettings(__result, mode, psi);
            plugin.AnnotateGroup(__result, mode, psi);
        }
        public static void SetStandGroupPrefix(NewGroupItem __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __0 == null) return;
            InductionMode mode;
            float psi;
            if (!plugin.TryReadGroupSettings(__0, out mode, out psi)
                && !plugin.TryReadStoredGroupSettings(__0, out mode, out psi))
            {
                mode = InductionMode.Off;
                psi = 8.0f;
            }
            plugin.selectedMode = mode;
            plugin.selectedBoostPsi = psi;
            plugin.AnnotateGroup(__0, mode, psi);
            plugin.SaveGroupSettings(__0, mode, psi);
            plugin.SaveGlobalSettings();
            plugin.UpdateEffectiveSettings();
        }

        public static void InsertEnginePrefix(NewGroupItem __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return;
            try { plugin.RecordPendingInstall(__0); }
            catch (Exception exception) { plugin.Logger.LogError("Engine-install tracking prefix failed safely: " + exception); }
        }

        public static void InsertEnginePostfix(NewGroupItem __0, ref IEnumerator __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __result == null) return;
            try { __result = plugin.TrackActionInsertRoutine(__result, __0); }
            catch (Exception exception) { plugin.Logger.LogError("Engine-install tracking postfix failed safely: " + exception); }
        }

        public static void SwapEnginePrefix(CarLoader __instance, NewGroupItem __0)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return;
            try { plugin.MarkPendingEngineSwap(__instance, __0); }
            catch (Exception exception) { plugin.Logger.LogError("Engine-swap tracking prefix failed safely: " + exception); }
        }

        public static void SwapEnginePostfix(CarLoader __instance, NewGroupItem __0, ref IEnumerator __result)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __result == null) return;
            try { __result = plugin.TrackEngineSwapRoutine(__result, __instance, __0); }
            catch (Exception exception) { plugin.Logger.LogError("Engine-swap tracking postfix failed safely: " + exception); }
        }

        public static void SetEnginePostfix(CarLoader __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null) return;
            // Engine installation can reach SetEngine before the outer insertion
            // coroutine's completion hook. Recover only for the loader captured from
            // this specific crane transfer and only after its engine matches the group.
            if (plugin.pendingInstallGroup != null)
            {
                try { plugin.StartCoroutine(plugin.RecoverPendingEngineInstallAfterSetEngine(__instance)); }
                catch (Exception exception) { plugin.Logger.LogWarning("Pending engine-transfer recovery could not start safely: " + exception.Message); }
            }
            // CarLoader instances are also created for previews/showroom cars. Restore
            // runtime-only parts only on the currently active garage/dyno car.
            if (!plugin.IsActiveCarLoader(__instance)) return;
            try
            {
                plugin.EnsureMountForEngineSwap(__instance);
                plugin.StartCoroutine(plugin.RestoreInstalledKitAfterCarLoad(__instance));
            }
            catch (Exception exception) { plugin.Logger.LogWarning("Engine-swap mount preparation failed safely: " + exception.Message); }
        }

        public static void DynoPreparePostfix(DynoManager __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin != null)
            {
                // A previous chart draw may have thrown before Harmony ran its
                // postfix. Start each dyno pass from a known sampling state.
                plugin.dynoSampleBoostPsi = null;
                plugin.dynoResultsLoader = null;
                plugin.RefreshCarContext();
            }
        }

        public static void ShopCreatePrefix()
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null) return;
            plugin.prochargerShopCardRecolorPending = true;
            try { plugin.EnsureShopCatalogReady(); }
            catch (Exception exception) { plugin.Logger.LogWarning("Shop catalog registration before UI build failed safely: " + exception.Message); }
        }

        public static void ShopCardMoveNextPostfix(bool __result)
        {
            if (!__result) return;
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || !plugin.prochargerShopCardRecolorPending) return;
            try
            {
                // CMS colors the card in CreateShop.MoveNext using the part ID
                // prefix: t_ gets ITEM_TUNING (blue), everything else gets
                // ITEM_NORMAL (gray). Keep this mod's stable part ID and apply
                // the same native blue only to its rendered card background.
                ButtonAction[] cards = UnityEngine.Object.FindObjectsOfType<ButtonAction>();
                for (int i = 0; i < cards.Length; i++)
                {
                    ButtonAction card = cards[i];
                    if (card == null) continue;
                    NewHash hash = card.Get();
                    if (hash == null) continue;
                    string partId = hash.GetFromKey("PartName") as string;
                    if (!String.Equals(partId, ProchargerHighBoostPartId, StringComparison.Ordinal)) continue;
                    Transform background = card.transform.Find("OptimizedBG");
                    if (background == null) continue;
                    Image image = background.GetComponent<Image>();
                    if (image == null) continue;
                    image.color = GlobalData.ITEM_TUNING;
                    plugin.prochargerShopCardRecolorPending = false;
                    plugin.Logger.LogInfo("Applied CMS's native tuning-blue card tint to the ProCharger P-1X Tuning Shop card.");
                    return;
                }
            }
            catch (Exception exception)
            {
                plugin.Logger.LogWarning("Could not apply the native blue ProCharger shop-card tint: " + exception.Message);
            }
        }

        private static void OilCanEnabledPostfix(PuszkaWlewOleju __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || __instance == null) return;
            CarLoader car = __instance.carLoader;
            InductionMode mode;
            string kitId;
            plugin.expandedOilFillCar = TryDetectMountedInduction(car, out mode, out kitId)
                && IsProchargerPartId(kitId) ? car : null;
            if (plugin.expandedOilFillCar != null)
                plugin.Logger.LogInfo("Using the P-1X oil circuit's 15% larger fill capacity.");
        }

        private static void OilCanDisabledPostfix(PuszkaWlewOleju __instance)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin != null && __instance != null
                && System.Object.ReferenceEquals(plugin.expandedOilFillCar, __instance.carLoader))
                plugin.expandedOilFillCar = null;
        }

        private static float OilFillIncrement(float amount, bool expandedCapacity)
        {
            return expandedCapacity && amount > 0.0f ? amount / ProchargerOilCapacityMultiplier : amount;
        }

        private static void ProchargerOilFillPrefix(CarLoader __instance, ref float __0, ref float __1)
        {
            TurboPrototypePlugin plugin = Instance;
            if (plugin == null || plugin.expandedOilFillCar == null
                || !System.Object.ReferenceEquals(plugin.expandedOilFillCar, __instance) || __0 <= 0.0f) return;

            // CMS stores oil as a fraction of a full fill, so a larger circuit
            // needs more oil per percentage point. The dipstick still tops at 100%.
            __0 = OilFillIncrement(__0, true);
            __1 = OilFillIncrement(__1, true);
        }

        private float? ReadDynoBoostTarget(CarLoader loader)
        {
            InductionMode mode;
            string kitId;
            if (!TryDetectMountedInduction(loader, out mode, out kitId) || !IsProchargerPartId(kitId)) return null;

            float defaultTarget = IsHighBoostProchargerPartId(kitId) ? P1XHighBoostDefaultPsi : 8.0f;
            string key = BuildCarIdentityKey(loader);
            float savedTarget = String.IsNullOrEmpty(key) ? defaultTarget
                : PlayerPrefs.GetFloat(PrefKey(CarPsiPrefix + key), defaultTarget);
            return ProchargerMath.NormalizeBoostPsi(savedTarget,
                GetMaximumBoostPsi(mode, IsHighBoostProchargerPartId(kitId)), defaultTarget);
        }

        private static void DynoResultsPrefix(MenuDyno __instance, out CarLoader __state)
        {
            TurboPrototypePlugin plugin = Instance;
            bool available = !System.Object.ReferenceEquals(plugin, null);
            __state = available ? plugin.dynoResultsLoader : null;
            if (available) plugin.dynoResultsLoader = ReadComponentReference<CarLoader>(__instance, "connectedCarLoader");
        }

        private static Exception DynoResultsFinalizer(Exception __exception, CarLoader __state)
        {
            TurboPrototypePlugin plugin = Instance;
            if (!System.Object.ReferenceEquals(plugin, null)) plugin.dynoResultsLoader = __state;
            return __exception;
        }

        private static void DynoMeasuredEnginePrefix(CarLoader __0, out float? __state)
        {
            TurboPrototypePlugin plugin = Instance;
            bool available = !System.Object.ReferenceEquals(plugin, null);
            __state = available ? plugin.dynoSampleBoostPsi : null;
            if (!available || __0 == null || !System.Object.ReferenceEquals(__0, plugin.dynoResultsLoader)) return;

            // Only the constructor for the fitted car enters this scope. CMS uses
            // a different constructor when calculating the factory comparison.
            plugin.dynoSampleBoostPsi = plugin.ReadDynoBoostTarget(__0);
        }

        private static void DynoTorqueChartPrefix(out float? __state)
        {
            TurboPrototypePlugin plugin = Instance;
            bool available = !System.Object.ReferenceEquals(plugin, null);
            __state = available ? plugin.dynoSampleBoostPsi : null;
            if (!available || plugin.dynoResultsLoader == null) return;
            plugin.dynoSampleBoostPsi = plugin.ReadDynoBoostTarget(plugin.dynoResultsLoader);
        }

        private static Exception DynoSamplingFinalizer(Exception __exception, float? __state)
        {
            TurboPrototypePlugin plugin = Instance;
            if (!System.Object.ReferenceEquals(plugin, null)) plugin.dynoSampleBoostPsi = __state;
            return __exception;
        }
    }
    internal sealed class ProchargerBeltMeshOwner : MonoBehaviour
    {
        internal Mesh Mesh;

        private void OnDestroy()
        {
            if (Mesh != null) Destroy(Mesh);
        }
    }

    internal static class TurboPrototypeHooks
    {
        public static void InductionPieIconsPreparePrefix(PieMenuController __instance, ref string[] __0)
        {
            TurboPrototypePlugin.InductionPieIconsPreparePrefix(__instance, ref __0);
        }

        public static void InductionPieIconsPreparedPostfix(PieMenuController __instance, string[] __0)
        {
            TurboPrototypePlugin.InductionPieIconsPreparedPostfix(__instance, __0);
        }

        public static bool InductionPieOptionAvailablePrefix(string __0, ref bool __result)
        {
            return TurboPrototypePlugin.InductionPieOptionAvailablePrefix(__0, ref __result);
        }

        public static void InductionPieOptionsReadPostfix(PieMenuController __instance, string __0,
            ref string[] __result)
        {
            TurboPrototypePlugin.InductionPieOptionsReadPostfix(__instance, __0, ref __result);
        }

        public static bool InductionPieMenuSelectionPrefix(PieMenuController __instance)
        {
            return TurboPrototypePlugin.InductionPieMenuSelectionPrefix(__instance);
        }

        public static void InductionPieDescriptionPostfix(PieMenuController __instance, int __0)
        {
            TurboPrototypePlugin.InductionPieDescriptionPostfix(__instance, __0);
        }

        public static void MaxPowerTorquePostfix(VehiclePhysics.Engine __instance, float __0, ref float __result)
        {
            TurboPrototypePlugin.MaxPowerTorquePostfix(__instance, __0, ref __result);
        }

        public static void StandGroupPostfix(ref NewGroupItem __result)
        {
            TurboPrototypePlugin.StandGroupPostfix(ref __result);
        }

        public static void SetStandGroupPrefix(NewGroupItem __0)
        {
            TurboPrototypePlugin.SetStandGroupPrefix(__0);
        }

        public static void InsertEnginePrefix(NewGroupItem __0)
        {
            TurboPrototypePlugin.InsertEnginePrefix(__0);
        }

        public static void InsertEnginePostfix(NewGroupItem __0, ref IEnumerator __result)
        {
            TurboPrototypePlugin.InsertEnginePostfix(__0, ref __result);
        }

        public static void SwapEnginePrefix(CarLoader __instance, NewGroupItem __0)
        {
            TurboPrototypePlugin.SwapEnginePrefix(__instance, __0);
        }

        public static void SwapEnginePostfix(CarLoader __instance, NewGroupItem __0, ref IEnumerator __result)
        {
            TurboPrototypePlugin.SwapEnginePostfix(__instance, __0, ref __result);
        }

        public static void SetEnginePostfix(CarLoader __instance)
        {
            TurboPrototypePlugin.SetEnginePostfix(__instance);
        }
        public static bool InductionTunePartPrefix(PartScript __instance, ref string __0,
            ref bool __result, out string __state)
        {
            return TurboPrototypePlugin.InductionTunePartPrefix(__instance, ref __0, ref __result, out __state);
        }

        public static void InductionTunePartPostfix(PartScript __instance, string __state, bool __result)
        {
            TurboPrototypePlugin.InductionTunePartPostfix(__instance, __state, __result);
        }

        public static bool ProchargerUnmountPrefix(PartScript __instance)
        {
            return TurboPrototypePlugin.ProchargerUnmountPrefix(__instance);
        }

        public static bool InductionIsTuningPrefix(string __0, string __1, ref bool __result)
        {
            return TurboPrototypePlugin.InductionIsTuningPrefix(__0, __1, ref __result);
        }

        public static bool InductionIsPartAccessiblePrefix(string __0, ref bool __result)
        {
            return TurboPrototypePlugin.InductionIsPartAccessiblePrefix(__0, ref __result);
        }

        public static void InductionInventoryGetItemsPostfix(string __0, ref List<NewInventoryItem> __result)
        {
            TurboPrototypePlugin.InductionInventoryGetItemsPostfix(__0, ref __result);
        }

        public static bool InductionGetGO2Prefix(GameInventory __instance, string __0, ref GameObject __result)
        {
            return TurboPrototypePlugin.InductionGetGO2Prefix(__instance, __0, ref __result);
        }

        public static bool InductionGetGOPrefix(GameInventory __instance, string __0, ref GameObject __result)
        {
            return TurboPrototypePlugin.InductionGetGOPrefix(__instance, __0, ref __result);
        }

        public static void InductionShopThumbPostfix(GameInventory __instance, string __0, ref Sprite __result)
        {
            TurboPrototypePlugin.InductionShopThumbPostfix(__instance, __0, ref __result);
        }

        public static void InductionShopNamePostfix(string __0, ref string __result)
        {
            TurboPrototypePlugin.InductionShopNamePostfix(__0, ref __result);
        }

        public static void InductionShopGetItemsPostfix(GameInventory __instance, string __0,
            ref List<GameInventory.PartProperty> __result)
        {
            TurboPrototypePlugin.InductionShopGetItemsPostfix(__instance, __0, ref __result);
        }

        public static void ShopCreatePrefix()
        {
            TurboPrototypePlugin.ShopCreatePrefix();
        }

        public static void InductionLocalizationPostfix(string __0, ref string __result)
        {
            TurboPrototypePlugin.InductionLocalizationPostfix(__0, ref __result);
        }

        public static void InductionIOLocalizedNamePostfix(InteractiveObject __0, ref string __result)
        {
            TurboPrototypePlugin.InductionIOLocalizedNamePostfix(__0, ref __result);
        }

        public static void DynoPreparePostfix(DynoManager __instance)
        {
            TurboPrototypePlugin.DynoPreparePostfix(__instance);
        }

    }
}
