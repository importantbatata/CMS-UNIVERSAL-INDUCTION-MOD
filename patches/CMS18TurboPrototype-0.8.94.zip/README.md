# CMS 2018 Forced Induction Mod — Patch 0.8.94

This build leaves CMS's car-parts radial menu untouched. ECU Lab opens with **F9**; forced-induction setup remains available from the engine-stand radial menu. The release also carries the standalone single-turbo dependency validator introduced in 0.8.93.

Patch 0.8.94 is installed with rollback. CMS was not launched. See `report.md` for tested checks and limits.

