# Patch 0.8.94 — keep ECU Lab out of CMS car-parts radial

## User-reported regression

The user reports ECU Lab opens but the adjacent custom gearbox-tuning action was still lost after 0.8.92. The separate ECU Lab radial insertion in 0.8.92/.90 still modifies the same CMS `!PartSelect` option array and cannot guarantee coexistence with another plugin's custom gearbox action.

## Change

- Removed the ECU Lab option insertion and all ECU-specific option handling from CMS radial menus.
- The ECU Lab sandbox now opens with **F9**, avoiding mutation or interception of the car-parts radial menu.
- Kept the engine-stand `Add forced induction` radial action.
- Kept the existing $3,500 one-time profile unlock and ECU Lab sandbox; it still does not write CMS ECU values or affect the game dyno.
- This is intentionally a safer interaction change; no CMS gearbox plugin code is altered.

## Verification

| Check | Result |
|---|---|
| C# build | PASS — plugin version 0.8.94 |
| Single-turbo dependency model | PASS — 5 assertions |
| ECU Lab simulation subset | PASS — 23 assertions against JavaScript reference values |
| Calibration schema | PASS — 9 assertions |
| Map evaluator | PASS — 8 assertions |
| Turbo size model | PASS — 14 assertions |
| Charge-air model | PASS — 11 assertions |
| Turbo operating-point model | PASS — 11 assertions |
| Offline source/game-signature/resource validator | PASS — 0.8.94 F9 routing and untouched car radial verified |
| CMS launch, gearbox option, F9 interaction, dyno or save/load | NOT RUN — requires user's live test |

## Expansion status

The independent single-turbo parts-and-connections validator from 0.8.93 remains included. It is a model-only prerequisite and is not yet connected to CMS-native installation or performance gating. Broader component registration, engine-specific install nodes, complete ECU map application, durability/failure, and persistent full-build state remain incomplete. See `docs/EXPANSION-STATUS.md`.

## Install status

Installed to the BepInEx plugins folder with the previous plugin backed up as `build/installed-backups/CMS18TurboPrototype-20261106-080249.dll`. Installed DLL SHA-256: `79ED4B95F11E91E6BEC2832FD8B9F98B5DFFD661427C2BAEE13E62ABE93FEF3A`. CMS was not launched. The gearbox fix is not declared live-confirmed until the user verifies the stock gearbox tuning action.

