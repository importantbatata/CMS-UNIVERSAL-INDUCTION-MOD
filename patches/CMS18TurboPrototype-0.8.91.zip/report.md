# Patch 0.8.91 — Route stock Tune parts radial action to ECU Lab

## Change

The reported dialog, **“There is no custom gearbox installed,”** is CMS's native response when the radial menu sends the click to its unavailable gearbox-tuning handler. Patch 0.8.91 intercepts the existing **Tune parts** radial action and opens the ECU Lab simulation sandbox instead. The custom duplicate radial action from 0.8.90 is no longer added.

The selected radial action is identified using the game's option key when it matches known Tune parts identifiers, or by the visible **Tune parts** label. The label fallback is included because the internal option key could not be verified from the supplied screenshot alone. The runtime log records the selected key and visible label for diagnosis if the game uses a different mapping.

## ECU Lab behavior

The panel remains the isolated ECU Lab simulation sandbox. Access still costs **$3,500 once per CMS profile**, charged only when the player confirms the unlock in the panel. It does not install an ECU, create a real calibration, or affect CMS engine power or dyno results.

## Verification

| Check | Result |
|---|---|
| Plugin build | PASS — version 0.8.91 |
| ECU Lab simulation reference checks | PASS — 23 assertions |
| Offline project validator | PASS — including the stock Tune parts interception source check |
| Installed plugin | PASS — installed to BepInEx/plugins; installed DLL hash matches build |
| Rollback copy | Saved under build/installed-backups/ before replacement |
| CMS launch and radial click | NOT RUN — game intentionally left closed; requires user's live test |
| Runtime Tune parts option-key mapping | UNVERIFIED until the live click is tested |

Built DLL SHA-256: 66371220C6A9D650F48331410ACFFEE14B275034A896BE740429B03BB875FCB3.

## Live test

1. Start CMS and open the same car radial menu shown in the screenshot.
2. Click the existing **Tune parts** icon.
3. Confirm the ECU Lab panel appears instead of the gearbox warning.
4. Confirm the panel's first screen offers the $3,500 profile unlock; no charge should occur merely from opening the radial panel.
5. If it still routes to the gearbox warning, send a screenshot and the latest BepInEx/LogOutput.log; the runtime diagnostic now records the selected option key and visible title.

## Files changed

- src/CMS18TurboPrototype.cs — intercepts the stock Tune parts action, updates its radial label/description, and opens the existing ECU Lab panel.
- tools/validate_build.ps1 — verifies the interception path and unlock behavior.
- build/CMS18TurboPrototype.dll — compiled 0.8.91 plugin.
- README.md — current patch status.
