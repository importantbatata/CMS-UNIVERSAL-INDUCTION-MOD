# CMS 2018 Turbo Prototype 0.8.91

Patch 0.8.91 routes the stock **Tune parts** car radial action to the ECU Lab simulation sandbox. It addresses the CMS message “There is no custom gearbox installed.” Access remains a one-time $3,500 profile unlock, confirmed inside the panel. The sandbox does not change CMS engine power or dyno results.

Install CMS18TurboPrototype.dll into Car Mechanic Simulator 2018/BepInEx/plugins/ while CMS is closed. See report.md for verification and the live-test steps. CMS was not launched for this patch.
