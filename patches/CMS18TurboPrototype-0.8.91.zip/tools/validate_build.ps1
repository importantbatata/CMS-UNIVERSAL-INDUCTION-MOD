param(
    [string]$GameRoot = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018',
    [switch]$SkipProfileIntegrityChecks
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$buildDll = Join-Path $projectRoot 'build\CMS18TurboPrototype.dll'
$installedDll = Join-Path $GameRoot 'BepInEx\plugins\CMS18TurboPrototype.dll'
$gameAssemblyPath = Join-Path $GameRoot 'cms2018_Data\Managed\Assembly-CSharp-firstpass.dll'
$cecilPath = Join-Path $GameRoot 'BepInEx\core\Mono.Cecil.dll'
$sourcePath = Join-Path $projectRoot 'src\CMS18TurboPrototype.cs'
$compatibilitySourcePath = Join-Path $projectRoot 'src\EngineCompatibilityCatalog.cs'
$turboModelSourcePath = Join-Path $projectRoot 'src\TurboPerformanceModel.cs'
$ecuCalibrationSourcePath = Join-Path $projectRoot 'src\EcuCalibrationSchema.cs'
$ecuMapEvaluatorSourcePath = Join-Path $projectRoot 'src\EcuMapEvaluator.cs'
$modelFiles = @(
    [pscustomobject]@{ Name='Turbocharger'; Resource='CMS18_Turbo_AddOn.obj'; Path=(Join-Path $projectRoot 'model\CMS18_Turbo_AddOn.obj') },
    [pscustomobject]@{ Name='Roots supercharger'; Resource='CMS18_Supercharger_AddOn.obj'; Path=(Join-Path $projectRoot 'model\CMS18_Supercharger_AddOn.obj') },
    [pscustomobject]@{ Name='P-1X-style ProCharger'; Resource='CMS18_ProCharger_P1X_AddOn.obj'; Path=(Join-Path $projectRoot 'model\CMS18_ProCharger_P1X_AddOn.obj') }
)
$embeddedModelFiles = @($modelFiles | Where-Object { $_.Name -eq 'P-1X-style ProCharger' })
$supportModels = @(
    (Join-Path $projectRoot 'model\CMS18_Turbo_Exhaust_Manifold.obj'),
    (Join-Path $projectRoot 'model\CMS18_Supercharger_Intake_Manifold.obj')
)

foreach ($path in @($buildDll, $installedDll, $gameAssemblyPath, $cecilPath, $sourcePath, $compatibilitySourcePath, $turboModelSourcePath, $ecuCalibrationSourcePath, $ecuMapEvaluatorSourcePath) + @($modelFiles | ForEach-Object { $_.Path }) + $supportModels) {
    if (-not (Test-Path -LiteralPath $path)) { throw "Required file is missing: $path" }
}

$validationCecilPath = Join-Path $env:TEMP 'CMS18TurboPrototype-Mono.Cecil.dll'
Copy-Item -LiteralPath $cecilPath -Destination $validationCecilPath -Force
Unblock-File -LiteralPath $validationCecilPath
Add-Type -Path $validationCecilPath

function Assert-Check {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw "FAIL: $Message" }
    Write-Host "PASS: $Message"
}

function Find-PluginVersion {
    param([Mono.Cecil.ModuleDefinition]$Module)
    $pluginType = $Module.Types | Where-Object { $_.FullName -eq 'CMS18TurboPrototype.TurboPrototypePlugin' } | Select-Object -First 1
    if ($null -eq $pluginType) { return $null }
    $attribute = $pluginType.CustomAttributes | Where-Object { $_.AttributeType.Name -eq 'BepInPlugin' } | Select-Object -First 1
    if ($null -eq $attribute -or $attribute.ConstructorArguments.Count -lt 3) { return $null }
    return [string]$attribute.ConstructorArguments[2].Value
}

function Assert-GameMethod {
    param([Mono.Cecil.ModuleDefinition]$Module,[string]$TypeName,[string]$MethodName,[string[]]$ParameterTypes)
    $type = $Module.Types | Where-Object { $_.FullName -eq $TypeName } | Select-Object -First 1
    if ($null -eq $type) { throw "FAIL: game type not found: $TypeName" }
    $matches = @($type.Methods | Where-Object {
        if ($_.Name -ne $MethodName -or $_.Parameters.Count -ne $ParameterTypes.Count) { return $false }
        for ($i = 0; $i -lt $ParameterTypes.Count; $i++) {
            if ($_.Parameters[$i].ParameterType.FullName -ne $ParameterTypes[$i]) { return $false }
        }
        return $true
    })
    Assert-Check ($matches.Count -eq 1) "$TypeName.$MethodName signature exists"
}

function Assert-GameField {
    param([Mono.Cecil.ModuleDefinition]$Module,[string]$TypeName,[string]$FieldName,[string]$FieldType)
    $type = $Module.Types | Where-Object { $_.FullName -eq $TypeName } | Select-Object -First 1
    if ($null -eq $type) { throw "FAIL: game type not found: $TypeName" }
    $matches = @($type.Fields | Where-Object { $_.Name -eq $FieldName -and $_.FieldType.FullName -eq $FieldType })
    Assert-Check ($matches.Count -eq 1) "$TypeName.$FieldName field has type $FieldType"
}

function Get-ObjSummary {
    param([string]$Path)
    $positionCount = 0
    $normalCount = 0
    $texCoordCount = 0
    $triangleCount = 0
    $invalid = $false
    $minimum = @([double]::PositiveInfinity, [double]::PositiveInfinity, [double]::PositiveInfinity)
    $maximum = @([double]::NegativeInfinity, [double]::NegativeInfinity, [double]::NegativeInfinity)
    $materials = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($line in [System.IO.File]::ReadLines($Path)) {
        $trimmed = $line.Trim()
        if ($trimmed.StartsWith('v ', [StringComparison]::Ordinal)) {
            $parts = [regex]::Split($trimmed, '\s+')
            if ($parts.Length -lt 4) { $invalid = $true; continue }
            for ($axis = 0; $axis -lt 3; $axis++) {
                try {
                    $coordinate = [double]::Parse($parts[$axis + 1], [Globalization.CultureInfo]::InvariantCulture)
                    if ($coordinate -lt $minimum[$axis]) { $minimum[$axis] = $coordinate }
                    if ($coordinate -gt $maximum[$axis]) { $maximum[$axis] = $coordinate }
                } catch { $invalid = $true }
            }
            $positionCount++
            continue
        }
        if ($trimmed.StartsWith('vn ', [StringComparison]::Ordinal)) { $normalCount++; continue }
        if ($trimmed.StartsWith('vt ', [StringComparison]::Ordinal)) { $texCoordCount++; continue }
        if ($trimmed.StartsWith('usemtl ', [StringComparison]::Ordinal)) {
            $parts = [regex]::Split($trimmed, '\s+')
            if ($parts.Length -gt 1) { [void]$materials.Add($parts[1]) }
            continue
        }
        if (-not $trimmed.StartsWith('f ', [StringComparison]::Ordinal)) { continue }
        $parts = [regex]::Split($trimmed, '\s+')
        if ($parts.Length -lt 4) { $invalid = $true; continue }
        $triangleCount += $parts.Length - 3
        for ($i = 1; $i -lt $parts.Length; $i++) {
            $indices = $parts[$i].Split('/')
            if ($indices.Length -lt 1 -or $indices.Length -gt 3 -or [string]::IsNullOrWhiteSpace($indices[0])) { $invalid = $true; break }
            try {
                $position = [int]::Parse($indices[0], [Globalization.CultureInfo]::InvariantCulture)
                $position = if ($position -gt 0) { $position - 1 } else { $positionCount + $position }
                if ($position -lt 0 -or $position -ge $positionCount) { $invalid = $true; break }
                if ($indices.Length -ge 2 -and -not [string]::IsNullOrWhiteSpace($indices[1])) {
                    $uv = [int]::Parse($indices[1], [Globalization.CultureInfo]::InvariantCulture)
                    $uv = if ($uv -gt 0) { $uv - 1 } else { $texCoordCount + $uv }
                    if ($uv -lt 0 -or $uv -ge $texCoordCount) { $invalid = $true; break }
                }
                if ($indices.Length -eq 3 -and -not [string]::IsNullOrWhiteSpace($indices[2])) {
                    $normal = [int]::Parse($indices[2], [Globalization.CultureInfo]::InvariantCulture)
                    $normal = if ($normal -gt 0) { $normal - 1 } else { $normalCount + $normal }
                    if ($normal -lt 0 -or $normal -ge $normalCount) { $invalid = $true; break }
                }
            }
            catch { $invalid = $true; break }
        }
    }
    return [pscustomobject]@{ Positions=$positionCount; Triangles=$triangleCount; Materials=$materials.Count; Dimensions=@(0..2 | ForEach-Object { $maximum[$_] - $minimum[$_] }); Invalid=$invalid }
}

$buildModule = [Mono.Cecil.ModuleDefinition]::ReadModule($buildDll)
$installedModule = [Mono.Cecil.ModuleDefinition]::ReadModule($installedDll)
$gameModule = [Mono.Cecil.ModuleDefinition]::ReadModule($gameAssemblyPath)
$selectionRaycast = $gameModule.Types | Where-Object { $_.FullName -eq 'Raycast' } | Select-Object -First 1
$selectionInit = if ($null -eq $selectionRaycast) { $null } else { $selectionRaycast.NestedTypes | Where-Object { $_.Name -match '<Init>' } | Select-Object -First 1 }
$selectionInitMoveNext = if ($null -eq $selectionInit) { $null } else { $selectionInit.Methods | Where-Object { $_.Name -eq 'MoveNext' } | Select-Object -First 1 }
$selectionMasksAreLayer16 = $false
if ($null -ne $selectionInitMoveNext -and $selectionInitMoveNext.HasBody) {
    $maskChecks = New-Object 'System.Collections.Generic.List[bool]'
    foreach ($fieldName in @('partSelectRaycastMask','partSelectMountRaycastMask')) {
        $fieldAssignedLayer16 = $false
        $instructions = $selectionInitMoveNext.Body.Instructions
        for ($i = 0; $i -lt $instructions.Count; $i++) {
            $instruction = $instructions[$i]
            if ($instruction.OpCode.Name -ne 'stfld' -or $instruction.Operand.Name -ne $fieldName) { continue }
            for ($j = $i - 1; $j -ge 0 -and $i - $j -le 3; $j--) {
                $candidate = $instructions[$j]
                if ($candidate.OpCode.Name -eq 'ldc.i4' -and [int]$candidate.Operand -eq 65536) {
                    $fieldAssignedLayer16 = $true
                    break
                }
            }
            if ($fieldAssignedLayer16) { break }
        }
        $maskChecks.Add($fieldAssignedLayer16)
    }
    $selectionMasksAreLayer16 = $maskChecks.Count -eq 2 -and $maskChecks[0] -and $maskChecks[1]
}
Assert-Check $selectionMasksAreLayer16 'CMS part-selection raycast masks are layer 16 in Assembly-CSharp-firstpass'
$selectionUsesDirectPartScript = $false
if ($null -ne $selectionRaycast) {
    $selectionUpdate = $selectionRaycast.Methods | Where-Object { $_.Name -eq 'Update' } | Select-Object -First 1
    if ($null -ne $selectionUpdate -and $selectionUpdate.HasBody) {
        $instructions = $selectionUpdate.Body.Instructions
        for ($i = 1; $i -lt $instructions.Count; $i++) {
            $called = $instructions[$i].Operand -as [Mono.Cecil.MethodReference]
            $previous = $instructions[$i - 1].Operand -as [Mono.Cecil.MethodReference]
            if ($null -eq $called -or $called.Name -ne 'GetComponent' -or $called.DeclaringType.FullName -ne 'UnityEngine.GameObject') { continue }
            if ($null -eq $previous -or $previous.Name -ne 'get_gameObject') { continue }
            if ($called.GetType().FullName -eq 'Mono.Cecil.GenericInstanceMethod' -and $called.GenericArguments.Count -eq 1 -and $called.GenericArguments[0].FullName -eq 'PartScript') {
                $selectionUsesDirectPartScript = $true
                break
            }
        }
    }
}
Assert-Check $selectionUsesDirectPartScript 'CMS selection resolves PartScript directly from the hit collider GameObject'
$nativePrefabGetter = $gameModule.Types | Where-Object { $_.FullName -eq 'GameInventory' } | Select-Object -First 1
$nativePrefabGetGo = if ($null -eq $nativePrefabGetter) { $null } else { $nativePrefabGetter.Methods | Where-Object { $_.Name -eq 'GetGO' -and $_.Parameters.Count -eq 1 } | Select-Object -First 1 }
$nativePrefabIsInstantiated = $false
if ($null -ne $nativePrefabGetGo -and $nativePrefabGetGo.HasBody) {
    foreach ($instruction in $nativePrefabGetGo.Body.Instructions) {
        $called = $instruction.Operand -as [Mono.Cecil.MethodReference]
        if ($null -ne $called -and $called.Name -eq 'Instantiate' -and $called.DeclaringType.FullName -eq 'UnityEngine.Object') {
            $nativePrefabIsInstantiated = $true
            break
        }
    }
}
Assert-Check $nativePrefabIsInstantiated 'GameInventory.GetGO returns an instantiated prefab, so its temporary model copy can be destroyed safely'
function Get-PluginTypeTree {
    param([Mono.Cecil.TypeDefinition]$Type)
    Write-Output $Type
    foreach ($nested in $Type.NestedTypes) { Get-PluginTypeTree $nested }
}
$legacyReflectionCalls = New-Object 'System.Collections.Generic.List[string]'
$reflectionTypesWithUnavailableComparisons = @(
    'System.Type', 'System.Reflection.FieldInfo', 'System.Reflection.MemberInfo',
    'System.Reflection.MethodBase', 'System.Reflection.MethodInfo', 'System.Reflection.PropertyInfo'
)
foreach ($topLevelType in $buildModule.Types) {
    foreach ($type in @(Get-PluginTypeTree $topLevelType)) {
        foreach ($method in $type.Methods) {
            if (-not $method.HasBody) { continue }
            foreach ($instruction in $method.Body.Instructions) {
                $called = $instruction.Operand -as [Mono.Cecil.MethodReference]
                if (-not [System.Object]::ReferenceEquals($called, $null) -and
                    @('op_Equality', 'op_Inequality') -contains $called.Name -and
                    $reflectionTypesWithUnavailableComparisons -contains $called.DeclaringType.FullName) {
                    $callName = '{0}.{1} -> {2}.{3}' -f $type.FullName, $method.Name,
                        $called.DeclaringType.FullName, $called.Name
                    $null = $legacyReflectionCalls.Add($callName)
                }
            }
        }
    }
}
Assert-Check ($legacyReflectionCalls.Count -eq 0) 'compiled IL avoids legacy Mono reflection comparison operators'
$unsupportedMonoStringCalls = New-Object 'System.Collections.Generic.List[string]'
foreach ($topLevelType in $buildModule.Types) {
    foreach ($type in @(Get-PluginTypeTree $topLevelType)) {
        foreach ($method in $type.Methods) {
            if (-not $method.HasBody) { continue }
            foreach ($instruction in $method.Body.Instructions) {
                $called = $instruction.Operand -as [Mono.Cecil.MethodReference]
                if (-not [System.Object]::ReferenceEquals($called, $null) -and $called.Name -eq 'IsNullOrWhiteSpace' -and $called.DeclaringType.FullName -eq 'System.String') {
                    $null = $unsupportedMonoStringCalls.Add($type.FullName + '.' + $method.Name)
                }
            }
        }
    }
}
Assert-Check ($unsupportedMonoStringCalls.Count -eq 0) 'compiled IL avoids Mono-incompatible System.String.IsNullOrWhiteSpace'
$systemActionTypeReferences = @($buildModule.GetTypeReferences() | Where-Object { $_.FullName -match '^System\.Action($|`)' })
Assert-Check ($systemActionTypeReferences.Count -eq 0) 'compiled plugin has no System.Action type references that can fail to load under CMS Mono'
$pluginTypeForCallback = $buildModule.Types | Where-Object { $_.FullName -eq 'CMS18TurboPrototype.TurboPrototypePlugin' } | Select-Object -First 1
$menuCallbackType = if ($pluginTypeForCallback -eq $null) { @() } else { @($pluginTypeForCallback.NestedTypes | Where-Object { $_.Name -eq 'MainMenuClickCallback' }) }
Assert-Check ($menuCallbackType.Count -eq 1) 'compiled plugin contains its local main-menu callback delegate'
$buildVersion = Find-PluginVersion $buildModule
$installedVersion = Find-PluginVersion $installedModule
$sourceText = Get-Content -LiteralPath $sourcePath -Raw
$compatibilitySourceText = Get-Content -LiteralPath $compatibilitySourcePath -Raw
$turboModelSourceText = Get-Content -LiteralPath $turboModelSourcePath -Raw
$sourceVersionMatch = [regex]::Match($sourceText, 'internal const string Version\s*=\s*"([^"]+)"')
Assert-Check ($sourceVersionMatch.Success -and $sourceVersionMatch.Groups[1].Value -eq $buildVersion) 'build DLL version matches the source version constant'
$usesVersionConstantForMetadata = $sourceText.Contains('[BepInPlugin("local.cms18.turboproto", "CMS 2018 Turbo Prototype", PluginInfo.Version)]')
$usesVersionConstantForStartupLog = $sourceText.Contains('" + PluginInfo.Version + " loaded for save profile "')
Assert-Check ($sourceVersionMatch.Success -and $sourceVersionMatch.Groups[1].Value -eq $buildVersion -and $usesVersionConstantForMetadata -and $usesVersionConstantForStartupLog) 'plugin metadata and startup log use the same version as the built DLL'
Assert-Check ($turboModelSourceText.Contains('new TurboPerformanceTier(35, 120, 220') -and
    $turboModelSourceText.Contains('new TurboPerformanceTier(45, 200, 350') -and
    $turboModelSourceText.Contains('new TurboPerformanceTier(55, 300, 550') -and
    $turboModelSourceText.Contains('new TurboPerformanceTier(62, 450, 750') -and
    $turboModelSourceText.Contains('new TurboPerformanceTier(67, 550, 950') -and
    $turboModelSourceText.Contains('new TurboPerformanceTier(76, 750, 1200') -and
    $turboModelSourceText.Contains('new TurboPerformanceTier(88, 1000, 1600') -and
    $turboModelSourceText.Contains('EstimatedMaxFlowLbPerMinute') -and
    $turboModelSourceText.Contains('AssumedPeakEfficiency') -and
    $turboModelSourceText.Contains('SpoolStartFraction') -and $turboModelSourceText.Contains('SpoolFullFraction')) 'turbo model contains seven estimated size tiers with distinct flow, efficiency, and spool parameters'
$turboSizePersistenceAndUi = $sourceText.Contains('GlobalTurboSizeKey') -and
    $sourceText.Contains('GroupTurboSizePrefix') -and $sourceText.Contains('CarTurboSizePrefix') -and
    $sourceText.Contains('MetaTurboSizeKey') -and $sourceText.Contains('ReadGroupTurboSize') -and
    $sourceText.Contains('DrawTurboSizeSelector') -and $sourceText.Contains('SetTurboInducerSize') -and
    $sourceText.Contains('TurboOperatingPointModel.Calculate(turboTier') -and
    $sourceText.Contains('operatingPoint.CompressorEfficiency') -and
    $sourceText.Contains('operatingPoint.ChargeAir')
Assert-Check $turboSizePersistenceAndUi 'turbo inducer selector is persisted by car and engine group and feeds the active torque model'
Assert-Check ($compatibilitySourceText.Contains('engine_r4') -and $compatibilitySourceText.Contains('I4 DOHC AQC') -and $compatibilitySourceText.Contains('TurboSpoolStartFraction') -and $sourceText.Contains('CalculateSpoolForCurrentEngine')) 'initial turbo profile targets the identified engine_r4 I4 and feeds sampled dyno spool calculations'
$p1xPipeAnchorMatchesOutlet = $sourceText.Contains('private static Vector3 ProchargerChargePipeOutlet') -and
    $sourceText.Contains('private static Vector3 ProchargerChargePipeDirection') -and
    $sourceText.Contains('modelTransform.TransformPoint(ProchargerChargePipeOutlet)') -and
    $sourceText.Contains('P-1X_2.62_inch_outlet_bore') -and
    $sourceText.Contains('P-1X_three-inch_outlet_bead') -and
    $sourceText.Contains('TryGetObjCircularPortGeometry')
Assert-Check ($p1xPipeAnchorMatchesOutlet -and $sourceText.Contains('ProchargerInletHoseMouth = new Vector3(0.168f, 0.000f, 0.000f);') -and $sourceText.Contains('modelTransform.TransformDirection(Vector3.right)')) 'P-1X charge-pipe socket is recovered from the actual OBJ port geometry'
$boostDialRepaintsOnly = $sourceText.Contains('Event.current.type != EventType.Repaint')
Assert-Check $boostDialRepaintsOnly 'decorative boost gauge skips non-repaint IMGUI events'
$pulleyAxisUsesPartOrientation = $sourceText.Contains('SmallestLocalBoundsAxis(localAxisSize, crankPulley.transform)') -and
    $sourceText.Contains('localToWorld.TransformDirection(localAxis)') -and
    $sourceText.Contains('engineTransform.InverseTransformDirection(pulleyAxisWorld)')
Assert-Check $pulleyAxisUsesPartOrientation 'induction mount orientation follows the crank pulley axis in engine-local space'
$pulleyGeometryUsesMeshBounds = $sourceText.Contains('TryGetPartLocalMeshBounds(crankPulley, out localPulleyBounds)') -and
    $sourceText.Contains('EstimatePulleyRadiusWorld(localPulleyBounds.size, crankPulley.transform)') -and
    $sourceText.Contains('private static bool TryGetPartLocalMeshBounds(PartScript part, out Bounds bounds)')
Assert-Check $pulleyGeometryUsesMeshBounds 'stand placement and installed belt geometry use local pulley mesh dimensions when available'
$chargePipeIsExplicitlyOpaque = $sourceText.Contains('material.renderQueue = 2000;') -and
    $sourceText.Contains('material.SetFloat("_ZWrite", 1.0f);') -and
    $sourceText.Contains('material.SetOverrideTag("RenderType", "Opaque");')
Assert-Check $chargePipeIsExplicitlyOpaque 'P-1X charge-pipe material is forced into the opaque render queue'
$partLayoutLogsUnmountedState = $sourceText.Contains('", unmounted=" + part.IsUnmounted()')
Assert-Check $partLayoutLogsUnmountedState 'fallback diagnostics record whether candidate engine parts are marked unmounted'
$actionRoutineWrapped = $sourceText.Contains('"ActionInsertEngineToCar", new Type[] { typeof(NewGroupItem) }, "InsertEnginePrefix", "InsertEnginePostfix"')
$swapRoutineWrapped = $sourceText.Contains('"SwapEngine", new Type[] { typeof(NewGroupItem) }, "SwapEnginePrefix", "SwapEnginePostfix"')
Assert-Check ($actionRoutineWrapped -and $swapRoutineWrapped) 'engine insert and engine swap coroutine completion paths are both wrapped'
$standUniversalMountHook = $sourceText.Contains('EnsureUniversalMountOnStand(game);') -and
    $sourceText.Contains('must exist even before the')
$standGetterDoesNotMutateOnRead = $sourceText.Contains('Patch(typeof(GameScript), "GetGroupOnEngineStand", Type.EmptyTypes, null, "StandGroupPostfix")')
$setEngineHook = $sourceText.Contains('Patch(typeof(CarLoader), "SetEngine", Type.EmptyTypes, null, "SetEnginePostfix")')
$sameEngineTransferGate = $sourceText.Contains('pendingHasUniversalMount = mode != InductionMode.Off') -and
    $sourceText.Contains('|| GroupContainsUniversalMount(group)') -and
    $sourceText.Contains('|| IsInductionPartId(groupKitId)') -and
    $sourceText.Contains('if (!IsInductionPartId(kitId)) kitId = KitIdForMode(pendingInstallMode);') -and
    $sourceText.Contains('if (!pendingHasUniversalMount || pendingSwapObserved || pendingInstallLoader == null || group == null) return;')
$swapTransferGate = $sourceText.Contains('if (!pendingSwapObserved || !pendingHasUniversalMount || pendingInstallGroup == null') -and
    $sourceText.Contains('loader != pendingInstallLoader')
$carScopedKitRestore = $sourceText.Contains('RestoreTransferredInductionKit(loader, group, carKey);') -and
    $sourceText.Contains('PlayerPrefs.GetString(PrefKey(InstalledKitModePrefix + carKey), String.Empty)') -and
    $sourceText.Contains('PlayerPrefs.SetString(PrefKey(InstalledKitModePrefix + carKey), kitId)')
Assert-Check ($standUniversalMountHook -and $standGetterDoesNotMutateOnRead -and $setEngineHook -and $sameEngineTransferGate -and $swapTransferGate -and $carScopedKitRestore) 'matching engine transfers use the current group or the car-specific installed-kit record'
$reducedPolling = $sourceText.Contains('private const float ContextRefreshSeconds = 3.0f;') -and
    $sourceText.Contains('private const float VisualRefreshSeconds = 4.0f;') -and
    $sourceText.Contains('nextContextRefresh = Time.unscaledTime + ContextRefreshSeconds;') -and
    $sourceText.Contains('nextVisualRefresh = Time.unscaledTime + VisualRefreshSeconds;')
Assert-Check $reducedPolling 'engine and visual scans use slower configurable refresh intervals'
$cachedUiArrays = $sourceText.Contains('private static readonly InductionMode[] ModeButtons') -and
    $sourceText.Contains('private static readonly float[] StandModeButtonWidths') -and
    $sourceText.Contains('private static readonly float[] GaugeModeButtonWidths') -and
    -not $sourceText.Contains('float[] widths = {')
Assert-Check $cachedUiArrays 'induction UI reuses button arrays instead of allocating them on every IMGUI event'
$nativePreviewCleanup = $sourceText.Contains('if (source != null) UnityEngine.Object.Destroy(source);') -and
    $sourceText.Contains('new string[] { "turbo_2" }') -and $sourceText.Contains('new string[] { "v8_supercharger" }') -and
    $sourceText.Contains('UnityEngine.Object.Instantiate(sourceMesh)') -and $sourceText.Contains('new Material(sourceMaterials[i])') -and
    $sourceText.Contains('CMS18OwnedVisualAssets')
Assert-Check $nativePreviewCleanup 'stock Turbo and Roots models are copied into mod-owned meshes and materials with lifecycle cleanup'
$mountedVisualLifecycle = $sourceText.Contains('AddUnmountVisibilityTargets(visualPartScript, visual.transform)') -and
    $sourceText.Contains('AddUnmountVisibilityTargets(existingPartScript, existingVisual)') -and
    $sourceText.Contains('captureRendererState && mode == InductionMode.Procharger') -and
    $sourceText.Contains('RemoveUnmountVisibilityTargets(partScript, visual)') -and
    $sourceText.Contains('visualRoot.GetComponentsInChildren<Renderer>(true)')
Assert-Check $mountedVisualLifecycle 'new and reused kit previews join CMS mount/unmount visibility without adding engine hardware to inventory previews'
$mountedNativeRenderersAreActionable = $sourceText.Contains('Renderer[] renderers = visualRoot.GetComponentsInChildren<Renderer>(true);') -and
    $sourceText.Contains('AddUnmountVisibilityTarget(partScript, renderer.gameObject);') -and
    $sourceText.Contains('RemoveUnmountVisibilityTarget(partScript, renderer.gameObject);')
Assert-Check $mountedNativeRenderersAreActionable 'copied multi-object native models register each renderer GameObject with CMS mount/unmount visibility'
$allInductionKitsRegistered = $sourceText.Contains('TurboKitPartId') -and $sourceText.Contains('SuperchargerKitPartId') -and
    $sourceText.Contains('UniversalMountPartId') -and $sourceText.Contains('MainShop", 12500') -and
    $sourceText.Contains('CMS18Internal') -and $sourceText.Contains('RegisterInductionProperty')
Assert-Check $allInductionKitsRegistered 'turbo, supercharger and P-1X kits are buyable and the universal mount stays hidden'
$completionBlock = [regex]::Match($sourceText, '(?s)private void CompleteEngineInstall\(CarLoader loader, NewGroupItem group\)(.*?)(?=\r?\n        private void AbortPendingInstall)')
$capturedInstallTargetOnly = $completionBlock.Success -and
    $completionBlock.Groups[1].Value.Contains('if (loader == null) loader = pendingInstallLoader;') -and
    -not $completionBlock.Groups[1].Value.Contains('FindActiveCarLoader')
Assert-Check $capturedInstallTargetOnly 'engine install completion requires the crane-captured or explicit swap loader and cannot bind another active car'
if ($installedVersion -eq $buildVersion) {
    # csc.exe stamps a fresh module MVID on each build, so byte hashes of two
    # builds from identical sources are not a reliable deployment comparison.
    # Compare against the archived release artifact and verify that its source
    # snapshot is the same as the active source tree instead.
    $releaseRoot = Join-Path $projectRoot (Join-Path ('build\release_' + $buildVersion) ('CMS18TurboPrototype-' + $buildVersion))
    $releaseDll = Join-Path $releaseRoot 'CMS18TurboPrototype.dll'
    $releaseSourcePaths = @(
        'src\CMS18TurboPrototype.cs',
        'src\EngineCompatibilityCatalog.cs',
        'src\TurboPerformanceModel.cs',
        'src\ChargeAirModel.cs',
        'src\TurboOperatingPointModel.cs',
        'src\EcuCalibrationSchema.cs',
        'src\EcuMapEvaluator.cs',
        'src\EcuLabSimulationCore.cs'
    )
    $releaseSourcesMatch = Test-Path -LiteralPath $releaseDll
    foreach ($relativePath in $releaseSourcePaths) {
        $activePath = Join-Path $projectRoot $relativePath
        $archivedPath = Join-Path $releaseRoot $relativePath
        if (-not (Test-Path -LiteralPath $activePath) -or -not (Test-Path -LiteralPath $archivedPath)) {
            $releaseSourcesMatch = $false
            break
        }
        $activeSourceHash = (Get-FileHash -LiteralPath $activePath -Algorithm SHA256).Hash
        $archivedSourceHash = (Get-FileHash -LiteralPath $archivedPath -Algorithm SHA256).Hash
        if ($activeSourceHash -ne $archivedSourceHash) {
            $releaseSourcesMatch = $false
            break
        }
    }
    if ($releaseSourcesMatch) {
        $releaseVersion = Find-PluginVersion ([Mono.Cecil.ModuleDefinition]::ReadModule($releaseDll))
        $installedHash = (Get-FileHash -LiteralPath $installedDll -Algorithm SHA256).Hash
        $releaseHash = (Get-FileHash -LiteralPath $releaseDll -Algorithm SHA256).Hash
        Assert-Check ($releaseVersion -eq $buildVersion -and $installedHash -eq $releaseHash) 'installed plugin matches the archived release DLL; active sources match that release (fresh-build MVID may differ)'
    } else {
        Write-Warning "Installed plugin version matches $buildVersion, but this version's archived release/source snapshot is unavailable or differs. Fresh-build byte hashes are not compared because csc.exe changes the module MVID."
    }
} else {
    Write-Warning "Installed game plugin is still version $installedVersion; version $buildVersion was built for review and was not installed."
}

foreach ($model in $embeddedModelFiles) {
    $resource = $buildModule.Resources | Where-Object { $_.Name -eq $model.Resource } | Select-Object -First 1
    Assert-Check ($null -ne $resource) "$($model.Name) OBJ is embedded in the plugin"
    $resourceHash = ([BitConverter]::ToString(([System.Security.Cryptography.SHA256]::Create()).ComputeHash($resource.GetResourceData()))).Replace('-', '')
    $modelHash = (Get-FileHash -LiteralPath $model.Path -Algorithm SHA256).Hash
    Assert-Check ($resourceHash -eq $modelHash) "$($model.Name) embedded model matches the source OBJ by SHA-256"
}
$stockVisualsAreNotEmbedded = @($buildModule.Resources | Where-Object {
    $_.Name -eq 'CMS18_Turbo_AddOn.obj' -or $_.Name -eq 'CMS18_Supercharger_AddOn.obj'
}).Count -eq 0
Assert-Check $stockVisualsAreNotEmbedded 'custom turbo and Roots OBJ models are excluded so the previews use stock CMS meshes'
foreach ($model in $modelFiles) {
    $summary = Get-ObjSummary $model.Path
    Assert-Check (-not $summary.Invalid -and $summary.Positions -gt 500 -and $summary.Triangles -gt 1000) "$($model.Name) OBJ geometry and face indices are valid ($($summary.Triangles) triangles)"
    Assert-Check ($summary.Materials -ge 3) "$($model.Name) OBJ has separate material groups"
}
$nativeModelsOnly = $sourceText.Contains('return TryCreateNativeInductionModel(mode);') -and
    $sourceText.Contains('new string[] { "turbo_2" }') -and $sourceText.Contains('new string[] { "v8_supercharger" }') -and
    $sourceText.Contains('inventory.GetGO(assetIds[i])') -and $sourceText.Contains('CopyNativeVisualNode') -and
    $sourceText.Contains('TryAttachNativeInductionVisual(partRoot, visualAnchor, captureRendererState, mode)') -and
    $sourceText.Contains('float physicalScale = GetPhysicalModelScale(mode, physicalBoundsSize);') -and
    $sourceText.Contains('Placed the installed native ' + '" + ModeName(mode) + " beside "') -and
    $sourceText.Contains('FindInductionPlacementCenter(engineRoot, mode,')
Assert-Check $nativeModelsOnly 'native turbo and Roots copies use the original CMS assets and are engine-scaled before side placement'
$nativeModelPositioning = $sourceText.Contains('sideHalf + modelHalfSide - 0.012f') -and
    $sourceText.Contains('engineRoot.right * Mathf.Max(0.0f,') -and
    $sourceText.Contains('engineRoot.up * Mathf.Max(-modelHalfUp * 0.35f, -targetHalfUp * 0.20f)') -and
    $sourceText.Contains('engineRoot.up * Mathf.Max(-modelHalfUp * 0.30f, -targetHalfUp * 0.18f)') -and
    $sourceText.Contains('ProjectedModelHalfExtent(sourceBounds, nativeScale, nativeWorldRotation, engineRoot.right)') -and
    $sourceText.Contains('engineRoot.rotation * source.transform.localRotation') -and
    $sourceText.Contains('Mathf.Clamp(targetWorldSize / largestDimension, 0.01f, 10.0f)')
Assert-Check $nativeModelPositioning 'stock turbo and Roots models mount beside the intake manifold instead of above the head, with measured side clearances'
$prochargerUsesAuthoredOrientation = $sourceText.Contains('Quaternion modelRotation = Quaternion.identity;') -and
    $sourceText.Contains('modelTransform.rotation = baseRotation;') -and
    -not $sourceText.Contains('Quaternion.Euler(0.0f, 180.0f, 0.0f)')
Assert-Check $prochargerUsesAuthoredOrientation 'P-1X display and pulley alignment use the authored model orientation without the block-side flip'
$intakeTargetRejectsExhaust = $sourceText.Contains('if (id.Contains("exhaust") || id.Contains("wydech")) continue;') -and
    $sourceText.Contains('id.Contains("kolektor_dolot")')
Assert-Check $intakeTargetRejectsExhaust 'charge pipes cannot select exhaust manifolds as their intake endpoint'
$compactChargePipe = $sourceText.Contains('BuildCompactChargePipeControlPoints(engineRoot, modelTransform, outletWorld, outletDirection,') -and
    $sourceText.Contains('float maxBow = Mathf.Min(0.16f, Mathf.Max(0.025f, distance * 0.45f));') -and
    $sourceText.Contains('TryFindClosestMeshSurface(intakeTarget, outletWorld') -and
    $sourceText.Contains('Vector3 outletDirection = modelTransform.TransformDirection(ProchargerChargePipeDirection).normalized') -and
    $sourceText.Contains('Mathf.Lerp(0.018f, fullOutletStub, outletAlignmentFactor)') -and
    $sourceText.Contains('outletAxisAlignment, pipeRadius * localScale + 0.006f') -and
    $sourceText.Contains('Vector3 intakeTangent = intakeDirection.sqrMagnitude') -and
    $sourceText.Contains('BuildHollowDuctMesh(p0, p1, p2, p3, pipeRadius, pipeInnerRadius, 20, 24)') -and
    $sourceText.Contains('Quaternion.FromToRotation(previousTangent, tangent) * previousNormal;') -and
    $sourceText.Contains('Built a routed P-1X charge-pipe connection to ') -and
    $sourceText.Contains('outlet stub ') -and
    -not $sourceText.Contains('BuildExteriorRouteControlPoints(engineRoot, outletWorld, targetWorld,')
Assert-Check $compactChargePipe 'P-1X charge pipe follows its authored outlet and intake, turns sooner when the outlet faces away, and uses a bounded rounded route'
$hookResolverHandlesPluginStatics = $sourceText.Contains('CreateHarmonyMethod(string methodName)') -and
    $sourceText.Contains('AccessTools.Method(typeof(TurboPrototypeHooks), methodName)') -and
    $sourceText.Contains('AccessTools.Method(typeof(TurboPrototypePlugin), methodName)') -and
    $sourceText.Contains('harmonyPatchFailures++')
Assert-Check $hookResolverHandlesPluginStatics 'startup resolves postfixes on either hook class and contains optional patch failures'
$mainMenuModsEntry = $sourceText.Contains('ConfigureMainMenuStyledButton(modsButton, "Mods", ToggleMainMenuModsPanel)') -and
    $sourceText.Contains('freshButton.onClick = new Button.ButtonClickedEvent();') -and
    $sourceText.Contains('Transform[] rowChildren = exitButton.transform.parent.GetComponentsInChildren<Transform>(true);') -and
    $sourceText.Contains('Array.IndexOf(horizontal.items, exitButton.gameObject)') -and
    $sourceText.Contains('normalizedItems.Insert(normalizedExitIndex, modsButton);') -and
    $sourceText.Contains('Array.IndexOf(mainMenuHorizontalItems.items, mainMenuModsButton) >= 0') -and
    $sourceText.Contains('if (modsSiblingIndex > exitSiblingIndex)') -and
    $sourceText.Contains('else if (modsSiblingIndex < exitSiblingIndex - 1)') -and
    $sourceText.Contains('Button freshButton = originalButton;')
Assert-Check $mainMenuModsEntry 'main-menu Mods button is registered once, avoids repeated layout rewrites, stays before Exit, and preserves Credits'
$modsRefreshBeforeGarageWork = $sourceText.Contains('try { EnsureMainMenuModsEntry(); }') -and
    $sourceText.Contains('Mods entry refresh failed: ') -and
    $sourceText.IndexOf('try { EnsureMainMenuModsEntry(); }', [StringComparison]::Ordinal) -lt
        $sourceText.IndexOf('if (Time.unscaledTime >= nextContextRefresh)', [StringComparison]::Ordinal)
Assert-Check $modsRefreshBeforeGarageWork 'main-menu Mods entry refresh runs before garage refreshes and reports failures'
$modsCallbackAvoidsSystemAction = $sourceText.Contains('private delegate void MainMenuClickCallback();') -and
    $sourceText.Contains('string objectName, string caption, MainMenuClickCallback onClick)') -and
    -not $sourceText.Contains('Action onClick') -and -not $sourceText.Contains('System.Action')
Assert-Check $modsCallbackAvoidsSystemAction 'main-menu button callbacks avoid Mono-incompatible System.Action plugin signatures'
$radialInductionUi = $sourceText.Contains('Patch(typeof(PieMenuController), "ReadOptionsFromIni", new Type[] { typeof(string) }, null, "InductionPieOptionsReadPostfix")') -and
    $sourceText.Contains('public static void InductionPieOptionsReadPostfix(PieMenuController __instance, string __0,') -and
    $sourceText.Contains('String.Equals(__0, "!EngineStand", StringComparison.Ordinal)') -and
    $sourceText.Contains('Added Add forced induction to the occupied engine-stand radial-menu options before stock icon creation.') -and
    $sourceText.Contains('PreviousValueFromIni') -and
    $sourceText.Contains('String.Equals(menuKey, "!EngineStand", StringComparison.Ordinal)') -and
    $sourceText.Contains('machineType == 5') -and
    $sourceText.Contains('NewGroupItem standGroup = game.GetGroupOnEngineStand();') -and
    $sourceText.Contains('bool hasEngine = plugin.standOccupied || standGroup != null;') -and
    $sourceText.Contains('Engine-stand radial diagnostic: key=') -and
    $sourceText.Contains('Added Add forced induction to the occupied engine-stand radial-menu options.') -and
    -not [regex]::IsMatch($sourceText, 'if\s*\(standOccupied\)\s*DrawStandPanel\(scale\)')
Assert-Check $radialInductionUi 'stand controls enter through the stock !EngineStand radial options without a persistent stand overlay'
$bepInExModsBrowser = $sourceText.Contains('BepInEx.Bootstrap.Chainloader.PluginInfos') -and
    $sourceText.Contains('ScrollRect') -and $sourceText.Contains('metadata.Name') -and
    $sourceText.Contains('metadata.Version') -and $sourceText.Contains('metadata.GUID') -and
    $sourceText.Contains('Input.GetKeyDown(KeyCode.Escape)')
Assert-Check $bepInExModsBrowser 'Mods panel lists loaded BepInEx plugin names, versions, and IDs in a scrollable panel with Escape close'
$mainMenuUiReferences = (Get-Content -LiteralPath (Join-Path $projectRoot 'build.ps1') -Raw).Contains("UnityEngine.UI.dll") -and
    (Get-Content -LiteralPath (Join-Path $projectRoot 'build.ps1') -Raw).Contains("UnityEngine.UIModule.dll")
Assert-Check $mainMenuUiReferences 'build includes the game UI assemblies used by the native-style Mods menu'
$p1xObj = Join-Path $projectRoot 'model\CMS18_ProCharger_P1X_AddOn.obj'
$p1xObjectNames = @([System.IO.File]::ReadLines($p1xObj) | Where-Object { $_.StartsWith('o ', [StringComparison]::Ordinal) })
$p1xRibCount = @($p1xObjectNames | Where-Object { $_ -match '^o P-1X_drive_pulley_rib_\d{2}$' }).Count
$p1xValleyCount = @($p1xObjectNames | Where-Object { $_ -match '^o P-1X_pulley_valley_\d{2}$' }).Count
Assert-Check ($p1xRibCount -eq 6 -and $p1xValleyCount -eq 5) 'ProCharger asset has six separate axial pulley ribs and five valleys'
$p1xMaterials = @{}
$activeP1xMaterialObject = ''
foreach ($line in [System.IO.File]::ReadLines($p1xObj)) {
    if ($line.StartsWith('o ', [StringComparison]::Ordinal)) { $activeP1xMaterialObject = $line.Substring(2); continue }
    if ($line.StartsWith('usemtl ', [StringComparison]::Ordinal)) { $p1xMaterials[$activeP1xMaterialObject] = $line.Substring(7) }
}
$billetAluminumParts = @('P-1X_cast_gearcase_shell','P-1X_drive_pulley','P-1X_mounting_ear_-1','P-1X_mounting_ear_1','P-1X_internal_5.56_inch_exducer_wheel_hub')
$billetAssignmentsValid = @($billetAluminumParts | Where-Object { $p1xMaterials[$_] -ne 'Machined_aluminum' }).Count -eq 0
$steelFastenersValid = $p1xMaterials['P-1X_gearcase_cover_bolt_00'] -eq 'Steel' -and $p1xMaterials['P-1X_compressor_cover_bolt_00'] -eq 'Steel'
Assert-Check ($billetAssignmentsValid -and $steelFastenersValid) 'P-1X billet gearcase, pulley, brackets and impeller use aluminum while hardware uses steel'
$p1xMeasureNames = @(
    'P-1X_outer_case_seam',
    'P-1X_3.75_inch_inlet_hose_neck',
    'P-1X_drive_pulley_rib_00',
    'P-1X_3.57_inch_inducer_main_vane_00',
    'P-1X_internal_5.56_inch_exducer_wheel_blade_00'
)
$p1xVertices = @{}
foreach ($objectName in $p1xMeasureNames) { $p1xVertices[$objectName] = [System.Collections.Generic.List[double[]]]::new() }
$activeP1xObject = ''
foreach ($line in [System.IO.File]::ReadLines($p1xObj)) {
    if ($line.StartsWith('o ', [StringComparison]::Ordinal)) { $activeP1xObject = $line.Substring(2); continue }
    if (-not $p1xVertices.ContainsKey($activeP1xObject) -or -not $line.StartsWith('v ', [StringComparison]::Ordinal)) { continue }
    $parts = [regex]::Split($line.Trim(), '\s+')
    $point = [double[]]::new(3)
    for ($axis = 0; $axis -lt 3; $axis++) {
        $point[$axis] = [double]::Parse($parts[$axis + 1], [Globalization.CultureInfo]::InvariantCulture)
    }
    $p1xVertices[$activeP1xObject].Add($point)
}
$seamPoints = $p1xVertices['P-1X_outer_case_seam']
$inletPoints = $p1xVertices['P-1X_3.75_inch_inlet_hose_neck']
$ribPoints = $p1xVertices['P-1X_drive_pulley_rib_00']
$inducerPoints = $p1xVertices['P-1X_3.57_inch_inducer_main_vane_00']
$exducerPoints = $p1xVertices['P-1X_internal_5.56_inch_exducer_wheel_blade_00']
Assert-Check ($seamPoints.Count -gt 0 -and $inletPoints.Count -gt 0 -and $ribPoints.Count -gt 0 -and $inducerPoints.Count -gt 0 -and $exducerPoints.Count -gt 0) 'P-1X housing, inlet, pulley and compressor wheels export as separate measurable objects'
$seamY = @($seamPoints | ForEach-Object { $_[1] })
$seamZ = @($seamPoints | ForEach-Object { $_[2] })
$seamDiameterInches = [Math]::Max((($seamY | Measure-Object -Maximum).Maximum - ($seamY | Measure-Object -Minimum).Minimum), (($seamZ | Measure-Object -Maximum).Maximum - ($seamZ | Measure-Object -Minimum).Minimum)) * 0.4 * 39.3700787
$inletRadii = @($inletPoints | ForEach-Object { [Math]::Sqrt($_[1] * $_[1] + $_[2] * $_[2]) })
$inletBoreInches = 2 * ($inletRadii | Measure-Object -Minimum).Minimum * 0.4 * 39.3700787
$ribRadii = @($ribPoints | ForEach-Object { $dz = $_[2] + 0.095; [Math]::Sqrt($_[1] * $_[1] + $dz * $dz) })
$ribDiameterInches = 2 * ($ribRadii | Measure-Object -Maximum).Maximum * 0.4 * 39.3700787
$inducerRadii = @($inducerPoints | ForEach-Object { [Math]::Sqrt($_[1] * $_[1] + $_[2] * $_[2]) })
$inducerDiameterInches = 2 * ($inducerRadii | Measure-Object -Maximum).Maximum * 0.4 * 39.3700787
$exducerRadii = @($exducerPoints | ForEach-Object { [Math]::Sqrt($_[1] * $_[1] + $_[2] * $_[2]) })
$exducerDiameterInches = 2 * ($exducerRadii | Measure-Object -Maximum).Maximum * 0.4 * 39.3700787
Assert-Check ([Math]::Abs($seamDiameterInches - 9.0) -le 0.03) ('exported P-1X outer seam measures {0:F3} inches against the 9-inch target' -f $seamDiameterInches)
Assert-Check ([Math]::Abs($inletBoreInches - 3.75) -le 0.01) ('exported P-1X inlet bore measures {0:F3} inches against the 3.75-inch target' -f $inletBoreInches)
Assert-Check ([Math]::Abs($ribDiameterInches - 3.528) -le 0.02) ('exported P-1X pulley-rib diameter measures {0:F3} inches' -f $ribDiameterInches)
Assert-Check ([Math]::Abs($inducerDiameterInches - 3.57) -le 0.02) ('exported P-1X inducer measures {0:F3} inches against the 3.57-inch target' -f $inducerDiameterInches)
Assert-Check ([Math]::Abs($exducerDiameterInches - 5.56) -le 0.02) ('exported P-1X exducer measures {0:F3} inches against the 5.56-inch target' -f $exducerDiameterInches)
Assert-Check ($sourceText.Contains('private const float ProchargerModelUnitScale = 0.40f;') -and $sourceText.Contains('if (mode == InductionMode.Procharger) return ProchargerModelUnitScale;')) 'P-1X runtime scale preserves the model unit conversion used by the 9-inch and 3.75-inch geometry checks'
Assert-Check ($sourceText.Contains('ReflectionProbeUsage.BlendProbesAndSkybox') -and $sourceText.Contains('LightProbeUsage.BlendProbes') -and $sourceText.Contains('ConfigureInductionRenderer(renderer);')) 'custom induction renderers explicitly use the scene reflection and light probes'
Assert-Check ($sourceText.Contains('ConfigureOpaqueStandardMaterial(material);') -and $sourceText.Contains('material.SetOverrideTag("RenderType", "Opaque")') -and $sourceText.Contains('material.renderQueue = 2000;')) 'custom model materials stay fully opaque and receive standard-specular reflections'
Assert-Check ($sourceText.Contains('name == "Bright_cast_compressor_aluminum") return 0.96f;') -and $sourceText.Contains('name == "Machined_aluminum") return 0.94f;')) 'P-1X cast and machined aluminum use separate polished-metal smoothness values'
foreach ($path in $supportModels) {
    $summary = Get-ObjSummary $path
    Assert-Check (-not $summary.Invalid -and $summary.Triangles -gt 300) "$(Split-Path -Leaf $path) is a valid manifold model ($($summary.Triangles) triangles)"
}

$sourceText = Get-Content -LiteralPath $sourcePath -Raw
Assert-Check ([regex]::Matches($sourceText, 'System\.Object\.ReferenceEquals\(field, null\)').Count -ge 3 -and $sourceText.Contains('System.Object.ReferenceEquals(original, null)')) 'reflection null guards avoid missing Mono op_Equality methods'
Assert-Check ($sourceText.Contains('BuildLegacyGroupKey') -and $sourceText.Contains('TryReadStoredGroupSettings')) 'stand settings use stable group keys and migrate previous keys'
Assert-Check ($sourceText.Contains('FindActiveCarLoader') -and $sourceText.Contains('"vpVehicleController"') -and $sourceText.Contains('"carLoader"')) 'active car lookup follows the setup component controller/loader link'
Assert-Check ($sourceText.Contains('dynoTorqueSampling') -and $sourceText.Contains('CalculateSpoolForSample')) 'dyno chart torque samples compute boost spool from sample RPM and throttle'
Assert-Check ($sourceText.Contains('CalculatePowerInKw') -and $sourceText.Contains('ApplyPower') -and $sourceText.Contains('CalculateInductionTorqueDelta')) 'boosted dyno power uses the same sampled torque gain as the torque curve'
Assert-Check ($sourceText.Contains('EngineSpecs is intentionally not patched') -and $sourceText.Contains('Patch(typeof(CarEngineHelper), "DrawPowerTorqueChart"') -and $sourceText.Contains('dynoTorqueSampling') -and -not $sourceText.Contains('Patch(typeof(VehiclePhysics.Engine), "GetEngineSpecifications"')) 'factory engine specifications stay untouched while dyno torque samples are scoped to the active chart'
Assert-Check ($sourceText.Contains('if (!System.Object.ReferenceEquals(plugin, null)) plugin.ApplyTorque') -and $sourceText.Contains('if (!System.Object.ReferenceEquals(plugin, null)) plugin.ApplyPower')) 'torque and power Harmony hooks use reference checks that work with isolated Unity plugin fixtures'
Assert-Check ($sourceText.Contains('EnsureUiStyles') -and $sourceText.Contains('GUI.skin.button') -and $sourceText.Contains('uiSelectedButtonStyle')) 'custom control styles keep the induction panels visually consistent'
Assert-Check ($sourceText.Contains('private void OpenInductionChooser()') -and $sourceText.Contains('Cursor.lockState = CursorLockMode.None;') -and $sourceText.Contains('Cursor.visible = true;') -and $sourceText.Contains('private void LateUpdate()') -and $sourceText.Contains('KeepChooserCursorAvailable();')) 'radial chooser forces an unlocked visible cursor through LateUpdate and IMGUI'
Assert-Check ($sourceText.Contains('private void CloseInductionChooser()') -and $sourceText.Contains('Cursor.lockState = chooserPreviousCursorLockState;') -and $sourceText.Contains('Cursor.visible = chooserPreviousCursorVisible;') -and $sourceText.Contains('CloseInductionChooser();')) 'chooser restores the prior cursor lock and visibility on every close and plugin shutdown'
Assert-Check ($sourceText.Contains('Patch(typeof(Cursor3D), "Update", Type.EmptyTypes, "Cursor3DUpdatePrefix", null);') -and $sourceText.Contains('public static bool Cursor3DUpdatePrefix()') -and $sourceText.Contains('return plugin == null || (!plugin.showInductionChooser && !plugin.showEcuLabPanel);')) 'CMS virtual cursor update is paused while a custom chooser owns mouse input'
$ecuLabRadialUnlock = $sourceText.Contains('private const string OpenEcuLabPieOption = "cms18_open_ecu_lab";') -and
    $sourceText.Contains('if (partSelectMenu) return;') -and
    $sourceText.Contains('IsEcuLabRadialSelection(selectedOption, visibleTitle)') -and
    $sourceText.Contains('String.Equals(title, "Tune parts", StringComparison.OrdinalIgnoreCase)') -and
    $sourceText.Contains('plugin.OpenEcuLabPanel();') -and
    $sourceText.Contains('private const int EcuLabUnlockPrice = 3500;') -and
    $sourceText.Contains('GlobalData.AddPlayerMoney(-EcuLabUnlockPrice);') -and
    $sourceText.Contains('GlobalData.AddPlayerMoney(EcuLabUnlockPrice);') -and
    $sourceText.Contains('PlayerPrefs.SetInt(PrefKey(EcuLabUnlockedKey), 1);') -and
    $sourceText.Contains('Intercepted the stock Tune parts radial action') -and
    $sourceText.Contains('no CMS ECU write or dyno effect')
Assert-Check $ecuLabRadialUnlock 'stock Tune parts radial action launches ECU Lab sandbox with a one-time $3,500 profile unlock instead of the unavailable gearbox handler'
Assert-Check ($sourceText.Contains('chooserPreviousGameCursorVisible = IsGameCursorGraphicVisible(chooserGameCursor);') -and $sourceText.Contains('chooserGameCursor.ShowCursor(false);') -and $sourceText.Contains('chooserGameCursor.ShowCursor(chooserPreviousGameCursorVisible);')) 'CMS cursor graphic is hidden only for the dialog and restored to its prior state afterward'
Assert-Check ($sourceText.Contains('GetUiScale') -and $sourceText.Contains('Screen.width - width')) 'control panels scale and anchor relative to the current screen'
Assert-Check ($nativeModelsOnly -and $sourceText.Contains('BuildInductionModelAsset(InductionMode.Procharger')) 'only the ProCharger uses a custom mesh; turbo and supercharger use original CMS game models'
Assert-Check ($sourceText.Contains('TryDetectMountedInduction') -and $sourceText.Contains('ClassifyNativePartId') -and $sourceText.Contains('activeHasNativeInduction')) 'mounted native shop parts select boost mode and prevent duplicate visual overlays'
Assert-Check ($sourceText.Contains('RefreshProfileContext') -and $sourceText.Contains('Logger.LogInfo(status);')) 'profile-selection transitions are written to the runtime log after startup'
Assert-Check ($sourceText.Contains('inventory.GetGO(assetIds[i])') -and $sourceText.Contains('CopyNativeVisualNode')) 'turbo and supercharger stand previews first reuse native CMS meshes'
Assert-Check ($sourceText.Contains('FindStandProchargerMount') -and $sourceText.Contains('TryCreateStandProchargerPreview') -and $sourceText.Contains('standPreviewRendererStates.Clear()') -and $sourceText.Contains('visualRoot.GetComponentsInChildren<Renderer>(true), mount.transform') -and $sourceText.Contains('if (mountedVisual != null) UpdateMountedInductionSelectionCollider(partScript, mountedVisual);') -and $sourceText.Contains('if (universalMount)') -and $sourceText.Contains('hitbox = partScript.GetComponent<BoxCollider>();')) 'stand and car selection hitboxes cover the complete P-1X renderer bounds'
Assert-Check ($sourceText.Contains('ScoreCrankPulleyCandidate') -and $sourceText.Contains('kolo_pasowe') -and $sourceText.Contains('walu')) 'P-1X belt placement recognizes Polish crank-pulley part IDs'
Assert-Check ($sourceText.Contains('FindIntakeConnectionTarget') -and $sourceText.Contains('TryFindClosestMeshSurface') -and $sourceText.Contains('Connected the P-1X charge pipe')) 'P-1X drive hardware follows the actual engine intake surface'
Assert-Check ($sourceText.Contains('FindAirFilterConnectionTarget') -and $sourceText.Contains('BuildHollowDuctMesh') -and $sourceText.Contains('ProchargerInletHoseInnerDiameterMeters = 0.09525f;') -and $sourceText.Contains('ProchargerInletHoseWallThicknessMeters = 0.004f;') -and $sourceText.Contains('GetProchargerInletHoseMaterial')) 'P-1X inlet has generated hollow 3D rubber duct geometry with a 3.75-inch bore and visible clamps'
Assert-Check ($sourceText.Contains('triangles[triangleIndex++] = a; triangles[triangleIndex++] = b; triangles[triangleIndex++] = d;') -and $sourceText.Contains('GetProchargerChargePipeMaterial') -and $sourceText.Contains('material.SetOverrideTag("RenderType", "Opaque")')) 'P-1X charge pipe has outward-facing mesh normals and an opaque reflective material'
Assert-Check ($sourceText.Contains('ProchargerChargePipeOuterRadiusModel') -and $sourceText.Contains('ProchargerChargePipeInnerRadiusModel') -and $sourceText.Contains('TryGetObjCircularPortGeometry(sourcePositions, outletBeadPositionIndices')) 'P-1X charge-pipe diameter and bore are measured from the modeled outlet bead and bore'
Assert-Check ($sourceText.Contains('AddChargePipeClamp(modelTransform, p0, p1, p2, p3, 0.075f') -and $sourceText.Contains('AddChargePipeClamp(modelTransform, p0, p1, p2, p3, 0.925f') -and $sourceText.Contains('ProchargerChargePipeClampWidthMeters = 0.010f;')) 'charge pipe has metal coupler bands at both the blower and intake connections'
Assert-Check ($p1xRibCount -eq 6 -and $sourceText.Contains('ProchargerDriveBeltWidthMeters = 0.0213f;') -and $sourceText.Contains('ProchargerDriveBeltThicknessMeters = 0.0034f;') -and $sourceText.Contains('ProchargerDriveBeltWidthMeters * 0.5f / modelScale')) 'drive belt thickness and width match the six-rib P-1X pulley'
Assert-Check ($sourceText.Contains('Bright_cast_compressor_aluminum') -and $sourceText.Contains('name == "Bright_cast_compressor_aluminum") return 0.96f;') -and $sourceText.Contains('name == "Machined_aluminum") return 0.94f;') -and $sourceText.Contains('renderer.reflectionProbeUsage = UnityEngine.Rendering.ReflectionProbeUsage.BlendProbesAndSkybox;') -and $sourceText.Contains('material.SetFloat("_Glossiness", 0.92f);')) 'P-1X aluminum and tubing use stronger polished-metal response with scene reflection probes'
Assert-Check ($sourceText.Contains('CreateProchargerShopProperty') -and $sourceText.Contains('AddToPartPropertyList') -and $sourceText.Contains('ProchargerPartId')) 'custom ProCharger is registered as a distinct Main Shop engine product'
Assert-Check (([regex]::Matches($sourceText, 'int\[\] dlc = new int\[\] \{ 0 \};').Count -ge 3) -and -not $sourceText.Contains('int[] dlc = new int[0];')) 'all custom shop products carry the verified base-game DLC sentinel required for visible shop cards'
Assert-Check ($sourceText.Contains('"IsTuning", new Type[] { typeof(string), typeof(string) }, "InductionIsTuningPrefix"') -and $sourceText.Contains('IsProchargerCompatibleSlot') -and $sourceText.Contains('UniversalMountPartId') -and $sourceText.Contains('partMode != InductionMode.Procharger')) 'all three kits use the universal mount, with P-1X blocked from the turbo exhaust slot'
Assert-Check ($sourceText.Contains('SetPartField(part, "canUnmountSingle", true)') -and $sourceText.Contains('CMS18 Universal Induction Mount')) 'universal mount is selectable and uses a readable in-game name'
 $selectableLayerUsesCmsMask = $sourceText.Contains('private const int PartSelectionLayer = 16;') -and
    $sourceText.Contains('sourceName = "CMS part-selection raycast layer 16";') -and
    $sourceText.Contains('return PartSelectionLayer;')
Assert-Check $selectableLayerUsesCmsMask 'virtual mount collider uses the confirmed CMS part-selection layer'
$universalMountLocalizedName = $sourceText.Contains('partMouseOver') -and
    $sourceText.Contains('ModeForInductionPartId') -and
    $sourceText.Contains('Universal Induction Mount') -and
    $sourceText.Contains('ProCharger Mount Bracket')
Assert-Check $universalMountLocalizedName 'universal mount uses a clear shared-kit name while recognizing its older saved alias'
$virtualMountOneClickRemoval = ($sourceText.Contains('SetPartField(part, "oneClickUnmount", true);') -and
    $sourceText.Contains('SetPartField(part, "MountObjects", new MountObject[0]);') -and
    $sourceText.Contains('StartsWith("CMS18 Induction Mount Bolt ", StringComparison.Ordinal)') -and
    -not $sourceText.Contains('AddVirtualMountBoltHeads(anchor)'))
Assert-Check $virtualMountOneClickRemoval 'internal mount removes in one click without synthetic bolts or stray unscrew targets'
$postTransferMountPlacement = ($sourceText.Contains('PositionUniversalMountNearDrivePulley(engine, mount.transform);') -and
    $sourceText.Contains('private static GameObject FindEngineContainer(GameObject part)') -and
    $sourceText.Contains('target = FindEngineContainer(candidate);'))
Assert-Check $postTransferMountPlacement 'virtual mount is attached to the engine container and repositioned after full assembly'
Assert-Check ($sourceText.Contains('BuildProchargerBeltMesh') -and $sourceText.Contains('CreateProchargerDrivePulley') -and $sourceText.Contains('AddProchargerBracketStrut') -and $sourceText.Contains('using estimated crank-pulley position')) 'P-1X visual includes belt, tensioner, crank-pulley alignment and mounting brackets'
Assert-Check ($sourceText.Contains('GetCurrentUniversalMountDisplayName') -and $sourceText.Contains('InductionIOLocalizedNamePostfix') -and $sourceText.Contains('Patch(typeof(GameInventory), "GetIOLocalizedName"')) 'a tuned universal mount reports its selected turbo, supercharger or ProCharger name'
Assert-Check ($sourceText.Contains('P1XMaxBoostPsi = 32.0f') -and $sourceText.Contains('P1XMaxFlowCfm = 1275.0f') -and $sourceText.Contains('P1XMaxImpellerRpm = 65000.0f') -and $sourceText.Contains('P1XInternalStepUpRatio = 4.10f') -and $sourceText.Contains('CalculateP1XBoostPsi')) 'P-1X pressure model uses published flow, boost, speed and gear-ratio ratings'
Assert-Check ($sourceText.Contains('CalculateManifoldGaugePsi') -and $sourceText.Contains('BoostGaugeMinimumPsi = -10.0f') -and $sourceText.Contains('MANIFOLD PRESSURE') -and $sourceText.Contains('DrawBoostDial')) 'boost meter shows a manifold-pressure dial with vacuum and positive boost'
Assert-Check ($sourceText.Contains('EstimatedHorsepowerPerLbPerMinute = 10.0f') -and $sourceText.Contains('SeaLevelAirDensityLbPerCubicFoot = 0.076f') -and $sourceText.Contains('Estimated airflow')) 'display labels airflow and horsepower as estimates using sea-level reference data'
Assert-Check ($sourceText.Contains('IsValidProchargerShopTemplate') -and -not $sourceText.Contains('turboTemplate.SpecialGroup == 0')) 'native turbo_2 SpecialGroup 0 does not block shop registration'
Assert-Check ($sourceText.Contains('FindObjectsOfType<GameInventory>()') -and $sourceText.Contains('candidate.IsReady && HasPartPropertyList(candidate)') -and $sourceText.Contains('HasValidTurboTemplate(candidate)') -and $sourceText.Contains('InductionShopGetItemsPostfix') -and $sourceText.Contains('GetItemProperty returns an unregistered placeholder')) 'shop registration uses an initialized catalog and valid stock turbo template without requiring the stuck parts-ready flag'
Assert-Check ($sourceText.Contains('public static bool InductionTunePartPrefix') -and $sourceText.Contains('if (IsInductionPartId(__0))') -and $sourceText.Contains('__result = true;') -and $sourceText.Contains('return false;')) 'custom induction IDs bypass vanilla TunePart catalog assumptions that caused the saved-car load exception'
Assert-Check ($sourceText.Contains('ProchargerPartId,') -and $sourceText.Contains('"ProCharger P-1X", "ProCharger", "MainShop", 12500') -and $sourceText.Contains('ProchargerHighBoostPartId,') -and $sourceText.Contains('"ProCharger P-1X High-Boost (32 PSI)", "ProCharger", "TuningShop", 24900')) 'standard P-1X is a $12,500 Main Shop item and the $24,900 high-boost P-1X is a Tuning Shop item'
Assert-Check ($sourceText.Contains('P1XStreetMaxBoostPsi = 20.0f') -and $sourceText.Contains('P1XHighBoostDefaultPsi = 24.0f') -and $sourceText.Contains('P1XMaxBoostPsi = 32.0f') -and $sourceText.Contains('ClampP1XTorqueDelta') -and $sourceText.Contains('P1XMaxSuperchargedHp / (rpm * horsepowerPerNewtonMeterAtRpm)')) 'high-boost P-1X can target more boost and power while staying within its published 950 hp rating'
Assert-Check ($sourceText.Contains('InductionGetGOPrefix') -and $sourceText.Contains('GetGO(ProchargerBasePartId)') -and $sourceText.Contains('InductionGetGO2Prefix') -and $sourceText.Contains('GetGO2(ProchargerBasePartId)') -and $sourceText.Contains('ConfigureInductionPart')) 'all custom kit previews reuse the stock turbo prefab and swap in their own model'
Assert-Check ($sourceText.Contains('Patch(typeof(PartScript), "TunePart"') -and $sourceText.Contains('NormalizeInductionTuneId') -and $sourceText.Contains('InductionTunePartPostfix')) 'custom tune IDs resolve to a stock resource prefab and restore their custom saved ID'
Assert-Check ($sourceText.Contains('Patch(typeof(Inventory), "GetItems", new Type[] { typeof(string) }, null, "InductionInventoryGetItemsPostfix")') -and $sourceText.Contains('ShouldHideUniversalMountFromSelector')) 'the internal universal mount is filtered out of its own replacement selector'
Assert-Check ($sourceText.Contains('private const int PartSelectionLayer = 16;') -and $sourceText.Contains('return PartSelectionLayer;')) 'the virtual mount collider uses the confirmed CMS part-selection layer'
$unconditionalTransferRestore = [regex]::IsMatch($sourceText, 'PlayerPrefs\.Save\(\);\s*\}\s*// Visual reattachment is safe after the[\s\S]*?RestoreTransferredInductionKit\(loader, group, carKey\);')
Assert-Check ($sourceText.Contains('FindInductionKitId(group)') -and $unconditionalTransferRestore -and $sourceText.Contains('InstalledKitModePrefix + carKey') -and $sourceText.Contains('ConfigureMountedInductionPart(mount, kitId)') -and $sourceText.Contains('Restored the " + kitId + " visual and mount on car')) 'transferred kit visuals restore even when plate identity is not ready; only persistence requires a stable car key'
Assert-Check ($sourceText.Contains('ReconcileTransferredInductionKit(loader, group, carKey)') -and $sourceText.Contains('currentCarKey, expectedCarKey') -and $sourceText.Contains('Post-transfer induction check finished for car')) 'brief post-transfer reconciliation reattaches only on the same plate-identified car if CMS replaces the engine object'
Assert-Check ($sourceText.Contains('plugin.StartCoroutine(plugin.RestoreInstalledKitAfterCarLoad(__instance))') -and $sourceText.Contains('FindMountedInductionPart(engine, kitId)') -and $sourceText.Contains('EnsureUniversalMount(engine, carKey)') -and $sourceText.Contains('PrepareUniversalMountForInstalledKit(engine, mount)') -and $sourceText.Contains('SetPartField(mount, "unmounted", false)') -and $sourceText.Contains('colliders[i].enabled = true') -and $sourceText.Contains('mountedVisualModes.TryGetValue(partKey, out previousMode)') -and $sourceText.Contains('previousMode != mode')) 'car reload restores a mounted kit and reactivates the runtime mount after CMS marks it unmounted'
Assert-Check ($sourceText.Contains('InductionShopThumbPostfix') -and $sourceText.Contains('InductionShopNamePostfix')) 'each induction kit receives a stock shop icon and readable item name'
Assert-Check ($sourceText.Contains('Patch(typeof(UIManager), "CreateShop", Type.EmptyTypes, "ShopCreatePrefix", null)') -and $sourceText.Contains('EnsureShopCatalogReady') -and $sourceText.Contains('!IsInductionPartId(__0) && !IsInductionPartId(__1)')) 'shop registration runs before the catalog is built and internal mounts cannot match ordinary replacement parts'
Assert-Check ($sourceText.Contains('IsInductionPartId(__0)') -and $sourceText.Contains('ModeForInductionPartId') -and $sourceText.Contains('IsCustomPartId')) 'all custom kit hooks accept numeric engine-slot suffixes'
Assert-Check ($sourceText.Contains('uiTextures.Clear()')) 'generated interface textures are released when the plugin shuts down'
Assert-Check ($sourceText.Contains('UnityEngine.Rendering.IndexFormat.UInt32')) 'runtime OBJ mesh uses 32-bit indices for model safety'

Assert-GameMethod $gameModule 'VehiclePhysics.Engine' 'CalculateTorque' @('System.Single', 'System.Single')
Assert-GameMethod $gameModule 'VehiclePhysics.Engine' 'CalculatePowerInKw' @('System.Single')
Assert-Check ($sourceText.Contains('IsPartAccessible') -and $sourceText.Contains('InductionIsPartAccessiblePrefix') -and $sourceText.Contains('__result = true;')) 'virtual induction mounts pass CMS raycast accessibility checks on engines without a matching native slot'
Assert-GameMethod $gameModule 'GameScript' 'GetGroupOnEngineStand' @()
Assert-GameMethod $gameModule 'PieMenuController' 'ReadOptionsFromIni' @('System.String')
Assert-GameMethod $gameModule 'GameScript' 'IsPartAccessible' @('System.String')
Assert-GameMethod $gameModule 'Inventory' 'GetItems' @('System.String')
Assert-GameMethod $gameModule 'GameScript' 'SetGroupOnEngineStand' @('NewGroupItem')
Assert-GameMethod $gameModule 'GameManager' 'ActionInsertEngineToCar' @('NewGroupItem')
Assert-GameMethod $gameModule 'CarLoader' 'SwapEngine' @('NewGroupItem')
Assert-GameMethod $gameModule 'PrepareCarPhysics' 'Get' @()
Assert-GameMethod $gameModule 'GameInventory' 'GetGO' @('System.String')
Assert-GameMethod $gameModule 'GameInventory' 'GetGO2' @('System.String')
Assert-GameMethod $gameModule 'GameInventory' 'GetItemProperty' @('System.String')
Assert-GameMethod $gameModule 'PartScript' 'TunePart' @('System.String','System.Boolean')
Assert-GameMethod $gameModule 'GameInventory' 'GetThumb' @('System.String')
Assert-GameMethod $gameModule 'GameInventory' 'GetItemLocalizeName' @('System.String')
Assert-GameMethod $gameModule 'GameInventory' 'GetIOLocalizedName' @('InteractiveObject')
Assert-GameMethod $gameModule 'PartScript' 'SetLayerRecursively' @('System.Int32')
Assert-GameMethod $gameModule 'GameInventory' 'AddToPartPropertyList' @('System.String','System.Int32','System.Int32','System.String','System.Int32','System.Int32','System.Int32','System.Int32[]','System.Single','System.Boolean','System.String','System.String','System.String')
Assert-GameField $gameModule 'GameInventory' 'IsReady' 'System.Boolean'
Assert-GameMethod $gameModule 'CarLoader' 'GetEngine' @()
Assert-GameMethod $gameModule 'CarLoader' 'GetRoot' @()
Assert-GameMethod $gameModule 'PartScript' 'IsUnmounted' @()
Assert-GameMethod $gameModule 'PartScript' 'GetID' @()
Assert-GameMethod $gameModule 'PartScript' 'GetIDWithTuned' @()
Assert-GameMethod $gameModule 'DynoManager' 'PrepareDyno' @()
Assert-GameMethod $gameModule 'UIManager' 'CreateShop' @()
Assert-GameMethod $gameModule 'CarEngineHelper' 'DrawPowerTorqueChart' @('CP.ProChart.LineChart', 'UnityEngine.Color', 'UnityEngine.Color')
Assert-GameField $gameModule 'PrepareCarPhysics' 'carLoader' 'CarLoader'
Assert-GameField $gameModule 'PrepareCarPhysics' 'vpVehicleController' 'VPVehicleController'

$profilePath = Join-Path $env:USERPROFILE 'AppData\LocalLow\Red Dot Games\Car Mechanic Simulator 2018\profile0'
if (Test-Path -LiteralPath $profilePath) {
    $profileNamePath = Join-Path $profilePath 'name.txt'
    $profileName = if (Test-Path -LiteralPath $profileNamePath) { (Get-Content -LiteralPath $profileNamePath -Raw).Trim() } else { '<missing>' }
    $profileFiles = @(Get-ChildItem -LiteralPath $profilePath -File -Force).Count
    Write-Host "INFO: profile0 name='$profileName'; local file count=$profileFiles"
}
$logPath = Join-Path $GameRoot 'BepInEx\LogOutput.log'
if (Test-Path -LiteralPath $logPath) {
    $runtimeLog = Get-Content -LiteralPath $logPath -Raw
    $startupPattern = 'CMS 2018 Turbo Prototype ' + [regex]::Escape($buildVersion) + ' loaded'
    $loaded = [regex]::IsMatch($runtimeLog, $startupPattern)
    if ($loaded) {
        Write-Host "PASS: BepInEx log contains the $buildVersion startup line."
        $runtimeMessages = @(
            'Patched VehiclePhysics.Engine.CalculateTorque',
            'Patched VehiclePhysics.Engine.CalculatePowerInKw',
            'Patched GameScript.GetGroupOnEngineStand',
            'Patched GameScript.SetGroupOnEngineStand',
            'Patched GameManager.ActionInsertEngineToCar',
            'Patched CarLoader.SwapEngine',
            'Patched CarLoader.SetEngine',
            'Patched GameInventory.GetGO',
            'Patched GameInventory.GetGO2',
            'Patched PartScript.TunePart',
            'Patched GameInventory.GetThumb',
            'Patched GameInventory.GetItemLocalizeName',
            'Patched DynoManager.PrepareDyno',
            'Patched CarEngineHelper.DrawPowerTorqueChart'
        )
        foreach ($message in $runtimeMessages) {
            Assert-Check ($runtimeLog.Contains($message)) "runtime log confirms $message"
        }
        if ($runtimeLog.Contains('Universal turbo, supercharger and P-1X kits registered in Main Shop / Engine')) {
            Assert-Check $true 'runtime log confirms induction kits registered in Main Shop / Engine'
        } else {
            Write-Warning 'This startup log does not confirm live shop registration; open the shop in game to exercise its registration path.'
        }
        $pluginErrors = [regex]::Matches($runtimeLog, '(?m)^\[Error\s*:CMS 2018 Turbo Prototype\]')
        $pluginWarnings = [regex]::Matches($runtimeLog, '(?m)^\[Warning:CMS 2018 Turbo Prototype\]')
        Assert-Check ($pluginErrors.Count -eq 0) 'runtime log has no turbo-prototype errors'
        Assert-Check ($pluginWarnings.Count -eq 0) 'runtime log has no turbo-prototype warnings'
        $unityOutputLogPath = Join-Path (Split-Path -Parent $profilePath) 'output_log.txt'
        if (Test-Path -LiteralPath $unityOutputLogPath) {
            $unityOutputLog = Get-Content -LiteralPath $unityOutputLogPath -Raw
            $pluginRuntimeException = [regex]::IsMatch($unityOutputLog, '(?s)(?:MissingMethodException|TypeLoadException|NullReferenceException|InvalidOperationException|Exception):[\s\S]{0,1500}?at CMS18TurboPrototype\.')
            Assert-Check (-not $pluginRuntimeException) 'Unity output log has no CMS18TurboPrototype exception stack'
            Assert-Check (-not $unityOutputLog.Contains('System.String.IsNullOrWhiteSpace')) 'Unity output log has no missing Mono whitespace API error'
        } else {
            Write-Warning "Unity output log is not available at $unityOutputLogPath; game-side exception validation is unverified."
        }
    } else {
        Write-Warning "Runtime load is not verified: the current BepInEx log has no $buildVersion startup line."
    }
}

$saveRoot = Join-Path $env:USERPROFILE 'AppData\LocalLow\Red Dot Games\Car Mechanic Simulator 2018'
$targetProfileIndex = 3
$targetProfilePath = Join-Path $saveRoot ('profile' + $targetProfileIndex)
$targetProfileName = 'cms18promo'
$targetProfileExists = Test-Path -LiteralPath $targetProfilePath -PathType Container
Assert-Check $targetProfileExists 'isolated cms18promo test clone profile3 exists'
if ($targetProfileExists) {
    $targetNamePath = Join-Path $targetProfilePath 'name.txt'
    $targetName = if (Test-Path -LiteralPath $targetNamePath) { [System.IO.File]::ReadAllText($targetNamePath).Trim() } else { '<missing>' }
    Assert-Check ($targetName -eq $targetProfileName) 'isolated profile3 clone is named cms18promo'
    $lastSavePath = Join-Path $targetProfilePath 'lastSave.txt'
    if (Test-Path -LiteralPath $lastSavePath) {
        $lastSave = [System.IO.File]::ReadAllText($lastSavePath).Trim()
        Write-Host "INFO: cms18promo lastSave.txt is present; date='$lastSave'."
    } else {
        Write-Host 'INFO: cms18promo has no lastSave.txt yet and remains a blank starter profile.'
    }
}

$tuffPath = Join-Path $saveRoot 'profile1'
$tuffBaselinePath = Join-Path $projectRoot 'save_backup\LocalLow-before-cloud-sync\profile1'
$tuffBaselineExists = Test-Path -LiteralPath $tuffBaselinePath -PathType Container
if (-not $SkipProfileIntegrityChecks -and $tuffBaselineExists -and (Test-Path -LiteralPath $tuffPath -PathType Container)) {
    $baselineHashes = @{}
    Get-ChildItem -LiteralPath $tuffBaselinePath -File -Recurse | ForEach-Object {
        $relativePath = $_.FullName.Substring($tuffBaselinePath.Length)
        $baselineHashes[$relativePath] = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
    }
    $tuffHashesMatch = $true
    $currentTuffFiles = @(Get-ChildItem -LiteralPath $tuffPath -File -Recurse)
    if ($currentTuffFiles.Count -ne $baselineHashes.Count) { $tuffHashesMatch = $false }
    foreach ($file in $currentTuffFiles) {
        $relativePath = $file.FullName.Substring($tuffPath.Length)
        $currentHash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
        if (-not $baselineHashes.ContainsKey($relativePath) -or $baselineHashes[$relativePath] -ne $currentHash) {
            $tuffHashesMatch = $false
            break
        }
    }
    Assert-Check $tuffHashesMatch 'profile1 tuff matches all files in its saved baseline'
} elseif (-not $SkipProfileIntegrityChecks) {
    Write-Warning 'tuff integrity comparison skipped because its private baseline is not present in this source package.'
}

$runtimeLogPathForProfileCheck = Join-Path $GameRoot 'BepInEx\LogOutput.log'
if (Test-Path -LiteralPath $runtimeLogPathForProfileCheck) {
    $profileRuntimeLog = Get-Content -LiteralPath $runtimeLogPathForProfileCheck -Raw
    $runtimeProfileMatch = [regex]::Match($profileRuntimeLog, 'CMS 2018 Turbo Prototype ' + [regex]::Escape($buildVersion) + ' loaded for save profile (\d+)')
    if ($runtimeProfileMatch.Success) {
        $runtimeProfileIndex = [int]$runtimeProfileMatch.Groups[1].Value
        if ($runtimeProfileIndex -eq $targetProfileIndex) {
            Assert-Check $true 'runtime plugin loaded on the isolated cms18promo profile3 test clone'
        } else {
            Write-Warning "Runtime plugin loaded on profile$runtimeProfileIndex; the isolated cms18promo profile3 game test has not run yet."
        }
    }
}
$profile0Path = Join-Path $saveRoot 'profile0'
$profile0BaselinePath = Join-Path $projectRoot 'save_backup\profile0-pre-cms18promo-new-save-20261029-072039'
$profile0BaselineExists = Test-Path -LiteralPath $profile0BaselinePath -PathType Container
if (-not $SkipProfileIntegrityChecks -and $profile0BaselineExists -and (Test-Path -LiteralPath $profile0Path -PathType Container)) {
    $profile0MetadataMatches = $true
    foreach ($fileName in @('difficulty.txt','name.txt')) {
        $baselineFile = Join-Path $profile0BaselinePath $fileName
        $currentFile = Join-Path $profile0Path $fileName
        if (-not (Test-Path -LiteralPath $baselineFile -PathType Leaf) -or -not (Test-Path -LiteralPath $currentFile -PathType Leaf)) {
            $profile0MetadataMatches = $false
            break
        }
        $baselineHash = (Get-FileHash -LiteralPath $baselineFile -Algorithm SHA256).Hash
        $currentHash = (Get-FileHash -LiteralPath $currentFile -Algorithm SHA256).Hash
        if ($baselineHash -ne $currentHash) {
            $profile0MetadataMatches = $false
            break
        }
    }
    $currentProfile0Names = @(Get-ChildItem -LiteralPath $profile0Path -File -Force | Select-Object -ExpandProperty Name | Sort-Object)
    $expectedProfile0Names = @('difficulty.txt','name.txt','tutorial.dat') | Sort-Object
    $profile0ShapeMatches = @(Compare-Object $expectedProfile0Names $currentProfile0Names).Count -eq 0
    Assert-Check ($profile0MetadataMatches -and $profile0ShapeMatches) 'profile0 matches its empty-save baseline plus CMS-created tutorial.dat'
} elseif (-not $SkipProfileIntegrityChecks) {
    Write-Warning 'profile0 integrity comparison skipped because its private baseline is not present in this source package.'
}
$profile3LastSavePath = Join-Path $targetProfilePath 'lastSave.txt'
if (Test-Path -LiteralPath $profile3LastSavePath) {
    Write-Host 'INFO: isolated profile3 cms18promo clone has a save timestamp and is ready for in-game testing.'
} else {
    Write-Warning 'profile3 is still a blank starter slot; it does not contain the unlocked cms18promo clone yet.'
}
