# Patch 0.8.61

See [report.md](report.md) for the change summary, installation/build record, rollback hash, known limits, and next live test.
