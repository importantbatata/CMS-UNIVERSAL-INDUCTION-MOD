# CMS 2018 Custom Induction Mod — Patch 0.8.61

**Date:** 2026-10-31  
**Build:** C# compilation succeeded; installed with CMS closed.  
**Installed DLL SHA-256:** `F91ED5E7BC9449F17B6DFB3A5BC2C8BCEA82F606E708C376AB922C45A18BCF74`  
**Rollback DLL SHA-256:** `BFBABAD804368A5F8435D77569B032D0787A97E15ED1A5FD78BC35EBD20DB4C5` (patch 0.8.60)  
**Status:** Installed; waiting for the user's dyno/32-psi live test. CMS has not been launched with 0.8.61.

## Goal and changes

This patch makes the boost system affect the engine-spec values the dyno displays and makes the selected custom kit take precedence over a factory induction part on the same engine.

- Adds modeled boost torque gain to the engine-spec torque at idle and peak torque RPM, and adds matching horsepower/kilowatt gain at the engine's rated power RPM. Horsepower gain uses the torque relationship `HP = N·m × RPM / 7,127`, keeping the displayed torque and horsepower changes tied to the same boost sample.
- Preserves the existing boost-pressure/charge-temperature/intercooler/drive-loss model and the live torque and power hooks.
- Searches fitted CMS induction kits before factory turbo/supercharger parts, so an unrelated stock turbo cannot hide the installed P-1X mode. Saved custom kit records preserve the selected mode and 32-psi tier while the synthetic mount is rebuilt after transfer/load.
- Keeps the 32-psi P-1X preset at 24 psi and its slider ceiling at 32 psi. Standard P-1X remains capped at 20 psi.
- Continues creating the universal induction mount on engine roots that lack a factory induction slot; the approach applies to base-game, non-DLC engines.
- Leaves the current model placement and charge-pipe route unchanged as requested. Alignment remains a later visual/debug pass.
- Shop routing/prices remain: standard P-1X at **$12,500** in Main Shop; High-Boost P-1X at **$24,900** in Tuning Shop.

## Evidence and validation

- Before this patch, user-provided dyno images showed factory and measured output equal with **0.00% gain/loss**: 285 HP / 360 N·m on one run and 303 HP / 383 N·m on another. The user also reported “no change.”
- The 0.8.60 BepInEx log loaded on profile 2 with **zero patch errors** and reported both shop entries present (`p1x=True`, `high=True`).
- The 0.8.61 C# source compiled successfully. No automated test suite was run and no live CMS/dyno test was performed for this build.
- The boost model estimates density/torque change from pressure ratio, charge temperature, intercooling, drive loss, engine RPM and baseline torque. The game dyno must still confirm the displayed response. Knock, fuel limits and engine durability are not simulated; P-1X limits remain 32 psi, 65,000 impeller RPM and a 950 hp component ceiling.
- No save data was edited. The plugin was replaced only after checking that CMS was closed. The prior 0.8.60 DLL is included for rollback.

## Next live test

Use the same `cms18promo` sandbox profile used in the last successful test. On a base-game engine without a factory turbo slot, fit the High-Boost P-1X, confirm the stand control allows **32 psi**, set it to 32 psi, transfer the engine, and run the dyno once. Capture factory/measured HP, torque, and gain/loss. If practical, compare the same engine at 0 psi. If the result remains unchanged, capture the new `Dyno engine specs boosted` line from `BepInEx\LogOutput.log`. Stop there and send the results; further work pauses until that live test.
