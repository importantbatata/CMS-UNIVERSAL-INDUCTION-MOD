# CMS 2018 part-selection code audit

**Assembly:** `Assembly-CSharp-firstpass.dll`  
**SHA-256:** `A5B7FF39FEA04F94D563794B4DB2CB9013D5DB6B60753935A948463C108EDC42`  
**MVID:** `d6eeaa47-1eae-409f-9151-fa80c29fd7e6`

The game’s `Raycast.Init` assigns `65536` to both `partSelectRaycastMask` and `partSelectMountRaycastMask`. That bit is layer 16 (`1 << 16`). In the corresponding `Raycast.Update` paths, CMS raycasts with those masks and calls `GetComponent<PartScript>()` on the hit collider’s own GameObject. It does not search the collider’s parent for a `PartScript`.

This explains why a virtual part can render correctly yet remain unselectable: its collider must use a layer accepted by the selection raycast, and the collider object itself must carry `PartScript`. The virtual induction mount puts those components on the same GameObject and uses the confirmed part-selection layer 16.

The same assembly shows the native mount lifecycle. `PartScript.HidePreview` disables the part object's colliders, marks it unmounted, changes it to layer 26, and disables every renderer listed in `hideWhenUnmontingMounting`. `ShowPreviewToMount` returns the object tree to layer 16 and re-enables those renderers. `ActionUnMount` checks `canBeUnmount` before it proceeds. `GameScript.SelectToMount` and `SelectToUnMount` both directly read `MountObjects[0]` to construct the camera target, so an empty `MountObjects` array breaks the native flow. v0.8.32 gives the virtual slot a native `MountObject` component on its existing collider and assigns it as the single anchor.

`PartScript.GetIDWithTuned` returns `tunedID` whenever it is non-empty, otherwise the base ID. `TunePart` asks `GameInventory.WhatIsMyID` for the replacement ID and loads its `CarParts/` resource; the mod therefore maps custom kit IDs to `turbo_2` for the native operation and restores the custom ID afterwards. The current source now uses those ID rules to locate an already-installed kit on transfer and to recreate the runtime-only universal mount from a profile-scoped kit record when a car engine is loaded again.

The current plugin adds generated induction, belt, bracket, tensioner, and charge-pipe renderers to `hideWhenUnmontingMounting` and removes those references when replacing the model. The extra `PartScript` method bodies are included in the targeted IL dump so the lifecycle findings can be checked against the assembly.

The full targeted IL dump is in [firstpass-selection-IL.txt](firstpass-selection-IL.txt). Recreate it with [inspect_selection_firstpass.ps1](../tools/inspect_selection_firstpass.ps1). This is static assembly evidence only; live engine selection still needs to be confirmed in CMS.
