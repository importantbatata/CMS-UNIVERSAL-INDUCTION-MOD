$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$modelPath = Join-Path $projectRoot 'model\CMS18_ProCharger_P1X_AddOn.obj'
$backupFolder = Join-Path $projectRoot 'model\backups'
$backupPath = Join-Path $backupFolder 'CMS18_ProCharger_P1X_AddOn_pre0837.obj'
$lines = [System.IO.File]::ReadAllLines($modelPath)

function Get-ObjSections {
    param([string[]]$Content)
    $sections = New-Object 'System.Collections.Generic.List[object]'
    $current = $null
    $vertexCount = 0
    $texCoordCount = 0
    $normalCount = 0
    for ($lineIndex = 0; $lineIndex -lt $Content.Length; $lineIndex++) {
        $line = $Content[$lineIndex]
        if ($line.StartsWith('o ', [StringComparison]::Ordinal)) {
            if ($null -ne $current) { $current.EndLine = $lineIndex }
            $current = [pscustomobject]@{
                Name = $line.Substring(2)
                StartLine = $lineIndex
                EndLine = $Content.Length
                VertexBase = $vertexCount
                TexCoordBase = $texCoordCount
                NormalBase = $normalCount
                VertexCount = 0
                TexCoordCount = 0
                NormalCount = 0
            }
            $sections.Add($current)
            continue
        }
        if ($null -eq $current) { continue }
        if ($line.StartsWith('v ', [StringComparison]::Ordinal)) {
            $vertexCount++; $current.VertexCount++
        }
        elseif ($line.StartsWith('vt ', [StringComparison]::Ordinal)) {
            $texCoordCount++; $current.TexCoordCount++
        }
        elseif ($line.StartsWith('vn ', [StringComparison]::Ordinal)) {
            $normalCount++; $current.NormalCount++
        }
    }
    return ,$sections
}

function Format-ObjVector {
    param([string]$Prefix, [double]$X, [double]$Y, [double]$Z)
    return [string]::Format([Globalization.CultureInfo]::InvariantCulture, '{0} {1:F6} {2:F6} {3:F6}', $Prefix, $X, $Y, $Z)
}

function Resolve-LocalIndex {
    param([int]$Index, [int]$Base, [int]$Count, [string]$Kind)
    $local = if ($Index -gt 0) { $Index - $Base - 1 } else { $Count + $Index }
    if ($local -lt 0 -or $local -ge $Count) { throw "Pulley clone references an external or invalid $Kind index." }
    return $local - $Count
}

function New-TranslatedObjClone {
    param([object]$Section, [string]$NewName, [double]$OffsetX, [string]$Material)
    $vertices = New-Object 'System.Collections.Generic.List[string]'
    $texCoords = New-Object 'System.Collections.Generic.List[string]'
    $normals = New-Object 'System.Collections.Generic.List[string]'
    $faces = New-Object 'System.Collections.Generic.List[string]'
    for ($lineIndex = $Section.StartLine + 1; $lineIndex -lt $Section.EndLine; $lineIndex++) {
        $line = $lines[$lineIndex]
        if ($line.StartsWith('v ', [StringComparison]::Ordinal)) {
            $parts = [regex]::Split($line.Trim(), '\s+')
            $x = [double]::Parse($parts[1], [Globalization.CultureInfo]::InvariantCulture) + $OffsetX
            $y = [double]::Parse($parts[2], [Globalization.CultureInfo]::InvariantCulture)
            $z = [double]::Parse($parts[3], [Globalization.CultureInfo]::InvariantCulture)
            $vertices.Add((Format-ObjVector 'v' $x $y $z))
        }
        elseif ($line.StartsWith('vt ', [StringComparison]::Ordinal)) { $texCoords.Add($line) }
        elseif ($line.StartsWith('vn ', [StringComparison]::Ordinal)) { $normals.Add($line) }
        elseif ($line.StartsWith('f ', [StringComparison]::Ordinal)) { $faces.Add($line) }
    }
    if ($vertices.Count -ne $Section.VertexCount -or $texCoords.Count -ne $Section.TexCoordCount -or $normals.Count -ne $Section.NormalCount -or $faces.Count -eq 0) {
        throw "Could not safely clone OBJ section '$($Section.Name)'."
    }

    $clone = New-Object 'System.Collections.Generic.List[string]'
    $clone.Add('o ' + $NewName)
    $clone.AddRange($vertices)
    $clone.AddRange($texCoords)
    $clone.AddRange($normals)
    $clone.Add('usemtl ' + $Material)
    foreach ($face in $faces) {
        $parts = [regex]::Split($face.Trim(), '\s+')
        $remapped = New-Object 'System.Collections.Generic.List[string]'
        for ($cornerIndex = 1; $cornerIndex -lt $parts.Length; $cornerIndex++) {
            $indices = $parts[$cornerIndex].Split('/')
            $newToken = [string](Resolve-LocalIndex ([int]$indices[0]) $Section.VertexBase $Section.VertexCount 'vertex')
            if ($indices.Length -gt 1) {
                $newToken += '/'
                if (-not [string]::IsNullOrEmpty($indices[1])) {
                    $newToken += [string](Resolve-LocalIndex ([int]$indices[1]) $Section.TexCoordBase $Section.TexCoordCount 'texture')
                }
                if ($indices.Length -gt 2) {
                    $newToken += '/'
                    if (-not [string]::IsNullOrEmpty($indices[2])) {
                        $newToken += [string](Resolve-LocalIndex ([int]$indices[2]) $Section.NormalBase $Section.NormalCount 'normal')
                    }
                }
            }
            $remapped.Add($newToken)
        }
        $clone.Add('f ' + ($remapped -join ' '))
    }
    return ,$clone
}

$sections = Get-ObjSections $lines
$sectionByName = @{}
foreach ($section in $sections) { $sectionByName[$section.Name] = $section }
if ($sectionByName.Count -eq 0 -or @($sectionByName.Keys | Where-Object { $_ -match '^P-1X_drive_pulley_rib_\d{2}$' }).Count -ne 5 -or @($sectionByName.Keys | Where-Object { $_ -match '^P-1X_pulley_valley_\d{2}$' }).Count -ne 4) {
    throw 'Expected the original five-rib, four-valley P-1X mesh. Refusing to modify an unexpected model.'
}
if (Test-Path -LiteralPath $backupPath) { throw "Backup already exists: $backupPath" }
New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null
Copy-Item -LiteralPath $modelPath -Destination $backupPath

$ribOffsets = @{
    'P-1X_drive_pulley_rib_00' = -0.00625
    'P-1X_drive_pulley_rib_01' = -0.00535
    'P-1X_drive_pulley_rib_02' = -0.00445
    'P-1X_drive_pulley_rib_03' = -0.00355
    'P-1X_drive_pulley_rib_04' = -0.00265
}
$valleyOffsets = @{
    'P-1X_pulley_valley_00' = -0.00580
    'P-1X_pulley_valley_01' = -0.00490
    'P-1X_pulley_valley_02' = -0.00400
    'P-1X_pulley_valley_03' = -0.00310
}
$materialChanges = @{}
foreach ($name in @(
    'P-1X_cast_gearcase_shell', 'P-1X_compressor_backplate', 'P-1X_drive_pulley',
    'P-1X_gearcase_cover_rim', 'P-1X_gearcase_rib_-1', 'P-1X_gearcase_rib_1',
    'P-1X_inducer_eye', 'P-1X_3.57_inch_inducer_machined_hub',
    'P-1X_internal_5.56_inch_exducer_wheel_hub', 'P-1X_mounting_ear_-1',
    'P-1X_mounting_ear_1', 'P-1X_mounting_boss_-1', 'P-1X_mounting_boss_1',
    'P-1X_outlet_inner_lip'
)) { $materialChanges[$name] = 'Machined_aluminum' }
foreach ($name in @(
    'P-1X_compressor_cover_bolt_00', 'P-1X_compressor_cover_bolt_01',
    'P-1X_compressor_cover_bolt_02', 'P-1X_compressor_cover_bolt_03',
    'P-1X_compressor_cover_bolt_04', 'P-1X_compressor_cover_bolt_05',
    'P-1X_compressor_cover_bolt_06', 'P-1X_compressor_cover_bolt_07',
    'P-1X_gearcase_cover_bolt_00', 'P-1X_gearcase_cover_bolt_01',
    'P-1X_gearcase_cover_bolt_02', 'P-1X_gearcase_cover_bolt_03',
    'P-1X_gearcase_cover_bolt_04', 'P-1X_gearcase_cover_bolt_05',
    'P-1X_gearcase_cover_bolt_06', 'P-1X_gearcase_cover_bolt_07',
    'P-1X_pulley_retainer_bolt_00', 'P-1X_pulley_retainer_bolt_01',
    'P-1X_pulley_retainer_bolt_02', 'P-1X_pulley_retainer_bolt_03',
    'P-1X_pulley_retainer_bolt_04', 'P-1X_pulley_retainer_bolt_05'
)) { $materialChanges[$name] = 'Steel' }
$materialChanges['P-1X_oil_fill_plug'] = 'Steel'

$updated = New-Object 'System.Collections.Generic.List[string]'
for ($lineIndex = 0; $lineIndex -lt $sections[0].StartLine; $lineIndex++) { $updated.Add($lines[$lineIndex]) }
foreach ($section in $sections) {
    for ($lineIndex = $section.StartLine; $lineIndex -lt $section.EndLine; $lineIndex++) {
        $line = $lines[$lineIndex]
        if ($line.StartsWith('v ', [StringComparison]::Ordinal)) {
            $parts = [regex]::Split($line.Trim(), '\s+')
            $x = [double]::Parse($parts[1], [Globalization.CultureInfo]::InvariantCulture)
            $y = [double]::Parse($parts[2], [Globalization.CultureInfo]::InvariantCulture)
            $z = [double]::Parse($parts[3], [Globalization.CultureInfo]::InvariantCulture)
            if ($ribOffsets.ContainsKey($section.Name)) { $x += $ribOffsets[$section.Name] }
            elseif ($valleyOffsets.ContainsKey($section.Name)) { $x += $valleyOffsets[$section.Name] }
            elseif ($section.Name -eq 'P-1X_drive_pulley') { $x = -0.405 + (($x + 0.405) * 1.3) }
            $line = Format-ObjVector 'v' $x $y $z
        }
        elseif ($line.StartsWith('usemtl ', [StringComparison]::Ordinal) -and $materialChanges.ContainsKey($section.Name)) {
            $line = 'usemtl ' + $materialChanges[$section.Name]
        }
        $updated.Add($line)
    }
}
$updated.AddRange((New-TranslatedObjClone $sectionByName['P-1X_drive_pulley_rib_04'] 'P-1X_drive_pulley_rib_05' 0.00625 'Machined_aluminum'))
$updated.AddRange((New-TranslatedObjClone $sectionByName['P-1X_pulley_valley_03'] 'P-1X_pulley_valley_04' 0.00580 'Dark_inlet'))

$ribCount = @($updated | Where-Object { $_ -match '^o P-1X_drive_pulley_rib_\d{2}$' }).Count
$valleyCount = @($updated | Where-Object { $_ -match '^o P-1X_pulley_valley_\d{2}$' }).Count
if ($ribCount -ne 6 -or $valleyCount -ne 5) { throw 'Six-rib pulley geometry did not assemble as expected; original OBJ is unchanged.' }
$tempPath = $modelPath + '.new'
[System.IO.File]::WriteAllLines($tempPath, $updated.ToArray(), [System.Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $tempPath -Destination $modelPath -Force
Write-Host "Updated P-1X pulley to six ribs/five valleys and matched billet aluminum/steel material assignments."
Write-Host "Backup: $backupPath"
