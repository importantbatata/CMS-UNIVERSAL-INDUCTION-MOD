param(
    [string]$AssemblyPath = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018\cms2018_Data\Managed\Assembly-CSharp-firstpass.dll',
    [string]$CecilPath = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018\BepInEx\core\Mono.Cecil.dll',
    [string]$OutputPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'docs\firstpass-selection-IL.txt')
)

$ErrorActionPreference = 'Stop'
$localCecilPath = Join-Path $env:TEMP 'CMS18-selection-Mono.Cecil.dll'
Copy-Item -LiteralPath $CecilPath -Destination $localCecilPath -Force
Unblock-File -LiteralPath $localCecilPath
Add-Type -Path $localCecilPath

$module = [Mono.Cecil.ModuleDefinition]::ReadModule($AssemblyPath)
$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add("Assembly: $AssemblyPath")
$lines.Add("MVID: $($module.Mvid)")
$lines.Add('')

function Get-TypeTree($type) {
    $type
    foreach ($nested in $type.NestedTypes) { Get-TypeTree $nested }
}

function Write-Il($method) {
    $lines.Add("  METHOD $($method.ReturnType.FullName) $($method.Name)")
    if (-not $method.HasBody) { return }
    foreach ($instruction in $method.Body.Instructions) {
        $operand = if ($null -eq $instruction.Operand) { '' } else { ' ' + $instruction.Operand.ToString() }
        $lines.Add(('    {0,-12}{1}{2}' -f $instruction.Offset.ToString('X4'), $instruction.OpCode.Name, $operand))
    }
}

$types = @($module.Types | ForEach-Object { Get-TypeTree $_ })
foreach ($name in @('Raycast', 'InteractiveObject', 'PartScript', 'GameInventory', 'GameManager', 'CarLoader',
        'MainMenu', 'MainMenuManager', 'MainMenuDownMenuItem', 'HorizontalItemsMove', 'MenuItemHorizontal')) {
    $type = $types | Where-Object { $_.Name -eq $name } | Select-Object -First 1
    if ($null -eq $type) { continue }
    $lines.Add("TYPE $($type.FullName)")
    foreach ($field in $type.Fields) {
        if ($name -ne 'PartScript' -or $field.Name -match 'layer|mount|collider|unmount|preview|raycast|partSelect') {
            $lines.Add("  FIELD $($field.FieldType.FullName) $($field.Name)")
        }
    }
    foreach ($method in $type.Methods) {
        if ((($name -eq 'Raycast') -and ($method.Name -in @('Start', 'Init', 'Update'))) -or
            (($name -eq 'InteractiveObject') -and ($method.Name -match 'CanMountGroup|GetPart|Update')) -or
            (($name -eq 'PartScript') -and ($method.Name -in @('HidePreview', 'ActionUnMount', 'FastUnmount', 'ShowPreviewToMount', 'TunePart', 'IsUnmounted', 'GetIDWithTuned', 'SetTunedID'))) -or
            (($name -eq 'GameInventory') -and ($method.Name -in @('GetGO', 'GetGO2', 'GetItemProperty', 'AddToPartPropertyList'))) -or
            (($name -eq 'GameManager') -and ($method.Name -in @('ActionInsertEngineToCar'))) -or
            (($name -eq 'CarLoader') -and ($method.Name -in @('SetEngine', 'SwapEngine', 'GetEngine'))) -or
            (($name -eq 'MainMenu') -and ($method.Name -in @('Awake', 'DrawMenu', 'Update'))) -or
            (($name -eq 'MainMenuManager') -and ($method.Name -in @('Start', 'PrepareScene', 'LoadCredits', 'QuitGame'))) -or
            (($name -eq 'MainMenuDownMenuItem') -and ($method.Name -in @('Mark', 'Select', 'SetDisabled', 'SetEnabled', 'IsEnabled'))) -or
            (($name -eq 'HorizontalItemsMove') -and ($method.Name -in @('SelectItem', 'Update', 'EnableMove', 'DisableMove'))) -or
            (($name -eq 'MenuItemHorizontal') -and ($method.Name -in @('Mark', 'Select', 'IsEnabled')))) {
            Write-Il $method
        }
    }
    foreach ($nested in $type.NestedTypes) {
        if ($nested.Name -match 'Init|Update|PrepareScene') {
            $lines.Add("NESTED $($nested.FullName)")
            foreach ($method in $nested.Methods) {
                if ($method.Name -eq 'MoveNext') { Write-Il $method }
            }
        }
    }
    $lines.Add('')
}

[System.IO.File]::WriteAllLines($OutputPath, $lines, [System.Text.UTF8Encoding]::new($false))
if ($module -is [System.IDisposable]) { $module.Dispose() }
Write-Output "Wrote $($lines.Count) lines to $OutputPath"
