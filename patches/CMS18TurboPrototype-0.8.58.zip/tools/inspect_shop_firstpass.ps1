param(
    [string]$AssemblyPath = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018\cms2018_Data\Managed\Assembly-CSharp-firstpass.dll',
    [string]$CecilPath = 'C:\Program Files (x86)\Steam\steamapps\common\Car Mechanic Simulator 2018\BepInEx\core\Mono.Cecil.dll',
    [string]$OutputPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'build\shop-firstpass-inspection.txt')
)

$ErrorActionPreference = 'Stop'
$localCecilPath = Join-Path $env:TEMP 'CMS18-shop-Mono.Cecil.dll'
Copy-Item -LiteralPath $CecilPath -Destination $localCecilPath -Force
Unblock-File -LiteralPath $localCecilPath
Add-Type -Path $localCecilPath

$module = [Mono.Cecil.ModuleDefinition]::ReadModule($AssemblyPath)
$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add("Assembly: $AssemblyPath")
$lines.Add("MVID: $($module.Mvid)")
$lines.Add('')

function Get-TypeTree($type) {
    $type
    foreach ($nested in $type.NestedTypes) { Get-TypeTree $nested }
}

function Write-Il($method) {
    $signature = ($method.Parameters | ForEach-Object { $_.ParameterType.FullName }) -join ', '
    $lines.Add("  METHOD $($method.ReturnType.FullName) $($method.Name)($signature)")
    if (-not $method.HasBody) { return }
    foreach ($instruction in $method.Body.Instructions) {
        $operand = if ($null -eq $instruction.Operand) { '' } else { ' ' + $instruction.Operand.ToString() }
        $lines.Add(('    {0,-12}{1}{2}' -f $instruction.Offset.ToString('X4'), $instruction.OpCode.Name, $operand))
    }
}

$types = @($module.Types | ForEach-Object { Get-TypeTree $_ })
foreach ($name in @('GameInventory', 'UIManager')) {
    $type = $types | Where-Object { $_.Name -eq $name } | Select-Object -First 1
    if ($null -eq $type) { continue }
    $lines.Add("TYPE $($type.FullName)")
    foreach ($field in $type.Fields) {
        if ($field.Name -match 'ready|partProperty|shop|item') {
            $lines.Add("  FIELD $($field.FieldType.FullName) $($field.Name)")
        }
    }
    foreach ($method in $type.Methods) {
        if (($name -eq 'GameInventory' -and $method.Name -in @('GetItems', 'GetItemProperty', 'AddToPartPropertyList', 'GetGO', 'GetGO2')) -or
            ($name -eq 'UIManager' -and $method.Name -in @('CreateShop'))) {
            Write-Il $method
        }
    }
    $lines.Add('')
}

[System.IO.File]::WriteAllLines($OutputPath, $lines, [System.Text.UTF8Encoding]::new($false))
if ($module -is [System.IDisposable]) { $module.Dispose() }
Write-Output "Wrote $($lines.Count) lines to $OutputPath"
