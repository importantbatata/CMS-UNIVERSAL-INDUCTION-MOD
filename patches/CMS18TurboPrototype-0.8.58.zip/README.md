# CMS 2018 Custom Induction Mod — Patch 0.8.58

This patch shortens the first ProCharger charge-pipe turn from 35 mm to 23 mm when the outlet points away from the intake. It responds to the 0.8.57 screenshot, where the upper pipe run still looked high/long. The measured outlet, intake target, blower position, and clearance route are unchanged.

The patch is installed and ready for a visual check. CMS has not been launched with this version. No dyno testing has been done.

See `REPORT.md` for build details and the next check. Run `build.ps1` from this folder to rebuild on the same PC.
