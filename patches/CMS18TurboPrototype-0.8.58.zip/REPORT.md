# CMS 2018 Custom Induction Mod — Patch 0.8.58

**Date:** 2026-10-31  
**Build:** C# compilation succeeded; patch installed while CMS was closed.  
**Installed DLL SHA-256:** `B6D85D3C584C60667D98577D22261C10D8849050B34455167FE57A57D44C75B1`  
**Rollback DLL:** `build/installed-backups/CMS18TurboPrototype-20261031-143649.dll` (patch 0.8.57)  
**Status:** Ready for the user's next visual check. CMS has not been launched with 0.8.58. No dyno test has been run.

## Evidence from the 0.8.57 visual check

- The user reported the pipe remains a little off; the screenshot shows the upper run still sits high/long around the ProCharger.
- BepInEx loaded 0.8.57 on profile 2 with zero patch errors.
- The runtime selected `r4_przepustnica`; outlet-axis alignment was `-0.46`. The reported `0.04 m` stub is rounded to two decimals; 0.8.57's minimum was 35 mm.
- The route retained its outboard clearance bow (0.13 m in one engine context, 0.06 m in another). Both logged endpoints remain the measured outlet and intake surface.

## Change in 0.8.58

- Shorten the minimum initial outlet handle from 35 mm to 23 mm when the outlet points away from the intake. At the logged R4 alignment of -0.46, the handle is about 25 mm.
- Keep the measured P-1X outlet, intake target, blower placement, outboard engine-clearance route, shop, menu, and power behavior unchanged.
- The I6 6DOHC fitment remains the visual placement reference; its charge-pipe behavior is still unconfirmed because no mounted intake target was found in the runtime scan.

## Build and installation

- Compiled from `src/CMS18TurboPrototype.cs` against the local CMS and BepInEx references.
- Installed in `BepInEx/plugins` with the previous 0.8.57 DLL backed up at the path listed above.
- The installed file hash matches the compiled DLL.
- No game launch, in-game test, save edit, dyno run, or test script was performed for this patch.

## Next visual check

Use the same sandbox profile. On the R4 stand, verify that the upper pipe sweep now sits closer to the compressor while still connecting cleanly at both ends and clearing the engine. Confirm I6 blower placement remains good. Hold dyno testing until you accept the pipe routing.
