# Model assets

- `CMS18_ProCharger_P1X_AddOn.obj` and `.mtl` are embedded by the plugin for the custom P-1X visual.
- `CMS18_Turbo_AddOn.obj` and `CMS18_Turbo_Exhaust_Manifold.obj` are prototype/reference meshes. The plugin uses the native CMS turbo model at runtime, as requested, so stock game content is not replaced.
- `CMS18_Supercharger_AddOn.obj` and `CMS18_Supercharger_Intake_Manifold.obj` are prototype/reference meshes. The plugin uses the native CMS supercharger model at runtime.
- The plugin build script embeds only the P-1X OBJ. It does not include or modify CMS game model files.
