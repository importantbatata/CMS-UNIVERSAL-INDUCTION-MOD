# CMS 2018 Custom Induction Mod — Patch 0.8.54

Installed plugin for the ProCharger charge-pipe connection. It finds the live throttle/intake part and uses the P-1X outlet socket to route the pipe. Read `REPORT.md` for changes, installation, rollback, and testing steps.

CMS remains closed. The patch is ready for your live visual check.
