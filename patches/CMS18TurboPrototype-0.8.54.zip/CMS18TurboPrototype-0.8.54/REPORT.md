# CMS 2018 Custom Induction Mod — Patch 0.8.54

**Date:** 2026-10-31  
**Build:** 0.8.54 compiled and installed while CMS was closed.  
**Game status:** CMS remains closed; 0.8.54 has not been launched for a live test.  
**Source:** `CMS18TurboPrototype-0.8.54/src/CMS18TurboPrototype.cs`  
**Installed DLL SHA-256:** EECA3764EC30BA7E331D6DA0B6FC8CCBAC84AFCAD74DF3DB02476650D0546FFE  
**Rollback:** `rollback/CMS18TurboPrototype-0.8.53.dll` (SHA-256 89A4DF418FDF734AB14AC5B376DA9B443F0F88CB626F815E27AE0F4216480FED)

## What the 0.8.53 log showed

- On `engine_r4_turbo`, the plugin found `r4_przepustnica`, but the part mesh was not readable. It therefore aimed at the throttle body's renderer bounds, which can leave the pipe visibly misaligned.
- On `engine_r6_dohc_wzdluzny`, no mounted part ID matched the intake/throttle search, so no charge pipe was generated.
- The P-1X outlet center and bore direction were correctly derived from the model. The remaining mismatch is at the engine-side target and the outlet tangent orientation.

## Changes in 0.8.54

- Keep using readable intake mesh triangles when available; otherwise use `Collider.ClosestPoint` on the actual throttle/intake part before falling back to renderer bounds.
- Insert the pipe end slightly into the detected surface to avoid a visible gap.
- Rank throttle bodies ahead of intake manifolds, then choose the nearest matching part when an engine has multiple candidates.
- Log the selected part, match priority, distance, surface method, and endpoint. If no intake target exists, log mounted part IDs to help identify other engine naming conventions.
- Preserve the P-1X outlet tangent. The outlet bore axis has no inherent sign in the mesh fit, so the plugin now orients it toward the selected intake without replacing it with a straight-line direction.
- Shop entries, menu, power calculations, and physical induction selection are unchanged.

## Build and installation

- The C# plugin compiled successfully and the installed DLL matches the release package copies.
- CMS closed before installation. The previous 0.8.53 DLL was backed up at `build/installed-backups/CMS18TurboPrototype-20261031-121313.dll`.
- No game launch, live visual check, or dyno test has been performed with 0.8.54.

## Next live check

Use the isolated `cms18promo` sandbox profile (profile 3, if available). Inspect the pipe first on the engine stand and then in the engine bay. Confirm that it begins at the P-1X outlet and joins the throttle/intake side without crossing the block. If the R6 still has no target, send the new BepInEx log lines containing `No mounted throttle-body` and `Engine part candidate` so its naming can be mapped safely. Wait to dyno until the pipe looks correct.
