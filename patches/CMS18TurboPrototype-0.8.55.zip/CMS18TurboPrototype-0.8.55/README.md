# CMS 2018 Custom Induction Mod — Patch 0.8.55

Installed plugin for the ProCharger charge-pipe routing correction. CMS was closed during installation. The patch is waiting for a visual check; do not dyno until the pipe visibly exits the P-1X outlet and reaches the intake without crossing the engine.

Read REPORT.md for changes and rollback details. The previous plugin is in rollback/.
