# CMS 2018 Custom Induction Mod — Patch 0.8.55

**Date:** 2026-10-31  
**Build:** Compiled and installed while CMS was closed.  
**Installed DLL SHA-256:** D269EF6B138E3110BCF63C132C839BF576860651DE6050C5B4A355EDBB460AF6  
**Rollback DLL:** rollback/CMS18TurboPrototype-0.8.54.dll (SHA-256 EECA3764EC30BA7E331D6DA0B6FC8CCBAC84AFCAD74DF3DB02476650D0546FFE)  
**Live status:** Installed and waiting for your visual check. The dyno has not been tested with this patch; hold off until the pipe routing looks right.

## Why 0.8.54 still looked inverted

The embedded P-1X OBJ identifies the outlet bore and bead at the terminal opening, with an outward axis signed from the charger housing toward the outlet. The prior routing code reversed that axis whenever the intake lay behind it. That could make the generated pipe begin in the wrong direction and appear to pass through the charger. The previous route also used only 8% of calculated engine-envelope clearance, leaving too little room to route around the engine.

## Changes in 0.8.55

- Keep the model-derived P-1X outlet direction; do not reverse it to point at the intake. The pipe exits the real port before bending toward the selected throttle-body/intake surface.
- Route around the measured engine envelope using the calculated outboard clearance, with a bounded bend.
- Log outlet-axis alignment and final route bow alongside the selected target and endpoints for the next visual check.
- Keep shop listings, the main-menu mod list, induction options, belt drive, power calculations, and native turbo/supercharger visuals unchanged.

## Build and installation

- C# compilation succeeded for 0.8.55.
- CMS was not running when the plugin was replaced. The prior installed DLL was backed up at build/installed-backups/CMS18TurboPrototype-20261031-124928.dll and is included in rollback/.
- Installed file and release package use the same SHA-256 above.
- No live visual acceptance or dyno validation has been performed for this version.

## Next check

On the engine stand, inspect that the pipe begins at the P-1X outlet and travels outward before turning toward the intake. Then check the engine bay for block clearance and a connected intake end. If it still appears reversed, capture the screen and the “Built a routed P-1X charge-pipe connection” log line. Wait on dyno testing until the physical routing looks right.
