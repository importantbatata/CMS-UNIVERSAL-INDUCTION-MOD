/**
 * The career: customer cars, each with one diagnosable fault.
 *
 * Its own module because it is DATA, not a screen. Nothing here is scripted — every
 * fault below is one the simulation already models, so every job is solved by reading
 * what the pull log actually says rather than by following a walkthrough.
 *
 *   `setup`          the state overrides applied when the job is taken on
 *   `goal(r, ctx)`   whether the job is complete, judged on the pull just measured
 *   `teaches`        shown once it is, because the point is the lesson and not the tick
 *
 * Every job is held by tests/career.test.js to two facts: it fails as the customer
 * delivers it, and the fix its brief points at passes it.
 */

import {
  EXHAUST_DIA_OPTS, INJECTOR_OPTS, TURBINE_OPTS, computeHardwareVE, defaultEcuCalibration,
  deriveEngine, tankFuel, turbineWithCount,
} from '../sim/index.js';

import { makeInitialState } from './state/initialState.js';

/** @typedef {import('./state/initialState.js').BuildState} BuildState */

/**
 * The hardware `computeHardwareVE` reads, derived from a build exactly as the shell's
 * `hwForVe` derives it. One derivation, so a customer's car is handed over with the VE
 * table the AIR page would call current, not one computed on slightly different inputs.
 *
 * @param {BuildState} build
 * @returns {object}
 */
export function hardwareOf(build) {
  return {
    turboOn: build.turboOn,
    turbine: build.turboOn ? turbineWithCount(TURBINE_OPTS[build.turbineIdx], build.turbineCount) : null,
    exhaustDia: EXHAUST_DIA_OPTS[build.exhaustDiaIdx].dia,
    fuel: tankFuel(build),
    peakBoostPsi: build.turboOn ? Math.max(...build.boostCurve) : 0,
  };
}

/**
 * The car a customer hands over: the stock car with that job's fault fitted, and the
 * VE table and factory engine management it arrives with.
 *
 * Built on the WHOLE stock build rather than patched over the player's, so nothing of
 * the previous car rides along: a pipe, turbine or compressor the player chose would
 * otherwise turn up on a customer's car the brief says nothing about.
 *
 * @param {typeof CAREER_JOBS[number]} job
 * @returns {{build: BuildState, ve: number[][], ecu: object}}
 */
export function jobCar(job) {
  const stock = makeInitialState().build;
  const s = job.setup;
  const injIdx = s.injIdx ?? stock.injIdx;
  /** @type {BuildState} */
  const build = {
    ...stock,
    engineConfig: {
      ...stock.engineConfig,
      ...(s.camDuration ? { camDuration: s.camDuration } : {}),
      ...(s.springRate ? { springRate: s.springRate } : {}),
    },
    mods: { ...stock.mods, intake: Boolean(s.intake) },
    turboOn: Boolean(s.turboOn),
    boostCurve: s.boostCurve ? [...s.boostCurve] : stock.boostCurve,
    octaneIdx: s.octaneIdx ?? stock.octaneIdx,
    injIdx,
    ecuInjectorCc: s.ecuInjectorCc ?? INJECTOR_OPTS[injIdx].cc,
  };
  // A "stale VE" job hands you the OLD log against new hardware, which is the whole
  // point of it: the table is a record of what the stock engine used to flow.
  const logged = s.staleVe ? stock : build;
  return {
    build,
    ve: computeHardwareVE(logged.engineConfig, logged.mods, hardwareOf(logged)),
    // Tuned to THIS engine's valvetrain noise, as a preset's is: the previous car's knock
    // threshold, corrections and map slots are not the customer's.
    ecu: defaultEcuCalibration({ derived: deriveEngine(build.engineConfig), gate: build.wastegate }),
  };
}

export const CAREER_JOBS = [
  {
    id: 'rich-injectors',
    title: 'Runs terrible since the fuel upgrade',
    customer: 'Owner fitted bigger injectors himself. Says it now stinks of fuel, fouls plugs and feels gutless.',
    brief: 'Something is delivering far more fuel than the tables ask for. Run a pull, read the log, and find the cause rather than bending the fuel table around it.',
    target: 'Reach Tuning Score 90+ without touching the AFR table.',
    setup: { injIdx: 4, ecuInjectorCc: 315 },
    goal: (r, ctx) => ctx.tuningScore >= 90 && !r.events.some((e) => e.type === 'rich' || e.type === 'injscale'),
    teaches: 'The ECU calculates pulse width for the injector size it has been told is fitted. Hardware changed; the ECU was never told.',
  },
  {
    id: 'stale-ve',
    title: 'Cam swap, never re-logged',
    customer: 'Shop fitted a big cam and handed it back on the old calibration. Customer says it runs rough and lean up top.',
    brief: 'The engine breathes differently now. The VE table is still describing the old engine, so the ECU fuels for the old engine\'s air: too much where the new cam breathes worse, too little where it breathes better.',
    target: 'Get the mixture back on target and reach Tuning Score 85+.',
    setup: { camDuration: 268, springRate: 78, staleVe: true },
    goal: (r, ctx) => ctx.tuningScore >= 85 && !r.events.some((e) => e.type === 'lean' || e.type === 'rich'),
    teaches: 'A VE table is a log of measured airflow. Change the hardware and that log is simply out of date.',
  },
  {
    id: 'untuned-turbo',
    title: 'Turbo kit, stock calibration',
    customer: 'Customer bolted on a turbo and drove it home. Says it pulls hard then goes flat and rattles under load.',
    brief: 'A factory naturally-aspirated calibration has nothing meaningful above atmospheric pressure. Everything above 101 kPa is your job.',
    target: 'Survive 8 psi with Tuning Score 85+ and no knock events.',
    setup: { turboOn: true, boostCurve: [0, 0, 3, 6, 8, 8, 8, 7], injIdx: 2, ecuInjectorCc: 550, octaneIdx: 1 },
    goal: (r, ctx) => ctx.tuningScore >= 85 && !r.events.some((e) => e.type === 'knock'),
    teaches: 'Boost raises cylinder pressure enormously. Spark has to come out and mixture has to come richer, in the boost rows specifically.',
  },
  {
    id: 'lean-intake',
    title: 'Intake fitted, now it hesitates',
    customer: 'Aftermarket intake went on last week. Customer reports poor economy and a stumble at part throttle.',
    brief: 'The airflow sensor is reading against a housing it was never calibrated for. Watch the fuel trims, not just the power number.',
    target: 'Clear the trim fault and reach Tuning Score 95+.',
    setup: { intake: true },
    goal: (r, ctx) => ctx.tuningScore >= 95 && !r.events.some((e) => e.type === 'maf'),
    teaches: 'Closed loop hides small airflow errors at cruise. At wide open throttle the ECU stops listening to the O2 sensor and the error passes straight through.',
  },
  {
    id: 'full-session',
    title: 'Fresh build, no calibration at all',
    customer: 'Engine shop finished a build and handed it over with the factory file still loaded. Nothing on it has been tuned.',
    brief: 'This is a complete session, and the order matters. Verify what is actually fitted, set the scaling constants, correct airflow, then set fuel, then spark — last and in small steps. Skip a step and you will be tuning on a wrong foundation.',
    target: 'Tuning 90+ with no knock, no mixture faults and no scaling errors. The cam advisory will remain — that is a hardware trade-off, not something calibration can remove.',
    setup: { camDuration: 252, springRate: 76, injIdx: 3, ecuInjectorCc: 315, intake: true, staleVe: true, octaneIdx: 1 },
    goal: (r, ctx) => ctx.tuningScore >= 90
      && !r.events.some((e) => ['knock', 'lean', 'rich', 'injscale', 'maf', 'fuel'].includes(e.type)),
    teaches: 'Real tuning is a sequence, not a set of independent knobs. Scaling first, then airflow, then fuel, then spark — because each step assumes the one before it is already right.',
  },
  {
    id: 'power-goal',
    title: 'Customer wants 320 whp, safely',
    customer: 'Track day car. Owner wants real power but has to finish the weekend — reliability matters more than a headline number.',
    brief: 'Build and calibrate whatever it takes. The constraint is that it has to be clean: no knock, no lean cells, nothing running out of fuel.',
    target: '320+ whp with Tuning Score 90+ and zero knock.',
    setup: {},
    goal: (r, ctx) => r.peakHp >= 320 && ctx.tuningScore >= 90 && !r.events.some((e) => e.type === 'knock'),
    teaches: 'Power is easy. Power that survives a weekend is the actual job.',
  },
];
