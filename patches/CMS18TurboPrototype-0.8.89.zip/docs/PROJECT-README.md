# CMS 2018 Custom Induction Mod

## ECU Lab simulation port — 0.8.89

ECU Lab v1.11.0 is being treated as a **simulation sandbox**, not as a tuning tool. This patch ports a verified subset of its engine-geometry, charge-thermodynamics, trapped-air, and parasitic-friction equations into an isolated C# module. It does not yet port the complete combustion-cycle solver, connect this model to CMS live power, or add an ECU tuning interface. See [the simulation-port report](build/release_0.8.89/report.md), [ECU Lab findings](docs/ECU-LAB-AUTO-DETECTION-FEASIBILITY.md), and [patch 0.8.89](build/release_0.8.89/report.md).

Checks for 0.8.89: clean plugin build; 23 isolated C# assertions compared to ECU Lab JavaScript references; calibration schema 9/9; map evaluator 8/8; turbo size 14/14; charge-air 11/11; turbo operating point 11/11; offline project validator passed with expected warnings that 0.8.89 is not installed/runtime-unverified. No CMS launch or install was performed.

## Expansion specification audit (2026-11-04)

This remains the existing mod project. The complete implemented/partial/missing feature comparison, verified CMS classes, save/installation constraints, and staged plan are in [docs/EXPANSION-STATUS.md](docs/EXPANSION-STATUS.md). Patch 0.8.87 repairs shop visibility by marking custom products as base-game content. The broader expansion remains incomplete.

## Debugging audit (2026-11-05)

The current build and offline model-check results, project inventory, defect register, ECU Lab simulation-port status, feature status, and exact live-test checklist are in [docs/DEBUGGING-AUDIT-2026-11-05.md](docs/DEBUGGING-AUDIT-2026-11-05.md). The project builds; turbo-tier (14), charge-air (11), and turbo operating-point (11) standalone assertions pass. I aligned the integrated power-curve harness with the current factory-spec safety behavior; 87 assertions pass before it reaches CMS's native `VehiclePhysics.Engine.CalculateTorque` ECall, which cannot execute in standalone PowerShell. The full harness is **not a pass** and no dyno result is claimed. CMS was not launched. This audit made no gameplay-source or game-install changes.

## Current status - Patch 0.8.87

Patch 0.8.87 is built, offline-validated, installed, and backed up. Built and installed DLL SHA-256: `DA87F29B122F2DB95A6DD748E681CD1A35E135B214511762A570DB8535B29764`. Previous plugin backup: `build/installed-backups/CMS18TurboPrototype-20261105-072936.dll`. It fixes the shop-card gate by using CMS's verified base-game DLC sentinel on both P-1X products. The built-in shop display and live buying still need the user's next in-game check; CMS was not launched. Decorative model bolt heads are not CMS screw interactions, and the virtual mount remains one-action removable. The physical turbo parts chain, broad verified engine support, and durability systems remain incomplete. See [Patch 0.8.87 report](build/release_0.8.87/report.md) and [the expansion audit](docs/EXPANSION-STATUS.md).
## Patch folders

Every numbered patch folder contains a quick README, detailed report, ZIP archive, and expanded package. `Source Project` contains the editable source snapshot. This README is the central patch and live-test record.

| Patch | Change | Live-test status |
|---|---|---|
| [0.8.47](Patch%200.8.47/report.md) | Shop registration, selection hitboxes, Mods menu, and induction visuals. | Build checks passed; no live launch. |
| [0.8.48](Patch%200.8.48/report.md) | Catalog registration and menu callbacks. | Shop capture timed out; profile 2 selected, profile 3 clone unchanged. |
| [0.8.49](Patch%200.8.49/report.md) | Shop readiness and custom part loading. | 124 power/torque checks passed; earlier log had missing listings and a custom-part loading exception. |
| [0.8.50](Patch%200.8.50/report.md) | Mono reflection fix and corrected P-1X orientation. | Later live session confirmed standard/high-boost shop entries and mounting on stand and in car. |
| [0.8.51](Patch%200.8.51/report.md) | Shortened pipe loop and conditional Mods button position. | User confirmed shop/installation; Mods button jitter and pipe alignment remained. |
| [0.8.52](Patch%200.8.52/report.md) | One-shot menu insertion and smoother pipe mesh. | Jitter reduced; tube still needed refinement. |
| [0.8.53](Patch%200.8.53/report.md) | Model-derived P-1X outlet, hollow pipe, and clamps. | No live visual test. |
| [0.8.54](Patch%200.8.54/report.md) | Intake target search and exhaust filtering. | R4 throttle body identified; I6 scan found no mounted intake target. |
| [0.8.55](Patch%200.8.55/report.md) | Pipe routed outboard around engine. | User confirmed pipe connected to P-1X; alignment still off. |
| [0.8.56](Patch%200.8.56/report.md) | Shorter first bend. | User reported nice I6 6DOHC fitment; I6 pipe target unverified. |
| [0.8.57](Patch%200.8.57/report.md) | Reduced outlet handle. | R4 still mildly off. |
| [0.8.58](Patch%200.8.58/report.md) | Further reduced outlet handle. | User said â€œalmost there.â€ |
| [0.8.59](Patch%200.8.59/report.md) | Reduced minimum outlet handle. | User said inlet/spacing remained wrong; collider route used. |
| [0.8.60](Patch%200.8.60/report.md) | Renderer-bounds intake endpoint and deeper insertion. | User deferred fitment; no dyno. |
| [0.8.61](Patch%200.8.61/report.md) | Boost added to shared dyno engine specs; kit priority and 32-psi tier. | Subsequent testing found factory/measured scope unsafe. |
| [0.8.62](Patch%200.8.62/report.md) | Dyno output scoping prototype. | Factory and measured values moved together; user reported no gain. |
| [0.8.63](Patch%200.8.63/report.md) | Attempted measured-helper scoping. | Constructor lookup prevented later hooks. |
| [0.8.64](Patch%200.8.64/report.md) | Constructor compatibility follow-up. | Mono equality exception prevented hook registration. |
| [0.8.65](Patch%200.8.65/report.md) | Constructor compatibility repair and dyno gains. | User confirmed gains on I4 and I6; curves were still the same. |
| [0.8.66](Patch%200.8.66/report.md) | Carbureted I6 turbo compatibility and non-DLC shop entries. | Cross-car ProCharger and factory-power contamination reported afterward. |
| [0.8.67](Patch%200.8.67/report.md) | Emergency cross-car containment. | The affected-session log is 0.8.66 and records engine specs boosted to 788 hp; 0.8.67 is installed but still needs an untouched-car live verification. |
| [0.8.68](Patch%200.8.68/report.md) | Isolates settings by model/plate; boost and visual restore require an installed custom kit. | Rebuilt and installed with backup; not live-tested. Untouched-car check and I6 transfer verification required. |
| [0.8.69](Patch%200.8.69/report.md) | Stable factory-plate identity for per-car kit and settings restoration. | Built and offline-validated; not installed or live-tested. |
| [0.8.70](Patch%200.8.70/report.md) | Exact-engine transfer recovery. | Installed after confirming CMS closed; user still reported the ProCharger missing in the car. |
| [0.8.71](Patch%200.8.71/report.md) | Re-enable the transferred mount/renderers and log visibility. | Installed; live transfer check still pending, then latest report again showed the part missing in the car. |
| [0.8.72](Patch%200.8.72/report.md) | Carburetor gating, native stand radial chooser, and tighter I4 ProCharger pipe routing. | Installed; stock radial interaction failed in the latest session. Superseded by 0.8.73. |
| [0.8.73](Patch%200.8.73/report.md) | Removed radial hooks as a stock-menu recovery hotfix. | Superseded by 0.8.74. |
| [0.8.74](Patch%200.8.74/report.md) | Adds the forced-induction action before the radial menuâ€™s normal icon-creation pass; preserves stock choices. | Built and installed with rollback backup; CMS not launched; live menu check pending. |
| [0.8.75](Patch%200.8.75/report.md) | Uses the radial controller `!EngineStand` key and removes the persistent stand panel. | Built, offline-validated, installed with rollback; CMS not launched; live check pending. |
| [0.8.76](Patch%200.8.76/report.md) | Detects the stand from menu key/enum and actual stand group; adds hook diagnostics. | Installed after 0.8.75 live failure; offline validation passed; retest pending. |
| [0.8.77](Patch%200.8.77/report.md) | Adds the stand action during stock radial option reading; side-mounts stock turbo and Roots visuals. | Installed with rollback; offline validation passed; CMS not launched; live test pending. |
| [0.8.81](build/release_0.8.81/report.md) | Starts the expansion with a single verified base-engine turbo response profile and catalog seam. | Built and offline-validated; not installed or live-tested. |
| [0.8.82](build/release_0.8.82/report.md) | Adds a persistent 35–88 mm turbo inducer selector and size-sensitive spool/estimated airflow model to the existing turbo kit. | Built and offline-validated; not installed or live-tested. Modeled tiers are assumptions, not compressor maps. |
| [0.8.83](build/release_0.8.83/report.md) | Rejects non-finite boost, RPM, load, horsepower, airflow, and spool inputs before they can contaminate calculations. | Build, 14 model assertions, and offline validator passed. Native dyno execution and in-game transfer remain unverified. |
| [0.8.84](build/release_0.8.84/report.md) | Adds a bounded charge-air estimate with compressor temperature, intercooler effectiveness and pressure drop; uses estimated manifold density in the existing sampled torque path. | Build and offline model/assembly checks passed; native dyno response unverified. |
| [0.8.85](build/release_0.8.85/report.md) | Adds a bounded turbo operating point with estimated compressor efficiency, size-tier flow limiting, and delivered boost into the existing torque/gauge path. | Build, 11 operating-point checks, 11 charge-air checks, 14 turbo-tier checks, and offline game-signature/resource checks passed. Live dyno/transfer behavior unverified. |

| [0.8.86](build/release_0.8.86/report.md) | Fixes visual placement lookup when CMS marks visible pulley/intake meshes unmounted during transfer. | Installed; DLL hash verified; build, 36 model checks, and offline validator passed. Live placement and gameplay still need user retest. |
| [0.8.87](build/release_0.8.87/report.md) | Fixes CMS hiding both P-1X products because their shop DLC arrays were empty; documents the virtual mount's one-action removal behavior. | Built and offline-validated, installed with rollback; no game launch. Shop-card visibility and removal need user's live check. |
| [0.8.89](build/release_0.8.89/report.md) | Ports an isolated ECU Lab simulation subset: engine geometry, charge heating/cooling, trapped air, and rubbing/pumping friction. | Clean build; simulation 23/23; existing model/schema checks and offline validator passed. Not installed; game power, UI, save/load, and dyno integration not run. |
| [0.8.88](build/release_0.8.88/report.md) | Adds a versioned ECU calibration record with strict vehicle, installed-engine, hardware, table-shape, and numeric validation; documents ECU Lab v1.11.0 findings. | Clean build, schema 9/9, sampler 8/8, induction model checks and offline validator passed. Not installed; CMS/UI/save/dyno tests not run. |

## Live-test record

### Shops and buying

- User saw the standard P-1X in the Main Shop at a base price of **$12,500** (discounted checkout showed **$11,875**).
- The high-boost P-1X appeared in the Tuning Shop for **$24,900** in a confirmed session.
- Earlier searches returned blank listings; later live testing confirmed both products.

### Installation and fitment

- The ProCharger was mounted on the engine stand and transferred into a car successfully in later test runs.
- Selection/removal bugs, invisible parts, ghost screws, bad part names, and missing engine transfer were reported and iteratively addressed.
- The P-1X orientation was corrected. The user described timing/belt alignment as connected and later said I6 6DOHC fitment looked good.
- Turbo and supercharger placements, radiator clearance on the I6, and ProCharger pipe/inlet alignment remained unfinished. The user chose to defer visual fitment while moving toward dyno work.

### Main menu and performance

- The added Mods page lists loaded BepInEx mods and keeps Credits. User confirmed it works.
- Mods button jittered around Exit in earlier live versions; later user said it worked well, though intermittent movement remained.
- User reported substantial lag and a CMS loading hang in earlier sessions. No frame-rate measurements were collected.

### Dyno data

Last confirmed gain screenshots came from patch 0.8.65:

| Engine | Factory | Measured | Gain |
|---|---:|---:|---:|
| I4 14 DOHC, 24 psi | 483 HP / 602 NÂ·m | 788 HP / 975 NÂ·m | +63.03% / +62.08% |
| I6 6 DOHC, 8 psi | 412 HP / 421 NÂ·m | 569 HP / 580 NÂ·m | +38.23% / +37.84% |

The user noted the curve looked the same despite the higher measured results. Later dyno scoping attempts altered factory power or produced no gain, so those results are not treated as trustworthy. The latest report is a containment build; it intentionally leaves factory engine specifications untouched.

### Cross-car contamination â€” latest issue

- User reported the ProCharger appearing in cars that had not been bought or modified, and factory engine power being increased across cars during dyno work.
- The prior code could both alter shared engine-specification values and persist selection by engine prefab/group aliases. Those paths are unsafe because CMS reuses engine types across multiple cars.
- Patch 0.8.67 disables the engine-spec hook, ignores shared aliases without deleting preferences, and limits auto-restoration to the active loader. No save file was changed. The BepInEx log from the reported session identifies 0.8.66 as loaded and logs its dyno spec hook outputting 788 hp. The installed 0.8.67 DLL matches the package hash, but its behavior has not been verified in a new launch yet.
- The torque/power boost path is temporarily limited to dyno chart sampling. Normal live-driving boost and measured headline output need a precisely scoped follow-up before being called finished.

## Cross-car safety and transfer follow-up â€” 0.8.68

The firstpass IL audit proved `CarLoader.GetSaveName()` is only `UnityEngine.Object.get_name()`, and the affected dyno log recorded `#carloader5`. Patch 0.8.68 therefore stops using loader names for persistent car settings. More importantly, no saved mode or stale kit preference alone can activate boost or reconstruct a part: an installed custom part must be detected on that car. The 0.8.67 factory-spec containment remains in place. The latest log confirms the prior runtime was 0.8.67 and its transferred kit record used `#carloader5`. The current build uses a model/plate key and restores from that matching saved kit record, which is needed because CMS may not serialize the synthetic mount. It was rebuilt and installed with a backup, but is not live-tested; the legacy ambiguous loader-name record will not be migrated automatically. The existing modified car may need the induction engine transferred again once to bind its kit to the durable key. See [report](Patch%200.8.68/report.md).

## Next live check for 0.8.68

1. Use the `cms18promo` sandbox profile and verify the in-game profile label.\n2. Inspect an untouched car first; it must have no ProCharger and unchanged factory HP/torque.\n3. Transfer the equipped engine from the stand to the previously modified car so the kit is linked to its model/plate identity. Confirm it appears, can be selected, and survives reloading the car.\n4. Check the base-game I6, then run a dyno only on the car with the custom kit installed.\n5. Stop if any untouched car is affected; capture a screenshot and BepInEx log.

## Folder guide

- `Patch 0.8.xx/README.md` â€” quick patch summary.
- `Patch 0.8.xx/report.md` â€” detailed change and build record.
- `Patch 0.8.xx/CMS18TurboPrototype-0.8.xx.zip` â€” package archive.
- `Patch 0.8.xx/CMS18TurboPrototype-0.8.xx/` â€” expanded plugin/source/model/rollback package.
- `Source Project/` â€” editable project snapshot.
- `Patch History.md` â€” compact version index.



### Identity key audit follow-up

Static inspection of `Assembly-CSharp-firstpass.dll` confirms the original factory plate is saved separately from the visible plates. Patch 0.8.68 uses the current visible plate first, so changing that plate may create a new lookup key. The follow-up should prefer the saved factory plate, then fall back to the visible plate fields. This finding is documented in [the source audit](Source%20Project/docs/Assembly-CSharp-firstpass-audit.md) and [the 0.8.68 report](Patch%200.8.68/report.md); it still needs implementation and a live reload check.

## Patch 0.8.69 live-test record

- Offline build and validation passed. Validation covers source and model assets and confirms the shared factory engine-spec hook remains disabled; it does not prove Unity runtime transfer behavior.
- The package is for review only. Patch 0.8.68 remains installed. No CMS process was launched and no save files were modified.
- Identity uses the persisted factory plate first because visible plates can change. The factory plate field was confirmed in the local firstpass assembly audit and save path.
- Awaiting the user's live test on the `cms18promo` sandbox. First verify an untouched car, then the fitted car and visible-plate change/reload, then dyno only after containment passes.






## Patch 0.8.70 â€” ProCharger engine-transfer recovery

- Major missing-in-car report traced to the installed game still loading 0.8.68. Its log ends immediately after the transfer action begins, with no completion/restore record.
- Added an exact-loader, exact-engine-group recovery on `CarLoader.SetEngine`, bounded to 120 frames; it cannot restore a kit to unrelated cars or change factory specs.
- Offline build and validator passed. Patch 0.8.70 has not been installed or live-tested; installed game remains 0.8.68.
- Live test pending: user should transfer the fitted engine in `cms18promo`, then confirm ProCharger visibility and unrelated-car isolation.
- Details: [Patch 0.8.70 report](Patch%200.8.70/report.md).

### 0.8.70 deployment update

The user reported the missing ProCharger again. Investigation confirmed the game was still on 0.8.68; that screenshot did not exercise the recovery change. With CMS confirmed closed, 0.8.70 is now installed and 0.8.68 was backed up. Build and offline validation passed. Runtime transfer remains untested; await the user's `cms18promo` test.

### Patch 0.8.71 live-test status

The user confirmed the missing ProCharger persists under 0.8.70. That run's log records transfer completion and restoration on `emden_lotz_gt_plate_yap-j1sw7`, but the screenshot still shows no part. Patch 0.8.71 explicitly reactivates the mount and renderer hierarchy and adds visibility diagnostics. It has been installed with a 0.8.70 backup; offline validation passed. CMS has not been relaunched, so wait for live transfer test. Do not dyno until visibility passes.

## Patch 0.8.72 status and live-test notes

- Offline C# build succeeded. The 0.8.72 DLL SHA-256 is `417EAB4B2340B3CFA74E14A6D13FE14A7D0411EF85FCFD92327F88A93F7AF5FF`.
- No CMS launch or game test was performed because the user is unavailable for testing. No save was edited and no game files were installed or replaced.
- The game's radial-menu method and field names were checked in the local firstpass assembly; actual interaction still needs the user's live test.
- Next test: on the engine stand, right-click and open **Add forced induction**; confirm Turbo/Supercharger are disabled on a carbureted engine and ProCharger remains selectable. Then try the non-carbureted I4 pipe/transfer. Stop before dyno if the part is missing or any untouched car is changed.
- This is not a confirmed visual fix. It keeps the existing detailed P-1X model/materials and changes the generated tube clearance; in-game appearance and transfer need live confirmation.


## Patch 0.8.73 live-test note

The current log identifies 0.8.72 and shows the radial hooks were registered, but has no radial-selection failure trace. Version 0.8.73 removes those hooks as a cautious isolation fix. Engine-transfer tracking remains active; test stock radial responsiveness and engine placement before any dyno run. Patch 0.8.73 is installed with a backup; CMS was not launched and no save changes were made.
## Patch 0.8.74 live check

1. With an engine on the stand, use the stock radial menu and confirm ordinary choices still work.
2. Confirm â€œAdd forced inductionâ€ appears and opens the chooser.
3. Confirm an empty stand does not show the custom action.
4. If the menu fails, close CMS and share the current BepInEx log.
## 0.8.74 offline retest

The project validator initially caught reflection equality operators in the new radial hooks. Those checks now use reference equality, and the compiled plugin passes the Mono compatibility, model, engine-transfer, shop, dyno-scope and game-signature checks. The validator's older pipe-clearance expectation was updated from 25 mm to the current 6 mm setting. This is offline verification only; the game has not been launched on 0.8.74.


| [0.8.78](Patch%200.8.78/report.md) | Keeps the pointer visible and usable over the radial-menu induction chooser; restores prior cursor state on close. | Offline validation passed; installed without launching CMS; live check pending. |




| [0.8.79](Patch%200.8.79/report.md) | Pauses the CMS virtual cursor only while the chooser is active; restores its visibility and prior system cursor state on close. | Offline validation passed; installed without launching CMS; live movement/click test pending. |


## Patch 0.8.80 status and live-test addendum

Patch **0.8.80 is installed**, built from the existing source project, and offline-validated. CMS was not launched after installation. Its rollback to 0.8.79 is in the patch folder.

### Existing systems reviewed

- **Working/previously confirmed:** buyable standard ProCharger in the Main Shop ($12,500; a discounted checkout showed $11,875), high-boost ProCharger in the Tuning Shop ($24,900), Turbo/Roots/P-1X selection, the stock-style Mods menu, and engine-stand selection. User confirmed a ProCharger dyno gain on the I4 and I6 in an earlier build.
- **Implemented but needs repeat live verification:** transfer/removal selection, side-mounted Turbo and Roots visuals, ProCharger engine-bay visual and tubing, cursor interaction, and per-car dyno effects. These have regressed across prior patches, so offline source checks do not count as live confirmation.
- **Safeguards preserved:** dyno code does not alter shared factory `EngineSpecs`; boost is scoped to the active car/chart. Car identity uses model/plate rather than shared engine names to prevent cross-car contamination.
- **Still missing from the larger expansion spec:** twin/sequential/compound/twincharged layouts, realistic turbo sizing maps, temperature/intercooler efficiency, dedicated intercooler/BOV/wastegate/pulley hardware, engine damage/supporting upgrades, and complete install dependency kits.


## Live-test record carried forward

| Check | Evidence and status |
|---|---|
| Shops | User confirmed standard and high-boost listings in a prior live session; prices above. |
| Installation | Earlier runs confirmed stand and car installation, but later reported transfer failures. The 0.8.79 log records an R4 restoration, while the latest user report says the ProCharger did not transfer. Treat transfer as **unresolved until the next live check**. |
| Dyno | Earlier confirmed I4 at 24 psi: 483 HP / 602 N·m factory, 788 HP / 975 N·m measured (+63.03% / +62.08%). I6 at 8 psi: 412 HP / 421 N·m factory, 569 HP / 580 N·m measured (+38.23% / +37.84%). The user reported the curve shape stayed the same. Later cross-car/factory-power regressions mean these values are historical, not validation of current builds. |
| Cross-car bug | Patch 0.8.66 was linked to ProChargers appearing on unrelated cars and factory power contamination. Containment was added in 0.8.67–0.8.68 and retained; untouched-car behavior still requires live confirmation. |
| Radial/menu | User confirmed the Mods menu and forced-induction chooser open. Pointer behavior was reported stuck/centered in the prior screenshot; the 0.8.79 Cursor3D handoff has not been live-confirmed from its fresh build. |

### 0.8.80 change and next check

CMS can replace an engine object after the initial transfer restoration. Patch 0.8.80 checks briefly for that replacement and reattaches the visual only on the same plate-identified car. It is installed but untested. On `cms18promo`, choose ProCharger on the stand, transfer the engine into a car, wait for the crane sequence to finish, then check visibility and selection in the bay. Verify an untouched car remains unchanged. Save `BepInEx/LogOutput.log` before restarting if it still fails. Hold dyno testing until transfer passes.

See [Patch 0.8.80 report](Patch%200.8.80/report.md) and [Patch History](Patch%20History.md).

## Expansion kickoff — Patch 0.8.81

Patch 0.8.81 starts the expansion with a single verified base-engine profile (`engine_r4`, I4 DOHC AQC) and routes its existing turbo spool response through that profile. The 55 mm turbo tier and spool thresholds are assumptions, not measured data. Build and offline validation passed; 0.8.80 remains installed, and no live/game test was run. This does not yet provide the physical turbo parts/dependency chain or resolve the existing ProCharger transfer issue. See [Patch 0.8.81 report](build/release_0.8.81/report.md) and the updated [expansion audit](docs/EXPANSION-STATUS.md).

## Expansion increment — Patch 0.8.82

Patch 0.8.82 builds on the existing turbo kit and profile without changing ProCharger or radial-menu code. It adds selectable 35, 45, 55, 62, 67, 76, and 88 mm compressor-inducer tiers, with illustrative horsepower/flow ceilings, efficiency assumptions, and size-dependent spool response. The selected size is saved globally, per engine-stand group, and per identified car; group metadata carries it across engine transfer. The active turbo dyno calculation uses the selected tier's estimated efficiency and airflow ceiling, without modifying shared factory engine specifications.

These are coarse balancing estimates, not measured compressor maps or a complete turbo conversion. The CMS kit still represents a virtual installable part and does not add the required manifold, oil plumbing, downpipe, intercooler, separate charge pipes, wastegate, or dependency graph. Patch 0.8.82 built and passed offline validation and compiled-code model checks. Patch 0.8.80 remains installed; CMS was not launched and no live test was performed. See [Patch 0.8.82 report](build/release_0.8.82/report.md).

The focused test against the compiled model passed its 10 tier/flow/spool assertions. The broader `tools/test_power_curves.ps1` passed its model and transfer assertions but stopped at synthetic engine torque execution because a CMS `VehiclePhysics.Engine` method is an internal call unavailable outside the game (`ECall methods must be packaged into a system module`). Therefore this is not evidence of a live dyno result.


Patch 0.8.82 DLL SHA-256: `0E93A276528B3AC1AB85D56CCBAB916761F2B9B2A8980AA36A593CB69493B58B`.

## Expansion stability increment — Patch 0.8.83

Patch 0.8.83 adds finite-safe normalization for boost targets, spool inputs, engine RPM used in the modeled compressor path, and estimated airflow inputs. This targets the confirmed calculation boundary defect only. It deliberately leaves the ProCharger transfer, shop, radial-menu, and visual mounting paths unchanged pending live reproduction. The project inventory is in [docs/PROJECT-INVENTORY-2026-11-04.md](docs/PROJECT-INVENTORY-2026-11-04.md) and its path list CSV.

The plugin compiled; 14 compiled-model assertions and the offline game-signature/resource validator passed. The broader dyno test cannot execute CMS's native `VehiclePhysics.Engine` call outside the game. Patch 0.8.80 remains installed, and CMS was not launched. Do not treat this patch as live-tested or as a complete forced-induction conversion. See the [0.8.83 report](build/release_0.8.83/report.md).

Patch 0.8.83 DLL SHA-256: `1F3FC260D56C07A3613C3AD7DE647CF57675119CAD3F30EFB6A74766EB37E9CC`.

## Expansion calculation increment — Patch 0.8.84

Added `src/ChargeAirModel.cs` as a pure bounded calculation layer and wired its estimated manifold air-density ratio into the existing `CalculateInductionTorqueDelta` path. It distinguishes compressor-outlet gauge pressure from manifold gauge pressure after a default core pressure drop, calculates compressor heating from pressure ratio and assumed efficiency, and estimates charge temperature after assumed intercooler effectiveness. Invalid inputs fall back to finite defaults. The values are estimates: the game integration does not yet expose selectable intercooler specs, real ambient data, per-engine volumetric-efficiency maps, or validated turbo compressor maps. This patch does not add physical intercooler items, turbo hardware dependencies, or full durability behavior.

Verification before installation: build succeeded; 11 compiled charge-air assertions and 14 turbo-tier/input assertions passed; the offline game signature/resource validator passed. The broad `test_power_curves.ps1` suite passed its static/model assertions until it attempted to invoke CMS's native `VehiclePhysics.Engine` ECall outside the game; that invocation is unsupported and exited with `ECall methods must be packaged into a system module`. Therefore the game torque/dyno response remains unverified. Patch 0.8.84 was subsequently installed with a rollback copy; CMS has not been launched. See [0.8.84 report](build/release_0.8.84/report.md).


Patch 0.8.84 DLL SHA-256: `3C01629CB8B1092A03379B59CC6EBD8A4FA700D858EA3BE45D498E46F0595A89`.


Release ZIP SHA-256: `9E4F8D148DD98734A827E1F36C6953CA31D0C552930727382FAA5B34E82C6DB8`


## Patch 0.8.86 — current status

Patch 0.8.86 is installed with a verified build/install DLL hash and rollback backup. It fixes the ProCharger placement fallback identified in the 0.8.85 live log: visible crank-pulley/intake meshes were ignored while CMS temporarily marked their part scripts unmounted during transfer. It uses active visible renderer geometry as a visual locator and leaves CMS install/remove rules unchanged. CMS has not been launched, so live placement still needs a check. The broader expansion remains partial; see [Patch 0.8.86 report](build/release_0.8.86/report.md) and [the expansion audit](docs/EXPANSION-STATUS.md).

### Patch 0.8.86 — placement repair installed, awaiting live test

- **Observed:** User screenshot showed the ProCharger far outside the engine bay. The prior live log showed crank-pulley/intake meshes present but `IsUnmounted=true` during engine transfer.
- **Change:** Visual locator accepts a part with active visible renderer geometry even while CMS temporarily marks it unmounted; installed-state rules remain unchanged. See [report](build/release_0.8.86/report.md) and [expansion status](docs/EXPANSION-STATUS.md).
- **Offline checks:** Build passed; 36 existing independent model assertions passed (11 turbo operating-point, 11 charge-air, 14 turbo-size); integration/resource validator passed both before and after deployment, confirming installed version consistency.
- **Live test:** Not run. CMS was not launched. ProCharger transfer placement, part selection, dyno, save/load, and untouched-car isolation still require live test.
- **Expansion:** This is one visual-transfer bug fix, not completion of the expansion. Physical turbo dependencies, additional configurations, durability, and full save persistence remain incomplete.

## Patch 0.8.87 — shop visibility fix

- **Observed:** User reported the standard ProCharger absent from Main Shop search and the 32 PSI variant absent from Tuning Shop, while confirming the part rendered in the car.
- **Root cause:** The game does not render catalog rows with an empty DLC list. The plugin inserted both rows into `GameInventory`, but CMS's `UIManager.CreateShop` checks `SteamScript.GetDLC(PartProperty.DLC)` before creating a card. An empty list returns false. The verified base-game sentinel is `[0]`.
- **Change:** All three custom product-registration paths now set DLC to `[0]`; names, IDs, prices, transfer behavior, and saved-car compatibility remain unchanged. Added test and validator checks for both P-1X entries.
- **Fasteners:** The four visible bolt details are part of the visual mesh and do not map to `MountObject` screw steps. The virtual universal mount has no CMS fastener objects and is configured for one-action removal. This patch preserves that tested-safe behavior instead of adding unverified unscrew targets.
- **Verification:** Build passed. The offline validator passed all source, asset, and verified-game-signature checks, including the base-game shop-card sentinel. The existing `test_power_curves.ps1` passed its model and shop-registration assertions, then hit an unrelated reflection `ECall methods must be packaged into a system module` at the later torque-hook invocation; do not count the full script as passing. CMS was not launched, so live shop cards/removal were not verified.
- **Build/install record:** Build SHA-256 `DA87F29B122F2DB95A6DD748E681CD1A35E135B214511762A570DB8535B29764`; installed DLL hash matches. Previous installed DLL is preserved at `build/installed-backups/CMS18TurboPrototype-20261105-072936.dll`.
- **Expansion:** Still in progress. Turbo manifold/charge-air hardware dependencies, twin-turbo and advanced configurations, durability/failure, and complete save persistence remain future work. See [expansion status](docs/EXPANSION-STATUS.md).

### 0.8.87 live shop confirmation and ECU audit — 2026-11-05

- **Live shop evidence:** The user supplied screenshots showing the standard ProCharger P-1X in Main Shop at $12,500 and the high-boost P-1X in Tuning Shop at $24,900. The latter listing is named for 32 PSI. This confirms those two listings are visible in that live session; it does not verify every purchase/install/save path.
- **Automatic engine identification:** Existing induction code finds the active CMS car loader, gets the current installed engine root identifier, and stores induction mode/boost by car identity. `engine_r4` is the only compatibility catalog entry and its boost response data is illustrative; this is not an ECU tune.
- **ECU functionality status:** No player-facing CMS ECU map editor, verified fuel/ignition-map payload, calibration writer, or safe ECU-screen hook has been identified. No ECU hook or fabricated map data was added. Full findings and next integration requirements are in [docs/ECU-LAB-AUTO-DETECTION-FEASIBILITY.md](docs/ECU-LAB-AUTO-DETECTION-FEASIBILITY.md).
- **ECU Lab simulation port:** the exact v1.11.0 source and MIT license are now present in `third_party/ecu-lab-1.11.0`. Patch 0.8.89 ports a validated first subset of its standalone simulator equations to an isolated C# module. The full simulation engine and any CMS live-power integration remain incomplete. See [the simulation-port report](build/release_0.8.89/report.md) and [source findings](docs/ECU-LAB-AUTO-DETECTION-FEASIBILITY.md).
- **Current scope:** The ECU feature is therefore **not implemented**. Existing car/engine detection is reusable foundation only. The next step is obtain/inspect the exact tagged source and identify a real CMS tuning UI/data integration point before implementing the calibration registry or UI.





