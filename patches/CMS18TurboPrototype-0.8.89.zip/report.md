# Patch 0.8.89 — ECU Lab simulation sandbox port

## Purpose

This continues the existing CMS 2018 mod. At the user's clarification, ECU Lab is being treated as a standalone engine-simulation sandbox, not as a tuning editor. This patch ports a first subset of the simulation equations into the existing C# plugin while keeping it isolated from CMS performance hooks.

## ECU Lab source reviewed

- Project: `DNiev/ecu-lab`, exact v1.11.0 source under `third_party/ecu-lab-1.11.0`.
- Archive SHA-256: `77BE9F5E108CEFEA1226EA53CA8749DF586C7D4E9D330786055026C79BDB57DE`.
- License: MIT; original license is included in the package.
- Source areas referenced: `src/sim/engine.js`, `thermo.js`, `cycle.js`, `friction.js`, `constants.js`, and `coefficients.js`.
- No JavaScript application/runtime, calibration table, or ECU interface was copied into CMS.

## Implementation

Added `src/EcuLabSimulationCore.cs` and included it in the existing `build.ps1` source list. It currently contains:

- Supported engine geometry derivation for the port's I4, I6, V6, and V8 configurations.
- Charge compression heating and intercooler effectiveness.
- Residual fraction and trapped charge temperature mixing.
- Fuel evaporative cooling and an exhaust temperature estimate.
- Inlet Mach index, the associated VE adjustment, cam behavior, spring friction, and bore/stroke behavior.
- Ideal-gas trapped air mass per cylinder-cycle.
- Rubbing FMEP, pumping FMEP, and derived friction torque.
- Finite/range validation around the newly exposed trapped-air and friction inputs.

This is not a port of ECU Lab's complete `evaluatePoint`/`point.js`, two-zone combustion integration in `cycle.js`, live simulation, fuel/ignition/knock, or all turbo and control systems. The new module has no CMS caller yet, so it does **not** change game power or dyno results. Existing induction and calibration code remains in place.

## Verification

| Check | Result |
|---|---|
| Existing plugin C# build | **PASS** — `build/CMS18TurboPrototype.dll`, version 0.8.89 |
| ECU Lab simulation reference harness | **PASS: 23 assertions** — values compared against original JavaScript modules; invalid absolute pressure and negative RPM rejected |
| Turbo-size model | **PASS: 14 assertions** |
| Charge-air model | **PASS: 11 assertions** |
| Turbo operating-point model | **PASS: 11 assertions** |
| Calibration schema | **PASS: 9 assertions** |
| Calibration map evaluator | **PASS: 8 assertions** |
| Offline CMS project validator | **PASS** — expected warning: installed game plugin is 0.8.87, and 0.8.89 was not installed or runtime-tested |
| CMS launch, live dyno, save/load, or in-game effect of this port | **NOT RUN** — intentionally kept separate from live game behavior |

Build emitted no compiler warnings. No game files, installed plugin, or player saves were changed. No CMS launch was performed.

## Files changed

- `src/EcuLabSimulationCore.cs` — added isolated C# port and input validation.
- `src/CMS18TurboPrototype.cs` — incremented plugin version to 0.8.89.
- `build.ps1` — already includes the C# module in plugin compilation.
- `tools/test_ecu_lab_simulation_core.ps1` — added 23 reference/safety assertions.
- `tools/validate_build.ps1` — includes newly compiled source files in release snapshot checks.
- `README.md`, `docs/ECU-LAB-AUTO-DETECTION-FEASIBILITY.md`, `docs/EXPANSION-STATUS.md`, and `docs/DEBUGGING-AUDIT-2026-11-05.md` — updated scope/status and preserved prior patch history.

## Next port milestone

The next substantial step is a narrow, validated implementation of ECU Lab's per-point airflow and engine-output path, comparing selected `evaluatePoint` outputs to the JavaScript version. After that, port the cycle solver incrementally. Do not connect the model to CMS torque/dyno hooks until the equations and test fixtures are mature; separately verify native integration and ensure the boost/performance modifier cannot apply twice.
