# Patch 0.8.89 — Development snapshot

This patch adds an isolated C# port of selected ECU Lab v1.11.0 engine-simulation equations to the existing CMS 2018 mod. It is a simulation sandbox port, not an ECU tuning interface. The port is not connected to CMS power or dyno hooks and therefore has no claimed in-game horsepower effect yet.

The package includes the existing source, assets, docs, the simulation reference test, and ECU Lab's original source/license for provenance. Review report.md before use. This build is not installed or live-tested; CMS was not launched.
