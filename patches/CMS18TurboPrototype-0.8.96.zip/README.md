# CMS 2018 Forced Induction Mod — Patch 0.8.96 candidate

This candidate disables the ECU Lab panel entry points while retaining its code. It adds readable diagnostics to the standalone turbo dependency model. The candidate is built and offline-validated but is not installed; CMS was not launched. Read `report.md` before testing.

**Do not treat the standalone dependency model as CMS installation support.**
