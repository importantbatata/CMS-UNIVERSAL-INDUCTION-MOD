# Patch 0.8.96 — ECU Lab disabled; turbo dependency diagnostics expanded

## Summary

This is an incremental continuation of the existing CMS 2018 forced-induction mod. It disables the ECU Lab panel while preserving the simulation and engine-identity source for possible later use. It also improves the existing standalone single-turbo dependency validator so an incomplete build has a concise first action to fix.

## Changes

- F9 no longer opens the ECU Lab panel. Additional guards prevent the panel open and draw methods from displaying it if another path sets its state.
- ECU Lab files and model code remain in the project; they were not deleted or rewritten.
- The stock CMS car-parts radial, the engine-stand forced-induction radial action, custom gearbox-tuning behavior, and current induction gameplay hooks were not intentionally changed.
- `ForcedInductionDependencyModel.Validation.FirstBlocker` now gives a user-readable first missing-component or missing-connection message.
- The dependency model is still offline-only. It is not wired to CMS part installation, inventory, boost activation, or saves.

## Verification

- C# plugin build: **PASS**, no compiler warnings.
- Existing isolated regression checks: **92 assertions PASS** (simulation 23, calibration schema 9, map evaluator 8, turbo sizing 14, charge-air 11, operating point 11, engine identity 7, dependency model 9).
- Static CMS assembly/resource/source validator: **PASS**. It identifies 0.8.94 as installed and 0.8.96 as a review build.
- In-game F9, stock radial/gearbox coexistence, installation, dyno, save/load, and live performance: **NOT RUN**.
- CMS was not launched and no game files or saves were modified.

## Build identity

- Plugin version: `0.8.96`
- SHA-256: `9BFDDA7D1467222A1AE0B78C99818B1462F9662FE10EFF961BB6AAC2E66FFF68`
- Installed baseline remains: `0.8.94` (rollback backup retained).

## Current limits and next work

The forced-induction expansion is not complete. Turbo hardware is still a virtual kit/model rather than a verified physical set of installable CMS parts. There is no complete turbo manifold/oil/downpipe/intercooler dependency chain, and the offline dependency schema is not connected to CMS installation. The next safe engineering milestone is verifying the native part-slot and save/transfer lifecycle before adding physical parts or gating power. Live confirmation is still required before treating ECU Lab disablement or preservation of the gearbox menu as verified in-game.

## Candidate use

This is a review candidate only. Do not install it over the existing game plugin until ready to test. If installing later, close CMS first and preserve the existing rollback copy.
