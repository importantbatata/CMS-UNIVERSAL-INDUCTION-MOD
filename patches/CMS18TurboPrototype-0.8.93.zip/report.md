# Patch 0.8.93 — first single-turbo dependency model

## Purpose

This is the first expansion increment after the radial-menu regression fix. It adds a mod-owned, standalone graph validator that describes the minimum parts and connections expected for a complete single-turbo installation. The graph is a prerequisite for a later verified CMS integration; it is not a CMS part registration or installation feature by itself.

## Existing project preserved

Patch 0.8.92 remains installed for the user's next live check. Its DLL backup is `build/installed-backups/CMS18TurboPrototype-20261106-070324.dll`. Patch 0.8.93 is packaged for review but was not installed, so the user can first confirm that stock gearbox tuning is restored without mixing expansion code into that test.

## Added

- `src/ForcedInductionDependencyModel.cs`: internal schema for required single-turbo hardware and route validation.
- `tools/test_forced_induction_dependencies.ps1`: standalone compiled harness covering incomplete/complete graph behavior, a missing oil-return part, a missing oil-return route, and duplicate valid edges.
- Build includes the model in the plugin assembly.

The schema requires 13 components and 15 directed routes spanning exhaust manifold/turbine/downpipe, filter/compressor/charge pipes/intercooler/throttle, turbo oil feed/return, wastegate/control, and blow-off valve/pressure reference. Names are model-owned keys, not claimed CMS part IDs.

## Verification

| Check | Result |
|---|---|
| C# plugin build | PASS — 0.8.93 |
| Dependency graph harness | PASS — 5 assertions |
| ECU Lab simulation subset | PASS — 23 assertions against v1.11.0 JavaScript references |
| Calibration schema | PASS — 9 assertions |
| Map evaluator | PASS — 8 assertions |
| Turbo size model | PASS — 14 assertions |
| Charge-air model | PASS — 11 assertions |
| Turbo operating-point model | PASS — 11 assertions |
| Offline project/assembly/resource validator | PASS; warns installed plugin is 0.8.92 and 0.8.93 has no startup log, as expected |
| CMS live install, radial-menu behavior, turbo assembly, boost gating, dyno, save/load | NOT RUN |

The integrated power-curve harness was not counted as a pass because CMS's native engine `ECall` cannot execute in the standalone test host. No CMS launch occurred.

## Limits and next expansion step

The validator currently has no caller in CMS gameplay. It neither creates parts nor blocks boost in an incomplete in-game build. The next work should verify whether the actual CMS mount/part/save structures can represent the first separate turbo component chain, then connect this model to that verified integration. Do not ship or enable the validator as a claim of functional physical installation until that integration and live test exist.

Other requested expansion areas remain partial or missing as recorded in `docs/EXPANSION-STATUS.md`: broad engine-specific compatibility, twin turbo/sequential/compound layouts, Roots and twin-screw systems, selectable intercoolers/wastegates/valves/pulleys, ECU map application, durability/failures, and versioned per-build persistence.

## File integrity

Built DLL SHA-256: `E5817C8D2A912730B4B4B09360EA42E6C9F8440710873B20CCAE4C67EE014E80`.

