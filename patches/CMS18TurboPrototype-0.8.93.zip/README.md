# CMS 2018 Forced Induction Mod — Patch 0.8.93

Patch 0.8.92 is the current game-installed build and restores the native **Tune parts** route. Patch 0.8.93 is a development package that begins the single-turbo expansion with an isolated dependency-graph validator. Install the new build only after the 0.8.92 gearbox-menu behavior has been checked; this package has not been installed or live-tested.

See `report.md` for exact scope, test results, limitations, and the next step. Source code and offline test scripts are included.
