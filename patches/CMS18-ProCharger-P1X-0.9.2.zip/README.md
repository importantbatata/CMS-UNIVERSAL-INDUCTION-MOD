# CMS 2018 ProCharger P-1X — patch 0.9.2

A focused BepInEx/Harmony add-on for Car Mechanic Simulator 2018. This release keeps the existing P-1X kit and retires the mod's turbocharger, Roots-supercharger, and ECU Lab features.

## Current game state

Patch 0.9.2 V7 was built and installed on 2026-11-12; the player confirmed that V7 appears and works in CMS. The current refinement keeps the 45-degree outlet clock, raises the compressor section 0.02 m at runtime, enlarges it 22%, and matches the custom timing case/pulley to the native CMS turbo material. The new geometry still needs a fresh in-game visual check. The pre-change checkpoint is `build/source-backups/pre-lift-scale-material-20261113-063718/`; the earlier clock/slim checkpoint is `build/source-backups/pre-outlet-clock-slim-drive-20261112-211308/`.

The previous P-1X model remains untouched at `model/CMS18_ProCharger_P1X_AddOn.obj` and in `build/source-backups/pre-1.0-full-visual-restart-20261111/`. The source checkpoint before this audit is `build/source-backups/pre-audit-0.9.2-20261112/`.

## Patch 0.9.2

### Selection, purchase, and removal repair (2026-11-13)

- The radial/menu selection no longer spawns a free P-1X preview. The chooser reports installed hardware, checks owned P-1X inventory, and only enables Apply for an owned kit. Apply opens CMS's native inventory selector for the engine mount; the normal CMS flow performs the installation.
- Installed P-1X labels use the standard or high-boost product name. The engine stand uses an invisible internal mount point so CMS has a valid target for fitting a purchased kit. It is not inventory and is not the blower; its empty-state hover label says `ProCharger Mount Point (kit not installed)` so it cannot be mistaken for fitted hardware.
- The empty mount is not selectable by default. The chooser checks actual CMS inventory and enables Apply only for an owned kit. Apply opens CMS's native item picker for the selected kit and mount; the kit still has to be chosen and fitted through CMS.
- Installed P-1X picking now uses a generated triangle MeshCollider on the CMS `PartScript` root, matching the game's verified direct-collider selection lookup. Previous root colliders are disabled while fitted and restored on removal; a tight renderer-bounds fallback is used only if the mesh cannot be built.
- Offline build, power-curve checks (20), charge-air checks (11), and assembly/source validation passed. Shop visibility, real mouse hit area, install/remove, and dyno remain **not verified in-game**; the screenshot's `Bad Request` is a Codex tool response and is not evidence of a CMS failure.

- V7 is built from the captured CMS `turbo_2` mesh. It retains compressor-side connected geometry, removes turbine/exhaust geometry, and uses existing P-1X timing-drive and pulley parts in the removed area. All separate inlet/charge tubing is omitted. The native `Turbocharger_2` material is cloned at runtime when available. The captured full mesh is at `model/reference/CMS18_turbo_2_native.obj`.
- Preserves the existing outlet-bore center, direction, part IDs, crank-drive center, install interaction, and runtime mount lifecycle so the visual rebuild does not change save identity or the working part hook.
- Smooths the generated mesh normals and reworks the variable-area scroll and machined compressor cover; six drive ribs, seven full and seven splitter inducer blades, seal/bead details, bolts, washers, and discharge flange are modeled separately.
- V7 is the first candidate built from the actual exported game mesh. It keeps 77 compressor-side connected islands (2,214 triangles) and 32 timing/drive objects. Its mesh source is `model/CMS18_ProCharger_P1X_v7.obj`.
- The current V7 refinement clocks only the compressor body 45° about its shaft axis, scales it 22% about the unchanged timing-case mating face, and raises it 0.02 m at the current 0.4 runtime scale. The custom timing-case radial profile is reduced to 80%, and the custom pulley radial profile and matching runtime belt radius are reduced to 90%. The gearcase and pulley use the native CMS `Turbocharger_2` material. Pulley center and axial/rib spacing stay fixed. The embedded-model bounds center is `(-0.133590, -0.014856, -0.025577)`.
- Applies CMS's own blue tuning-card tint to the ProCharger Tuning Shop row after the verified stock shop-card renderer runs. Stable part IDs stay unchanged.

## Patch 0.9.0 behavior retained

- Limits the mod's choices and custom shop registrations to standard and high-boost ProCharger P-1X kits.
- Keeps the existing engine-stand radial entry, shop integration, universal P-1X mount, boost display, and dyno hooks.
- Uses the P-1X-specific centrifugal speed curve and bounded pressure/power ratings already present in the project; it does not expose generic turbo size selection.
- Adds two runtime P-1X mounting fasteners through CMS's verified `MountObject` workflow. They use the game's bolt raycast layer and unscrew speed field; the fastener renderers stay visible during part removal.
- Adds a “No forced induction” chooser option and migrates saved non-ProCharger mode selections to Off. The stable plugin GUID and P-1X part IDs remain unchanged.
- Keeps legacy turbo/Roots identifiers only to safely recognize old saved custom parts. Those retired parts are not sold, selectable, or applied to performance. They are filtered out of the universal-mount selector.
- Removes ECU Lab from the active plugin source, build inputs, and runtime UI.
- Moves old turbo/Roots source, models, tests, and the pre-0.9 project snapshot into `build/source-backups/` for recovery.

## Parts

| Part | CMS shop | Price | Modeled limit |
|---|---|---:|---:|
| ProCharger P-1X | Main Shop | $12,500 | 20 PSI boost target |
| ProCharger P-1X High-Boost | Tuning Shop | $24,900 | 32 PSI boost target |

The plugin uses the stock `turbo_2` CMS prefab as its verified item/mount host and embeds the P-1X OBJ for the custom visual. P-1X values such as 65,000 rpm, 4.10:1 internal step-up ratio, 32 PSI, and 950 hp are component-model bounds; the in-game dyno model remains an estimate, not a manufacturer-map or full thermodynamic simulation.

## Build and offline review

From this project directory in Windows PowerShell:

```powershell
.\build.ps1
.\tools\test_charge_air_model.ps1
.\tools\test_power_curves.ps1
.\tools\validate_build.ps1
```

The build compiles against the local CMS/BepInEx assemblies and embeds V7. Offline checks cover the bounded charge-air/P-1X calculations and verified CMS method signatures. They do not prove V7 fit, native material response, or dyno behavior in a live game.

## Installation and rollback

Close CMS first, keep the old DLL backup, then copy `build/CMS18TurboPrototype.dll` to the game's `BepInEx/plugins/CMS18TurboPrototype.dll`. The OBJ is embedded in the DLL, so no extra runtime asset file is needed. Existing vehicle saves are not modified by the build process. Back up a save before testing old vehicles that contain retired custom turbo/Roots kit IDs.

To return to the previous V6 plugin, copy `build/installed-backups/CMS18TurboPrototype-20261112-210256.dll` into `BepInEx/plugins/CMS18TurboPrototype.dll` while CMS is closed. The earlier 0.9.0 build is also preserved in the dated installed backups.

## Status and limits

The pre-refinement V7 was confirmed by the player in-game. The refined DLL is built and installed; offline source/assembly validation, 17 ProCharger behavior checks, and 11 charge-air checks pass. The 45° clock, 22% compressor enlargement/lift, and unified finish need in-game visual confirmation. No dyno change is intended or claimed; the performance model is untouched. Dyno verification is the next step after visual acceptance, followed by engine-specific charge pipes for non-DLC engines.

Patch 0.9.2 remains intentionally ProCharger-only. Turbocharging, twin-turbo, Roots/twin-screw superchargers, ECU Lab, editable ECU maps, standalone engine durability/failure simulation, and component-by-component turbo plumbing are not part of this build. The requested full 1.0 polish still needs in-game visual review and likely another fitting/material iteration.
