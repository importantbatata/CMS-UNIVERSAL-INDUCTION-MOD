# 0.9.2 forensic audit and stabilization notes

## Project and runtime inventory

- Existing project: `work/installable_part_fix`; no Git repository or solution/project file exists. A dated source checkpoint is retained at `build/source-backups/pre-audit-0.9.2-20261112/`.
- Initial audit build inputs: `src/CMS18TurboPrototype.cs`, `src/ProchargerMath.cs`, `src/ChargeAirModel.cs`, and embedded V2 mesh. The current 0.9.2 visual candidate is V7, built from the captured native `turbo_2` compressor mesh plus existing timing-drive geometry. See `VISUAL-REDESIGN-0.9.2.md` for the current visual status.
- Build: `build.ps1`, Microsoft .NET Framework C# compiler at `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe`.
- Game runtime verified from Unity log: Unity 2017.4.24.7890793, Mono CLR 2.0.50727.1433, x64. Mod loader: BepInEx 5.4.23.5; HarmonyX/0Harmony.
- Runtime references verified by the build and Cecil validation include `Assembly-CSharp-firstpass.dll`, UnityEngine modules, BepInEx, and Harmony. The game assembly audit records signatures for torque, power, shop, inventory, engine stand, and mount/unmount methods.
- The repaired 0.9.2 plugin is installed. The verified 0.9.0 DLL remains preserved for rollback; the broken 0.9.2 DLL is separately backed up as `build/installed-backups/CMS18TurboPrototype-20261112-070604.dll`.

## 0.9.2 visual-candidate addendum (2026-11-12)

V5 remains the displayed interim OBJ. The latest installed diagnostic disables runtime-generated intake/charge tubes and requests the real `turbo_2` prefab hierarchy through `GameInventory.GetGO2` during the engine-stand preview. That diagnostic clone is only inspected and destroyed; it does not yet drive the displayed visual. No fresh run log has captured its renderer data. The V5 mesh remains embedded pending native-mesh separation. See `VISUAL-REDESIGN-0.9.2.md` for current state.

## Dyno recheck (2026-11-12)

Corrected `tools/inspect_dyno_assembly.ps1` to read `Assembly-CSharp-firstpass.dll`, which contains the verified gameplay types; the old default inspected the smaller `Assembly-CSharp.dll` and returned only an MVID. The corrected IL confirms `CarEngineHelper.DrawPowerTorqueChart` samples `CalculatePowerInKw` and `CalculateTorque` separately at 10 RPM points. Both hook paths use the same full-throttle induction torque delta, and a new offline unit-conversion check confirms their Nm/kW/hp/lb-ft outputs agree. Existing calculation checks pass. No current `Dyno chart draw` or `Dyno induction sample` lines are present in the available run log, so an in-game dyno graph has not been verified.

## Dependency path

CMS Unity/Mono → BepInEx chainloader → `TurboPrototypePlugin.Awake` → Harmony hooks → shop/radial/engine-stand detection → virtual induction mount and P-1X part selection → bounded P-1X calculation in `VehiclePhysics.Engine.CalculateTorque` / `CalculatePowerInKw` → dyno chart hooks → profile/group/car-keyed settings.

No active ECU map subsystem or ECU Lab code is included in the 0.9.2 build. ECU Lab source preserved under historical backups is not a runtime dependency.

## Defects and repairs

### 0.9.2-BOOT-001 — Mono-incompatible `System.Type` null comparison prevented plugin construction

- **Severity:** Critical.
- **Location:** `src/CMS18TurboPrototype.cs`, `TurboPrototypePlugin.Awake`, optional `UIManager/<CreateShop>c__IteratorD` hook check.
- **Symptom:** The plugin vanished from the game. BepInEx listed it as “Loading,” but no `Awake` logs or hooks followed.
- **Root cause:** Unity `GameObject.AddComponent(Type)` failed while instantiating the plugin with `MissingMethodException: Method not found: 'System.Type.op_Inequality'`. The newly added `if (shopCreatorType != null)` compiled to that missing operator, unsupported by this CMS 2018 Mono profile. This is directly confirmed by the preserved `Unity-output_log.txt` from the failed 0.9.2 run.
- **Repair:** Replaced the operator with `!System.Object.ReferenceEquals(shopCreatorType, null)`. Scanned the source; this was the only local `Type` value compared to null with `==`/`!=`. The guarded bootstrap logging remains to make any future startup failure diagnosable.
- **Verification:** Rebuild and offline runtime-compatibility assertion pass. A live 0.9.2 launch is still required to confirm BepInEx creates the plugin and all hooks initialize.
### 0.9.2-HOOK-001 — normal fallback hook lookup emitted a misleading Harmony warning

- **Severity:** Low.
- **Location:** `src/CMS18TurboPrototype.cs`, `CreateHarmonyMethod`.
- **Symptom:** The real 0.9.0 startup log says Harmony could not find `TurboPrototypeHooks.Cursor3DUpdatePrefix`, then the fallback successfully patches `TurboPrototypePlugin.Cursor3DUpdatePrefix`.
- **Root cause:** `AccessTools.Method` logs a warning on the expected miss before searching the plugin class.
- **Repair:** Uses quiet reflection for the two-step lookup; a real missing hook still throws and is logged at the patch boundary.
- **Verification:** Offline source assertion passes. Confirm disappearance of the warning in the next live log.

## Feature status for this patch

| Feature | Status | Evidence / limitation |
|---|---|---|
| BepInEx plugin and stable GUID | WORKING in 0.9.0; repaired 0.9.2 awaiting live verification | 0.9.0 live startup log confirms initialization; 0.9.2 needs a fresh log. |
| ProCharger P-1X shop products | WORKING in 0.9.0; repaired 0.9.2 awaiting live verification | Shop registration was logged in 0.9.0. |
| Engine-stand radial action and chooser | WORKING in 0.9.0; No forced induction awaits live verification | 0.9.2 chooser paths pass source regression checks, not live interaction. |
| P-1X placement/model V2 | PARTIALLY WORKING | OBJ interfaces/normals and resource embedding validated offline; final fit/material response is unverified in game. |
| Boost and dyno behavior | PARTIALLY WORKING | Game calculation targets are verified; bounded model checks pass; no 0.9.2 dyno comparison. |
| Native fasteners/unscrew flow | UNVERIFIED in 0.9.2 | Game APIs confirmed; this build has static checks only. |
| Save/load | PARTIALLY IMPLEMENTED | Mode/boost use profile/group/car keyed settings; complete versioned hardware/calibration persistence is absent. |
| Full turbo, twin-turbo, Roots/twin-screw | NOT IMPLEMENTED in this ProCharger-only patch | Retired modes migrate to Off; old part IDs are inert aliases. |
| ECU maps/automatic engine calibration | NOT IMPLEMENTED | ECU Lab and ECU tuning modules are absent from the live build. |
| Mechanical durability/damage and audio simulation | NOT IMPLEMENTED | Not part of the active P-1X build. |

## Build and tests

- `build.ps1` — passed; output `build/CMS18TurboPrototype.dll`.
- `tools/test_charge_air_model.ps1` — 11/11 checks passed (estimates only).
- `tools/test_power_curves.ps1` — 13/13 checks passed, including Off selection and hook fallback lookup.
- `tools/validate_build.ps1` — CMS API/resource assertions passed before adding the two new bootstrap/hook assertions; rerun after this audit update.
- The failed-run startup is reproduced by its preserved exception log. No post-fix in-game purchase, installation/removal, dyno, save/reload, or performance-profile test has yet been performed.

## Next verification

Use the updated 0.9.2 candidate, then save `BepInEx/LogOutput.log` and `AppData/LocalLow/Red Dot Games/Car Mechanic Simulator 2018/output_log.txt` before another build replaces them. Check the bootstrap-entry line, hook count/errors, Mods entry, radial option, chooser selections (Off and P-1X), shop rows, model fit, and unscrew behavior. Until that run, 0.9.2 remains experimental; the verified 0.9.0 DLL is retained for rollback.

## Selection and hit-target repair (2026-11-13)

- **0.9.2-UI-001 — radial selection could create a free P-1X preview.** `SetMode` and `EnsureVisual` now require a detected installed P-1X before exposing its visual. The chooser checks `Inventory.GetItem` for the standard/high-boost product; its Apply buttons are disabled without the corresponding owned item. Apply arms only the current engine's virtual mount and opens CMS's verified `GameScript.ShowSelectPartMount` inventory flow, setting the current mouse-over target to that mount. The inventory filter then shows only the kit selected in the mod UI. Product registration and the verified `PartScript.TunePart` installation path remain. Static checks/build pass; actual purchase/install still needs in-game confirmation.
- **0.9.2-PICK-001 — broad selection collider could select the assembly around the part.** Replaced renderer-bounds inflated box for an installed P-1X with a generated triangle `MeshCollider` attached to the actual `PartScript` root (verified CMS raycast expects `PartScript` on the hit collider GameObject). Existing root colliders are captured, disabled while the mod mesh collider is active, and restored on removal. Mesh generation has a tight 1.02 renderer-bounds fallback and logs its use. Compiles and source assertion passes; mouse hit accuracy/removal behavior require an in-game check.
- **Build/test evidence:** `build.ps1` succeeded; `test_power_curves.ps1` 18/18, `test_charge_air_model.ps1` 11/11, and `validate_build.ps1` passed all source/assembly checks. The rebuilt DLL was installed after backing up the previous plugin; installed and build SHA-256 both match `592523AC046F2463946C958CE48990CAAA658B51F2CD636554CE2355BBB9463A`. The validator itself does not perform installation. No live game, purchase, mount, selection, or dyno test was performed.
- **Rollback:** the pre-change source/model/DLL/docs copy is `build/source-backups/pre-selection-shop-hitbox-20261113-070430/`.

## Empty mount label correction (2026-11-13)

- **0.9.2-UI-002 — empty engine-stand attachment point appeared selectable and fitted.** `EnsureUniversalMountOnStand` creates an internal, invisible `PartScript` anchor because CMS needs an install target. Its collider is now disabled and CMS accessibility is denied until the player has a kit in inventory and presses Apply. The empty-state hover label reads `ProCharger Mount Point (kit not installed)`; the fitted part uses the standard/high-boost product name. The internal ID and save identity are unchanged.
- Verification pending in CMS: place an engine on the stand and confirm the anchor cannot be selected; verify Apply is disabled without inventory; buy a kit, press Apply, confirm CMS opens the native list, install, and verify the installed name.

## Inventory-gated stand mount and explicit Apply flow (2026-11-13)

- **0.9.2-UI-003 — the virtual mount was ray-selectable immediately after placing an engine on the stand.** The engine-stand initializer was creating an active collider and marking the placeholder mount unmountable. It now disables the placeholder collider and denies CMS `IsPartAccessible` for the virtual mount until the player opens the mod UI and applies a kit that `Inventory.GetItem` confirms is owned.
- Apply sets the active engine mount as CMS's mouse-over target and calls the verified `GameScript.ShowSelectPartMount(string)` with the virtual mount ID. The existing CMS inventory list is used to choose and install the part; the list is filtered to the exact standard or high-boost kit selected in the mod UI. After installation, the P-1X uses the mesh hitbox; after removal, the mount is locked again and must be applied again.
- The actual APIs were checked in `Assembly-CSharp-firstpass.dll`: `Inventory.GetItem(string)`, `GameScript.SetPartMouseOver(PartScript)`, and `GameScript.ShowSelectPartMount(string)`. An initial compile attempt exposed an unsupported `GameInventory.Get()` assumption; it was removed. Final build succeeds.
- **Offline verification:** `test_power_curves.ps1` 20/20, `test_charge_air_model.ps1` 11/11, and `validate_build.ps1` passed, including the three integration signatures. In-game mount lock, inventory gating, Apply handoff, install/removal, and dyno remain NOT RUN.
