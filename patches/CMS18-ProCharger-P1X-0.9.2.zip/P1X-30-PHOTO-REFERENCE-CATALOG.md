# P-1X visual reference catalog (30 photographs)

This 41-photo set informed the 0.9.2 P-1X mesh revamp. It combines isolated head-unit photographs, owner-submitted alternate angles, and a documented installation sequence: isolated views guide the scroll, gearcase, inlet, impeller, and finish; installed views guide bracket, pulley, hose, intercooler, and engine-bay scale. Not every image is a studio angle of the bare unit; the catalog distinguishes standalone and installation-context references. The external pages retain their original copyright and credits; this catalog links to the originals and does not redistribute downloaded copies.

## Isolated or near-isolated head-unit references

1. [P-1X satin head unit, front three-quarter view](https://treperformance.com/images/F143859518.jpg) — [product page](https://treperformance.com/i-23899973-ati-p-1x-procharger-supercharger-head-unit-only.html)
2. [P-1X black finish with exposed inlet wheel](https://moorethrottle.com/cdn/shop/files/IMG_2358.jpg?v=1687019420&width=1946) — [listing](https://moorethrottle.com/products/p1x-procharger-reverse-rotation-w-helical-gearset-black)
3. [P-1X head-unit product photograph](https://cdn11.bigcommerce.com/s-rhkj47blc7/images/stencil/1280x1280/products/16997/31845/procharger_headunit__34998.1669668906.jpg?c=2) — [listing](https://highhorseperformance.com/procharger-pc053a-040-p-1x-supercharger-head-unit/)
4. [P-1X silver/black head units, comparative view](https://www.procharger.com/wp/content/uploads/2021/08/p1x_d1x_p-1x_d-1x_procharger_supercharger_head_units_main.jpg) — [official release](https://www.procharger.com/blog/now-shipping-p-1x-and-d-1x-head-units-results/)
5. [P-1X installed in a yellow engine bay, head unit and discharge clocking](https://www.procharger.com/wp/content/smush-webp/2021/09/ProCharger-P1X-yellow-uh.jpeg.webp) — [official specifications](https://www.procharger.com/p-1x-d-1x-upgrade/)
6. [P-1X standalone used head unit, inlet-side view](https://www.mustang6g.com/forums/attachments/20230516_113004-jpg.757804/) — [classified source](https://www.mustang6g.com/forums/threads/procharger-p1x-head-unit.188545/)

## P-1X sales and in-bay reference photos

These owner-submitted references include close-ups and additional engine-bay perspectives of real P-1X systems. The individual angles are useful for checking the gearcase/pulley relationship and how the outlet is clocked relative to the belt and bracket.

7. [P-1X housing and blue serial plate close-up](https://www.mustang6g.com/forums/attachments/20211215_143825-webp.637908/) — [source thread](https://www.mustang6g.com/forums/threads/2018-procharger-p1x-h-o-kit.168307/)
8. [P-1X kit photo, first alternate angle](https://cdn.mustang6g.com/attachments/612/612494-2dda59edcd28c25dd2bc03fe1295baee.jpg)
9. [P-1X kit photo, second alternate angle](https://cdn.mustang6g.com/attachments/612/612495-c59a460dd09e6aea1b3e22289617da6f.jpg)
10. [P-1X kit photo, third alternate angle](https://cdn.mustang6g.com/attachments/612/612496-d276499749f4b46724c229e480bb3044.jpg)
11. [P-1X kit photo, fourth alternate angle](https://cdn.mustang6g.com/attachments/612/612497-bf5de7d712cac2176367008182b878df.webp)
12. [P-1X kit update, fifth view](https://cdn.mustang6g.com/attachments/616/616990-f79655dc8723a438f2d018ebae9e6b68.jpg)
13. [P-1X kit update, sixth view](https://cdn.mustang6g.com/attachments/616/616991-953f42faae0cdb412bbe41cf2f81b6c0.webp)
14. [P-1X kit update, seventh view](https://cdn.mustang6g.com/attachments/616/616992-29877fbfa48e69c9dae2d667bc99521c.jpg)
15. [P-1X kit update, eighth view](https://cdn.mustang6g.com/attachments/616/616993-299b2d9e42caf04851ae8215a14835a3.webp)
16. [P-1X kit update, ninth view](https://cdn.mustang6g.com/attachments/616/616994-34666510f1f7cbfbb46a8bcf26bb3c39.webp)

## P-1X kit installation photo sequence (26 distinct photos)

The following are distinct frames from HOT ROD’s 2018 Mustang P-1X installation report. Early photos show kit components and clearances; mid-sequence photos show compressor mounting, belt drive, valves, and tubing; later frames document completed calibration/dyno context.

17. [Kit overview and head unit](https://hips.hearstapps.com/mtg-prod/65de052aa12952000844765e/002-2018-mustang-gt-procharger-kit.jpg?format=webp&q=75&w=768&width=768)
18. [Intercooler alternatives / kit components](https://hips.hearstapps.com/mtg-prod/65de052a15ade60008d14414/003-2018-mustang-gt-procharger-intercoolers.jpg?format=webp&q=75&w=768&width=768)
19. [Factory intake removal context](https://hips.hearstapps.com/mtg-prod/65de052ab201f60008727c8e/004-2018-mustang-gt-intake-tube.jpg?format=webp&q=75&w=768&width=768)
20. [Front fascia clearance](https://hips.hearstapps.com/mtg-prod/65de052ab8ed2c0008f14cce/005-2018-mustang-gt-facia-removal.jpg?format=webp&q=75&w=768&width=768)
21. [Coolant drain before mounting work](https://hips.hearstapps.com/mtg-prod/65de052ba12952000844765f/006-2018-mustang-gt-coolant-drain.jpg?format=webp&q=75&w=768&width=768)
22. [Thermostat-housing clearance detail](https://hips.hearstapps.com/mtg-prod/65de052a40658c000894392a/007-2018-mustang-gt-procharger-thermostat-housing.jpg?format=webp&q=75&w=768&width=768)
23. [Radiator bracket installation](https://hips.hearstapps.com/mtg-prod/65de052a729101000895567b/008-2018-mustang-gt-procharger-radiator-bracket.jpg?format=webp&q=75&w=768&width=768)
24. [MAF and intercooler tank routing](https://hips.hearstapps.com/mtg-prod/65de052a729101000895567c/009-2018-mustang-gt-procharger-maf-sensor-intercooler.jpg?format=webp&q=75&w=768&width=768)
25. [Intercooler fitting behind fascia](https://hips.hearstapps.com/mtg-prod/65de052ab8ed2c0008f14ccd/010-2018-mustang-gt-procharger-intercooler.jpg?format=webp&q=75&w=768&width=768)
26. [Intercooler position, alternate view](https://hips.hearstapps.com/mtg-prod/65de052ab201f60008727c8d/011-2018-mustang-gt-procharger-intercooler.jpg?format=webp&q=75&w=768&width=768)
27. [Crank pulley drive interface](https://hips.hearstapps.com/mtg-prod/65de052a40658c000894392b/012-2018-mustang-gt-procharger-crankshaft-pulley.jpg?format=webp&q=75&w=768&width=768)
28. [Auxiliary idler pulley](https://hips.hearstapps.com/mtg-prod/65de059215ade60008d14422/013-2018-mustang-gt-procharger-idler-pulley.jpg?format=webp&q=75&w=768&width=768)
29. [Head-unit bracket spacers and standoffs](https://hips.hearstapps.com/mtg-prod/65de0ab1f419d3000967aa40/014-2018-mustang-gt-procharger-bracket-standoff.jpg?format=webp&q=75&w=768&width=768)
30. [P-1X head unit mounted at the front of the engine](https://hips.hearstapps.com/mtg-prod/65de0ab1ffd5fb00084e0201/015-2018-mustang-gt-procharger-p1x-blower.jpg?format=webp&q=75&w=768&width=768)
31. [Dedicated belt installation](https://hips.hearstapps.com/mtg-prod/65de0ab10a15f8000807451a/016-2018-mustang-gt-procharger-belt-installation.jpg?format=webp&q=75&w=768&width=768)
32. [Belt tensioner adjustment](https://hips.hearstapps.com/mtg-prod/65de0ab140658c00089439c3/017-2018-mustang-gt-procharger-belt-tension.jpg?format=webp&q=75&w=768&width=768)
33. [Surge valve and associated pipework](https://hips.hearstapps.com/mtg-prod/65de0ab115ade60008d144b1/018-2018-mustang-gt-procharger-surge-valve.jpg?format=webp&q=75&w=768&width=768)
34. [Cold-air inlet routing](https://hips.hearstapps.com/mtg-prod/65de0ab1f419d3000967aa44/019-2018-mustang-gt-procharger-cold-air-intake.jpg?format=webp&q=75&w=768&width=768)
35. [Discharge tube bend and connection](https://hips.hearstapps.com/mtg-prod/65de0ab1f419d3000967aa41/020-2018-mustang-gt-procharger-discharge-tubing.jpg?format=webp&q=75&w=768&width=768)
36. [Coolant reservoir clearance](https://hips.hearstapps.com/mtg-prod/65de0ab115ade60008d144af/021-2018-mustang-gt-procharger-coolant-reservoir.jpg?format=webp&q=75&w=768&width=768)
37. [Fuel pump booster placement](https://hips.hearstapps.com/mtg-prod/65de0ab1ffd5fb00084e0200/022-2018-mustang-gt-procharger-fuel-pump-booster.jpg?format=webp&q=75&w=768&width=768)
38. [Fuel-pump booster wiring](https://hips.hearstapps.com/mtg-prod/65de0ab1f419d3000967aa43/023-2018-mustang-gt-procharger-fuel-pump-booster-wiring.jpg?format=webp&q=75&w=768&width=768)
39. [Boost switch and reference line](https://hips.hearstapps.com/mtg-prod/65de0ab115ade60008d144b0/024-2018-mustang-gt-procharger-boost-fuel-pump-switch.jpg?format=webp&q=75&w=768&width=768)
40. [Completed underhood assembly / brace context](https://hips.hearstapps.com/mtg-prod/65de0ab1f419d3000967aa42/025-2018-mustang-gt-procharger-strut-tower-brace.jpg?format=webp&q=75&w=768&width=768)
41. [Calibration process](https://hips.hearstapps.com/mtg-prod/65de0ab140658c00089439c4/026-2018-mustang-gt-procharger-tune.jpg?format=webp&q=75&w=768&width=768)

## Geometry and material constraints extracted from the sources

- The P-1X is a centrifugal compressor head unit with a cast volute and a separate self-contained gearcase; its driven pulley is on the gearcase, not a turbine-like exhaust housing.
- Official P-1X specifications give a 9-inch volute, 3.75-inch compressor inlet, 3-inch outlet (2.62-inch outlet I.D.), 3.57-inch inducer, 5.56-inch exducer, 4.10:1 step-up, and 65,000 rpm maximum impeller speed. Those dimensions define relative proportions; exact subfeatures not dimensioned by the manufacturer remain artistic interpretation.
- Installation photos show that the head unit sits on a dedicated front accessory bracket, with a separate belt path and routed discharge tubing. Kit photos are context references rather than part of the standalone blower mesh.
- Manufacturer pages show satin, polished, and black finishes; the mod uses its existing game-compatible metallic material response, while the mesh gets more controlled machined/cast surface breaks and restrained hardware.

Source pages: [official P-1X specifications](https://www.procharger.com/p-1x-d-1x-upgrade/), [official head-unit release](https://www.procharger.com/blog/now-shipping-p-1x-and-d-1x-head-units-results/), [official installation manual](https://downloads.procharger.com/uploads/manuals/FORD-AUTO/PMFW1A-009_Q_2018_GT_STG%202.pdf), [HOT ROD installation story](https://www.hotrod.com/how-to/procharger-adds-276-wheel-horsepower-2018-mustang), [TRE P-1X head-unit listing](https://treperformance.com/i-23899973-ati-p-1x-procharger-supercharger-head-unit-only.html).
