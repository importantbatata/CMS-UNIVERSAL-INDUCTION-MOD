# ProCharger visual redesign — 0.9.1 candidate

## Preservation

Before authoring the replacement, the existing 0.9 asset and plugin sources were checkpointed in `build/source-backups/pre-1.0-full-visual-restart-20261111/`. The original live model file `model/CMS18_ProCharger_P1X_AddOn.obj` was not overwritten. The candidate is a separate embedded resource, `model/CMS18_ProCharger_P1X_v2.obj`.

## Changes

- Added `tools/generate_p1x_v2.js` as the reproducible parametric OBJ authoring source.
- Rebuilt the P-1X silhouette and major subassemblies: rounded gearcase, scroll shell, machined compressor cover, full and splitter inducer blades, inlet neck and bead, ribbed drive pulley, mount ears, fasteners, and tangential outlet.
- Retained the established outlet-bore and bead object identifiers. Their measured common center remains `(0.0203, 0.2817, 0.2310)` and the drive-pulley center remains `(-0.405, 0, -0.095)`, preserving the runtime tubing and belt interface.
- Updated the model-bounds center used by the virtual mount placement calculation to match V2's measured bounds center `(-0.139, 0.050281, 0.00569)`.
- Added smooth OBJ vertex normals and removed degenerate geometry. Current static inventory: 15,416 vertices, 15,416 normals, 30,568 triangles, 71 named meshes, zero degenerate triangles.
- Increased generated charge-pipe and inlet-hose surface resolution, added silicone couplers and paired clamps, and added clamp screw details. Aluminum tubing uses the same loaded `Machined_aluminum` material as the P-1X body.
- Added a narrowly targeted post-hook on the inspected CMS shop-card coroutine. It applies `GlobalData.ITEM_TUNING` to the ProCharger high-boost card's `OptimizedBG` image while keeping the part ID unchanged.

## Verified offline

- `build.ps1` compiles the candidate DLL and embeds `CMS18_ProCharger_P1X_v2.obj`.
- `test_charge_air_model.ps1`: passed 11 checks.
- `test_power_curves.ps1`: passed 11 checks.
- `validate_build.ps1`: passed 24 checks, including verified CMS method signatures, the shop-card coroutine target, and V2 asset resource presence.
- The card tint rule was confirmed in `Assembly-CSharp-firstpass.dll`: `UIManager/<CreateShop>c__IteratorD.MoveNext` assigns `ITEM_TUNING` only to IDs beginning `t_`, otherwise `ITEM_NORMAL`. The candidate preserves its ID and uses a targeted color hook after stock rendering.
- The OBJ was parsed and its interface point means, normals, face indices, bounds, materials, and degeneracy count were checked offline.

## Not verified

CMS was not launched. The candidate's installed alignment, in-game specular response, hose routing/clearance, card tint, and normal disassembly interaction are not verified in gameplay. The existing installed DLL is a different hash from the candidate and was left untouched. Do not treat this as a final 1.0 model until those in-game checks and at least one fitting iteration are complete.

## Rollback

To return to the exact previous 0.9.0 behavior, restore `build/installed-backups/CMS18TurboPrototype-before-0.9.1-visual-20261111.dll` to the game plugin folder while CMS is closed. Its SHA-256 was verified against the active game DLL. The 0.9.0 release ZIP also remains available. To rebuild that source version, restore `src/CMS18TurboPrototype.cs` and `model/CMS18_ProCharger_P1X_AddOn.obj` from `build/source-backups/pre-1.0-full-visual-restart-20261111/` and select the old OBJ resource name in `build.ps1`.
